using UnityEngine;

public class BridgeActivator : MonoBehaviour
{
    [SerializeField] private GameObject bridgeObject;

    public void ActivateBridge()
    {
        GameObject target = bridgeObject == null ? gameObject : bridgeObject;
        target.SetActive(true);
    }
}
