using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Collider2D))]
[RequireComponent(typeof(SpriteRenderer))]
public class CollapsingFalseBrick : MonoBehaviour
{
    [SerializeField] private float collapseDelay = 0.2f;
    [SerializeField] private float respawnDelay = 1.5f;

    private Collider2D brickCollider;
    private SpriteRenderer spriteRenderer;
    private Coroutine collapseRoutine;

    private void Awake()
    {
        brickCollider = GetComponent<Collider2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        TryCollapse(collision.collider, collision.GetContact(0).point.y);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.contactCount == 0)
        {
            return;
        }

        TryCollapse(collision.collider, collision.GetContact(0).point.y);
    }

    private void TryCollapse(Collider2D other, float contactY)
    {
        if (collapseRoutine != null)
        {
            return;
        }

        PlayerController player = other.GetComponent<PlayerController>();
        if (player == null)
        {
            return;
        }

        if (player.transform.position.y < transform.position.y)
        {
            return;
        }

        collapseRoutine = StartCoroutine(CollapseRoutine());
    }

    private IEnumerator CollapseRoutine()
    {
        yield return new WaitForSeconds(collapseDelay);

        brickCollider.enabled = false;
        spriteRenderer.enabled = false;

        yield return new WaitForSeconds(respawnDelay);

        brickCollider.enabled = true;
        spriteRenderer.enabled = true;
        collapseRoutine = null;
    }
}
