using UnityEngine;

public class BridgeSlot : MonoBehaviour
{
    [SerializeField] private bool restrictBlockType;
    [SerializeField] private BlockType acceptedBlockType;

    private DraggableBridgeBlock currentBlock;

    public bool IsOccupied => currentBlock != null;
    public Vector3 SnapPosition => transform.position;

    public bool CanAccept(DraggableBridgeBlock block)
    {
        if (block == null)
        {
            return false;
        }

        if (currentBlock != null && currentBlock != block)
        {
            return false;
        }

        return !restrictBlockType || block.BlockType == acceptedBlockType;
    }

    public void AssignBlock(DraggableBridgeBlock block)
    {
        currentBlock = block;
    }

    public void ClearBlock(DraggableBridgeBlock block)
    {
        if (currentBlock == block)
        {
            currentBlock = null;
        }
    }
}
