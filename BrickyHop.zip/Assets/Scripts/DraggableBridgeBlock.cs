using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class DraggableBridgeBlock : MonoBehaviour
{
    [SerializeField] private BlockType blockType;
    [SerializeField] private float snapRadius = 1.5f;
    [SerializeField] private bool allowFreePlacement = true;
    [SerializeField] private bool detachFromParentOnFirstDrag = true;

    private Rigidbody2D rb;
    private Camera mainCamera;
    private BridgeSlot currentSlot;
    private Vector3 homePosition;
    private Vector3 dragOffset;
    private bool isDragging;
    private RigidbodyType2D defaultBodyType;
    private bool draggingEnabled = true;
    private Vector3 dragStartPosition;
    private bool hasDetachedFromParent;
    private Transform initialParent;
    private Vector3 initialLocalPosition;

    public event System.Action<DraggableBridgeBlock> BlockMoved;

    public BlockType BlockType => blockType;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        initialParent = transform.parent;
        initialLocalPosition = transform.localPosition;
        if (rb != null)
        {
            defaultBodyType = rb.bodyType;
        }
    }

    private void Start()
    {
        mainCamera = Camera.main;
        homePosition = transform.position;
    }

    private void LateUpdate()
    {
        if (hasDetachedFromParent || initialParent == null)
        {
            return;
        }

        if (transform.parent != initialParent)
        {
            transform.SetParent(initialParent, false);
        }

        transform.localPosition = initialLocalPosition;
    }

    private void OnMouseDown()
    {
        if (!enabled || !draggingEnabled)
        {
            return;
        }

        mainCamera ??= Camera.main;
        if (mainCamera == null)
        {
            return;
        }

        isDragging = true;
        DetachFromParentIfNeeded();
        dragStartPosition = transform.position;
        dragOffset = transform.position - GetMouseWorldPosition();
        ReleaseCurrentSlot();

        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.bodyType = RigidbodyType2D.Kinematic;
        }
    }

    private void OnMouseDrag()
    {
        if (!isDragging)
        {
            return;
        }

        Vector3 targetPosition = GetMouseWorldPosition() + dragOffset;
        targetPosition.z = transform.position.z;
        transform.position = targetPosition;
    }

    private void OnMouseUp()
    {
        if (!isDragging)
        {
            return;
        }

        isDragging = false;

        BridgeSlot targetSlot = FindNearestValidSlot();
        if (targetSlot != null)
        {
            SnapToSlot(targetSlot);
        }
        else if (allowFreePlacement)
        {
            PlaceFreely();
        }
        else
        {
            ReturnHome();
            
            if (rb != null)
            {
                rb.linearVelocity = Vector2.zero;
            }
        }

        if (Vector3.Distance(transform.position, dragStartPosition) > 0.05f)
        {
            BlockMoved?.Invoke(this);
        }
    }

    private void PlaceFreely()
    {
        homePosition = transform.position;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.linearVelocity = Vector2.zero;
        }
    }

    private Vector3 GetMouseWorldPosition()
    {
        Vector3 screenPoint = Input.mousePosition;
        screenPoint.z = Mathf.Abs(mainCamera.transform.position.z - transform.position.z);
        return mainCamera.ScreenToWorldPoint(screenPoint);
    }

    private BridgeSlot FindNearestValidSlot()
    {
        BridgeSlot[] slots = FindObjectsByType<BridgeSlot>(FindObjectsSortMode.None);
        BridgeSlot nearestSlot = null;
        float nearestDistance = snapRadius;

        foreach (BridgeSlot slot in slots)
        {
            if (!slot.CanAccept(this))
            {
                continue;
            }

            float distance = Vector2.Distance(transform.position, slot.SnapPosition);
            if (distance > nearestDistance)
            {
                continue;
            }

            nearestDistance = distance;
            nearestSlot = slot;
        }

        return nearestSlot;
    }

    private void SnapToSlot(BridgeSlot slot)
    {
        currentSlot = slot;
        currentSlot.AssignBlock(this);
        transform.position = slot.SnapPosition;
        homePosition = transform.position;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
        }
    }

    private void ReleaseCurrentSlot()
    {
        if (currentSlot == null)
        {
            return;
        }

        currentSlot.ClearBlock(this);
        currentSlot = null;
    }

    private void ReturnHome()
    {
        transform.position = homePosition;

        if (rb != null)
        {
            rb.bodyType = defaultBodyType;
        }
    }

    public void SetDraggingEnabled(bool enabled)
    {
        draggingEnabled = enabled;
        isDragging = false;

        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            if (!enabled)
            {
                rb.bodyType = RigidbodyType2D.Kinematic;
            }
        }
    }

    private void DetachFromParentIfNeeded()
    {
        if (!detachFromParentOnFirstDrag || hasDetachedFromParent || transform.parent == null)
        {
            return;
        }

        transform.SetParent(null, true);
        hasDetachedFromParent = true;
        homePosition = transform.position;
    }
}
