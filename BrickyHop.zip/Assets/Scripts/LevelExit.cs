using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

[RequireComponent(typeof(Collider2D))]
public class LevelExit : MonoBehaviour
{
    [SerializeField] private GameUI gameUI;
    [SerializeField] private string clearMessage = "Level 1 Clear";
    [SerializeField] private float topClearTolerance = 0.2f;
    [SerializeField] private bool pauseOnClear = true;
    [SerializeField] private bool loadNextSceneOnClear;
    [SerializeField] private string nextSceneName;
    [SerializeField] private float loadDelay = 1.5f;

    private bool hasTriggered;
    private Collider2D exitCollider;

    private void Reset()
    {
        Collider2D triggerCollider = GetComponent<Collider2D>();
        triggerCollider.isTrigger = true;
    }

    private void Awake()
    {
        exitCollider = GetComponent<Collider2D>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        TryHandleLevelClear(other.GetComponent<PlayerController>());
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        TryHandleLevelClear(collision.collider.GetComponent<PlayerController>());
    }

    private void TryHandleLevelClear(PlayerController player)
    {
        if (hasTriggered || player == null || !IsPlayerOnTop(player))
        {
            return;
        }

        hasTriggered = true;

        if (gameUI != null)
        {
            gameUI.ShowPersistentStatus(clearMessage, Color.green);
        }

        if (pauseOnClear && !loadNextSceneOnClear)
        {
            Time.timeScale = 0f;
            return;
        }

        if (loadNextSceneOnClear)
        {
            StartCoroutine(LoadNextSceneRoutine());
        }
    }

    private IEnumerator LoadNextSceneRoutine()
    {
        Time.timeScale = 1f;
        yield return new WaitForSecondsRealtime(loadDelay);

        if (!string.IsNullOrWhiteSpace(nextSceneName))
        {
            SceneManager.LoadScene(nextSceneName);
            yield break;
        }

        int nextBuildIndex = SceneManager.GetActiveScene().buildIndex + 1;
        if (nextBuildIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextBuildIndex);
        }
    }

    private bool IsPlayerOnTop(PlayerController player)
    {
        if (exitCollider == null)
        {
            return false;
        }

        Collider2D playerCollider = player.GetComponent<Collider2D>();
        if (playerCollider == null)
        {
            return false;
        }

        Bounds exitBounds = exitCollider.bounds;
        Bounds playerBounds = playerCollider.bounds;

        bool withinHorizontalBounds =
            playerBounds.center.x >= exitBounds.min.x &&
            playerBounds.center.x <= exitBounds.max.x;

        bool feetNearTop = playerBounds.min.y >= exitBounds.max.y - topClearTolerance;

        return withinHorizontalBounds && feetNearTop;
    }
}
