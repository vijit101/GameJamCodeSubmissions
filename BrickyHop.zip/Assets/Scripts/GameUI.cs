using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameUI : MonoBehaviour
{
    [SerializeField] private PlayerInventory playerInventory;
    [SerializeField] private TMP_Text inventoryText;
    [SerializeField] private TMP_Text recipeText;
    [SerializeField] private TMP_Text resultText;
    [SerializeField] private float messageDuration = 1.5f;
    [SerializeField] private string startMessage = "Level 1 Start";
    [SerializeField] private float startMessageDuration = 1.5f;
    [SerializeField] private Color bannerBackgroundColor = new Color(0f, 0f, 0f, 0.7f);
    [SerializeField] private bool useSceneNameForStartMessage = true;

    private Coroutine messageRoutine;
    private Image resultBackground;
    private bool bannerInitialized;

    private void Start()
    {
        Time.timeScale = 1f;

        if (playerInventory != null)
        {
            playerInventory.InventoryChanged += UpdateInventory;
            UpdateInventory(playerInventory.CollectedBlocks);
        }

        InitializeBannerIfNeeded();
        HideHudText();

        if (resultText != null)
        {
            resultText.text = string.Empty;
        }

        SetBannerVisible(false);
        ShowSceneStartMessage();
        SceneManager.sceneLoaded += HandleSceneLoaded;
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= HandleSceneLoaded;

        if (playerInventory != null)
        {
            playerInventory.InventoryChanged -= UpdateInventory;
        }
    }

    public void SetRecipe(BlockType a, BlockType b)
    {
        if (recipeText != null)
        {
            recipeText.text = $"Recipe: {a} + {b}";
        }
    }

    public void ShowCompileResult(bool success, string message)
    {
        ShowStatus(message, messageDuration, success ? Color.green : Color.red);
    }

    public void ShowStatus(string message)
    {
        ShowStatus(message, messageDuration);
    }

    public void ShowStatus(string message, float duration, Color? color = null)
    {
        if (resultText == null)
        {
            return;
        }

        if (messageRoutine != null)
        {
            StopCoroutine(messageRoutine);
        }

        messageRoutine = StartCoroutine(ShowMessageRoutine(message, duration, color));
    }

    public void ShowPersistentStatus(string message, Color? color = null)
    {
        if (resultText == null)
        {
            return;
        }

        if (messageRoutine != null)
        {
            StopCoroutine(messageRoutine);
            messageRoutine = null;
        }

        if (color.HasValue)
        {
            resultText.color = color.Value;
        }

        resultText.text = message;
        SetBannerVisible(true);
    }

    public float GetMessageDuration()
    {
        return messageDuration;
    }

    public void SetStartMessage(string message, bool showImmediately = true)
    {
        startMessage = message;
        if (showImmediately)
        {
            ShowSceneStartMessage();
        }
    }

    private void UpdateInventory(IReadOnlyList<BlockType> blocks)
    {
        if (inventoryText == null)
        {
            return;
        }

        if (blocks.Count == 0)
        {
            inventoryText.text = "Inventory: Empty";
            return;
        }

        inventoryText.text = $"Inventory: {string.Join(", ", blocks)}";
    }

    private IEnumerator ShowMessageRoutine(string message, float duration, Color? color)
    {
        if (color.HasValue)
        {
            resultText.color = color.Value;
        }
        else
        {
            resultText.color = Color.white;
        }

        resultText.text = message;
        SetBannerVisible(true);
        yield return new WaitForSecondsRealtime(duration);
        resultText.text = string.Empty;
        SetBannerVisible(false);
        messageRoutine = null;
    }

    private void SetupResultBanner()
    {
        if (resultText == null)
        {
            return;
        }

        RectTransform resultRect = resultText.rectTransform;
        resultRect.anchorMin = new Vector2(0.5f, 1f);
        resultRect.anchorMax = new Vector2(0.5f, 1f);
        resultRect.pivot = new Vector2(0.5f, 0.5f);
        resultRect.anchoredPosition = new Vector2(0f, -80f);
        resultRect.sizeDelta = new Vector2(700f, 120f);

        resultText.alignment = TextAlignmentOptions.Center;
        resultText.textWrappingMode = TextWrappingModes.NoWrap;
        resultText.fontSize = Mathf.Max(resultText.fontSize, 42f);
        resultText.color = Color.white;

        Transform parent = resultText.transform.parent;
        Transform existingBackground = parent.Find("ResultBannerBackground");
        if (existingBackground != null)
        {
            resultBackground = existingBackground.GetComponent<Image>();
        }

        if (resultBackground == null)
        {
            GameObject backgroundObject = new GameObject("ResultBannerBackground", typeof(RectTransform), typeof(Image));
            backgroundObject.transform.SetParent(parent, false);
            backgroundObject.transform.SetSiblingIndex(resultText.transform.GetSiblingIndex());
            resultBackground = backgroundObject.GetComponent<Image>();
        }

        RectTransform backgroundRect = resultBackground.rectTransform;
        backgroundRect.anchorMin = resultRect.anchorMin;
        backgroundRect.anchorMax = resultRect.anchorMax;
        backgroundRect.pivot = resultRect.pivot;
        backgroundRect.anchoredPosition = resultRect.anchoredPosition;
        backgroundRect.sizeDelta = resultRect.sizeDelta + new Vector2(40f, 30f);
        resultBackground.color = bannerBackgroundColor;
        resultText.transform.SetAsLastSibling();
    }

    private void InitializeBannerIfNeeded()
    {
        if (bannerInitialized)
        {
            return;
        }

        SetupResultBanner();
        bannerInitialized = true;
    }

    private void HideHudText()
    {
        HideLabel(inventoryText);
        HideLabel(recipeText);
    }

    private void HideLabel(TMP_Text textComponent)
    {
        if (textComponent == null)
        {
            return;
        }

        textComponent.text = string.Empty;
        textComponent.enabled = false;
    }

    private void SetBannerVisible(bool visible)
    {
        if (resultBackground != null)
        {
            resultBackground.enabled = visible;
        }

        if (resultText != null)
        {
            resultText.enabled = visible;
        }
    }

    private void HandleSceneLoaded(Scene scene, LoadSceneMode loadSceneMode)
    {
        Time.timeScale = 1f;
        InitializeBannerIfNeeded();
        SetBannerVisible(false);
        ShowSceneStartMessage();
    }

    private void ShowSceneStartMessage()
    {
        string messageToShow = startMessage;
        if (useSceneNameForStartMessage)
        {
            messageToShow = $"{SceneManager.GetActiveScene().name} Start";
        }

        if (!string.IsNullOrWhiteSpace(messageToShow))
        {
            ShowStatus(messageToShow, startMessageDuration);
        }
    }
}
