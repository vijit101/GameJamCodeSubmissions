using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class CollectibleBlock : MonoBehaviour
{
    [SerializeField] private bool allowCollection;
    [SerializeField] private BlockType blockType;
    [SerializeField] private GameUI gameUI;

    private void Reset()
    {
        Collider2D triggerCollider = GetComponent<Collider2D>();
        triggerCollider.isTrigger = true;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!allowCollection)
        {
            return;
        }

        PlayerInventory inventory = other.GetComponent<PlayerInventory>();
        if (inventory == null)
        {
            return;
        }

        if (inventory.AddBlock(blockType))
        {
            if (gameUI != null)
            {
                gameUI.ShowStatus($"{blockType} collected");
            }

            Destroy(gameObject);
            return;
        }

        if (gameUI != null)
        {
            gameUI.ShowStatus("Inventory full");
        }
    }
}
