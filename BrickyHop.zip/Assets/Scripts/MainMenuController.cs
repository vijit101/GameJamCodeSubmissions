using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    [SerializeField] private string firstLevelSceneName = "Level 1";
    [SerializeField] private GameObject controlsPanel;

    private void Start()
    {
        Time.timeScale = 1f;
        SetControlsVisible(false);
    }

    public void PlayGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(firstLevelSceneName);
    }

    public void ShowControls()
    {
        SetControlsVisible(true);
    }

    public void HideControls()
    {
        SetControlsVisible(false);
    }

    public void ToggleControls()
    {
        if (controlsPanel == null)
        {
            return;
        }

        controlsPanel.SetActive(!controlsPanel.activeSelf);
    }

    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    private void SetControlsVisible(bool visible)
    {
        if (controlsPanel != null)
        {
            controlsPanel.SetActive(visible);
        }
    }
}
