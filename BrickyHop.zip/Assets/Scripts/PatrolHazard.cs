using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class PatrolHazard : MonoBehaviour
{
    [SerializeField] private Transform pointA;
    [SerializeField] private Transform pointB;
    [SerializeField] private float moveSpeed = 2f;
    [SerializeField] private bool moveAlongX = true;
    [SerializeField] private bool moveAlongY;

    private Transform currentTarget;

    private void Start()
    {
        currentTarget = pointB != null ? pointB : pointA;
    }

    private void Update()
    {
        if (pointA == null || pointB == null || currentTarget == null)
        {
            return;
        }

        Vector3 targetPosition = transform.position;
        if (moveAlongX)
        {
            targetPosition.x = currentTarget.position.x;
        }

        if (moveAlongY)
        {
            targetPosition.y = currentTarget.position.y;
        }

        transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetPosition) <= 0.05f)
        {
            currentTarget = currentTarget == pointA ? pointB : pointA;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        RespawnPlayer(other);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        RespawnPlayer(other);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        RespawnPlayer(collision.collider);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        RespawnPlayer(collision.collider);
    }

    private void RespawnPlayer(Collider2D other)
    {
        PlayerController player = other.GetComponent<PlayerController>();
        if (player != null)
        {
            player.Respawn();
        }
    }
}
