using UnityEngine;

public class DragBridgeController : MonoBehaviour
{
    [SerializeField] private BridgeSlot[] requiredSlots;
    [SerializeField] private GameUI gameUI;
    [SerializeField] private string completionMessage = "Bridge Ready";

    private bool bridgeCompleted;

    private void Update()
    {
        if (bridgeCompleted || requiredSlots == null || requiredSlots.Length == 0)
        {
            return;
        }

        for (int index = 0; index < requiredSlots.Length; index++)
        {
            if (requiredSlots[index] == null || !requiredSlots[index].IsOccupied)
            {
                return;
            }
        }

        bridgeCompleted = true;
        gameUI?.ShowStatus(completionMessage);
    }
}
