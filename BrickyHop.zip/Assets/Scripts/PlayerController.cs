using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(PlayerInventory))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 8f;
    public float jumpForce = 12f;
    [Min(1)] public int maxJumpCount = 2;
    
    [Header("Detection")]
    public LayerMask groundLayer;
    public Transform groundCheck;
    [Min(0.05f)] public float checkRadius = 0.15f;

    [Header("Level Bounds")]
    [SerializeField] private Collider2D leftBoundaryCollider;
    [SerializeField] private Collider2D rightBoundaryCollider;

    [Header("Debug")]
    [SerializeField] private bool logBlockedMovement;

    public event System.Action Respawned;

    private Rigidbody2D rb;
    private Collider2D playerCollider;
    private SpriteRenderer spriteRenderer;
    private PlayerInventory inventory;
    private bool isGrounded;
    private float moveInput;
    private int jumpsRemaining;
    private Vector3 respawnPoint;
    private bool hasHorizontalBounds;
    private float minPlayerX;
    private float maxPlayerX;
    private bool controlsEnabled = true;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        playerCollider = GetComponent<Collider2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        inventory = GetComponent<PlayerInventory>();
    }

    private void Start()
    {
        AutoAssignBoundaryColliders();
        RefreshHorizontalBounds();
        respawnPoint = transform.position;
        jumpsRemaining = maxJumpCount;
    }

    private void Update()
    {
        if (!controlsEnabled)
        {
            moveInput = 0f;
            return;
        }

        moveInput = Input.GetAxisRaw("Horizontal");
        bool wasGrounded = isGrounded;
        isGrounded = groundCheck != null &&
            Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundLayer);

        if (isGrounded && !wasGrounded)
        {
            jumpsRemaining = maxJumpCount;
        }

        if (Input.GetButtonDown("Jump") && jumpsRemaining > 0)
        {
            if (!isGrounded && rb.linearVelocity.y > 0f)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f);
            }

            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            jumpsRemaining--;
        }

        if (spriteRenderer != null)
        {
            if (moveInput > 0)
            {
                spriteRenderer.flipX = false;
            }
            else if (moveInput < 0)
            {
                spriteRenderer.flipX = true;
            }
        }
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(moveInput * moveSpeed, rb.linearVelocity.y);

        if (!hasHorizontalBounds)
        {
            return;
        }

        Vector2 position = rb.position;
        float clampedX = Mathf.Clamp(position.x, minPlayerX, maxPlayerX);
        if (!Mathf.Approximately(position.x, clampedX))
        {
            rb.position = new Vector2(clampedX, position.y);
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
        }
    }

    public void SetRespawnPoint(Transform spawnPoint)
    {
        if (spawnPoint != null)
        {
            respawnPoint = spawnPoint.position;
        }
    }

    public void Respawn()
    {
        rb.linearVelocity = Vector2.zero;
        transform.position = respawnPoint;
        jumpsRemaining = maxJumpCount;
        Respawned?.Invoke();
    }

    public void SetControlsEnabled(bool enabled)
    {
        controlsEnabled = enabled;

        if (!enabled)
        {
            moveInput = 0f;
            rb.linearVelocity = Vector2.zero;
        }
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null)
        {
            return;
        }

        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(groundCheck.position, checkRadius);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (!logBlockedMovement || Mathf.Approximately(moveInput, 0f))
        {
            return;
        }

        if (Mathf.Abs(rb.linearVelocity.x) > 0.05f)
        {
            return;
        }

        Debug.Log(
            $"Player movement blocked by {collision.collider.name} on layer {LayerMask.LayerToName(collision.collider.gameObject.layer)}",
            collision.collider);
    }

    private void AutoAssignBoundaryColliders()
    {
        if (leftBoundaryCollider == null)
        {
            GameObject startPlatform = GameObject.Find("StartPlatform");
            if (startPlatform != null)
            {
                leftBoundaryCollider = startPlatform.GetComponent<Collider2D>();
            }
        }

        if (rightBoundaryCollider == null)
        {
            GameObject exitPlatform = GameObject.Find("ExitPlatform");
            if (exitPlatform != null)
            {
                rightBoundaryCollider = exitPlatform.GetComponent<Collider2D>();
            }
        }
    }

    private void RefreshHorizontalBounds()
    {
        if (leftBoundaryCollider == null || rightBoundaryCollider == null || playerCollider == null)
        {
            hasHorizontalBounds = false;
            return;
        }

        float playerHalfWidth = playerCollider.bounds.extents.x;
        minPlayerX = leftBoundaryCollider.bounds.min.x + playerHalfWidth;
        maxPlayerX = rightBoundaryCollider.bounds.max.x - playerHalfWidth;
        hasHorizontalBounds = minPlayerX <= maxPlayerX;
    }
}
