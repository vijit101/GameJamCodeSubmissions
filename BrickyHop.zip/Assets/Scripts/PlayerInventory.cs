using System;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInventory : MonoBehaviour
{
    [SerializeField] private int maxBlocks = 2;

    private readonly List<BlockType> collectedBlocks = new();

    public event Action<IReadOnlyList<BlockType>> InventoryChanged;

    public IReadOnlyList<BlockType> CollectedBlocks => collectedBlocks;
    public int MaxBlocks => maxBlocks;

    private void Start()
    {
        NotifyInventoryChanged();
    }

    public bool AddBlock(BlockType type)
    {
        if (collectedBlocks.Count >= maxBlocks)
        {
            return false;
        }

        collectedBlocks.Add(type);
        NotifyInventoryChanged();
        return true;
    }

    public bool MatchesRecipe(BlockType a, BlockType b)
    {
        if (collectedBlocks.Count != 2)
        {
            return false;
        }

        return (collectedBlocks[0] == a && collectedBlocks[1] == b)
            || (collectedBlocks[0] == b && collectedBlocks[1] == a);
    }

    public void ClearInventory()
    {
        collectedBlocks.Clear();
        NotifyInventoryChanged();
    }

    private void NotifyInventoryChanged()
    {
        InventoryChanged?.Invoke(collectedBlocks);
    }
}
