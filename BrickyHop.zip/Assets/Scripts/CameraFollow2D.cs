using UnityEngine;

public class CameraFollow2D : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new(0f, 1f, -10f);
    [SerializeField] private float smoothTime = 0.2f;
    [SerializeField] private bool followX = true;
    [SerializeField] private bool followY = false;

    [Header("Bounds")]
    [SerializeField] private bool clampToBounds = true;
    [SerializeField] private float minX = -10f;
    [SerializeField] private float maxX = 10f;
    [SerializeField] private float minY = -10f;
    [SerializeField] private float maxY = 10f;

    private Camera targetCamera;
    private Vector3 currentVelocity;

    private void Awake()
    {
        targetCamera = GetComponent<Camera>();
    }

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        Vector3 desiredPosition = transform.position;
        Vector3 targetPosition = target.position + offset;

        if (followX)
        {
            desiredPosition.x = targetPosition.x;
        }

        if (followY)
        {
            desiredPosition.y = targetPosition.y;
        }

        desiredPosition.z = offset.z;
        Vector3 smoothedPosition = Vector3.SmoothDamp(transform.position, desiredPosition, ref currentVelocity, smoothTime);

        if (clampToBounds)
        {
            smoothedPosition = ClampToCameraBounds(smoothedPosition);
        }

        transform.position = smoothedPosition;
    }

    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }

    private Vector3 ClampToCameraBounds(Vector3 position)
    {
        if (targetCamera == null || !targetCamera.orthographic)
        {
            position.x = Mathf.Clamp(position.x, minX, maxX);
            position.y = Mathf.Clamp(position.y, minY, maxY);
            return position;
        }

        float verticalExtent = targetCamera.orthographicSize;
        float horizontalExtent = verticalExtent * targetCamera.aspect;

        float clampedX = Mathf.Clamp(position.x, minX + horizontalExtent, maxX - horizontalExtent);
        float clampedY = Mathf.Clamp(position.y, minY + verticalExtent, maxY - verticalExtent);
        return new Vector3(clampedX, clampedY, position.z);
    }
}
