public enum BlockType
{
    Brick,
    Support,
    Plank
}
