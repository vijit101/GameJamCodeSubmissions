using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelPhaseController : MonoBehaviour
{
    [SerializeField] private PlayerController player;
    [SerializeField] private DraggableBridgeBlock[] draggableBlocks;
    [SerializeField] private Button setupButton;
    [SerializeField] private Button completeRunButton;
    [SerializeField] private GameUI gameUI;
    [SerializeField] private string setupMessage = "Setup Mode";
    [SerializeField] private string runMessage = "Run Started";
    [SerializeField] private bool showSetupMessage = false;

    private bool hasUnlockedRun;

    private void Start()
    {
        if (player != null)
        {
            player.Respawned += HandlePlayerRespawned;
        }

        SubscribeToBlocks();

        EnterInitialState();
        SceneManager.sceneLoaded += HandleSceneLoaded;
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= HandleSceneLoaded;

        if (player != null)
        {
            player.Respawned -= HandlePlayerRespawned;
        }

        UnsubscribeFromBlocks();
    }

    public void EnterSetupMode()
    {
        SetDraggingEnabled(true);
        player?.SetControlsEnabled(false);
        if (setupButton != null)
        {
            setupButton.interactable = false;
        }

        if (completeRunButton != null)
        {
            completeRunButton.interactable = hasUnlockedRun;
        }

        if (showSetupMessage)
        {
            gameUI?.ShowStatus(setupMessage);
        }
    }

    public void StartRun()
    {
        SetDraggingEnabled(false);
        player?.SetControlsEnabled(true);

        if (setupButton != null)
        {
            setupButton.interactable = true;
        }

        if (completeRunButton != null)
        {
            completeRunButton.interactable = false;
        }

        gameUI?.ShowStatus(runMessage);
    }

    private void HandleSceneLoaded(Scene scene, LoadSceneMode loadSceneMode)
    {
        EnterInitialState();
    }

    private void HandlePlayerRespawned()
    {
        if (Time.timeScale == 0f)
        {
            return;
        }

        EnterSetupMode();
    }

    private void EnterInitialState()
    {
        hasUnlockedRun = false;
        SetDraggingEnabled(false);
        player?.SetControlsEnabled(false);

        if (setupButton != null)
        {
            setupButton.interactable = true;
        }

        if (completeRunButton != null)
        {
            completeRunButton.interactable = false;
        }
    }

    private void HandleBlockMoved(DraggableBridgeBlock block)
    {
        if (hasUnlockedRun)
        {
            return;
        }

        hasUnlockedRun = true;
        if (completeRunButton != null)
        {
            completeRunButton.interactable = true;
        }
    }

    private void SubscribeToBlocks()
    {
        if (draggableBlocks == null)
        {
            return;
        }

        for (int index = 0; index < draggableBlocks.Length; index++)
        {
            if (draggableBlocks[index] != null)
            {
                draggableBlocks[index].BlockMoved += HandleBlockMoved;
            }
        }
    }

    private void UnsubscribeFromBlocks()
    {
        if (draggableBlocks == null)
        {
            return;
        }

        for (int index = 0; index < draggableBlocks.Length; index++)
        {
            if (draggableBlocks[index] != null)
            {
                draggableBlocks[index].BlockMoved -= HandleBlockMoved;
            }
        }
    }

    private void SetDraggingEnabled(bool enabled)
    {
        if (draggableBlocks == null)
        {
            return;
        }

        for (int index = 0; index < draggableBlocks.Length; index++)
        {
            if (draggableBlocks[index] != null)
            {
                draggableBlocks[index].SetDraggingEnabled(enabled);
            }
        }
    }
}
