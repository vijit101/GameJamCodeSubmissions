using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public enum GameMode
{
    Swap,
    Rotate,
    Play,
    Win
}

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public GameMode currentMode = GameMode.Swap;

    [Header("UI References")]
    public TMP_Text modeText;
    public TMP_Text messageText;
    public TMP_Text levelText;
    public GameObject winPanel;

    [Header("Player Reference")]
    public Transform player;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        SetMode(GameMode.Swap);

        if (winPanel != null)
            winPanel.SetActive(false);

        if (levelText != null && GridManager.Instance != null)
            levelText.text = "Level " + GridManager.Instance.currentLevel;

        MovePlayerToStart();
    }

    private void Update()
    {
        if (currentMode == GameMode.Win)
            return;

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (currentMode == GameMode.Play)
                SetMode(GameMode.Swap);
            else
                SetMode(GameMode.Play);
        }

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (currentMode == GameMode.Swap)
                SetMode(GameMode.Rotate);
            else if (currentMode == GameMode.Rotate)
                SetMode(GameMode.Swap);
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void SetMode(GameMode newMode)
    {
        Tile.ClearSelection();
        currentMode = newMode;

        if (modeText != null)
            modeText.text = "Mode: " + currentMode;

        if (messageText != null)
        {
            switch (currentMode)
            {
                case GameMode.Swap:
                    messageText.text = "Swap Mode: Select 2 adjacent tiles to swap. Press Tab for Rotate, Space for Play.";
                    break;

                case GameMode.Rotate:
                    messageText.text = "Rotate Mode: Click yellow corners to rotate. Press Tab for Swap, Space for Play.";
                    break;

                case GameMode.Play:
                    messageText.text = "Play Mode: Use WASD or Arrow Keys to move. Press Space to go back.";
                    break;

                case GameMode.Win:
                    messageText.text = "Level Complete!";
                    break;
            }
        }
    }

    public void WinLevel()
    {
        Debug.Log("WIN TRIGGERED");

        Tile.ClearSelection();
        currentMode = GameMode.Win;

        if (modeText != null)
            modeText.text = "Mode: WIN";

        if (messageText != null)
            messageText.text = "Route Restored!";

        if (winPanel != null)
            winPanel.SetActive(true);

        Invoke(nameof(LoadNextScene), 1.5f);
    }

    void LoadNextScene()
    {
        if (GridManager.Instance == null)
            return;

        int currentLevel = GridManager.Instance.currentLevel;

        if (currentLevel == 1)
            SceneManager.LoadScene("Level2");
        else if (currentLevel == 2)
            SceneManager.LoadScene("Level3");
        else if (currentLevel == 3)
            SceneManager.LoadScene("Level4");
        else if (currentLevel == 4)
            SceneManager.LoadScene("Level5");
        else
        {
            if (messageText != null)
                messageText.text = "All Levels Complete! Press R to Restart.";
        }
    }

    void MovePlayerToStart()
    {
        if (player == null || GridManager.Instance == null)
            return;

        Vector2Int start = GridManager.Instance.startPos;
        Tile startTile = GridManager.Instance.GetTileAt(start.x, start.y);

        if (startTile != null)
            player.position = startTile.transform.position + new Vector3(0f, 0f, -1f);
    }

    public void OnToggleModeButton()
    {
        if (currentMode == GameMode.Swap)
            SetMode(GameMode.Rotate);
        else if (currentMode == GameMode.Rotate)
            SetMode(GameMode.Swap);
        else if (currentMode == GameMode.Play)
            SetMode(GameMode.Swap);
    }

    public void OnPlayButton()
    {
        if (currentMode == GameMode.Play)
            SetMode(GameMode.Swap);
        else
            SetMode(GameMode.Play);
    }

    public void OnRestartButton()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}