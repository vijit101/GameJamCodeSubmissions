using UnityEngine;

public class GridManager : MonoBehaviour
{
    public static GridManager Instance;

    [Header("Grid Settings")]
    public int width = 3;
    public int height = 3;
    public float tileSpacing = 1.1f;
    public GameObject tilePrefab;

    [Header("Level Settings")]
    public int currentLevel = 1;

    [HideInInspector] public Tile[,] tiles;

    public Vector2Int startPos;
    public Vector2Int goalPos;

    private void Awake()
    {
        Instance = this;
        LoadLevel(currentLevel);
    }

    public Tile GetTileAt(int x, int y)
    {
        if (x < 0 || y < 0 || x >= width || y >= height)
            return null;

        return tiles[x, y];
    }

    public void LoadLevel(int level)
    {
        ClearGrid();

        currentLevel = level;

        if (level == 1)
            GenerateLevel1();
        else if (level == 2)
            GenerateLevel2();
        else if (level == 3)
            GenerateLevel3();
        else if (level == 4)
            GenerateLevel4();
        else if (level == 5)
            GenerateLevel5();
    }

    public void SwapTiles(Tile tileA, Tile tileB)
    {
        if (tileA == null || tileB == null) return;
        if (tileA == tileB) return;

        int ax = tileA.x;
        int ay = tileA.y;
        int bx = tileB.x;
        int by = tileB.y;

        tiles[ax, ay] = tileB;
        tiles[bx, by] = tileA;

        tileA.x = bx;
        tileA.y = by;

        tileB.x = ax;
        tileB.y = ay;

        tileA.transform.position = GridToWorld(tileA.x, tileA.y);
        tileB.transform.position = GridToWorld(tileB.x, tileB.y);
    }

    void ClearGrid()
    {
        if (tiles == null) return;

        for (int y = 0; y < tiles.GetLength(1); y++)
        {
            for (int x = 0; x < tiles.GetLength(0); x++)
            {
                if (tiles[x, y] != null)
                    Destroy(tiles[x, y].gameObject);
            }
        }
    }

    void GenerateLevel1()
    {
        width = 3;
        height = 3;
        tiles = new Tile[width, height];

        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
                CreateTile(x, y, TileType.Empty, 0, false);

        CreateTile(0, 2, TileType.Start, 0, false);
        CreateTile(1, 2, TileType.Straight, 0, false);
        CreateTile(2, 2, TileType.Corner, 1, true);
        CreateTile(2, 1, TileType.Straight, 1, false);
        CreateTile(2, 0, TileType.Goal, 1, false);

        startPos = new Vector2Int(0, 2);
        goalPos = new Vector2Int(2, 0);
    }

    void GenerateLevel2()
    {
        width = 4;
        height = 4;
        tiles = new Tile[width, height];

        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
                CreateTile(x, y, TileType.Empty, 0, false);

        CreateTile(0, 3, TileType.Start, 0, false);

        CreateTile(1, 3, TileType.Corner, 2, true);
        CreateTile(2, 3, TileType.Straight, 0, false);

        CreateTile(2, 2, TileType.Straight, 1, false);
        CreateTile(2, 1, TileType.Corner, 0, true);
        CreateTile(3, 1, TileType.Corner, 2, true);
        CreateTile(3, 0, TileType.Goal, 1, false);

        CreateTile(3, 3, TileType.Empty, 0, false);
        CreateTile(0, 2, TileType.Empty, 0, false);
        CreateTile(1, 2, TileType.Empty, 0, false);
        CreateTile(3, 2, TileType.Empty, 0, false);
        CreateTile(0, 1, TileType.Empty, 0, false);
        CreateTile(1, 1, TileType.Empty, 0, false);
        CreateTile(2, 0, TileType.Empty, 0, false);

        CreateTile(0, 0, TileType.Blocked, 0, false);
        CreateTile(1, 0, TileType.Blocked, 0, false);

        startPos = new Vector2Int(0, 3);
        goalPos = new Vector2Int(3, 0);
    }

    void GenerateLevel3()
{
    width = 5;
    height = 5;
    tiles = new Tile[width, height];

    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            CreateTile(x, y, TileType.Empty, 0, false);
        }
    }

    /*
        CLEAN LEVEL 3

        Solved route:
        S -> Straight -> Corner
                       |
                       Straight
                       |
                       Corner -> Straight -> Corner
                                                 |
                                                 Straight
                                                 |
                                                 Goal

        Needs:
        - 1 swap
        - 2 rotations
    */

    CreateTile(0, 4, TileType.Start, 0, false);

    // swap pair
    CreateTile(1, 4, TileType.Corner, 2, true);     // should move to (2,4)
    CreateTile(2, 4, TileType.Straight, 0, false);  // should move to (1,4)

    // main route
    CreateTile(2, 3, TileType.Straight, 1, false);
    CreateTile(2, 2, TileType.Corner, 1, true);     // rotate to 0
    CreateTile(3, 2, TileType.Straight, 0, false);
    CreateTile(4, 2, TileType.Corner, 1, true);     // rotate to 2
    CreateTile(4, 1, TileType.Straight, 1, false);
    CreateTile(4, 0, TileType.Goal, 1, false);

    // fillers
    CreateTile(3, 4, TileType.Empty, 0, false);
    CreateTile(4, 4, TileType.Blocked, 0, false);
    CreateTile(0, 3, TileType.Empty, 0, false);
    CreateTile(1, 3, TileType.Empty, 0, false);
    CreateTile(3, 3, TileType.Empty, 0, false);
    CreateTile(4, 3, TileType.Empty, 0, false);
    CreateTile(0, 2, TileType.Empty, 0, false);
    CreateTile(1, 2, TileType.Empty, 0, false);
    CreateTile(0, 1, TileType.Empty, 0, false);
    CreateTile(1, 1, TileType.Empty, 0, false);
    CreateTile(2, 1, TileType.Empty, 0, false);
    CreateTile(3, 1, TileType.Empty, 0, false);
    CreateTile(0, 0, TileType.Blocked, 0, false);
    CreateTile(1, 0, TileType.Blocked, 0, false);
    CreateTile(2, 0, TileType.Empty, 0, false);
    CreateTile(3, 0, TileType.Empty, 0, false);

    startPos = new Vector2Int(0, 4);
    goalPos = new Vector2Int(4, 0);
}

    void GenerateLevel4()
{
    width = 6;
    height = 6;
    tiles = new Tile[width, height];

    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            CreateTile(x, y, TileType.Empty, 0, false);
        }
    }

    /*
        LEVEL 4 — medium thinking

        Intended solved path:
        S -> Straight -> Corner
                       |
                       Straight
                       |
                       Corner -> Straight -> Corner
                                                 |
                                                 Straight
                                                 |
                                                 Corner -> Straight -> Goal

        Needs:
        - 2 swaps
        - 3 rotations
        - blockers near the route
        - one distractor corner
    */

    CreateTile(0, 5, TileType.Start, 0, false);

    // Top section: first swap needed
    CreateTile(1, 5, TileType.Corner, 2, true);      // should become part of route later
    CreateTile(2, 5, TileType.Straight, 0, false);   // should be at (1,5)

    // Main descent
    CreateTile(2, 4, TileType.Straight, 1, false);
    CreateTile(2, 3, TileType.Corner, 1, true);      // rotate to 0

    // Middle route
    CreateTile(3, 3, TileType.Straight, 0, false);
    CreateTile(4, 3, TileType.Corner, 1, true);      // rotate to 2

    // Lower descent
    CreateTile(4, 2, TileType.Straight, 1, false);

    // Second swap zone near the end
    CreateTile(4, 1, TileType.Empty, 0, false);      // swap target
    CreateTile(5, 1, TileType.Corner, 1, true);      // should move left and rotate to 0

    // Final goal section
    CreateTile(3, 0, TileType.Goal, 1, false);

    // Distractor / misleading tile
    CreateTile(1, 3, TileType.Corner, 3, false);

    // Blockers placed to shape thinking
    CreateTile(5, 5, TileType.Blocked, 0, false);
    CreateTile(0, 4, TileType.Blocked, 0, false);
    CreateTile(1, 4, TileType.Blocked, 0, false);
    CreateTile(3, 2, TileType.Blocked, 0, false);
    CreateTile(0, 0, TileType.Blocked, 0, false);
    CreateTile(1, 0, TileType.Blocked, 0, false);

    startPos = new Vector2Int(0, 5);
    goalPos = new Vector2Int(3, 0);
}
   void GenerateLevel5()
{
    width = 7;
    height = 7;
    tiles = new Tile[width, height];

    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            CreateTile(x, y, TileType.Empty, 0, false);
        }
    }

    /*
        LEVEL 5 — harder but still readable

        Intended solved path:
        S -> Straight -> Corner
                       |
                       Straight
                       |
                       Corner -> Straight -> Corner
                                                 |
                                                 Straight
                                                 |
                                                 Corner -> Straight -> Corner
                                                                           |
                                                                           Straight
                                                                           |
                                                                           Goal

        Needs:
        - 2 swaps
        - 4 rotations
        - blockers near path
        - 2 distractor pieces
    */

    CreateTile(0, 6, TileType.Start, 0, false);

    // First swap area
    CreateTile(1, 6, TileType.Corner, 2, true);      // wrong spot
    CreateTile(2, 6, TileType.Straight, 0, false);   // should go to (1,6)

    // First drop
    CreateTile(2, 5, TileType.Straight, 1, false);
    CreateTile(2, 4, TileType.Corner, 1, true);      // rotate to 0

    // First horizontal run
    CreateTile(3, 4, TileType.Straight, 0, false);
    CreateTile(4, 4, TileType.Corner, 1, true);      // rotate to 2

    // Second drop
    CreateTile(4, 3, TileType.Straight, 1, false);

    // Second swap area
    CreateTile(4, 2, TileType.Empty, 0, false);      // swap target
    CreateTile(5, 2, TileType.Corner, 1, true);      // should move left, rotate to 0

    // Final section
    CreateTile(6, 2, TileType.Corner, 1, true);      // rotate to 2
    CreateTile(6, 1, TileType.Straight, 1, false);
    CreateTile(6, 0, TileType.Goal, 1, false);

    // Distractors
    CreateTile(1, 4, TileType.Corner, 3, false);
    CreateTile(3, 2, TileType.Straight, 0, false);

    // Blockers to force route reading
    CreateTile(6, 6, TileType.Blocked, 0, false);
    CreateTile(0, 5, TileType.Blocked, 0, false);
    CreateTile(1, 5, TileType.Blocked, 0, false);
    CreateTile(5, 4, TileType.Blocked, 0, false);
    CreateTile(3, 3, TileType.Blocked, 0, false);
    CreateTile(0, 1, TileType.Blocked, 0, false);
    CreateTile(0, 0, TileType.Blocked, 0, false);
    CreateTile(1, 0, TileType.Blocked, 0, false);

    startPos = new Vector2Int(0, 6);
    goalPos = new Vector2Int(6, 0);
}
    void CreateTile(int x, int y, TileType type, int rotation, bool rotatable)
    {
        Vector3 worldPos = GridToWorld(x, y);
        GameObject obj = Instantiate(tilePrefab, worldPos, Quaternion.identity, transform);

        Tile tile = obj.GetComponent<Tile>();
        tile.Setup(x, y, type, rotation, rotatable);

        tiles[x, y] = tile;
    }

    public Vector3 GridToWorld(int x, int y)
    {
        float offsetX = -(width - 1) * tileSpacing / 2f;
        float offsetY = -(height - 1) * tileSpacing / 2f;

        return new Vector3(
            x * tileSpacing + offsetX,
            y * tileSpacing + offsetY,
            0f
        );
    }
}