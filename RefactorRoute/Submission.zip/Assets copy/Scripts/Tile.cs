using UnityEngine;

public enum TileType
{
    Empty,
    Start,
    Goal,
    Straight,
    Corner,
    Blocked
}

public class Tile : MonoBehaviour
{
    [Header("Sprites")]
    public Sprite straightHorizontal;
    public Sprite straightVertical;
    public Sprite cornerSprite;
    public Sprite startSprite;
    public Sprite goalSprite;

    [Header("Renderers")]
    public SpriteRenderer baseRenderer;
    public SpriteRenderer pathRenderer;

    [Header("State")]
    public int x;
    public int y;
    public TileType tileType;
    public bool isRotatable = false;

    [HideInInspector] public int rotationState = 0;

    private Vector3 baseScale = Vector3.one;

    private readonly Color emptyColor = Hex("#DCE3EA");
    private readonly Color fixedTileColor = Hex("#94A3B8");
    private readonly Color editableTileColor = Hex("#FBBF24");
    private readonly Color startColor = Hex("#22C55E");
    private readonly Color goalColor = Hex("#F43F5E");
    private readonly Color blockedColor = Hex("#1F2937");
    private readonly Color selectedColor = Hex("#22D3EE");

    private const float normalScale = 1.0f;
    private const float editableScale = 1.08f;
    private const float hoverScaleMultiplier = 1.12f;

    private static Tile selectedTile = null;

    private static Color Hex(string hex)
    {
        Color color;
        ColorUtility.TryParseHtmlString(hex, out color);
        return color;
    }

    private void Awake()
    {
        if (baseRenderer == null)
            baseRenderer = transform.Find("Base")?.GetComponent<SpriteRenderer>();

        if (pathRenderer == null)
            pathRenderer = transform.Find("Path")?.GetComponent<SpriteRenderer>();
    }

    public void Setup(int gridX, int gridY, TileType type, int rotation, bool rotatable)
    {
        x = gridX;
        y = gridY;
        tileType = type;
        rotationState = rotation;
        isRotatable = rotatable;
        UpdateVisual();
    }

    public void SetType(TileType newType)
    {
        tileType = newType;
        UpdateVisual();
    }

    public static void ClearSelection()
    {
        if (selectedTile != null)
        {
            selectedTile.Highlight(false);
            selectedTile = null;
        }
    }

    private bool CanRotate()
    {
        return tileType == TileType.Corner && isRotatable;
    }

    private bool CanSwap()
    {
        return tileType == TileType.Empty ||
               tileType == TileType.Straight ||
               tileType == TileType.Corner;
    }

    private bool IsAdjacent(Tile a, Tile b)
    {
        int dx = Mathf.Abs(a.x - b.x);
        int dy = Mathf.Abs(a.y - b.y);
        return (dx + dy) == 1;
    }

    private void Highlight(bool state)
    {
        if (baseRenderer == null) return;

        if (state)
            baseRenderer.color = selectedColor;
        else
            UpdateVisual();
    }

    private void SelectThisTile()
    {
        ClearSelection();
        selectedTile = this;
        Highlight(true);
    }

    private void OnMouseDown()
    {
        if (GameManager.Instance == null) return;
        if (GridManager.Instance == null) return;

        if (GameManager.Instance.currentMode == GameMode.Rotate)
        {
            ClearSelection();

            if (CanRotate())
                RotateTile();

            return;
        }

        if (GameManager.Instance.currentMode != GameMode.Swap)
            return;

        if (!CanSwap())
        {
            ClearSelection();
            return;
        }

        // Nothing selected yet
        if (selectedTile == null)
        {
            SelectThisTile();
            return;
        }

        // Clicking same tile = deselect
        if (selectedTile == this)
        {
            ClearSelection();
            return;
        }

        // Adjacent valid swap
        if (selectedTile.CanSwap() && CanSwap() && IsAdjacent(selectedTile, this))
        {
            GridManager.Instance.SwapTiles(selectedTile, this);
            ClearSelection();
            return;
        }

        // Not adjacent? Make the new tile the selection.
        SelectThisTile();
    }

    private void OnMouseEnter()
    {
        if (GameManager.Instance == null) return;
        if (GridManager.Instance == null) return;

        if (GameManager.Instance.currentMode == GameMode.Rotate)
        {
            if (!CanRotate()) return;
        }
        else if (GameManager.Instance.currentMode == GameMode.Swap)
        {
            if (!CanSwap()) return;
        }
        else
        {
            return;
        }

        if (selectedTile == this) return;

        transform.localScale = baseScale * hoverScaleMultiplier;
    }

    private void OnMouseExit()
    {
        if (selectedTile == this) return;
        transform.localScale = baseScale;
    }

    public void RotateTile()
    {
        rotationState = (rotationState + 1) % 4;
        UpdateVisual();
    }

    public bool IsWalkable()
    {
        return tileType != TileType.Blocked;
    }

    public void UpdateVisual()
    {
        if (baseRenderer == null || pathRenderer == null) return;

        transform.localScale = Vector3.one;
        transform.rotation = Quaternion.identity;
        baseScale = Vector3.one;

        baseRenderer.color = emptyColor;

        pathRenderer.sprite = null;
        pathRenderer.color = Color.white;
        pathRenderer.transform.localRotation = Quaternion.identity;

        switch (tileType)
        {
            case TileType.Empty:
                baseScale = Vector3.one;
                break;

            case TileType.Blocked:
                pathRenderer.sprite = null;
                baseRenderer.color = blockedColor;
                baseScale = Vector3.one;
                break;

            case TileType.Start:
                pathRenderer.sprite = startSprite;
                pathRenderer.color = startColor;
                pathRenderer.transform.localRotation = Quaternion.Euler(0f, 0f, -90f * rotationState);
                baseScale = new Vector3(1.08f, 1.08f, 1f);
                break;

            case TileType.Goal:
                pathRenderer.sprite = goalSprite;
                pathRenderer.color = goalColor;
                pathRenderer.transform.localRotation = Quaternion.Euler(0f, 0f, -90f * rotationState);
                baseScale = new Vector3(1.08f, 1.08f, 1f);
                break;

            case TileType.Straight:
                pathRenderer.sprite = (rotationState % 2 == 0) ? straightHorizontal : straightVertical;
                pathRenderer.color = fixedTileColor;
                baseScale = new Vector3(normalScale, normalScale, 1f);
                break;

            case TileType.Corner:
                pathRenderer.sprite = cornerSprite;
                pathRenderer.color = isRotatable ? editableTileColor : fixedTileColor;
                pathRenderer.transform.localRotation = Quaternion.Euler(0f, 0f, 90f - 90f * rotationState);
                baseScale = isRotatable
                    ? new Vector3(editableScale, editableScale, 1f)
                    : new Vector3(normalScale, normalScale, 1f);
                break;
        }

        transform.localScale = baseScale;

        if (selectedTile == this && baseRenderer != null)
            baseRenderer.color = selectedColor;
    }

    public bool HasConnection(Vector2Int dir)
    {
        if (tileType == TileType.Straight)
        {
            return (rotationState % 2 == 0)
                ? dir == Vector2Int.left || dir == Vector2Int.right
                : dir == Vector2Int.up || dir == Vector2Int.down;
        }

        if (tileType == TileType.Corner)
        {
            if (rotationState == 0) return dir == Vector2Int.up || dir == Vector2Int.right;
            if (rotationState == 1) return dir == Vector2Int.right || dir == Vector2Int.down;
            if (rotationState == 2) return dir == Vector2Int.down || dir == Vector2Int.left;
            if (rotationState == 3) return dir == Vector2Int.left || dir == Vector2Int.up;
        }

        if (tileType == TileType.Start)
        {
            if (rotationState == 0) return dir == Vector2Int.right;
            if (rotationState == 1) return dir == Vector2Int.down;
            if (rotationState == 2) return dir == Vector2Int.left;
            if (rotationState == 3) return dir == Vector2Int.up;
        }

        if (tileType == TileType.Goal)
        {
            if (rotationState == 0) return dir == Vector2Int.left;
            if (rotationState == 1) return dir == Vector2Int.up;
            if (rotationState == 2) return dir == Vector2Int.right;
            if (rotationState == 3) return dir == Vector2Int.down;
        }

        return false;
    }
}