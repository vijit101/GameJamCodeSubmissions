using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public float moveDuration = 0.15f;

    private Vector2Int currentGridPos;
    private bool isMoving = false;

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private IEnumerator Start()
    {
        yield return null;
        ResetToStart();
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        StartCoroutine(ResetNextFrame());
    }

    private IEnumerator ResetNextFrame()
    {
        yield return null;
        ResetToStart();
    }

    private void Update()
    {
        if (GameManager.Instance == null) return;
        if (GridManager.Instance == null) return;
        if (GameManager.Instance.currentMode != GameMode.Play) return;
        if (isMoving) return;

        Vector2Int moveDir = Vector2Int.zero;

        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            moveDir = Vector2Int.up;
        else if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            moveDir = Vector2Int.right;
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
            moveDir = Vector2Int.down;
        else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            moveDir = Vector2Int.left;

        if (moveDir != Vector2Int.zero)
            TryMove(moveDir);
    }

    void TryMove(Vector2Int dir)
    {
        Tile currentTile = GridManager.Instance.GetTileAt(currentGridPos.x, currentGridPos.y);
        Vector2Int targetPos = currentGridPos + dir;
        Tile nextTile = GridManager.Instance.GetTileAt(targetPos.x, targetPos.y);

        if (currentTile == null || nextTile == null) return;
        if (nextTile.tileType == TileType.Empty) return;
        if (nextTile.tileType == TileType.Blocked) return;

        Vector2Int opposite = new Vector2Int(-dir.x, -dir.y);

        bool currentConnects = currentTile.HasConnection(dir);
        bool nextConnects = nextTile.HasConnection(opposite);

        if (currentConnects && nextConnects)
        {
            currentGridPos = targetPos;
            Vector3 targetWorld = GridManager.Instance.GridToWorld(currentGridPos.x, currentGridPos.y) + new Vector3(0f, 0f, -1f);
            StartCoroutine(MoveTo(targetWorld));

            if (currentGridPos == GridManager.Instance.goalPos)
                GameManager.Instance.WinLevel();
        }
    }

    IEnumerator MoveTo(Vector3 targetPos)
    {
        isMoving = true;

        Vector3 startPosWorld = transform.position;
        float t = 0f;

        while (t < moveDuration)
        {
            t += Time.deltaTime;
            float lerp = Mathf.Clamp01(t / moveDuration);
            transform.position = Vector3.Lerp(startPosWorld, targetPos, lerp);
            yield return null;
        }

        transform.position = targetPos;
        isMoving = false;
    }

    public void ResetToStart()
    {
        StopAllCoroutines();
        isMoving = false;

        if (GridManager.Instance == null) return;

        currentGridPos = GridManager.Instance.startPos;
        transform.position = GridManager.Instance.GridToWorld(currentGridPos.x, currentGridPos.y) + new Vector3(0f, 0f, -1f);
    }
}