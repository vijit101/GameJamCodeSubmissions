using System.Collections.Generic;
using UnityEngine;

namespace Backtrack
{
    // Ariadne's thread — a continuous LineRenderer that grows as the player
    // moves forward, and shrinks as the player rewinds backward. The "live tip"
    // of the line always tracks the player transform, so the thread stays
    // visually connected during smooth cell-to-cell motion.
    [RequireComponent(typeof(LineRenderer))]
    public class ThreadRenderer : MonoBehaviour
    {
        [Header("Source")]
        public Transform follow;

        [Header("Style")]
        public Color threadColor = new Color(0.35f, 0.92f, 1.00f, 1f);
        public float threadWidth = 0.16f;

        private LineRenderer _line;
        private readonly List<Vector3> _committed = new();

        void Awake()
        {
            _line = GetComponent<LineRenderer>();
            _line.material = new Material(Shader.Find("Sprites/Default"));
            _line.startWidth = threadWidth;
            _line.endWidth = threadWidth;
            _line.startColor = threadColor;
            _line.endColor = threadColor;
            _line.numCapVertices = 6;
            _line.numCornerVertices = 4;
            _line.useWorldSpace = true;
            _line.sortingOrder = 3;
            _line.positionCount = 0;
            _line.textureMode = LineTextureMode.Stretch;
        }

        void LateUpdate()
        {
            if (follow == null)
            {
                _line.positionCount = 0;
                return;
            }

            int n = _committed.Count;
            _line.positionCount = n + 1;
            for (int i = 0; i < n; i++) _line.SetPosition(i, _committed[i]);
            _line.SetPosition(n, follow.position + Vector3.back * 0.05f);
        }

        public void Commit(Vector3 pos)
        {
            _committed.Add(pos + Vector3.back * 0.05f);
        }

        public void PopLast()
        {
            if (_committed.Count > 0)
                _committed.RemoveAt(_committed.Count - 1);
        }

        public void Clear() => _committed.Clear();
    }
}
