using UnityEngine;

namespace Backtrack
{
    public class AudioManager : MonoBehaviour
    {
        public AudioSource source;
        public AudioClip step;
        public AudioClip branch;
        public AudioClip back;
        public AudioClip win;
        public AudioClip lose;

        void Awake()
        {
            if (source == null) source = GetComponent<AudioSource>();
        }

        public void PlayStep()   => Play(step);
        public void PlayBranch() => Play(branch);
        public void PlayBack()   => Play(back);
        public void PlayWin()    => Play(win);
        public void PlayLose()   => Play(lose);

        private void Play(AudioClip clip)
        {
            if (source == null || clip == null) return;
            source.PlayOneShot(clip);
        }
    }
}
