using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Backtrack
{
    [RequireComponent(typeof(SpriteRenderer))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Refs")]
        public LevelGrid grid;
        public BacktrackManager backtrack;
        public GameManager game;
        public AudioManager audioManager;
        public ThreadRenderer thread;

        [Header("Move")]
        public float moveSpeed = 8f;
        [Tooltip("Multiplier on moveSpeed while rewinding.")]
        public float rewindSpeedMul = 3.5f;
        [Tooltip("Color the player tints to while rewinding.")]
        public Color rewindColor = new Color(0.9f, 0.5f, 0.9f);

        public Vector2Int Cell { get; private set; }
        public Vector2Int LastCell { get; private set; }

        private Vector3 _targetWorld;
        private bool _moving;
        private bool _rewinding;
        private Color _idleColor;

        void Start()
        {
            EnsureSprite();
            EnsureThread();
            if (grid == null) grid = FindObjectOfType<LevelGrid>();
            Cell = grid.StartCell;
            LastCell = Cell;
            transform.position = grid.CellToWorld(Cell);
            transform.localScale = Vector3.one * 0.7f;
            _targetWorld = transform.position;
            _idleColor = GetComponent<SpriteRenderer>().color;

            backtrack?.Init(Cell);
            thread?.Clear();
            thread?.Commit(transform.position);
        }

        private void EnsureThread()
        {
            if (thread != null) return;
            var go = new GameObject("PlayerThread");
            go.transform.SetParent(transform.parent, false);
            thread = go.AddComponent<ThreadRenderer>();
            thread.follow = transform;
        }

        private void EnsureSprite()
        {
            var sr = GetComponent<SpriteRenderer>();
            if (sr.sprite != null) return;

            const int size = 24;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Bilinear
            };
            var pixels = new Color32[size * size];
            float r = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x + 0.5f - r, dy = y + 0.5f - r;
                    float d = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1f - (d / (r - 0.5f)));
                    pixels[y * size + x] = new Color32(240, 240, 255, (byte)(a * 255f));
                }
            }
            tex.SetPixels32(pixels);
            tex.Apply();
            sr.sprite = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
            sr.color = new Color(0.95f, 0.95f, 1f);
            sr.sortingOrder = 10;
        }

        void Update()
        {
            if (_rewinding) return;

            if (_moving)
            {
                transform.position = Vector3.MoveTowards(
                    transform.position, _targetWorld, moveSpeed * Time.deltaTime);
                if (transform.position == _targetWorld)
                {
                    _moving = false;
                    thread?.Commit(_targetWorld);
                }
                return;
            }

            if (Input.GetKeyDown(KeyCode.R))
            {
                TryBacktrack();
                return;
            }

            Vector2Int dir = ReadInput();
            if (dir != Vector2Int.zero) TryMove(dir);
        }

        private Vector2Int ReadInput()
        {
            if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))    return Vector2Int.up;
            if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))  return Vector2Int.down;
            if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))  return Vector2Int.left;
            if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) return Vector2Int.right;
            return Vector2Int.zero;
        }

        private void TryMove(Vector2Int dir)
        {
            Vector2Int next = Cell + dir;
            if (!grid.IsWalkable(next)) return;

            LastCell = Cell;
            Cell = next;
            _targetWorld = grid.CellToWorld(Cell);
            _moving = true;

            backtrack?.OnEnter(Cell, LastCell);

            var type = grid.Get(Cell);
            if (type == CellType.Trap) game.OnTrap();
            else if (type == CellType.Goal) game.OnGoal();
        }

        private void TryBacktrack()
        {
            if (_rewinding) return;
            if (backtrack == null || !backtrack.CanPop) return;
            if (game != null && !game.RequestBacktrack()) return;

            if (backtrack.TryPopForRewind(out var path, out var deadCells, out var final))
            {
                StartCoroutine(RewindCoroutine(path, deadCells, final));
            }
        }

        private IEnumerator RewindCoroutine(
            List<Vector2Int> path, List<Vector2Int> deadCells, Vector2Int finalCell)
        {
            _rewinding = true;
            _moving = false;
            var sr = GetComponent<SpriteRenderer>();
            sr.color = rewindColor;

            var deadSet = new HashSet<Vector2Int>(deadCells);
            foreach (var cell in path)
            {
                thread?.PopLast();
                _targetWorld = grid.CellToWorld(cell);
                float speed = moveSpeed * rewindSpeedMul;
                while (Vector3.Distance(transform.position, _targetWorld) > 0.001f)
                {
                    transform.position = Vector3.MoveTowards(
                        transform.position, _targetWorld, speed * Time.deltaTime);
                    yield return null;
                }
                transform.position = _targetWorld;
                LastCell = Cell;
                Cell = cell;
                if (deadSet.Contains(cell))
                {
                    backtrack.TintCellDead(cell);
                    deadSet.Remove(cell);
                }
            }

            // Cells the player stood on but didn't walk through (e.g. initial current cell) also die.
            foreach (var c in deadSet) backtrack.TintCellDead(c);

            Cell = finalCell;
            sr.color = _idleColor;
            _rewinding = false;
        }

        public void Respawn()
        {
            Cell = grid.StartCell;
            LastCell = Cell;
            transform.position = grid.CellToWorld(Cell);
            _targetWorld = transform.position;
            _moving = false;
            backtrack?.Init(Cell);
            thread?.Clear();
            thread?.Commit(transform.position);
        }
    }
}
