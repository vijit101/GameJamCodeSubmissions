using System.Collections.Generic;
using UnityEngine;

namespace Backtrack
{
    public enum CellType { Wall, Floor, Trap, Goal, Start }

    public class LevelGrid : MonoBehaviour
    {
        [Header("Grid")]
        public int width = 15;
        public int height = 11;
        public float cellSize = 1f;

        [Header("Scoring")]
        [Tooltip("Optimal (minimum) number of backtracks to solve this level.")]
        public int par = 2;
        [Tooltip("Maximum backtracks allowed before game over.")]
        public int maxBacktracks = 5;

        [Header("Level Layout (rows top-to-bottom)")]
        [Tooltip("# = wall, . = floor, S = start, G = goal, X = trap")]
        public string[] layout = new string[]
        {
            "###############",
            "#S....#.......#",
            "#.###.#.#####.#",
            "#.#.#...#...#.#",
            "#.#.#####.#.#.#",
            "#.#.......#.X.#",
            "#.#########.#.#",
            "#.....X.....#.#",
            "#####.#######.#",
            "#.............G",
            "###############",
        };

        [Header("Visuals")]
        public Color floorColor = new Color(0.20f, 0.22f, 0.28f);
        public Color wallColor  = new Color(0.08f, 0.08f, 0.10f);
        public Color trapColor  = new Color(0.85f, 0.25f, 0.25f);
        public Color goalColor  = new Color(0.30f, 0.85f, 0.45f);
        public Color startColor = new Color(0.90f, 0.85f, 0.30f);

        public Vector2Int StartCell { get; private set; }
        public Vector2Int GoalCell  { get; private set; }

        private CellType[,] _cells;
        private Sprite _tileSprite;

        void Awake()
        {
            Build();
        }

        void Start()
        {
            PaintTiles();
        }

        private void PaintTiles()
        {
            _tileSprite ??= CreateTileSprite();
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    var cell = new Vector2Int(x, y);
                    var type = Get(cell);
                    var go = new GameObject($"Tile_{x}_{y}");
                    go.transform.SetParent(transform, false);
                    go.transform.position = CellToWorld(cell);
                    var sr = go.AddComponent<SpriteRenderer>();
                    sr.sprite = _tileSprite;
                    sr.color = type switch
                    {
                        CellType.Wall  => wallColor,
                        CellType.Trap  => trapColor,
                        CellType.Goal  => goalColor,
                        CellType.Start => startColor,
                        _              => floorColor,
                    };
                    sr.sortingOrder = 0;
                }
            }
        }

        private static Sprite CreateTileSprite()
        {
            const int size = 16;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Clamp
            };
            var pixels = new Color32[size * size];
            for (int i = 0; i < pixels.Length; i++) pixels[i] = new Color32(255, 255, 255, 255);
            // one-pixel inner border for grid visibility
            for (int i = 0; i < size; i++)
            {
                pixels[i] = new Color32(0, 0, 0, 40);
                pixels[(size - 1) * size + i] = new Color32(0, 0, 0, 40);
                pixels[i * size] = new Color32(0, 0, 0, 40);
                pixels[i * size + size - 1] = new Color32(0, 0, 0, 40);
            }
            tex.SetPixels32(pixels);
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        }

        public void Build()
        {
            height = layout.Length;
            width  = layout[0].Length;
            _cells = new CellType[width, height];

            for (int y = 0; y < height; y++)
            {
                string row = layout[height - 1 - y];
                for (int x = 0; x < width; x++)
                {
                    char c = x < row.Length ? row[x] : '#';
                    _cells[x, y] = c switch
                    {
                        '#' => CellType.Wall,
                        'S' => CellType.Start,
                        'G' => CellType.Goal,
                        'X' => CellType.Trap,
                        _   => CellType.Floor,
                    };
                    if (c == 'S') StartCell = new Vector2Int(x, y);
                    if (c == 'G') GoalCell  = new Vector2Int(x, y);
                }
            }
        }

        public bool InBounds(Vector2Int p) =>
            p.x >= 0 && p.x < width && p.y >= 0 && p.y < height;

        public CellType Get(Vector2Int p) =>
            InBounds(p) ? _cells[p.x, p.y] : CellType.Wall;

        public bool IsWalkable(Vector2Int p) => Get(p) != CellType.Wall;

        public Vector3 CellToWorld(Vector2Int p) =>
            new Vector3(p.x * cellSize, p.y * cellSize, 0);

        // A branch cell has >=2 walkable neighbors excluding the one you came from.
        public bool IsBranch(Vector2Int cell, Vector2Int from)
        {
            int exits = 0;
            foreach (var d in Dirs)
            {
                Vector2Int n = cell + d;
                if (n == from) continue;
                if (IsWalkable(n)) exits++;
            }
            return exits >= 2;
        }

        public static readonly Vector2Int[] Dirs =
        {
            Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right
        };
    }
}
