using System.Collections.Generic;
using UnityEngine;

namespace Backtrack.ThreeD
{
    // Procedural primitive dungeon. Spawns a small branching labyrinth of
    // floor/wall cubes at runtime — no imported assets needed. Geometry is
    // grid-aligned (2m cells) so the Ariadne thread tracks cleanly. Layout
    // supports # wall, . floor, S start, G goal, $ gem, X trap.
    public class ThreeDDungeon : MonoBehaviour
    {
        public enum Tile { Wall, Floor, Start, Goal, Gem, Trap }

        [Header("Geometry")]
        public float cellSize = 2f;
        public float wallHeight = 3f;
        public float wallThickness = 0.25f;

        [Header("Palette")]
        public Color floorColor = new Color(0.16f, 0.14f, 0.12f);
        public Color wallColor  = new Color(0.28f, 0.22f, 0.18f);
        public Color goalColor  = new Color(1.00f, 0.70f, 0.25f);
        public Color startColor = new Color(0.40f, 0.80f, 1.00f);
        public Color gemColor   = new Color(0.50f, 0.85f, 1.00f);
        public Color trapColor  = new Color(1.00f, 0.25f, 0.20f);

        // A larger, more exploratory labyrinth with multiple branches, dead-ends
        // stocked with gems, traps forcing careful route-planning, and a couple
        // of loops so the player can discover shortcuts on a retrace.
        public string[] layout = new[]
        {
            "#########################",
            "#S........#.......#.....#",
            "#.######.#.######.#.###.#",
            "#.#....#.#.#....#.#.#.$.#",
            "#.#.##.#.#.#.##.#.#.#.###",
            "#.#.$#.#.#.#.#$.#.#.#...#",
            "#.#..#.#.#.#.#.##.#.###.#",
            "#.##.#.#.#.#.#....#.#...#",
            "#....#.#.#.#.######.#.###",
            "####.#.#.#.#..X...#.#...#",
            "#....#.#.#.######.#.###.#",
            "#.####.#.#........#...#.#",
            "#.#....#.##########.###.#",
            "#.#.####.$........#.#.$.#",
            "#.#......##########.#.###",
            "#.################..#...#",
            "#....X..........#.#.###.#",
            "####.###########.#.#...#",
            "#.$..#.........#.#.###.#",
            "#.####.#######.#.#.....#",
            "#......#.....#.#.######",
            "########.###.#.#.......#",
            "#........#.......X....G#",
            "#########################",
        };

        public Vector3 StartWorld { get; private set; }
        public Vector3 GoalWorld  { get; private set; }

        private Tile[,] _tiles;      // indexed by [row, col] — matches layout strings directly
        private GameObject[,] _pickables;
        private Renderer[,] _floorRenderers; // non-null only for Floor/Start/Goal
        private float[,] _lastTouched;       // Time.time when player last visited (or 0 if never)
        private int _rows, _cols;
        private GameObject _goalPedestal;
        private Renderer _goalFloorRenderer;

        private Material _floorMat;
        private Material _wallMat;
        private Material _goalMat;
        private Material _startMat;
        private Material _gemMat;
        private Material _trapMat;

        public int Rows => _rows;
        public int Cols => _cols;

        public bool IsReady { get; private set; }

        // Tablets: stone pillars scattered through the labyrinth with
        // Ariadne's whispered lines. Hardcoded positions — each (row, col)
        // pairs with a whisper index consumed by ThreeDManager.
        public struct Tablet { public Vector3 world; public int whisperId; }
        public readonly List<Tablet> Tablets = new();

        // Placements — row, col, whisperId. If a cell is a wall, it's silently skipped.
        private static readonly (int r, int c, int id)[] _tabletSpots =
        {
            (2, 3, 0),
            (5, 12, 1),
            (11, 2, 2),
            (16, 20, 3),
            (21, 5, 4),
        };

        void Awake()
        {
            try
            {
                _floorMat = MakeMat(floorColor);
                _wallMat  = MakeMat(wallColor);
                _goalMat  = MakeMatEmissive(goalColor);
                _startMat = MakeMatEmissive(startColor);
                _gemMat   = MakeMatEmissive(gemColor);
                _trapMat  = MakeMatEmissive(trapColor);
                Build();
                IsReady = true;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[ThreeDDungeon] Awake failed: {e}");
                IsReady = false;
            }
        }

        private Material MakeMat(Color c)
        {
            // In WebGL, Shader.Find can return null if the shader wasn't pulled
            // into the build. Fall through a chain of candidates, and last-ditch
            // grab any shader from a runtime-spawned primitive.
            var shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Universal Render Pipeline/Simple Lit");
            if (shader == null) shader = Shader.Find("Universal Render Pipeline/Unlit");
            if (shader == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            if (shader == null)
            {
                var probe = GameObject.CreatePrimitive(PrimitiveType.Cube);
                shader = probe.GetComponent<Renderer>().sharedMaterial?.shader;
                Destroy(probe);
            }

            var mat = shader != null ? new Material(shader) : new Material(Shader.Find("Hidden/InternalErrorShader"));
            mat.color = c;
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", c);
            return mat;
        }

        private Material MakeMatEmissive(Color c)
        {
            var mat = MakeMat(c);
            if (mat != null && mat.HasProperty("_EmissionColor"))
            {
                mat.EnableKeyword("_EMISSION");
                mat.SetColor("_EmissionColor", c * 1.6f);
            }
            return mat;
        }

        private void Build()
        {
            _rows = layout.Length;
            _cols = layout[0].Length;
            _tiles = new Tile[_rows, _cols];
            _pickables = new GameObject[_rows, _cols];
            _floorRenderers = new Renderer[_rows, _cols];
            _lastTouched = new float[_rows, _cols];

            for (int r = 0; r < _rows; r++)
            {
                string row = layout[r];
                for (int c = 0; c < _cols; c++)
                {
                    char ch = c < row.Length ? row[c] : '#';
                    Tile t = ch switch
                    {
                        '#' => Tile.Wall,
                        'S' => Tile.Start,
                        'G' => Tile.Goal,
                        '$' => Tile.Gem,
                        'X' => Tile.Trap,
                        _   => Tile.Floor,
                    };
                    _tiles[r, c] = t;

                    float x = c * cellSize;
                    float z = -(r * cellSize);

                    if (t == Tile.Wall)
                    {
                        SpawnWall(new Vector3(x, wallHeight * 0.5f, z));
                    }
                    else
                    {
                        SpawnFloor(new Vector3(x, 0, z), t);
                        if (t == Tile.Start) StartWorld = new Vector3(x, 1.0f, z);
                        if (t == Tile.Goal)  GoalWorld  = new Vector3(x, 1.0f, z);
                        if (t == Tile.Gem)   SpawnGem(new Vector3(x, 0, z), r, c);
                        if (t == Tile.Trap)  SpawnTrap(new Vector3(x, 0, z), r, c);
                    }
                }
            }

            // After all tiles are placed, drop tablets at the marked spots.
            foreach (var spot in _tabletSpots)
            {
                if (!InBounds(spot.r, spot.c)) continue;
                if (_tiles[spot.r, spot.c] == Tile.Wall) continue;
                float tx = spot.c * cellSize;
                float tz = -(spot.r * cellSize);
                SpawnTablet(new Vector3(tx, 0, tz), spot.id);
            }
        }

        private void SpawnFloor(Vector3 pos, Tile t)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = $"Floor_{pos.x}_{pos.z}";
            go.transform.SetParent(transform, true);
            go.transform.position = pos + Vector3.down * 0.1f;
            go.transform.localScale = new Vector3(cellSize, 0.2f, cellSize);
            var r = go.GetComponent<Renderer>();
            // Per-renderer material instance so we can fade each floor independently.
            r.material = new Material(t switch
            {
                Tile.Start => _startMat,
                Tile.Goal  => _goalMat,
                _          => _floorMat,
            });
            // Record this renderer under the grid cell the position came from.
            var cell = WorldToCell(pos);
            if (InBounds(cell)) _floorRenderers[cell.x, cell.y] = r;

            if (t == Tile.Goal)
            {
                var pedestal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                pedestal.name = "GoalPedestal";
                pedestal.transform.SetParent(transform, true);
                pedestal.transform.position = pos + Vector3.up * 0.5f;
                pedestal.transform.localScale = new Vector3(0.7f, 0.5f, 0.7f);
                pedestal.GetComponent<Renderer>().material = _goalMat;
                Destroy(pedestal.GetComponent<Collider>());

                // Breathing emission + slow spin so the prize reads as alive in the dark.
                var bob = pedestal.AddComponent<BobRotate>();
                bob.bobAmplitude = 0.05f;
                bob.bobFrequency = 0.9f;
                bob.rotateDegPerSec = 35f;
                var pulse = pedestal.AddComponent<EmissivePulse>();
                pulse.baseColor = goalColor;
                pulse.minMul = 0.9f;
                pulse.maxMul = 2.0f;
                pulse.frequency = 0.8f;

                _goalPedestal = pedestal;
                _goalFloorRenderer = r;
            }
        }

        private void SpawnWall(Vector3 pos)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "Wall";
            go.transform.SetParent(transform, true);
            go.transform.position = pos;
            go.transform.localScale = new Vector3(cellSize, wallHeight, cellSize);
            var rend = go.GetComponent<Renderer>();
            rend.material = _wallMat;

            // Per-wall color nudge via MaterialPropertyBlock — adds texture/variation
            // without instancing a new material per wall.
            var block = new MaterialPropertyBlock();
            float j = Random.Range(-0.08f, 0.08f);
            Color c = new Color(
                Mathf.Clamp01(wallColor.r + j),
                Mathf.Clamp01(wallColor.g + j * 0.8f),
                Mathf.Clamp01(wallColor.b + j * 0.6f));
            rend.GetPropertyBlock(block);
            if (_wallMat.HasProperty("_BaseColor")) block.SetColor("_BaseColor", c);
            else                                     block.SetColor("_Color", c);
            rend.SetPropertyBlock(block);
        }

        private void SpawnGem(Vector3 pos, int row, int col)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            go.name = $"Gem_{row}_{col}";
            go.transform.SetParent(transform, true);
            go.transform.position = pos + Vector3.up * 0.9f;
            go.transform.localScale = Vector3.one * 0.45f;
            Destroy(go.GetComponent<Collider>());
            go.GetComponent<Renderer>().material = _gemMat;

            // Float + rotate + slow emission breathe
            var bob = go.AddComponent<BobRotate>();
            bob.bobAmplitude = 0.2f;
            bob.bobFrequency = 1.8f;
            bob.rotateDegPerSec = 90f;
            var pulse = go.AddComponent<EmissivePulse>();
            pulse.baseColor = gemColor;
            pulse.minMul = 1.2f;
            pulse.maxMul = 2.2f;
            pulse.frequency = 1.4f;

            _pickables[row, col] = go;
        }

        private void SpawnTrap(Vector3 pos, int row, int col)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = $"Trap_{row}_{col}";
            go.transform.SetParent(transform, true);
            go.transform.position = pos + Vector3.up * 0.04f;
            go.transform.localScale = new Vector3(cellSize * 0.9f, 0.1f, cellSize * 0.9f);
            Destroy(go.GetComponent<Collider>());
            go.GetComponent<Renderer>().material = _trapMat;
            _pickables[row, col] = go;
        }

        private void SpawnTablet(Vector3 basePos, int whisperId)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = $"Tablet_{whisperId}";
            go.transform.SetParent(transform, true);
            go.transform.position = basePos + Vector3.up * 0.9f;
            go.transform.localScale = new Vector3(0.25f, 1.4f, 0.5f);
            Destroy(go.GetComponent<Collider>());

            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            var mat = new Material(shader);
            var col = new Color(0.25f, 0.55f, 0.85f);
            mat.color = col;
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", col);
            if (mat.HasProperty("_EmissionColor"))
            {
                mat.EnableKeyword("_EMISSION");
                mat.SetColor("_EmissionColor", col * 0.9f);
            }
            go.GetComponent<Renderer>().material = mat;

            Tablets.Add(new Tablet { world = basePos + Vector3.up * 1f, whisperId = whisperId });
        }

        // ---------- Decay ----------
        [Header("Decay")]
        [Tooltip("Seconds for a freshly-touched floor tile to fade from bright to dark.")]
        public float decayTime = 18f;
        [Tooltip("Darkness floor tiles settle into after decayTime.")]
        public float decayFloor = 0.15f;

        void Update()
        {
            if (_floorRenderers == null) return;
            // Fade each recently-touched floor tile's color toward dark.
            for (int r = 0; r < _rows; r++)
            {
                for (int c = 0; c < _cols; c++)
                {
                    var rend = _floorRenderers[r, c];
                    if (rend == null) continue;
                    if (_lastTouched[r, c] <= 0) continue;
                    float age = Time.time - _lastTouched[r, c];
                    float k = Mathf.Clamp01(age / decayTime);
                    // original color depends on tile — recompute from palette.
                    Color baseC = _tiles[r, c] switch
                    {
                        Tile.Start => startColor,
                        Tile.Goal  => goalColor,
                        _          => floorColor,
                    };
                    Color dark = baseC * decayFloor;
                    Color cur = Color.Lerp(baseC, dark, k);
                    if (rend.material.HasProperty("_BaseColor"))
                        rend.material.SetColor("_BaseColor", cur);
                    else
                        rend.material.color = cur;
                }
            }
        }

        // Called by ThreeDManager when the player enters a cell — refreshes the decay timer.
        public void TouchCell(Vector2Int rc)
        {
            if (!InBounds(rc)) return;
            _lastTouched[rc.x, rc.y] = Time.time;
        }

        // ---------- Grid API ----------

        public Vector2Int WorldToCell(Vector3 world)
        {
            int c = Mathf.RoundToInt(world.x / cellSize);
            int r = Mathf.RoundToInt(-world.z / cellSize);
            return new Vector2Int(r, c);
        }

        public bool InBounds(int r, int c) => r >= 0 && r < _rows && c >= 0 && c < _cols;
        public bool InBounds(Vector2Int rc) => InBounds(rc.x, rc.y);

        public Tile TileAt(int r, int c) => InBounds(r, c) ? _tiles[r, c] : Tile.Wall;
        public Tile TileAt(Vector2Int rc) => TileAt(rc.x, rc.y);

        public bool CollectGem(Vector2Int rc)
        {
            if (!InBounds(rc) || _tiles[rc.x, rc.y] != Tile.Gem) return false;
            _tiles[rc.x, rc.y] = Tile.Floor;
            if (_pickables[rc.x, rc.y] != null) Destroy(_pickables[rc.x, rc.y]);
            _pickables[rc.x, rc.y] = null;
            return true;
        }

        public Vector3 CellToWorld(int r, int c)
        {
            return new Vector3(c * cellSize, 0, -(r * cellSize));
        }

        public bool WasVisited(int r, int c) => InBounds(r, c) && _lastTouched[r, c] > 0f;

        // Called by ThreeDManager when the player first touches the goal pedestal.
        // Visually "consumes" the prize: pedestal disappears, goal floor dims to
        // a faint glow so the spot is still findable but no longer magnetic.
        public void ClaimGoal()
        {
            if (_goalPedestal != null)
            {
                Destroy(_goalPedestal);
                _goalPedestal = null;
            }
            if (_goalFloorRenderer != null)
            {
                var dim = goalColor * 0.25f;
                if (_goalFloorRenderer.material.HasProperty("_BaseColor"))
                    _goalFloorRenderer.material.SetColor("_BaseColor", dim);
                else
                    _goalFloorRenderer.material.color = dim;
            }
        }

        // A cell with 3+ walkable neighbors — a genuine fork where the player
        // makes a decision. Used as checkpoints for the hold-R retrace.
        public bool IsBranch(int r, int c)
        {
            if (!InBounds(r, c)) return false;
            if (_tiles[r, c] == Tile.Wall) return false;
            int exits = 0;
            if (TileAt(r - 1, c) != Tile.Wall) exits++;
            if (TileAt(r + 1, c) != Tile.Wall) exits++;
            if (TileAt(r, c - 1) != Tile.Wall) exits++;
            if (TileAt(r, c + 1) != Tile.Wall) exits++;
            return exits >= 3;
        }
    }
}
