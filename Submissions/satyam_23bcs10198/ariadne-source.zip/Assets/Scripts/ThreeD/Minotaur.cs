using UnityEngine;

namespace Backtrack.ThreeD
{
    // The pursuer. Spawns a few seconds into the run somewhere behind the
    // player and walks forward along the recorded Ariadne thread — always
    // one step behind you. Speed is slightly less than a walking player, so
    // walking straight buys you time but never outruns it forever.
    //
    // When the player presses R and retraces, the Minotaur is thrown off —
    // your backward motion is faster than its pursuit, so a retrace buys
    // distance. This is the theme: backtracking isn't retreat, it's escape.
    //
    // If it reaches you, GAME OVER.
    public class Minotaur : MonoBehaviour
    {
        [Header("Refs")]
        public Transform player;
        public AriadneThread thread;
        public ThreeDManager manager;

        [Header("Behaviour")]
        public float spawnDelay = 8f;
        public float chaseSpeed = 3.0f;     // slightly slower than player walk (4.5)
        public float catchDistance = 1.2f;
        public Color bodyColor = new Color(0.45f, 0.07f, 0.07f);
        public float bodyHeight = 2.3f;

        private float _timeAlive;
        private int _threadIndex;           // which recorded point we're targeting next
        private bool _spawned;
        private bool _caught;

        public bool IsSpawned => _spawned;
        private Transform _body;
        private Light _eyeLight;

        // Called by ThreeDManager when the player retraces. Resets the
        // Minotaur to the oldest thread point — he has to chase the whole
        // labyrinth again. Freezing during the retrace is handled in Update.
        public void Scatter()
        {
            _threadIndex = 0;
            if (thread != null && thread.Length > 0)
            {
                transform.position = PlayerlikeWorld(thread.GetPoint(0));
            }
        }

        void Start()
        {
            // Invisible / inactive until spawnDelay elapses.
            BuildBody();
            _body.gameObject.SetActive(false);
        }

        void Update()
        {
            if (_caught) return;
            // Retracing disturbs the thread pattern — the Minotaur freezes until
            // the player stops rewinding. Combined with the full reset on R press,
            // a retrace ALWAYS creates distance.
            if (thread != null && thread.IsRewinding) return;

            _timeAlive += Time.deltaTime;

            if (!_spawned && _timeAlive >= spawnDelay && thread != null && thread.Length > 3)
            {
                _spawned = true;
                _threadIndex = 0;                 // start from the oldest thread point
                transform.position = PlayerlikeWorld(thread.GetPoint(_threadIndex));
                _body.gameObject.SetActive(true);
            }
            if (!_spawned) return;

            // If player rewinds, the thread shrinks — clamp the index.
            int maxIdx = Mathf.Max(0, thread.Length - 1);
            if (_threadIndex > maxIdx) _threadIndex = maxIdx;

            Vector3 target = PlayerlikeWorld(thread.GetPoint(_threadIndex));
            Vector3 diff = target - transform.position;
            if (diff.sqrMagnitude < 0.04f && _threadIndex < maxIdx)
            {
                _threadIndex++;
            }
            else
            {
                transform.position += diff.normalized * chaseSpeed * Time.deltaTime;
            }

            // Face the player, and glow the eye-light more intensely as we close in.
            if (player != null)
            {
                Vector3 look = player.position - transform.position; look.y = 0;
                if (look.sqrMagnitude > 0.01f)
                    transform.rotation = Quaternion.LookRotation(look);

                float dist = Vector3.Distance(transform.position, player.position);
                if (_eyeLight) _eyeLight.intensity = Mathf.Lerp(1.0f, 5.0f, Mathf.Clamp01(1f - dist / 10f));

                if (dist < catchDistance)
                {
                    _caught = true;
                    manager?.OnMinotaurCaught();
                }
            }
        }

        private Vector3 PlayerlikeWorld(Vector3 threadPoint)
        {
            return new Vector3(threadPoint.x, 0.9f, threadPoint.z);
        }

        private void BuildBody()
        {
            _body = new GameObject("MinotaurBody").transform;
            _body.SetParent(transform, false);
            _body.localPosition = Vector3.zero;

            // Shadowy column + two red eye lights
            var trunk = GameObject.CreatePrimitive(PrimitiveType.Cube);
            trunk.name = "Trunk";
            trunk.transform.SetParent(_body, false);
            trunk.transform.localPosition = new Vector3(0, bodyHeight * 0.5f, 0);
            trunk.transform.localScale = new Vector3(0.6f, bodyHeight, 0.6f);
            var tr = trunk.GetComponent<Renderer>();
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            var mat = new Material(shader);
            mat.color = bodyColor;
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", bodyColor);
            if (mat.HasProperty("_EmissionColor"))
            {
                mat.EnableKeyword("_EMISSION");
                mat.SetColor("_EmissionColor", bodyColor * 0.4f);
            }
            tr.material = mat;
            Destroy(trunk.GetComponent<Collider>());

            // Single red point-light eye
            var eyeGo = new GameObject("Eye");
            eyeGo.transform.SetParent(_body, false);
            eyeGo.transform.localPosition = new Vector3(0, bodyHeight - 0.25f, 0.35f);
            _eyeLight = eyeGo.AddComponent<Light>();
            _eyeLight.type = LightType.Point;
            _eyeLight.color = new Color(1f, 0.25f, 0.15f);
            _eyeLight.range = 10f;
            _eyeLight.intensity = 1.5f;
        }
    }
}
