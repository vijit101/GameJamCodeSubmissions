using UnityEngine;

namespace Backtrack.ThreeD
{
    // The flashlight dims + flickers as the Minotaur closes in. Pure tension
    // telegraph — no gameplay effect, but you *feel* him before you see him.
    public class FlashlightFlicker : MonoBehaviour
    {
        public Light flashlight;
        public Transform player;
        public Minotaur minotaur;

        [Header("Tuning")]
        public float baseIntensity = 3.5f;
        public float flickerStartDistance = 10f;   // start flickering when Minotaur within this
        public float maxFlickerAmount = 0.55f;     // at zero distance the light dims by this fraction

        void Update()
        {
            if (flashlight == null || player == null) return;

            if (minotaur == null || !minotaur.IsSpawned)
            {
                flashlight.intensity = Mathf.Lerp(flashlight.intensity, baseIntensity, Time.deltaTime * 3f);
                return;
            }

            float d = Vector3.Distance(player.position, minotaur.transform.position);
            if (d > flickerStartDistance)
            {
                flashlight.intensity = Mathf.Lerp(flashlight.intensity, baseIntensity, Time.deltaTime * 3f);
                return;
            }

            float k = 1f - (d / flickerStartDistance);       // 0 far → 1 on top of you
            float flickerSpan = maxFlickerAmount * k;
            float roll = Random.value * flickerSpan;
            flashlight.intensity = baseIntensity * (1f - roll);
        }
    }
}
