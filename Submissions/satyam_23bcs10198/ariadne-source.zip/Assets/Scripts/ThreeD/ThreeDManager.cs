using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Backtrack.ThreeD
{
    // Top-level glue for the 3D labyrinth scene.
    //
    // R key is context-dependent:
    //   • Tap R (under holdThreshold) → scatter Minotaur IF he's within
    //     scatterRadius AND player has >=1 gem. Costs 1 gem.
    //   • Hold R (over holdThreshold) → teleport-retrace to the last visited
    //     branch cell (checkpoint). Thread truncates to that point. No cost.
    public class ThreeDManager : MonoBehaviour
    {
        [Header("Refs")]
        public ThreeDPlayer player;
        public AriadneThread thread;
        public ThreeDDungeon dungeon;
        public Minotaur minotaur;

        [Header("UI")]
        public Text hudText;
        public Text statusText;
        public GameObject winPanel;
        public Text winScoreText;
        public GameObject gameOverPanel;
        public Text gameOverText;
        public GameObject pausePanel;

        [Header("Tuning")]
        public float goalRadius = 1.6f;
        [Tooltip("Max distance to the Minotaur for a tap-R scatter to work.")]
        public float scatterRadius = 10f;
        [Tooltip("Seconds of R-held before it switches from tap-scatter to hold-retrace.")]
        public float holdThreshold = 0.35f;
        [Tooltip("Player starts with this many gems.")]
        public int startingGems = 1;
        [Tooltip("Minotaur speed boost (flat add) once the prize is claimed — makes the escape tense.")]
        public float minotaurEscapeBoost = 0.8f;

        private enum Phase { Search, Escape }
        private Phase _phase = Phase.Search;

        private bool _won;
        private bool _paused;
        private int _gems;
        private Vector2Int _lastCell = new Vector2Int(-1, -1);
        private float _trapCooldown;

        // R key state machine
        private float _rHoldTime;
        private bool  _rRetracedThisHold;

        // Checkpoints — one per branch cell visited, paired with thread length
        // at the moment of entry so we can truncate the thread on retrace.
        private readonly List<Vector2Int> _checkpoints = new();
        private readonly List<int> _checkpointThreadLens = new();

        // Ariadne's whispers — inscribed on tablets throughout the labyrinth.
        private static readonly string[] Whispers =
        {
            "\"You are being watched. The beast knows this thread.\"",
            "\"Every gem is a fallen tribute.  Spend them well.\"",
            "\"Daedalus built this place to forget you.  Only the thread remembers.\"",
            "\"The prize at the heart is not the end.  Do not celebrate.\"",
            "\"Follow me home, Theseus.  Pull the thread.\"",
        };
        private readonly HashSet<int> _readWhispers = new();
        public float tabletReadRadius = 2.2f;

        void Start()
        {
            _gems = startingGems;
            if (dungeon != null && !dungeon.IsReady)
            {
                Debug.LogError("[ThreeDManager] Dungeon didn't initialize — win checks will stay disabled this run.");
            }
            if (dungeon != null && player != null)
            {
                player.TeleportTo(dungeon.StartWorld);
                player.transform.rotation = Quaternion.identity;
            }
            if (winPanel) winPanel.SetActive(false);
            if (gameOverPanel) gameOverPanel.SetActive(false);
            if (pausePanel) pausePanel.SetActive(false);
            if (statusText)
                statusText.text = "Find the amber prize.  Tap R: scatter (-1 gem) · Hold R: retrace · Shift: sprint";
            UpdateHud();
        }

        private void SetPaused(bool p)
        {
            _paused = p;
            Time.timeScale = p ? 0f : 1f;
            if (pausePanel) pausePanel.SetActive(p);
            Cursor.lockState = p ? CursorLockMode.None : CursorLockMode.Locked;
            Cursor.visible   = p;
            if (player != null) player.InputLocked = p;
        }

        public void ResumeFromPause() => SetPaused(false);

        public void OnMinotaurCaught()
        {
            if (_won) return;
            _won = true;
            if (gameOverPanel) gameOverPanel.SetActive(true);
            if (gameOverText)
                gameOverText.text = $"The minotaur found you.\nThread laid: {thread.Length}   💎 {_gems}";
            if (statusText) statusText.text = "";
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            player.InputLocked = true;
        }

        void Update()
        {
            if (_won) return;

            // Escape toggles pause. Works even when InputLocked (so we can
            // still resume); doesn't fire during the intro fade because the
            // intro canvas intercepts Input.anyKeyDown before this runs.
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                SetPaused(!_paused);
                return;
            }
            if (_paused) return;

            UpdateHud();
            if (_trapCooldown > 0) _trapCooldown -= Time.deltaTime;

            HandleRKey();

            // Cell-based pickup / trap / checkpoint
            if (dungeon != null && !thread.IsRewinding)
            {
                var cell = dungeon.WorldToCell(player.transform.position);
                if (cell != _lastCell)
                {
                    _lastCell = cell;
                    dungeon.TouchCell(cell);

                    var tile = dungeon.TileAt(cell);
                    if (tile == ThreeDDungeon.Tile.Gem)
                    {
                        if (dungeon.CollectGem(cell))
                        {
                            _gems++;
                            if (statusText) StartCoroutine(FlashStatus("+1 gem", 1.0f));
                        }
                    }
                    else if (tile == ThreeDDungeon.Tile.Trap && _trapCooldown <= 0)
                    {
                        _trapCooldown = 1.5f;
                        if (statusText) StartCoroutine(FlashStatus("A trap! Retracing…", 1.2f));
                        StartCoroutine(thread.TrapRewindCoroutine(5));
                    }

                    // Record a checkpoint when we enter a branch cell for the first time
                    if (dungeon.IsBranch(cell.x, cell.y) &&
                        (_checkpoints.Count == 0 || _checkpoints[_checkpoints.Count - 1] != cell))
                    {
                        _checkpoints.Add(cell);
                        _checkpointThreadLens.Add(thread.Length);
                    }
                }
            }

            // Tablet proximity — first time within reach of a tablet, read it.
            if (dungeon != null && dungeon.Tablets != null)
            {
                var ppos = player.transform.position;
                for (int i = 0; i < dungeon.Tablets.Count; i++)
                {
                    var t = dungeon.Tablets[i];
                    if (_readWhispers.Contains(t.whisperId)) continue;
                    if (Vector3.Distance(ppos, t.world) > tabletReadRadius) continue;
                    _readWhispers.Add(t.whisperId);
                    if (t.whisperId >= 0 && t.whisperId < Whispers.Length && statusText)
                        StartCoroutine(FlashStatus(Whispers[t.whisperId], 5.0f));
                }
            }

            // Phase-based win check — skip entirely if the dungeon didn't
            // initialize cleanly, otherwise both StartWorld and GoalWorld
            // default to (0,0,0) and the player auto-wins on frame 1.
            if (dungeon != null && dungeon.IsReady)
            {
                var flat = new Vector3(player.transform.position.x, 0, player.transform.position.z);
                if (_phase == Phase.Search)
                {
                    var g = new Vector3(dungeon.GoalWorld.x, 0, dungeon.GoalWorld.z);
                    if (Vector3.Distance(flat, g) < goalRadius) OnClaimGoal();
                }
                else // Escape phase — must reach the start cell
                {
                    var s = new Vector3(dungeon.StartWorld.x, 0, dungeon.StartWorld.z);
                    if (Vector3.Distance(flat, s) < goalRadius) OnEscape();
                }
            }
        }

        // ---------- R KEY STATE MACHINE ----------

        private void HandleRKey()
        {
            if (thread.IsRewinding) return;

            if (Input.GetKey(KeyCode.R))
            {
                _rHoldTime += Time.deltaTime;

                // Once the hold threshold elapses, fire the retrace ONCE and
                // wait for the key to be released before we can fire again.
                if (_rHoldTime >= holdThreshold && !_rRetracedThisHold)
                {
                    _rRetracedThisHold = true;
                    RetraceToLastCheckpoint();
                }
            }

            if (Input.GetKeyUp(KeyCode.R))
            {
                // Tap: short press that never triggered the retrace → scatter attempt.
                if (!_rRetracedThisHold && _rHoldTime > 0f && _rHoldTime < holdThreshold)
                {
                    TryScatterMinotaur();
                }
                _rHoldTime = 0f;
                _rRetracedThisHold = false;
            }
        }

        private void TryScatterMinotaur()
        {
            if (minotaur == null || !minotaur.IsSpawned)
            {
                if (statusText) StartCoroutine(FlashStatus("The Minotaur isn't here yet.", 1.0f));
                return;
            }

            float d = Vector3.Distance(player.transform.position, minotaur.transform.position);
            if (d > scatterRadius)
            {
                if (statusText) StartCoroutine(FlashStatus($"Minotaur too far ({d:0.0}m) — get closer or Hold R to retrace.", 1.4f));
                return;
            }
            if (_gems < 1)
            {
                if (statusText) StartCoroutine(FlashStatus("No gems — can't scatter the Minotaur.", 1.2f));
                return;
            }

            _gems--;
            minotaur.Scatter();
            if (statusText) StartCoroutine(FlashStatus("Gem spent — Minotaur scattered!", 1.2f));
            UpdateHud();
        }

        private void RetraceToLastCheckpoint()
        {
            if (_checkpoints.Count == 0)
            {
                if (statusText) StartCoroutine(FlashStatus("No fork behind you yet.", 1.0f));
                return;
            }

            int last = _checkpoints.Count - 1;
            var cell = _checkpoints[last];
            int threadLen = _checkpointThreadLens[last];
            _checkpoints.RemoveAt(last);
            _checkpointThreadLens.RemoveAt(last);

            // Truncate the thread so the Minotaur's chase target shrinks with it.
            thread.TruncateTo(threadLen);

            // Teleport the player to the checkpoint cell (grid-snapped, eye height).
            var w = dungeon.CellToWorld(cell.x, cell.y);
            player.TeleportTo(new Vector3(w.x, 1f, w.z));

            // Reset cell tracker so entering the checkpoint fires TouchCell etc.
            _lastCell = new Vector2Int(-1, -1);

            if (statusText) StartCoroutine(FlashStatus("Retraced to the last fork.", 1.0f));
        }

        // ---------- UI ----------

        private System.Collections.IEnumerator FlashStatus(string msg, float duration)
        {
            if (statusText == null) yield break;
            string prev = statusText.text;
            statusText.text = msg;
            yield return new WaitForSeconds(duration);
            if (statusText.text == msg) statusText.text = prev;
        }

        private void UpdateHud()
        {
            if (hudText == null || thread == null) return;
            bool inRange = minotaur != null && minotaur.IsSpawned &&
                           Vector3.Distance(player.transform.position, minotaur.transform.position) <= scatterRadius;
            string scatterHint = inRange ? "   <b>[TAP R]</b>" : "";
            string phaseTag = _phase == Phase.Search
                ? "<color=#ffbe4c>SEARCH</color>"
                : "<color=#5cd1ff>ESCAPE</color>";

            // Stamina meter using block glyphs — 8 cells, filled proportional to StaminaPct.
            string staminaBar = "";
            if (player != null)
            {
                int total = 10;
                int filled = Mathf.RoundToInt(player.StaminaPct * total);
                string bar = new string('█', filled) + new string('░', total - filled);
                string color = player.IsSprinting ? "#ff6060" : "#bdbdbd";
                staminaBar = $"\n<color={color}>SHIFT sprint</color>  {bar}";
            }

            hudText.text =
                $"{phaseTag}   Thread: {thread.Length}   💎 {_gems}{scatterHint}{staminaBar}";
            hudText.supportRichText = true;
        }

        // Phase 1 → Phase 2: grabbed the prize, now escape back to the start.
        private void OnClaimGoal()
        {
            if (_phase != Phase.Search) return;
            _phase = Phase.Escape;
            dungeon.ClaimGoal();
            if (minotaur != null) minotaur.chaseSpeed += minotaurEscapeBoost;
            if (statusText) StartCoroutine(FlashStatus(
                "PRIZE TAKEN — now escape back to the entrance!", 3.5f));
        }

        // Phase 2 complete: player made it back to the start cell.
        private void OnEscape()
        {
            if (_won) return;
            _won = true;
            if (winPanel) winPanel.SetActive(true);
            if (winScoreText)
                winScoreText.text =
                    $"ESCAPED THE LABYRINTH\nThread laid: {thread.Length}   💎 {_gems}";
            if (statusText) statusText.text = "Free.";
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            player.InputLocked = true;
        }

        public void Restart() => SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        public void ToMenu()
        {
            if (SceneManager.GetSceneByName("MainMenu").IsValid())
                SceneManager.LoadScene("MainMenu");
        }
    }
}
