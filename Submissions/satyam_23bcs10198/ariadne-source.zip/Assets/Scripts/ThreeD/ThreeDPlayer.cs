using UnityEngine;

namespace Backtrack.ThreeD
{
    // First-person character controller using Unity's built-in CharacterController.
    // Mouse looks, WASD walks, Space jumps. Disabled while rewinding — the
    // AriadneThread coroutine drives the transform during retrace.
    [RequireComponent(typeof(CharacterController))]
    public class ThreeDPlayer : MonoBehaviour
    {
        [Header("Move")]
        public float walkSpeed = 4.5f;
        public float jumpSpeed = 4.5f;
        public float gravity = 14f;

        [Header("Sprint")]
        public float sprintMultiplier = 1.7f;
        public float staminaMax = 100f;
        public float staminaDrainPerSec = 34f;
        public float staminaRegenPerSec = 42f;
        [Tooltip("Stamina must regen above this fraction before sprint re-enables after depletion.")]
        public float staminaLockoutThreshold = 0.25f;

        [Header("Look")]
        public float mouseSensitivity = 1.3f;
        public float pitchClamp = 85f;
        public Transform cameraRoot;

        [Header("Camera feel")]
        public float walkFov = 75f;
        public float sprintFov = 88f;
        public float fovLerpSpeed = 6f;
        public float headBobWalk = 0.03f;
        public float headBobSprint = 0.06f;
        public float headBobFreqWalk = 8f;
        public float headBobFreqSprint = 14f;
        public float cameraBaseY = 1.6f;

        private CharacterController _cc;
        private Camera _cam;
        private Vector3 _velocity;
        private float _pitch;
        private bool _cursorLocked = true;
        private float _stamina;
        private bool _sprintLocked;
        private float _bobTime;

        public bool InputLocked { get; set; }
        public bool IsSprinting { get; private set; }
        public float StaminaPct => staminaMax <= 0 ? 0 : Mathf.Clamp01(_stamina / staminaMax);

        void Awake()
        {
            // Must run in Awake so TeleportTo works from other scripts' Start().
            _cc = GetComponent<CharacterController>();
            if (cameraRoot != null) _cam = cameraRoot.GetComponent<Camera>();
        }

        void Start()
        {
            _stamina = staminaMax;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        void Update()
        {
            // Esc is owned by ThreeDManager (pause menu). No handling here.
            if (InputLocked) return;

            // Mouse look
            float mx = Input.GetAxis("Mouse X") * mouseSensitivity;
            float my = Input.GetAxis("Mouse Y") * mouseSensitivity;
            transform.Rotate(0f, mx, 0f);
            _pitch = Mathf.Clamp(_pitch - my, -pitchClamp, pitchClamp);
            if (cameraRoot) cameraRoot.localRotation = Quaternion.Euler(_pitch, 0f, 0f);

            // Planar move
            float h = Input.GetAxis("Horizontal");
            float v = Input.GetAxis("Vertical");
            Vector3 planar = (transform.right * h + transform.forward * v);
            if (planar.sqrMagnitude > 1f) planar.Normalize();

            // Sprint — Shift while moving, gated by stamina.
            bool wantsSprint = (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
                && planar.sqrMagnitude > 0.01f;
            IsSprinting = wantsSprint && !_sprintLocked && _stamina > 0.01f;
            if (IsSprinting)
            {
                _stamina = Mathf.Max(0f, _stamina - staminaDrainPerSec * Time.deltaTime);
                if (_stamina <= 0f) { _stamina = 0f; _sprintLocked = true; }
            }
            else
            {
                _stamina = Mathf.Min(staminaMax, _stamina + staminaRegenPerSec * Time.deltaTime);
                if (_sprintLocked && StaminaPct >= staminaLockoutThreshold) _sprintLocked = false;
            }

            float speedNow = IsSprinting ? walkSpeed * sprintMultiplier : walkSpeed;
            Vector3 move = planar * speedNow;

            // Gravity + jump
            if (_cc.isGrounded)
            {
                _velocity.y = -1f;
                if (Input.GetKeyDown(KeyCode.Space)) _velocity.y = jumpSpeed;
            }
            else
            {
                _velocity.y -= gravity * Time.deltaTime;
            }

            _cc.Move((move + Vector3.up * _velocity.y) * Time.deltaTime);

            ApplyCameraFeel(planar.sqrMagnitude > 0.01f && _cc.isGrounded);
        }

        private void ApplyCameraFeel(bool moving)
        {
            // FOV lerp — snaps wider while sprinting for a sense of speed.
            if (_cam != null)
            {
                float target = IsSprinting ? sprintFov : walkFov;
                _cam.fieldOfView = Mathf.Lerp(_cam.fieldOfView, target, Time.deltaTime * fovLerpSpeed);
            }

            // Head-bob — sinusoidal vertical jiggle while walking; faster + deeper while sprinting.
            if (cameraRoot == null) return;

            if (moving)
            {
                float freq = IsSprinting ? headBobFreqSprint : headBobFreqWalk;
                float amp  = IsSprinting ? headBobSprint : headBobWalk;
                _bobTime += Time.deltaTime * freq;
                float by = Mathf.Sin(_bobTime) * amp;
                cameraRoot.localPosition = new Vector3(0, cameraBaseY + by, 0);
            }
            else
            {
                cameraRoot.localPosition = Vector3.Lerp(
                    cameraRoot.localPosition,
                    new Vector3(0, cameraBaseY, 0),
                    Time.deltaTime * 6f);
            }
        }

        // Used by AriadneThread during rewind — bypass CharacterController collision.
        public void TeleportTo(Vector3 pos)
        {
            if (_cc == null) _cc = GetComponent<CharacterController>();
            if (_cc != null) _cc.enabled = false;
            transform.position = pos;
            if (_cc != null) _cc.enabled = true;
        }
    }
}
