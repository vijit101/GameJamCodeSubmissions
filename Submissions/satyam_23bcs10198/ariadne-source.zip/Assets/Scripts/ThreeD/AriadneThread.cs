using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Backtrack.ThreeD
{
    // The signature mechanic: a glowing amber/cyan thread auto-unspools
    // behind the player as they walk through the 3D dungeon. Hold R to be
    // pulled back along the thread (popping the DFS stack visually).
    // Every vertex on the LineRenderer is a recorded world-space position
    // sampled at fixed intervals.
    [RequireComponent(typeof(LineRenderer))]
    public class AriadneThread : MonoBehaviour
    {
        [Header("Refs")]
        public Transform player;
        public ThreeDPlayer playerController;

        [Header("Recording")]
        [Tooltip("Seconds between samples while walking.")]
        public float recordInterval = 0.12f;
        [Tooltip("Minimum world-space distance to commit a new point.")]
        public float minDistance = 0.5f;
        [Tooltip("Vertical offset so the thread sits on the ground, not at camera height.")]
        public float groundOffset = -0.8f;

        [Header("Style")]
        public Color threadColor = new Color(1.00f, 0.72f, 0.22f);
        public float threadWidth = 0.10f;

        [Header("Rewind")]
        [Tooltip("Units per second while pulling the player back along the thread.")]
        public float rewindSpeed = 9f;

        private LineRenderer _lr;
        private readonly List<Vector3> _points = new();
        private float _timer;
        private bool _rewinding;

        public bool IsRewinding => _rewinding;
        public int Length => _points.Count;

        public Vector3 GetPoint(int index)
        {
            index = Mathf.Clamp(index, 0, _points.Count - 1);
            return _points.Count == 0 ? Vector3.zero : _points[index];
        }

        // Drops thread points past `targetLength`. Used by the checkpoint
        // retrace: jumps the player back and truncates the thread so the
        // Minotaur's thread-chase target shrinks with it.
        public void TruncateTo(int targetLength)
        {
            if (targetLength < 0) targetLength = 0;
            if (targetLength >= _points.Count) return;
            while (_points.Count > targetLength) _points.RemoveAt(_points.Count - 1);
            _lr.positionCount = _points.Count;
        }

        void Awake()
        {
            _lr = GetComponent<LineRenderer>();
            _lr.material = new Material(Shader.Find("Sprites/Default"));
            _lr.startWidth = threadWidth;
            _lr.endWidth = threadWidth;
            _lr.startColor = threadColor;
            _lr.endColor = threadColor;
            _lr.numCapVertices = 6;
            _lr.numCornerVertices = 4;
            _lr.useWorldSpace = true;
            _lr.positionCount = 0;
            _lr.textureMode = LineTextureMode.Stretch;
        }

        void Start()
        {
            if (player != null) Commit(GroundPos());
        }

        void Update()
        {
            // Pulse the thread color slightly — even when standing still, the
            // silk glows a little brighter and dimmer so it feels alive.
            if (_lr != null)
            {
                float pulse = 0.75f + 0.25f * Mathf.Sin(Time.time * 2.4f);
                Color c = threadColor * pulse;
                c.a = threadColor.a;
                _lr.startColor = c;
                _lr.endColor = c;
            }

            if (player == null || _rewinding) return;

            _timer += Time.deltaTime;
            if (_timer < recordInterval) return;
            _timer = 0f;

            var p = GroundPos();
            if (_points.Count == 0 || Vector3.Distance(_points[_points.Count - 1], p) >= minDistance)
            {
                Commit(p);
            }
        }

        private Vector3 GroundPos() => player.position + Vector3.up * groundOffset;

        private void Commit(Vector3 p)
        {
            _points.Add(p);
            _lr.positionCount = _points.Count;
            _lr.SetPosition(_points.Count - 1, p);
        }

        // Forced mini-rewind triggered by trap hit. Pulls the player back
        // exactly N segments, fast, with no key-hold requirement.
        public IEnumerator TrapRewindCoroutine(int segments)
        {
            if (playerController == null || _points.Count < 2) yield break;
            _rewinding = true;
            playerController.InputLocked = true;

            int target = Mathf.Max(1, _points.Count - segments);
            while (_points.Count > target)
            {
                Vector3 lastPoint = _points[_points.Count - 1];
                Vector3 playerTarget = lastPoint - Vector3.up * groundOffset;
                while ((player.position - playerTarget).sqrMagnitude > 0.02f)
                {
                    Vector3 next = Vector3.MoveTowards(player.position, playerTarget,
                        rewindSpeed * 1.5f * Time.deltaTime);
                    playerController.TeleportTo(next);
                    yield return null;
                }
                _points.RemoveAt(_points.Count - 1);
                _lr.positionCount = _points.Count;
            }

            playerController.InputLocked = false;
            _rewinding = false;
        }

        // Pulls the player backward along the thread. Hold R to keep pulling;
        // the coroutine ends when you release R or when the thread is exhausted.
        public IEnumerator RewindCoroutine()
        {
            if (playerController == null || _points.Count < 2) yield break;
            _rewinding = true;
            playerController.InputLocked = true;

            while (Input.GetKey(KeyCode.R) && _points.Count > 1)
            {
                Vector3 target = _points[_points.Count - 1];
                Vector3 playerTarget = target - Vector3.up * groundOffset;
                while ((player.position - playerTarget).sqrMagnitude > 0.02f && Input.GetKey(KeyCode.R))
                {
                    Vector3 next = Vector3.MoveTowards(player.position, playerTarget, rewindSpeed * Time.deltaTime);
                    playerController.TeleportTo(next);
                    yield return null;
                }
                if (!Input.GetKey(KeyCode.R)) break;

                // Pop the last point — the thread retracts one segment.
                _points.RemoveAt(_points.Count - 1);
                _lr.positionCount = _points.Count;
            }

            playerController.InputLocked = false;
            _rewinding = false;
        }
    }
}
