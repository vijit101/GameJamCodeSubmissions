using UnityEngine;

namespace Backtrack.ThreeD
{
    // Cheap life for pickups — bob up and down while spinning on an axis.
    // Applied to gems, goal pedestals, tablets, anything that should read
    // as "interactive, alive" in an otherwise static labyrinth.
    public class BobRotate : MonoBehaviour
    {
        public float bobAmplitude = 0.18f;
        public float bobFrequency = 1.6f;
        public Vector3 rotateAxis = Vector3.up;
        public float rotateDegPerSec = 75f;

        private Vector3 _basePos;
        private float _rnd;

        void Start()
        {
            _basePos = transform.position;
            _rnd = Random.value * Mathf.PI * 2f;
        }

        void Update()
        {
            transform.position = _basePos + Vector3.up * Mathf.Sin(Time.time * bobFrequency + _rnd) * bobAmplitude;
            transform.Rotate(rotateAxis, rotateDegPerSec * Time.deltaTime, Space.World);
        }
    }
}
