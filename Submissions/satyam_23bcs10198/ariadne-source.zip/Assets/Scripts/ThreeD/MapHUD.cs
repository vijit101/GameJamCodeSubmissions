using UnityEngine;
using UnityEngine.UI;

namespace Backtrack.ThreeD
{
    // Top-down minimap of the labyrinth. Walls hidden (unknown); floor
    // cells only appear once the player has stepped on them (fog of war);
    // the player shows as a bright cyan dot, the Minotaur as bright red.
    // Updates every frame so retraces are visible in real-time — when you
    // press R, you watch your dot slide backward through the graph and
    // the Minotaur dot snap to the labyrinth entrance.
    public class MapHUD : MonoBehaviour
    {
        [Header("Refs")]
        public ThreeDDungeon dungeon;
        public Transform player;
        public Transform minotaur;
        public RawImage target;

        [Header("Look")]
        public int pixelsPerCell = 6;
        public Color colorBg       = new Color(0.02f, 0.02f, 0.03f, 0.92f);
        public Color colorUnknown  = new Color(0.05f, 0.05f, 0.06f, 0.92f);
        public Color colorVisited  = new Color(0.85f, 0.80f, 0.55f, 1f);
        public Color colorStart    = new Color(0.40f, 0.80f, 1.00f, 1f);
        public Color colorGoal     = new Color(1.00f, 0.70f, 0.25f, 1f);
        public Color colorGem      = new Color(0.50f, 0.85f, 1.00f, 1f);
        public Color colorTrap     = new Color(1.00f, 0.25f, 0.25f, 1f);
        public Color colorPlayer   = new Color(0.35f, 1.00f, 0.95f, 1f);
        public Color colorMinotaur = new Color(1.00f, 0.20f, 0.15f, 1f);

        private Texture2D _tex;
        private int _w, _h;

        void Start()
        {
            if (dungeon == null || target == null) return;
            _w = dungeon.Cols * pixelsPerCell;
            _h = dungeon.Rows * pixelsPerCell;
            _tex = new Texture2D(_w, _h, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
            target.texture = _tex;
            target.SetNativeSize();
            target.rectTransform.sizeDelta = new Vector2(_w * 2, _h * 2);
        }

        void Update()
        {
            if (_tex == null) return;
            Render();
            _tex.Apply(false);
        }

        private void Render()
        {
            // Background wash
            var bg = _tex.GetRawTextureData<Color32>();
            Color32 bg32 = (Color32)colorBg;
            for (int i = 0; i < bg.Length; i++) bg[i] = bg32;

            int rows = dungeon.Rows, cols = dungeon.Cols;
            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    var tile = dungeon.TileAt(r, c);
                    if (tile == ThreeDDungeon.Tile.Wall) continue;

                    bool visited = dungeon.WasVisited(r, c);
                    Color fill;
                    if (!visited)
                    {
                        // Unknown floor — very dim so the shape isn't a spoiler.
                        fill = colorUnknown;
                    }
                    else
                    {
                        fill = tile switch
                        {
                            ThreeDDungeon.Tile.Start => colorStart,
                            ThreeDDungeon.Tile.Goal  => colorGoal,
                            ThreeDDungeon.Tile.Gem   => colorGem,
                            ThreeDDungeon.Tile.Trap  => colorTrap,
                            _                        => colorVisited,
                        };
                    }
                    FillCell(r, c, fill);
                }
            }

            // Player + Minotaur dots on top
            DrawDot(player, colorPlayer, 2);
            if (minotaur != null && minotaur.gameObject.activeSelf)
                DrawDot(minotaur, colorMinotaur, 2);
        }

        private void FillCell(int r, int c, Color color)
        {
            // Map y grows upward in the texture; dungeon rows grow DOWN in world.
            int py = (dungeon.Rows - 1 - r) * pixelsPerCell;
            int px = c * pixelsPerCell;
            int sz = pixelsPerCell;
            for (int y = py; y < py + sz; y++)
            {
                for (int x = px; x < px + sz; x++)
                {
                    if ((uint)x < (uint)_w && (uint)y < (uint)_h)
                        _tex.SetPixel(x, y, color);
                }
            }
        }

        private void DrawDot(Transform t, Color color, int radius)
        {
            if (t == null) return;
            var cell = dungeon.WorldToCell(t.position);
            int cx = cell.y * pixelsPerCell + pixelsPerCell / 2;
            int cy = (dungeon.Rows - 1 - cell.x) * pixelsPerCell + pixelsPerCell / 2;
            for (int y = cy - radius; y <= cy + radius; y++)
            {
                for (int x = cx - radius; x <= cx + radius; x++)
                {
                    int dx = x - cx, dy = y - cy;
                    if (dx * dx + dy * dy > radius * radius) continue;
                    if ((uint)x < (uint)_w && (uint)y < (uint)_h)
                        _tex.SetPixel(x, y, color);
                }
            }
        }
    }
}
