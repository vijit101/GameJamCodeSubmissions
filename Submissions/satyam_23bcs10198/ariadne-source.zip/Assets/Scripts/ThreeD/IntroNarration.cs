using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Backtrack.ThreeD
{
    // Full-screen atmospheric narration that plays once at scene start.
    // Locks player input, dims the world, reveals text. Fades out after
    // `totalDuration`. Pressing any key skips.
    public class IntroNarration : MonoBehaviour
    {
        [Header("Refs")]
        public CanvasGroup group;
        public Text narrationText;
        public ThreeDPlayer player;

        [Header("Timing (seconds)")]
        public float totalDuration = 9f;
        public float fadeInDuration = 0.8f;
        public float fadeOutDuration = 1.2f;

        [TextArea(4, 10)]
        public string narration =
            "You enter Minos's labyrinth as tribute.\n" +
            "Ariadne gives you a thread of glowing silk and a single gem.\n\n" +
            "Unspool the thread.  The Minotaur hunts along it.\n" +
            "Tap R with a gem when he draws near — he will scatter.\n" +
            "Hold R to pull yourself back to the last fork.\n" +
            "Hold Shift to sprint when nothing else remains.\n\n" +
            "Find the amber prize at the heart.\n" +
            "Then follow your thread home.";

        void Start()
        {
            if (narrationText) narrationText.text = narration;
            if (group) group.alpha = 0f;
            if (player) player.InputLocked = true;
            StartCoroutine(Play());
        }

        void Update()
        {
            // Skip on any key
            if (Input.anyKeyDown)
            {
                StopAllCoroutines();
                StartCoroutine(FadeOutAndUnlock(0.3f));
            }
        }

        private IEnumerator Play()
        {
            // Fade in
            float t = 0;
            while (t < fadeInDuration)
            {
                t += Time.deltaTime;
                if (group) group.alpha = Mathf.Clamp01(t / fadeInDuration);
                yield return null;
            }
            if (group) group.alpha = 1f;

            // Hold
            float holdDuration = Mathf.Max(0.5f, totalDuration - fadeInDuration - fadeOutDuration);
            yield return new WaitForSeconds(holdDuration);

            yield return FadeOutAndUnlock(fadeOutDuration);
        }

        private IEnumerator FadeOutAndUnlock(float dur)
        {
            float t = 0;
            float startAlpha = group ? group.alpha : 1f;
            while (t < dur)
            {
                t += Time.deltaTime;
                if (group) group.alpha = Mathf.Lerp(startAlpha, 0f, t / dur);
                yield return null;
            }
            if (group) group.alpha = 0f;
            if (player) player.InputLocked = false;
            gameObject.SetActive(false);
        }
    }
}
