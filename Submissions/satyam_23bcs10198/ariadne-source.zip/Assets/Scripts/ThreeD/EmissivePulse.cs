using UnityEngine;

namespace Backtrack.ThreeD
{
    // Makes a renderer's emission color breathe between min/max multipliers.
    // Used on the goal pedestal and the goal floor tile so the prize feels
    // alive — gently pulsing in the dark until claimed.
    public class EmissivePulse : MonoBehaviour
    {
        public Renderer target;
        public Color baseColor = Color.white;
        public float minMul = 0.6f;
        public float maxMul = 1.8f;
        public float frequency = 1.2f;

        private float _phase;

        void Start()
        {
            if (target == null) target = GetComponent<Renderer>();
            _phase = Random.value * Mathf.PI * 2f;
        }

        void Update()
        {
            if (target == null || target.material == null) return;
            float s = (Mathf.Sin(Time.time * frequency + _phase) + 1f) * 0.5f;
            float mul = Mathf.Lerp(minMul, maxMul, s);
            Color c = baseColor * mul;
            var m = target.material;
            if (m.HasProperty("_EmissionColor"))
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", c);
            }
            else
            {
                m.color = c;
            }
        }
    }
}
