using System.Collections.Generic;
using UnityEngine;

namespace Backtrack
{
    // Tracks the player's DFS path as a stack of segments, one per branch.
    // When R is pressed, the top segment is popped — every cell in that
    // segment is re-tinted red in-place so the "dead-end subtree" is visible.
    // Markers are procedural sprites so no prefab wiring is required.
    public class BacktrackManager : MonoBehaviour
    {
        public LevelGrid grid;
        public TreeVisualizer tree; // optional

        [Header("Trail Visuals")]
        public Color activeTrailColor = new Color(0.70f, 0.90f, 1.00f, 0.85f);
        public Color branchTrailColor = new Color(1.00f, 0.85f, 0.25f, 0.95f);
        public Color deadTrailColor   = new Color(1.00f, 0.30f, 0.30f, 0.80f);
        public float markerScale = 0.35f;

        private class Segment
        {
            public Vector2Int branchCell;
            public readonly List<Vector2Int> cellsAfter = new();
        }

        private readonly Stack<Segment> _segments = new();
        private readonly HashSet<Vector2Int> _visited = new();
        private readonly Dictionary<Vector2Int, SpriteRenderer> _markers = new();
        private Sprite _dotSprite;

        public int Depth => Mathf.Max(0, _segments.Count - 1);
        public int VisitedCount => _visited.Count;
        public bool CanPop => _segments.Count > 1;

        void Awake()
        {
            _dotSprite = CreateDotSprite();
        }

        public void Init(Vector2Int start)
        {
            foreach (var sr in _markers.Values)
                if (sr) Destroy(sr.gameObject);
            _markers.Clear();
            _segments.Clear();
            _visited.Clear();

            _visited.Add(start);
            _segments.Push(new Segment { branchCell = start });
            SpawnMarker(start, branchTrailColor);

            tree?.Reset();
            tree?.AddNode(start, Vector2Int.zero, isBranch: true);
        }

        public void OnEnter(Vector2Int cell, Vector2Int from)
        {
            bool firstVisit = _visited.Add(cell);
            bool branch = grid != null && grid.IsBranch(cell, from);

            if (firstVisit && branch)
            {
                _segments.Push(new Segment { branchCell = cell });
                SpawnMarker(cell, branchTrailColor);
                tree?.AddNode(cell, from, isBranch: true);
            }
            else if (firstVisit)
            {
                if (_segments.Count > 0) _segments.Peek().cellsAfter.Add(cell);
                // Path cells no longer spawn dots — the ThreadRenderer draws the path.
                tree?.AddNode(cell, from, isBranch: false);
            }
        }

        // Legacy: pops and tints immediately. Kept for compatibility but unused.
        public bool TryPop(out Vector2Int target)
        {
            if (!TryPopForRewind(out _, out var deadCells, out target)) return false;
            foreach (var c in deadCells) RecolorMarker(c, deadTrailColor);
            return true;
        }

        // Pops the top segment from the DFS stack and returns the cell sequence
        // needed to animate the player walking backward to the parent branch.
        // The caller (PlayerController) walks through walkPath, calling
        // TintCellDead(cell) for each cell that appears in deadCells.
        public bool TryPopForRewind(
            out List<Vector2Int> walkPath,
            out List<Vector2Int> deadCells,
            out Vector2Int finalCell)
        {
            walkPath = null;
            deadCells = null;
            finalCell = default;

            if (_segments.Count <= 1) return false;

            var dead = _segments.Pop();
            var parent = _segments.Peek();

            walkPath = new List<Vector2Int>();
            deadCells = new List<Vector2Int>();

            // Walk backward through dead.cellsAfter (skipping the last — the
            // player is already standing on it), then through dead.branchCell,
            // then through parent.cellsAfter in reverse, ending at parent.branchCell.
            if (dead.cellsAfter.Count > 0)
            {
                for (int i = dead.cellsAfter.Count - 2; i >= 0; i--)
                {
                    walkPath.Add(dead.cellsAfter[i]);
                    deadCells.Add(dead.cellsAfter[i]);
                }
                walkPath.Add(dead.branchCell);
                deadCells.Add(dead.branchCell);
                deadCells.Add(dead.cellsAfter[dead.cellsAfter.Count - 1]); // current cell also tints red
            }
            else
            {
                walkPath.Add(dead.branchCell);
                deadCells.Add(dead.branchCell);
            }

            for (int i = parent.cellsAfter.Count - 1; i >= 0; i--)
                walkPath.Add(parent.cellsAfter[i]);
            walkPath.Add(parent.branchCell);

            finalCell = parent.branchCell;
            tree?.MarkDeadEnd(finalCell);
            return true;
        }

        // Called by PlayerController during the rewind coroutine to progressively
        // tint cells as the player walks backward through them.
        public void TintCellDead(Vector2Int cell) => RecolorMarker(cell, deadTrailColor);

        // --- marker helpers ---

        private void SpawnMarker(Vector2Int cell, Color color)
        {
            if (grid == null) return;
            if (_markers.TryGetValue(cell, out var existing) && existing != null)
            {
                existing.color = color;
                return;
            }

            var go = new GameObject($"Trail_{cell.x}_{cell.y}");
            go.transform.SetParent(transform, false);
            go.transform.position = grid.CellToWorld(cell) + new Vector3(0f, 0f, -0.1f);
            go.transform.localScale = Vector3.one * markerScale;

            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = _dotSprite;
            sr.color = color;
            sr.sortingOrder = 5;
            _markers[cell] = sr;
        }

        private void RecolorMarker(Vector2Int cell, Color color)
        {
            if (_markers.TryGetValue(cell, out var sr) && sr != null)
                sr.color = color;
        }

        private static Sprite CreateDotSprite()
        {
            const int size = 16;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
            var pixels = new Color32[size * size];
            float r = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x + 0.5f - r, dy = y + 0.5f - r;
                    float d = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1f - (d / (r - 0.5f)));
                    pixels[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }
            tex.SetPixels32(pixels);
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        }
    }
}
