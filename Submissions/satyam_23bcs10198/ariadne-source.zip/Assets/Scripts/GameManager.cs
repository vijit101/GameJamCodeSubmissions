using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Backtrack
{
    public class GameManager : MonoBehaviour
    {
        [Header("Refs")]
        public PlayerController player;
        public LevelGrid grid;
        public BacktrackManager backtrack;
        public AudioManager audioManager;

        [Header("UI")]
        public GameObject gameOverPanel;
        public GameObject winPanel;
        public Text statusText;
        public Text hudText;        // live: "Depth: 3   Backtracks left: 2/5"
        public Text winSummary;     // on win: "Backtracks used: 3   Par: 2"

        [Header("Scenes")]
        public string[] levelScenes = { "Level1", "Level2", "Level3" };
        public string winScene = "WinScreen";
        public string menuScene = "MainMenu";

        private int _backtracksUsed;
        private bool _levelOver;

        void Start()
        {
            if (gameOverPanel) gameOverPanel.SetActive(false);
            if (winPanel)      winPanel.SetActive(false);
            if (statusText)    statusText.text = "";
            _backtracksUsed = 0;
            _levelOver = false;
            UpdateHud();
        }

        void Update()
        {
            UpdateHud();
        }

        private void UpdateHud()
        {
            if (hudText == null || backtrack == null || grid == null) return;
            int remaining = Mathf.Max(0, grid.maxBacktracks - _backtracksUsed);
            hudText.text =
                $"Depth: {backtrack.Depth}   Backtracks left: {remaining}/{grid.maxBacktracks}";
        }

        // Called by PlayerController before attempting a pop.
        // Returns false if the player has no backtracks left.
        public bool RequestBacktrack()
        {
            if (_levelOver) return false;
            if (grid == null) return true;
            if (backtrack != null && !backtrack.CanPop) return false;

            if (_backtracksUsed >= grid.maxBacktracks)
            {
                if (statusText) statusText.text = "No backtracks left!";
                OnBacktracksExhausted();
                return false;
            }
            _backtracksUsed++;
            audioManager?.PlayBack();
            return true;
        }

        public void OnTrap()
        {
            if (_levelOver) return;
            _levelOver = true;
            audioManager?.PlayLose();
            if (gameOverPanel) gameOverPanel.SetActive(true);
            if (statusText) statusText.text = "Caught by a trap. Backtrack earlier next time.";
            Time.timeScale = 0f;
        }

        private void OnBacktracksExhausted()
        {
            if (_levelOver) return;
            _levelOver = true;
            audioManager?.PlayLose();
            if (gameOverPanel) gameOverPanel.SetActive(true);
            if (statusText) statusText.text = "Out of backtracks. The stack is empty.";
            Time.timeScale = 0f;
        }

        public void OnGoal()
        {
            if (_levelOver) return;
            _levelOver = true;
            audioManager?.PlayWin();
            if (winPanel) winPanel.SetActive(true);
            if (winSummary && grid)
                winSummary.text = $"Backtracks used: {_backtracksUsed}   Par: {grid.par}";
            if (statusText) statusText.text = "Goal reached.";
            Time.timeScale = 0f;
        }

        // --- scene transitions ---

        public void Restart()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        public void NextLevel()
        {
            Time.timeScale = 1f;
            string current = SceneManager.GetActiveScene().name;
            for (int i = 0; i < levelScenes.Length; i++)
            {
                if (levelScenes[i] == current)
                {
                    if (i + 1 < levelScenes.Length)
                    {
                        SceneManager.LoadScene(levelScenes[i + 1]);
                        return;
                    }
                    SceneManager.LoadScene(winScene);
                    return;
                }
            }
            SceneManager.LoadScene(menuScene);
        }

        public void ToMenu()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(menuScene);
        }

        public void StartGame() => SceneManager.LoadScene(levelScenes[0]);
        public void Quit() => Application.Quit();
    }
}
