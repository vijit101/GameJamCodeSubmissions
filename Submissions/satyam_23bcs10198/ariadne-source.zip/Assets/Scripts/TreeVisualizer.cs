using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Backtrack
{
    // Side-panel UI that draws the DFS exploration tree as the player plays.
    // Green = active path, red = dead-end subtree, grey = freshly added.
    // Each node is a UI Image parented under 'nodeRoot'; connections are
    // thin UI Images stretched between parent and child.
    public class TreeVisualizer : MonoBehaviour
    {
        [Header("Refs")]
        public RectTransform nodeRoot;
        public GameObject nodePrefab;  // simple Image with 20x20 size
        public GameObject edgePrefab;  // Image, anchored center, pivot 0.5,0.5

        [Header("Layout")]
        public float nodeSpacing = 28f;

        [Header("Colors")]
        public Color currentColor = new Color(0.2f, 0.9f, 0.4f);
        public Color branchColor  = new Color(0.9f, 0.8f, 0.2f);
        public Color pathColor    = new Color(0.7f, 0.7f, 0.7f);
        public Color deadColor    = new Color(0.9f, 0.3f, 0.3f);

        private class Node
        {
            public Vector2Int cell;
            public Vector2Int parentCell;
            public RectTransform rt;
            public Image img;
            public int depth;
            public bool isBranch;
            public bool isDead;
        }

        private readonly Dictionary<Vector2Int, Node> _nodes = new();
        private readonly List<Image> _edges = new();
        private Vector2Int _current;

        public void Reset()
        {
            foreach (var n in _nodes.Values) if (n.rt) Destroy(n.rt.gameObject);
            foreach (var e in _edges)        if (e)    Destroy(e.gameObject);
            _nodes.Clear();
            _edges.Clear();
        }

        public void AddNode(Vector2Int cell, Vector2Int parent, bool isBranch)
        {
            if (_nodes.ContainsKey(cell)) { SetCurrent(cell); return; }
            if (nodeRoot == null || nodePrefab == null) return;

            int depth = _nodes.TryGetValue(parent, out var p) ? p.depth + 1 : 0;
            var go = Instantiate(nodePrefab, nodeRoot);
            var rt = (RectTransform)go.transform;
            rt.anchoredPosition = LayoutFor(depth, _nodes.Count);

            var img = go.GetComponent<Image>();
            var node = new Node
            {
                cell = cell, parentCell = parent, rt = rt, img = img,
                depth = depth, isBranch = isBranch
            };
            _nodes[cell] = node;
            img.color = isBranch ? branchColor : pathColor;

            if (p != null && edgePrefab != null)
            {
                var edgeGo = Instantiate(edgePrefab, nodeRoot);
                var edge = edgeGo.GetComponent<Image>();
                DrawEdge(edge, p.rt.anchoredPosition, rt.anchoredPosition);
                _edges.Add(edge);
            }

            SetCurrent(cell);
        }

        public void MarkDeadEnd(Vector2Int backTo)
        {
            foreach (var n in _nodes.Values)
            {
                if (n.depth > (_nodes.TryGetValue(backTo, out var b) ? b.depth : 0)
                    && !n.isDead)
                {
                    n.isDead = true;
                    if (n.img) n.img.color = deadColor;
                }
            }
            SetCurrent(backTo);
        }

        private void SetCurrent(Vector2Int cell)
        {
            _current = cell;
            foreach (var n in _nodes.Values)
            {
                if (n.isDead) continue;
                if (n.cell == cell) n.img.color = currentColor;
                else                n.img.color = n.isBranch ? branchColor : pathColor;
            }
        }

        private Vector2 LayoutFor(int depth, int total)
        {
            return new Vector2(depth * nodeSpacing, -total * nodeSpacing * 0.6f);
        }

        private void DrawEdge(Image edge, Vector2 a, Vector2 b)
        {
            var rt = (RectTransform)edge.transform;
            Vector2 mid = (a + b) * 0.5f;
            Vector2 delta = b - a;
            rt.anchoredPosition = mid;
            rt.sizeDelta = new Vector2(delta.magnitude, 2f);
            rt.localEulerAngles = new Vector3(0, 0, Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg);
        }
    }
}
