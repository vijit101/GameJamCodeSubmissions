#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Backtrack.EditorTools
{
    // Headless scene generator. Builds MainMenu, Level1-3, WinScreen scenes
    // with Canvas UI, all references wired, camera framed, and registers them
    // in EditorBuildSettings. Run via:
    //   Unity -batchmode -quit -projectPath <path> \
    //         -executeMethod Backtrack.EditorTools.SceneBuilder.BuildAll
    public static class SceneBuilder
    {
        private const string ScenesDir = "Assets/Scenes";

        // Per-level layouts override LevelGrid defaults.
        private static readonly (string name, string[] layout, int par, int maxBacktracks)[] Levels =
        {
            ("Level1",
             new[]
             {
                 "###############",
                 "#S....#.......#",
                 "#.###.#.#####.#",
                 "#.#.#.....#...#",
                 "#.#.#####.#.#.#",
                 "#.#.......#.X.#",
                 "#.#########.#.#",
                 "#.....X.....#.#",
                 "#####.#######.#",
                 "#............G#",
                 "###############",
             }, par: 2, maxBacktracks: 5),

            ("Level2",
             new[]
             {
                 "#################",
                 "#S..#.....#.....#",
                 "#.#.#.###.#.###.#",
                 "#.#.#.#.#.#.#X#.#",
                 "#.#.#.#.#.#.#.#.#",
                 "#.#...#...#...#.#",
                 "#.#####.#####.#.#",
                 "#.......X.....#.#",
                 "#.###########.#.#",
                 "#.............#G#",
                 "#################",
             }, par: 3, maxBacktracks: 6),

            ("Level3",
             new[]
             {
                 "###################",
                 "#S......#.........#",
                 "#.#####.#.#######.#",
                 "#.#...#.#.#.....#.#",
                 "#.#.#.#.#.#.###.#.#",
                 "#.#.#.#.#.#.#X#.#.#",
                 "#.#.#...#...#.#...#",
                 "#.#.#####.###.#.###",
                 "#.#.......X...#...#",
                 "#.#############.#.#",
                 "#...............#G#",
                 "###################",
             }, par: 5, maxBacktracks: 8),
        };

        [MenuItem("Backtrack/Build All Scenes")]
        public static void BuildAll()
        {
            Directory.CreateDirectory(ScenesDir);

            var scenePaths = new List<string>();

            scenePaths.Add(BuildMenuScene("MainMenu"));
            foreach (var l in Levels)
                scenePaths.Add(BuildGameplayScene(l.name, l.layout, l.par, l.maxBacktracks));
            scenePaths.Add(BuildWinScreen("WinScreen"));
            scenePaths.Add(BuildThreeDScene("ThreeD"));

            // Register every scene in Build Settings
            var editorScenes = new List<EditorBuildSettingsScene>();
            foreach (var path in scenePaths)
                editorScenes.Add(new EditorBuildSettingsScene(path, true));
            EditorBuildSettings.scenes = editorScenes.ToArray();

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log($"[SceneBuilder] Built {scenePaths.Count} scenes.");
        }

        // ---------- Scene: gameplay ----------

        private static string BuildGameplayScene(string name, string[] layout, int par, int maxBacktracks)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Camera
            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = Mathf.Max(6f, layout.Length * 0.55f);
            cam.backgroundColor = new Color(0.06f, 0.06f, 0.08f);
            cam.clearFlags = CameraClearFlags.SolidColor;
            camGo.AddComponent<AudioListener>();

            // Grid
            var gridGo = new GameObject("Grid");
            var grid = gridGo.AddComponent<LevelGrid>();
            grid.layout = layout;
            grid.par = par;
            grid.maxBacktracks = maxBacktracks;

            // Frame camera on the maze
            int w = layout[0].Length, h = layout.Length;
            camGo.transform.position = new Vector3((w - 1) * 0.5f, (h - 1) * 0.5f, -10f);

            // Player
            var playerGo = new GameObject("Player");
            playerGo.AddComponent<SpriteRenderer>();
            var player = playerGo.AddComponent<PlayerController>();
            player.grid = grid;

            // BacktrackManager
            var btGo = new GameObject("BacktrackManager");
            var bt = btGo.AddComponent<BacktrackManager>();
            bt.grid = grid;

            // AudioManager
            var amGo = new GameObject("AudioManager");
            var src = amGo.AddComponent<AudioSource>();
            src.playOnAwake = false;
            var am = amGo.AddComponent<AudioManager>();
            am.source = src;

            // GameManager
            var gmGo = new GameObject("GameManager");
            var gm = gmGo.AddComponent<GameManager>();
            gm.player = player;
            gm.grid = grid;
            gm.backtrack = bt;
            gm.audioManager = am;

            player.backtrack = bt;
            player.game = gm;

            // Canvas + HUD
            BuildCanvas(gm, par, maxBacktracks);

            // Save
            string path = $"{ScenesDir}/{name}.unity";
            EditorSceneManager.SaveScene(scene, path);
            return path;
        }

        private static void BuildCanvas(GameManager gm, int par, int maxBacktracks)
        {
            var canvasGo = new GameObject("Canvas",
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);

            // EventSystem
            var es = new GameObject("EventSystem",
                typeof(UnityEngine.EventSystems.EventSystem),
                typeof(UnityEngine.EventSystems.StandaloneInputModule));

            // HUD text (top-left)
            var hud = MakeText(canvasGo.transform, "HudText",
                $"Depth: 0   Backtracks left: {maxBacktracks}/{maxBacktracks}",
                anchorMin: new Vector2(0, 1), anchorMax: new Vector2(0, 1),
                pivot: new Vector2(0, 1),
                anchoredPos: new Vector2(24, -24),
                size: new Vector2(700, 60),
                fontSize: 32,
                align: TextAnchor.UpperLeft);
            gm.hudText = hud;

            // Status text (bottom-center)
            var status = MakeText(canvasGo.transform, "StatusText", "",
                anchorMin: new Vector2(0.5f, 0), anchorMax: new Vector2(0.5f, 0),
                pivot: new Vector2(0.5f, 0),
                anchoredPos: new Vector2(0, 40),
                size: new Vector2(900, 50),
                fontSize: 28,
                align: TextAnchor.LowerCenter);
            gm.statusText = status;

            // Top-right helper: controls
            MakeText(canvasGo.transform, "Controls",
                "WASD / Arrows: Move\nR: Backtrack\nEsc: Menu",
                anchorMin: new Vector2(1, 1), anchorMax: new Vector2(1, 1),
                pivot: new Vector2(1, 1),
                anchoredPos: new Vector2(-24, -24),
                size: new Vector2(380, 120),
                fontSize: 22,
                align: TextAnchor.UpperRight);

            // Game Over panel
            var over = MakePanel(canvasGo.transform, "GameOverPanel",
                new Color(0, 0, 0, 0.75f));
            MakeText(over.transform, "Title", "GAME OVER",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 120),
                size: new Vector2(800, 120),
                fontSize: 84,
                align: TextAnchor.MiddleCenter,
                color: new Color(1f, 0.35f, 0.35f));
            MakeButton(over.transform, "RestartBtn", "Restart",
                new Vector2(0, -40), gm, nameof(GameManager.Restart));
            MakeButton(over.transform, "MenuBtn", "Main Menu",
                new Vector2(0, -130), gm, nameof(GameManager.ToMenu));
            over.SetActive(false);
            gm.gameOverPanel = over;

            // Win panel
            var win = MakePanel(canvasGo.transform, "WinPanel",
                new Color(0, 0, 0, 0.75f));
            MakeText(win.transform, "Title", "LEVEL CLEAR",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 180),
                size: new Vector2(800, 120),
                fontSize: 84,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.35f, 1f, 0.55f));
            var summary = MakeText(win.transform, "Summary", "",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 60),
                size: new Vector2(800, 60),
                fontSize: 32,
                align: TextAnchor.MiddleCenter);
            gm.winSummary = summary;
            MakeButton(win.transform, "NextBtn", "Next Level",
                new Vector2(0, -40), gm, nameof(GameManager.NextLevel));
            MakeButton(win.transform, "MenuBtn", "Main Menu",
                new Vector2(0, -130), gm, nameof(GameManager.ToMenu));
            win.SetActive(false);
            gm.winPanel = win;
        }

        // ---------- Scene: main menu ----------

        private static string BuildMenuScene(string name)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.06f, 0.06f, 0.08f);
            camGo.transform.position = new Vector3(0, 0, -10);
            camGo.AddComponent<AudioListener>();

            var gmGo = new GameObject("GameManager");
            var gm = gmGo.AddComponent<GameManager>();
            // This branch ships the 3D Ariadne labyrinth.
            gm.levelScenes = new[] { "ThreeD" };

            var canvasGo = new GameObject("Canvas",
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);

            new GameObject("EventSystem",
                typeof(UnityEngine.EventSystems.EventSystem),
                typeof(UnityEngine.EventSystems.StandaloneInputModule));

            MakeText(canvasGo.transform, "Title", "ARIADNE",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 200),
                size: new Vector2(1000, 160),
                fontSize: 120,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.95f, 0.85f, 0.35f));

            MakeText(canvasGo.transform, "Tagline", "a 3D labyrinth of Minos — after the myth of Theseus, Ariadne, and the Minotaur",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 100),
                size: new Vector2(1400, 50),
                fontSize: 26,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.85f, 0.75f, 0.55f));

            MakeText(canvasGo.transform, "Lore",
                "You enter Minos's labyrinth as tribute.\n" +
                "Ariadne has given you a thread of glowing silk and a single gem.\n\n" +
                "Unspool the thread. The Minotaur hunts along it.\n" +
                "Find the prize at the heart — then follow your thread home.",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, -10),
                size: new Vector2(1200, 220),
                fontSize: 26,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.75f, 0.75f, 0.80f));

            MakeButton(canvasGo.transform, "StartBtn", "Enter",
                new Vector2(0, -180), gm, nameof(GameManager.StartGame));
            MakeButton(canvasGo.transform, "QuitBtn", "Quit",
                new Vector2(0, -270), gm, nameof(GameManager.Quit));

            string path = $"{ScenesDir}/{name}.unity";
            EditorSceneManager.SaveScene(scene, path);
            return path;
        }

        // ---------- Scene: win screen ----------

        private static string BuildWinScreen(string name)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.04f, 0.06f, 0.04f);
            camGo.transform.position = new Vector3(0, 0, -10);
            camGo.AddComponent<AudioListener>();

            var gmGo = new GameObject("GameManager");
            var gm = gmGo.AddComponent<GameManager>();

            var canvasGo = new GameObject("Canvas",
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);

            new GameObject("EventSystem",
                typeof(UnityEngine.EventSystems.EventSystem),
                typeof(UnityEngine.EventSystems.StandaloneInputModule));

            MakeText(canvasGo.transform, "Title", "ALL BRANCHES SOLVED",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 100),
                size: new Vector2(1400, 160),
                fontSize: 90,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.35f, 1f, 0.55f));

            MakeButton(canvasGo.transform, "MenuBtn", "Main Menu",
                new Vector2(0, -60), gm, nameof(GameManager.ToMenu));

            string path = $"{ScenesDir}/{name}.unity";
            EditorSceneManager.SaveScene(scene, path);
            return path;
        }

        // ---------- Scene: 3D labyrinth (Ariadne's thread) ----------

        private static string BuildThreeDScene(string name)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Ambient + directional light — dim so the player's flashlight pops.
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.06f, 0.05f, 0.04f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Exponential;
            RenderSettings.fogColor = new Color(0.02f, 0.02f, 0.03f);
            RenderSettings.fogDensity = 0.08f;

            var dirGo = new GameObject("DirectionalLight");
            var dir = dirGo.AddComponent<Light>();
            dir.type = LightType.Directional;
            dir.intensity = 0.15f;
            dir.color = new Color(0.5f, 0.6f, 0.8f);
            dirGo.transform.rotation = Quaternion.Euler(55f, -35f, 0f);

            // Dungeon
            var dungeonGo = new GameObject("Dungeon");
            var dungeon = dungeonGo.AddComponent<Backtrack.ThreeD.ThreeDDungeon>();

            // Player (Capsule + CharacterController + camera + flashlight)
            var playerGo = new GameObject("Player");
            var cc = playerGo.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.35f;
            cc.center = new Vector3(0, 0.9f, 0);
            var player = playerGo.AddComponent<Backtrack.ThreeD.ThreeDPlayer>();
            playerGo.transform.position = new Vector3(0, 1f, 0);

            // Camera as child of player
            var camGo = new GameObject("MainCamera");
            camGo.tag = "MainCamera";
            camGo.transform.SetParent(playerGo.transform, false);
            camGo.transform.localPosition = new Vector3(0, 1.6f, 0);
            var cam = camGo.AddComponent<Camera>();
            cam.fieldOfView = 75f;
            cam.farClipPlane = 50f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.01f, 0.01f, 0.02f);
            camGo.AddComponent<AudioListener>();
            player.cameraRoot = camGo.transform;

            // Flashlight — spotlight on the camera
            var flashGo = new GameObject("Flashlight");
            flashGo.transform.SetParent(camGo.transform, false);
            var flash = flashGo.AddComponent<Light>();
            flash.type = LightType.Spot;
            flash.range = 14f;
            flash.spotAngle = 70f;
            flash.innerSpotAngle = 40f;
            flash.intensity = 3.5f;
            flash.color = new Color(1f, 0.92f, 0.78f);

            // Flashlight flicker — dims + flickers when Minotaur approaches
            var flick = flashGo.AddComponent<Backtrack.ThreeD.FlashlightFlicker>();
            flick.flashlight = flash;
            flick.player = playerGo.transform;
            // minotaur wired below once the GO exists

            // Thread (LineRenderer) — separate GO so its transform is independent
            var threadGo = new GameObject("AriadneThread");
            var lr = threadGo.AddComponent<LineRenderer>();
            var thread = threadGo.AddComponent<Backtrack.ThreeD.AriadneThread>();
            thread.player = playerGo.transform;
            thread.playerController = player;

            // Minotaur
            var minotaurGo = new GameObject("Minotaur");
            var minotaur = minotaurGo.AddComponent<Backtrack.ThreeD.Minotaur>();
            minotaur.player = playerGo.transform;
            minotaur.thread = thread;
            flick.minotaur = minotaur;

            // Manager
            var mgrGo = new GameObject("ThreeDManager");
            var mgr = mgrGo.AddComponent<Backtrack.ThreeD.ThreeDManager>();
            mgr.player = player;
            mgr.thread = thread;
            mgr.dungeon = dungeon;
            mgr.minotaur = minotaur;
            minotaur.manager = mgr;

            // Canvas HUD
            var canvasGo = new GameObject("Canvas",
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);

            new GameObject("EventSystem",
                typeof(UnityEngine.EventSystems.EventSystem),
                typeof(UnityEngine.EventSystems.StandaloneInputModule));

            var hud = MakeText(canvasGo.transform, "HudText", "Thread: 0",
                anchorMin: new Vector2(0, 1), anchorMax: new Vector2(0, 1),
                pivot: new Vector2(0, 1),
                anchoredPos: new Vector2(24, -24),
                size: new Vector2(600, 60),
                fontSize: 32,
                align: TextAnchor.UpperLeft,
                color: new Color(1f, 0.78f, 0.3f));
            mgr.hudText = hud;

            var status = MakeText(canvasGo.transform, "StatusText",
                "WASD + mouse to walk.  Hold R to follow the thread back.",
                anchorMin: new Vector2(0.5f, 0), anchorMax: new Vector2(0.5f, 0),
                pivot: new Vector2(0.5f, 0),
                anchoredPos: new Vector2(0, 40),
                size: new Vector2(1400, 50),
                fontSize: 26,
                align: TextAnchor.LowerCenter);
            mgr.statusText = status;

            // Minimap (top-right) — RawImage backed by a dynamically-drawn Texture2D
            var mapGo = new GameObject("Minimap", typeof(RectTransform), typeof(RawImage));
            mapGo.transform.SetParent(canvasGo.transform, false);
            var mapRt = (RectTransform)mapGo.transform;
            mapRt.anchorMin = new Vector2(1, 1);
            mapRt.anchorMax = new Vector2(1, 1);
            mapRt.pivot = new Vector2(1, 1);
            mapRt.anchoredPosition = new Vector2(-24, -24);
            mapRt.sizeDelta = new Vector2(320, 320);
            var mapImage = mapGo.GetComponent<RawImage>();
            mapImage.color = Color.white;
            var mapHud = mapGo.AddComponent<Backtrack.ThreeD.MapHUD>();
            mapHud.dungeon = dungeon;
            mapHud.player = playerGo.transform;
            mapHud.minotaur = minotaurGo.transform;
            mapHud.target = mapImage;

            // "Map" label above the minimap
            MakeText(canvasGo.transform, "MapLabel", "MAP",
                anchorMin: new Vector2(1, 1), anchorMax: new Vector2(1, 1),
                pivot: new Vector2(1, 1),
                anchoredPos: new Vector2(-180, -2),
                size: new Vector2(160, 30),
                fontSize: 20,
                align: TextAnchor.UpperRight,
                color: new Color(0.95f, 0.80f, 0.55f, 0.9f));

            // Reticle dot at center of screen
            MakeText(canvasGo.transform, "Reticle", "+",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: Vector2.zero,
                size: new Vector2(40, 40),
                fontSize: 32,
                align: TextAnchor.MiddleCenter,
                color: new Color(1f, 0.9f, 0.5f, 0.7f));

            // Win panel
            var win = MakePanel(canvasGo.transform, "WinPanel",
                new Color(0, 0, 0, 0.78f));
            MakeText(win.transform, "Title", "OUT OF THE LABYRINTH",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 120),
                size: new Vector2(1200, 120),
                fontSize: 72,
                align: TextAnchor.MiddleCenter,
                color: new Color(1f, 0.75f, 0.30f));
            var winScore = MakeText(win.transform, "WinScore", "",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 20),
                size: new Vector2(900, 60),
                fontSize: 34,
                align: TextAnchor.MiddleCenter);
            mgr.winScoreText = winScore;
            MakeThreeDButton(win.transform, "RestartBtn", "Run Again",
                new Vector2(0, -80), mgr, nameof(Backtrack.ThreeD.ThreeDManager.Restart));
            win.SetActive(false);
            mgr.winPanel = win;

            // Intro narration — fades in, holds, fades out, unlocks input
            var introGo = new GameObject("IntroNarration", typeof(RectTransform), typeof(CanvasGroup), typeof(Image));
            introGo.transform.SetParent(canvasGo.transform, false);
            var introRt = (RectTransform)introGo.transform;
            introRt.anchorMin = Vector2.zero;
            introRt.anchorMax = Vector2.one;
            introRt.offsetMin = Vector2.zero;
            introRt.offsetMax = Vector2.zero;
            introGo.GetComponent<Image>().color = new Color(0.01f, 0.01f, 0.02f, 0.95f);
            var introGroup = introGo.GetComponent<CanvasGroup>();
            var introText = MakeText(introGo.transform, "NarrationText",
                "",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: Vector2.zero,
                size: new Vector2(1200, 500),
                fontSize: 30,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.85f, 0.80f, 0.55f));
            var introComp = introGo.AddComponent<Backtrack.ThreeD.IntroNarration>();
            introComp.group = introGroup;
            introComp.narrationText = introText;
            introComp.player = player;
            MakeText(introGo.transform, "SkipHint",
                "press any key to skip",
                anchorMin: new Vector2(0.5f, 0), anchorMax: new Vector2(0.5f, 0),
                pivot: new Vector2(0.5f, 0),
                anchoredPos: new Vector2(0, 60),
                size: new Vector2(600, 30),
                fontSize: 20,
                align: TextAnchor.LowerCenter,
                color: new Color(0.6f, 0.6f, 0.6f));

            // Game Over panel (Minotaur got you)
            var over = MakePanel(canvasGo.transform, "GameOverPanel",
                new Color(0.10f, 0.01f, 0.01f, 0.90f));
            MakeText(over.transform, "Title", "THE MINOTAUR FOUND YOU",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 120),
                size: new Vector2(1400, 120),
                fontSize: 64,
                align: TextAnchor.MiddleCenter,
                color: new Color(1f, 0.25f, 0.2f));
            var overBody = MakeText(over.transform, "OverText", "",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 20),
                size: new Vector2(900, 80),
                fontSize: 32,
                align: TextAnchor.MiddleCenter);
            mgr.gameOverText = overBody;
            MakeThreeDButton(over.transform, "RestartBtnOver", "Try Again",
                new Vector2(0, -80), mgr, nameof(Backtrack.ThreeD.ThreeDManager.Restart));
            over.SetActive(false);
            mgr.gameOverPanel = over;

            // Pause panel — Escape during gameplay brings this up
            var pause = MakePanel(canvasGo.transform, "PausePanel",
                new Color(0.02f, 0.02f, 0.03f, 0.92f));
            MakeText(pause.transform, "Title", "PAUSED",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 300),
                size: new Vector2(1200, 100),
                fontSize: 72,
                align: TextAnchor.MiddleCenter,
                color: new Color(1f, 0.85f, 0.45f));
            MakeText(pause.transform, "Subtitle", "Press ESC to resume",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(0, 220),
                size: new Vector2(900, 40),
                fontSize: 24,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.75f, 0.75f, 0.75f));

            // Controls column
            MakeText(pause.transform, "ControlsHeader", "CONTROLS",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(-280, 130),
                size: new Vector2(500, 36),
                fontSize: 26,
                align: TextAnchor.MiddleCenter,
                color: new Color(1f, 0.80f, 0.40f));
            var pauseControls = MakeText(pause.transform, "ControlsBody",
                "WASD / Arrows — walk\n" +
                "Mouse — look around\n" +
                "Shift — sprint (stamina)\n" +
                "Space — jump\n" +
                "Tap R — scatter Minotaur\n" +
                "    (costs 1 gem, within 10m)\n" +
                "Hold R — retrace to last fork\n" +
                "Esc — pause / resume",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(-280, -40),
                size: new Vector2(600, 320),
                fontSize: 22,
                align: TextAnchor.UpperCenter);

            // Lore / features column
            MakeText(pause.transform, "FeaturesHeader", "REMINDERS",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(280, 130),
                size: new Vector2(500, 36),
                fontSize: 26,
                align: TextAnchor.MiddleCenter,
                color: new Color(0.55f, 0.85f, 1.00f));
            MakeText(pause.transform, "FeaturesBody",
                "<color=#ffbe4c>SEARCH</color> — find the amber prize\n" +
                "<color=#5cd1ff>ESCAPE</color> — retrace to the entrance\n\n" +
                "<color=#5cd1ff>●</color>  cyan gems — saves for scatter\n" +
                "<color=#ff4040>●</color>  red plates — snake traps\n" +
                "<color=#4080ff>●</color>  blue pillars — Ariadne's notes\n" +
                "<color=#ff8c1a>●</color>  amber thread — your path home\n\n" +
                "The Minotaur hunts along your thread.\nRetrace to disturb his trail.",
                anchorMin: new Vector2(0.5f, 0.5f), anchorMax: new Vector2(0.5f, 0.5f),
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: new Vector2(280, -40),
                size: new Vector2(600, 380),
                fontSize: 22,
                align: TextAnchor.UpperLeft).supportRichText = true;

            MakeThreeDButton(pause.transform, "ResumeBtn", "Resume",
                new Vector2(-180, -260), mgr, nameof(Backtrack.ThreeD.ThreeDManager.ResumeFromPause));
            MakeThreeDButton(pause.transform, "RestartBtnPause", "Restart",
                new Vector2(180, -260), mgr, nameof(Backtrack.ThreeD.ThreeDManager.Restart));
            pause.SetActive(false);
            mgr.pausePanel = pause;

            string path = $"{ScenesDir}/{name}.unity";
            EditorSceneManager.SaveScene(scene, path);
            return path;
        }

        private static void MakeThreeDButton(Transform parent, string name, string label,
            Vector2 anchoredPos, Backtrack.ThreeD.ThreeDManager mgr, string method)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = anchoredPos;
            rt.sizeDelta = new Vector2(320, 70);
            go.GetComponent<Image>().color = new Color(0.20f, 0.22f, 0.30f, 0.95f);

            var btn = go.GetComponent<Button>();
            if (method == nameof(Backtrack.ThreeD.ThreeDManager.Restart))
                UnityEventTools.AddPersistentListener(btn.onClick, mgr.Restart);
            else if (method == nameof(Backtrack.ThreeD.ThreeDManager.ToMenu))
                UnityEventTools.AddPersistentListener(btn.onClick, mgr.ToMenu);
            else if (method == nameof(Backtrack.ThreeD.ThreeDManager.ResumeFromPause))
                UnityEventTools.AddPersistentListener(btn.onClick, mgr.ResumeFromPause);

            MakeText(go.transform, "Label", label,
                anchorMin: Vector2.zero, anchorMax: Vector2.one,
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: Vector2.zero, size: Vector2.zero,
                fontSize: 28, align: TextAnchor.MiddleCenter);
        }

        // ---------- UI helpers ----------

        private static Text MakeText(Transform parent, string name, string content,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot,
            Vector2 anchoredPos, Vector2 size,
            int fontSize, TextAnchor align, Color? color = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.pivot = pivot;
            rt.anchoredPosition = anchoredPos;
            rt.sizeDelta = size;

            var t = go.GetComponent<Text>();
            t.text = content;
            t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            t.fontSize = fontSize;
            t.alignment = align;
            t.color = color ?? new Color(0.95f, 0.95f, 0.95f);
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            return t;
        }

        private static GameObject MakePanel(Transform parent, string name, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            go.GetComponent<Image>().color = color;
            return go;
        }

        private static void MakeButton(Transform parent, string name, string label,
            Vector2 anchoredPos, GameManager gm, string method)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = anchoredPos;
            rt.sizeDelta = new Vector2(320, 70);
            go.GetComponent<Image>().color = new Color(0.20f, 0.22f, 0.30f, 0.95f);

            var btn = go.GetComponent<Button>();

            // Wire onClick persistently so it survives scene save.
            switch (method)
            {
                case nameof(GameManager.Restart):
                    UnityEventTools.AddPersistentListener(btn.onClick, gm.Restart); break;
                case nameof(GameManager.NextLevel):
                    UnityEventTools.AddPersistentListener(btn.onClick, gm.NextLevel); break;
                case nameof(GameManager.ToMenu):
                    UnityEventTools.AddPersistentListener(btn.onClick, gm.ToMenu); break;
                case nameof(GameManager.StartGame):
                    UnityEventTools.AddPersistentListener(btn.onClick, gm.StartGame); break;
                case nameof(GameManager.Quit):
                    UnityEventTools.AddPersistentListener(btn.onClick, gm.Quit); break;
            }

            MakeText(go.transform, "Label", label,
                anchorMin: Vector2.zero, anchorMax: Vector2.one,
                pivot: new Vector2(0.5f, 0.5f),
                anchoredPos: Vector2.zero, size: Vector2.zero,
                fontSize: 28, align: TextAnchor.MiddleCenter);
        }
    }
}
#endif
