#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Backtrack.EditorTools
{
    // Headless WebGL build for itch.io. Invoke:
    //   Unity -batchmode -quit -projectPath <path> \
    //         -executeMethod Backtrack.EditorTools.WebGLBuilder.BuildWebGL
    //
    // Output ends up at <project>/Build/WebGL/ which can be zipped and
    // uploaded directly to itch.io as a playable-in-browser project.
    public static class WebGLBuilder
    {
        private const string OutputDir = "Build/WebGL";

        [MenuItem("Backtrack/Build WebGL")]
        public static void BuildWebGL()
        {
            // Product metadata — shown on the itch.io loader.
            PlayerSettings.productName = "Ariadne";
            PlayerSettings.companyName = "Backtrack";
            PlayerSettings.bundleVersion = "0.1.0";

            // WebGL tuning — no compression so itch.io's static host works
            // without server-side content-encoding headers.
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
            PlayerSettings.WebGL.memorySize = 512;          // MB
            // Keep exceptions visible in the browser console — without this, any
            // runtime error surfaces only as 'Uncaught undefined' at framework.js.
            PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.FullWithStacktrace;
            PlayerSettings.WebGL.dataCaching = true;
            PlayerSettings.SplashScreen.show = false;       // free licences can disable

            // Keep IL2CPP stripping gentle — Resources.Load targets and reflection
            // via Shader.Find can be dead-code-eliminated under Medium/High.
            PlayerSettings.SetManagedStrippingLevel(
                UnityEditor.Build.NamedBuildTarget.WebGL,
                ManagedStrippingLevel.Minimal);
            PlayerSettings.stripEngineCode = false;

            // Force URP shaders into the WebGL build. GraphicsSettings →
            // Always Included Shaders is the reliable way; otherwise Shader.Find
            // returns null at runtime for Universal Render Pipeline/*.
            EnsureAlwaysIncluded(new[]
            {
                "Universal Render Pipeline/Lit",
                "Universal Render Pipeline/Simple Lit",
                "Universal Render Pipeline/Unlit",
                "Universal Render Pipeline/Particles/Lit",
                "Universal Render Pipeline/Particles/Unlit",
                "Sprites/Default",
                "Unlit/Color",
                "Unlit/Texture",
                "Standard",
            });

            // Fixed aspect-ratio canvas for the loader page.
            PlayerSettings.defaultWebScreenWidth  = 1280;
            PlayerSettings.defaultWebScreenHeight = 720;

            Directory.CreateDirectory(OutputDir);

            // Respect EditorBuildSettings — all the scenes registered via SceneBuilder.
            var scenes = new List<string>();
            foreach (var s in EditorBuildSettings.scenes)
                if (s.enabled) scenes.Add(s.path);

            if (scenes.Count == 0)
            {
                Debug.LogError("[WebGLBuilder] No scenes in Build Settings. Run SceneBuilder first.");
                EditorApplication.Exit(1);
                return;
            }

            var opts = new BuildPlayerOptions
            {
                scenes = scenes.ToArray(),
                locationPathName = OutputDir,
                target = BuildTarget.WebGL,
                options = BuildOptions.None,
            };

            var report = BuildPipeline.BuildPlayer(opts);
            var sum = report.summary;

            Debug.Log($"[WebGLBuilder] Result: {sum.result}");
            Debug.Log($"[WebGLBuilder] Output: {sum.outputPath}");
            Debug.Log($"[WebGLBuilder] Total size: {sum.totalSize / (1024 * 1024)} MB  |  Build time: {sum.totalTime.TotalSeconds:0.0}s");

            if (sum.result != BuildResult.Succeeded)
            {
                Debug.LogError($"[WebGLBuilder] Build failed ({sum.totalErrors} errors).");
                EditorApplication.Exit(2);
            }
        }

        // Adds the named shaders to GraphicsSettings → Always Included Shaders
        // so the build pipeline bakes them into the WebGL asset bundles.
        // Without this, URP/Lit is NOT shipped for a code-driven scene (nothing
        // references it at edit-time via a Material asset) and Shader.Find
        // returns null at runtime.
        private static void EnsureAlwaysIncluded(string[] shaderNames)
        {
            var path = "ProjectSettings/GraphicsSettings.asset";
            var assets = AssetDatabase.LoadAllAssetsAtPath(path);
            if (assets == null || assets.Length == 0)
            {
                Debug.LogError("[WebGLBuilder] Could not load GraphicsSettings.");
                return;
            }

            var so = new SerializedObject(assets[0]);
            var arr = so.FindProperty("m_AlwaysIncludedShaders");
            if (arr == null)
            {
                Debug.LogError("[WebGLBuilder] m_AlwaysIncludedShaders property missing.");
                return;
            }

            int added = 0;
            foreach (var name in shaderNames)
            {
                var sh = Shader.Find(name);
                if (sh == null)
                {
                    Debug.LogWarning($"[WebGLBuilder] Shader not found in project: {name}");
                    continue;
                }

                bool already = false;
                for (int i = 0; i < arr.arraySize; i++)
                {
                    var elem = arr.GetArrayElementAtIndex(i);
                    if (elem.objectReferenceValue == sh) { already = true; break; }
                }
                if (already) continue;

                arr.arraySize++;
                arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = sh;
                added++;
            }

            if (added > 0)
            {
                so.ApplyModifiedPropertiesWithoutUndo();
                AssetDatabase.SaveAssets();
                Debug.Log($"[WebGLBuilder] Added {added} shader(s) to Always Included.");
            }
        }
    }
}
#endif
