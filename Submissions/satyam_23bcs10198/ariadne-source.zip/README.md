# Ariadne

A 3D first-person labyrinth about Theseus, the Minotaur, and the glowing thread.
Built for the Scaler School of Technology 26-Hour Solo Game Jam.
**Theme: Backtracking.**

## Concept

You are a tribute to Minos's labyrinth. Ariadne has given you a thread of glowing
silk and a single gem. Unspool the thread as you descend — the Minotaur hunts
along it, but can be scattered if you sacrifice a gem when he draws near. Find
the amber prize at the heart of the labyrinth, **then follow your thread home**.

The game is literal DFS: each step pushes a point onto your stack (the thread).
Retracing pops the stack. Reaching the goal is the midpoint — you haven't won
until you've backtracked out.

## Controls

| Input | Action |
|---|---|
| WASD / Arrow keys | Walk |
| Mouse | Look around |
| Shift | Sprint (limited by stamina) |
| Space | Jump |
| **Tap R** | Scatter the Minotaur (costs 1 gem, within 10m) |
| **Hold R** | Teleport-retrace to last fork |
| Esc | Pause / Resume |

## Gameplay loop

```
Enter → Unspool thread → Search for the prize → Claim it →
  Minotaur speeds up → Retrace thread home → Escape
```

## Tech

- **Engine**: Unity 6000.4.2f1, URP (3D)
- **Language**: C#
- **Platform**: WebGL (plays in browser)
- ~3500 lines of C# across 18 scripts
- Headless scene generator (`SceneBuilder`) + WebGL builder (`WebGLBuilder`) — full project rebuilds from a single `-executeMethod` command
- No imported 3D assets — the 25×24 labyrinth is built at runtime from Unity primitives with per-tile material instances

## Build

### Scenes
```bash
Unity -batchmode -quit -projectPath . \
      -executeMethod Backtrack.EditorTools.SceneBuilder.BuildAll
```

### WebGL
```bash
Unity -batchmode -quit -projectPath . \
      -executeMethod Backtrack.EditorTools.WebGLBuilder.BuildWebGL
```
Output: `Build/WebGL/`. Ready to zip and upload to itch.io.

## Branch layout

The repo holds four parallel experiments, each a different take on the theme:

| Branch | Interpretation |
|---|---|
| `main` | Original abstract DFS grid puzzle |
| `jungle` | 2D fog-of-war with speculation ghosts at every branch |
| `rhythm` | 2D lane-runner where crashes auto-retrace |
| **`threed`** | **3D first-person Ariadne labyrinth — the shipped version** |

Safety tags `jungle-v1-colored` and `jungle-v2-treasures` preserve intermediate states.

## Play

itch.io: _<paste link after upload>_

See [SUBMISSION.md](SUBMISSION.md) for the full jam write-up (architecture, polish
list, gameplay details).

## Credits

Solo build by Kushal Talati.
Myth: Theseus, Ariadne, and the Minotaur (classical).
