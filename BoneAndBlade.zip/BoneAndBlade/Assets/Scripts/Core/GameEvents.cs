using System;

namespace ClassSwap.Core
{
    /// <summary>
    /// Static event bus for cross-system game events.
    /// Use Raise* methods to fire; subscribe via += / -=.
    /// Call ResetAll() in tests or on scene reload to prevent stale subscribers.
    /// </summary>
    public static class GameEvents
    {
        public static event Action<int> OnEnemyKilled;     // xp value dropped
        public static event Action<int> OnXPPickup;        // amount of xp picked up
        public static event Action<int> OnCoinPickup;      // coin value picked up
        public static event Action<int> OnPlayerDamaged;   // damage amount
        public static event Action OnPlayerDied;
        public static event Action<int> OnLevelUp;         // new level
        public static event Action<int> OnRoundChanged;    // round number (1/2/3)
        public static event Action<int> OnBossDefeated;    // levelIndex of boss just killed (1/2/3)
        public static event Action OnGameWon;

        public static void RaiseEnemyKilled(int xp) => OnEnemyKilled?.Invoke(xp);
        public static void RaiseXPPickup(int amount) => OnXPPickup?.Invoke(amount);
        public static void RaiseCoinPickup(int amount) => OnCoinPickup?.Invoke(amount);
        public static void RaisePlayerDamaged(int amount) => OnPlayerDamaged?.Invoke(amount);
        public static void RaisePlayerDied() => OnPlayerDied?.Invoke();
        public static void RaiseLevelUp(int level) => OnLevelUp?.Invoke(level);
        public static void RaiseRoundChanged(int round) => OnRoundChanged?.Invoke(round);
        public static void RaiseBossDefeated(int levelIndex) => OnBossDefeated?.Invoke(levelIndex);
        public static void RaiseGameWon() => OnGameWon?.Invoke();

        /// <summary>
        /// Clears all subscribers. Call on scene reload (Unity preserves static state across reloads otherwise).
        /// </summary>
        public static void ResetAll()
        {
            OnEnemyKilled = null;
            OnXPPickup = null;
            OnCoinPickup = null;
            OnPlayerDamaged = null;
            OnPlayerDied = null;
            OnLevelUp = null;
            OnRoundChanged = null;
            OnBossDefeated = null;
            OnGameWon = null;
        }
    }
}
