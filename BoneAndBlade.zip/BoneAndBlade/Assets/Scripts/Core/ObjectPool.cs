using System;
using System.Collections.Generic;

namespace ClassSwap.Core
{
    /// <summary>
    /// Generic object pool. Use for enemies, projectiles, gems, damage popups, etc.
    /// Avoids GC pressure from frequent instantiate/destroy cycles.
    /// </summary>
    public class ObjectPool<T>
    {
        readonly Stack<T> idle = new Stack<T>();
        readonly Func<T> create;
        readonly Action<T> onGet;
        readonly Action<T> onRelease;

        public ObjectPool(Func<T> create, Action<T> onGet = null, Action<T> onRelease = null, int prewarm = 0)
        {
            if (create == null) throw new ArgumentNullException(nameof(create));
            this.create = create;
            this.onGet = onGet;
            this.onRelease = onRelease;
            for (int i = 0; i < prewarm; i++)
            {
                var inst = create();
                onRelease?.Invoke(inst);
                idle.Push(inst);
            }
        }

        public T Get()
        {
            T item = idle.Count > 0 ? idle.Pop() : create();
            onGet?.Invoke(item);
            return item;
        }

        public void Release(T item)
        {
            onRelease?.Invoke(item);
            idle.Push(item);
        }

        public int IdleCount => idle.Count;
    }
}
