using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Player;

namespace ClassSwap.Enemies
{
    /// <summary>
    /// Slow, tanky armored enemy. Takes 50% damage from non-Slash sources (counter: Knight).
    /// Telegraphed bash on close range.
    /// </summary>
    public class ArmoredKnightAI : EnemyBase
    {
        [SerializeField] float moveSpeed = 1.0f;
        [SerializeField] int contactDamage = 18;
        [SerializeField] float contactInterval = 1.2f;
        [SerializeField] float armorReduction = 0.5f;

        Transform player;
        float nextContact;

        protected override void OnEnable()
        {
            base.OnEnable();
            var go = GameObject.FindWithTag("Player");
            if (go != null) player = go.transform;
        }

        public override void TakeDamage(int amount, DamageType type)
        {
            // Armor reduces non-slash damage
            if (type != DamageType.Slash)
                amount = Mathf.Max(1, Mathf.RoundToInt(amount * armorReduction));
            base.TakeDamage(amount, type);
        }

        void Update()
        {
            if (player == null) return;
            Vector3 dir = player.position - transform.position;
            dir.y = 0;
            if (dir.sqrMagnitude < 0.01f) return;
            transform.position += dir.normalized * moveSpeed * Time.deltaTime;
            transform.forward = dir.normalized;
        }

        void OnCollisionStay(Collision col)
        {
            if (Time.time < nextContact) return;
            if (col.collider.TryGetComponent(out PlayerHealth ph))
            {
                ph.TakeDamage(contactDamage, DamageType.Contact);
                nextContact = Time.time + contactInterval;
            }
        }
    }
}
