using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Core;

namespace ClassSwap.Enemies
{
    /// <summary>
    /// Abstract base for all enemies. Handles HP, damage, death, XP gem drop.
    /// Subclasses define chase/attack behavior in Update.
    /// </summary>
    public abstract class EnemyBase : MonoBehaviour, IDamageable
    {
        [Header("Stats")]
        [SerializeField] protected int maxHp = 30;
        [SerializeField] protected int xpValue = 1;

        [Header("Drops & VFX")]
        [SerializeField] protected GameObject xpGemPrefab;
        [SerializeField] protected GameObject coinPrefab;
        [Tooltip("Probability (0..1) of a coin drop on death")]
        [SerializeField, Range(0f, 1f)] protected float coinDropChance = 0.4f;
        [SerializeField] protected GameObject deathVfxPrefab;

        protected int hp;

        protected virtual void OnEnable()
        {
            hp = maxHp;
        }

        public virtual void TakeDamage(int amount, DamageType type)
        {
            if (hp <= 0) return;

            // Hit-flash callback (optional component)
            var flash = GetComponent<Juice.HitFlash>();
            if (flash != null) flash.Flash();

            hp -= amount;
            if (hp <= 0) Die();
        }

        protected virtual void Die()
        {
            GameEvents.RaiseEnemyKilled(xpValue);

            if (deathVfxPrefab != null)
            {
                Instantiate(deathVfxPrefab, transform.position, Quaternion.identity);
            }

            // Drop XP gems based on xpValue
            if (xpGemPrefab != null)
            {
                int drops = Mathf.Max(1, xpValue);
                for (int i = 0; i < drops; i++)
                {
                    Vector3 offset = new Vector3(Random.Range(-0.5f, 0.5f), 0f, Random.Range(-0.5f, 0.5f));
                    Vector3 pos = transform.position + offset;
                    pos.y = 0.3f;
                    Instantiate(xpGemPrefab, pos, Quaternion.identity);
                }
            }

            // Probabilistic coin drop
            if (coinPrefab != null && Random.value < coinDropChance)
            {
                Vector3 offset = new Vector3(Random.Range(-0.6f, 0.6f), 0f, Random.Range(-0.6f, 0.6f));
                Vector3 pos = transform.position + offset;
                pos.y = 0.4f;
                Instantiate(coinPrefab, pos, Quaternion.identity);
            }

            gameObject.SetActive(false);
        }
    }
}
