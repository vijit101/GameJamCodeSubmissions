using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Player;

namespace ClassSwap.Enemies
{
    /// <summary>
    /// Medium-speed teleporter. Periodically jumps to within attack range of player.
    /// Counter: Assassin (single-target burst, dash through teleport).
    /// </summary>
    public class WraithAI : EnemyBase
    {
        [SerializeField] float moveSpeed = 2.0f;
        [SerializeField] int contactDamage = 22;
        [SerializeField] float contactInterval = 1.5f;
        [SerializeField] float teleportInterval = 4f;
        [SerializeField] float teleportTriggerDistance = 8f;
        [SerializeField] float teleportArrivalRange = 1.5f;
        [SerializeField] GameObject teleportVfxPrefab; // optional puff

        Transform player;
        float nextContact;
        float nextTeleport;

        protected override void OnEnable()
        {
            base.OnEnable();
            var go = GameObject.FindWithTag("Player");
            if (go != null) player = go.transform;
            nextTeleport = Time.time + teleportInterval;
        }

        void Update()
        {
            if (player == null) return;

            float dist = Vector3.Distance(transform.position, player.position);

            if (Time.time >= nextTeleport && dist > teleportTriggerDistance)
            {
                Teleport();
                nextTeleport = Time.time + teleportInterval;
                return;
            }

            Vector3 dir = player.position - transform.position;
            dir.y = 0;
            if (dir.sqrMagnitude < 0.01f) return;
            transform.position += dir.normalized * moveSpeed * Time.deltaTime;
            transform.forward = dir.normalized;
        }

        void Teleport()
        {
            // Random angle behind/around player
            Vector2 r = Random.insideUnitCircle.normalized * teleportArrivalRange;
            Vector3 dest = player.position + new Vector3(r.x, 0, r.y);
            dest.y = transform.position.y;
            if (teleportVfxPrefab != null)
            {
                Instantiate(teleportVfxPrefab, transform.position, Quaternion.identity);
                Instantiate(teleportVfxPrefab, dest, Quaternion.identity);
            }
            transform.position = dest;
        }

        void OnCollisionStay(Collision col)
        {
            if (Time.time < nextContact) return;
            if (col.collider.TryGetComponent(out PlayerHealth ph))
            {
                ph.TakeDamage(contactDamage, DamageType.Contact);
                nextContact = Time.time + contactInterval;
            }
        }
    }
}
