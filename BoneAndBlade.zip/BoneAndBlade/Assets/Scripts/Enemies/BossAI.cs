using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Player;
using ClassSwap.Core;

namespace ClassSwap.Enemies
{
    /// <summary>
    /// Skeleton King boss — large, high HP, slow chase + radius slam attack.
    /// On death, raises GameWon event.
    /// </summary>
    public class BossAI : EnemyBase
    {
        [SerializeField] float moveSpeed = 1.2f;
        [SerializeField] float slamRadius = 5f;
        [SerializeField] int slamDamage = 35;
        [SerializeField] float slamCooldown = 4f;
        [SerializeField] float slamWindup = 1.0f;
        [SerializeField] GameObject slamVfxPrefab;
        [Tooltip("Only the final boss should set this true — raises GameWon on death.")]
        [SerializeField] bool isFinalBoss = false;
        [Tooltip("Which level (1, 2, or 3) this boss belongs to.")]
        [SerializeField] int levelIndex = 1;

        Transform player;
        float nextSlam;
        bool slamming;

        protected override void OnEnable()
        {
            base.OnEnable();
            var go = GameObject.FindWithTag("Player");
            if (go != null) player = go.transform;
            nextSlam = Time.time + slamCooldown;
        }

        void Update()
        {
            if (player == null || slamming) return;
            Vector3 dir = player.position - transform.position;
            dir.y = 0;
            if (dir.sqrMagnitude < 0.01f) return;
            transform.position += dir.normalized * moveSpeed * Time.deltaTime;
            transform.forward = dir.normalized;

            if (Time.time >= nextSlam && dir.sqrMagnitude < slamRadius * slamRadius)
                StartCoroutine(SlamCoroutine());
        }

        System.Collections.IEnumerator SlamCoroutine()
        {
            slamming = true;
            // Wind-up — could spawn telegraph circle here
            yield return new WaitForSeconds(slamWindup);

            if (slamVfxPrefab != null)
                Instantiate(slamVfxPrefab, transform.position, Quaternion.identity);

            // Damage anything in radius
            var hits = Physics.OverlapSphere(transform.position, slamRadius);
            foreach (var h in hits)
            {
                if (h.TryGetComponent(out PlayerHealth ph))
                    ph.TakeDamage(slamDamage, DamageType.Contact);
            }

            nextSlam = Time.time + slamCooldown;
            slamming = false;
        }

        protected override void Die()
        {
            base.Die();
            if (isFinalBoss) GameEvents.RaiseGameWon();
            else GameEvents.RaiseBossDefeated(levelIndex);
        }
    }
}
