using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Player;

namespace ClassSwap.Enemies
{
    /// <summary>
    /// Slow basic chaser. Counter: any class. Drops 1 XP gem.
    /// </summary>
    public class SkeletonAI : EnemyBase
    {
        [Header("Behavior")]
        [SerializeField] float moveSpeed = 1.5f;
        [SerializeField] int contactDamage = 10;
        [SerializeField] float contactInterval = 1.0f;

        Transform player;
        float nextContact;

        protected override void OnEnable()
        {
            base.OnEnable();
            var go = GameObject.FindWithTag("Player");
            if (go != null) player = go.transform;
        }

        void Update()
        {
            if (player == null) return;
            Vector3 dir = player.position - transform.position;
            dir.y = 0;
            float dist = dir.magnitude;
            if (dist > 0.01f)
            {
                Vector3 step = dir.normalized * moveSpeed * Time.deltaTime;
                transform.position += step;
                transform.forward = dir.normalized;
            }
        }

        void OnCollisionStay(Collision col)
        {
            if (Time.time < nextContact) return;
            if (col.collider.TryGetComponent(out PlayerHealth ph))
            {
                ph.TakeDamage(contactDamage, DamageType.Contact);
                nextContact = Time.time + contactInterval;
            }
        }
    }
}
