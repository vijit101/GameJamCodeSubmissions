using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Player;

namespace ClassSwap.Enemies
{
    /// <summary>
    /// Fast, fragile swarmer. Spawned in packs. 1 HP, fast chase, weak contact.
    /// Counter: Wizard AoE.
    /// </summary>
    public class BatSwarmAI : EnemyBase
    {
        [SerializeField] float moveSpeed = 3.5f;
        [SerializeField] int contactDamage = 5;
        [SerializeField] float contactInterval = 0.8f;
        [SerializeField] float weaveAmplitude = 0.4f;
        [SerializeField] float weaveFrequency = 5f;

        Transform player;
        float nextContact;
        float weavePhase;

        protected override void OnEnable()
        {
            base.OnEnable();
            var go = GameObject.FindWithTag("Player");
            if (go != null) player = go.transform;
            weavePhase = Random.value * Mathf.PI * 2f;
        }

        void Update()
        {
            if (player == null) return;
            Vector3 dir = player.position - transform.position;
            dir.y = 0;
            if (dir.sqrMagnitude < 0.01f) return;
            dir.Normalize();
            // Add weave for swarm feel
            Vector3 perp = new Vector3(-dir.z, 0, dir.x);
            float weave = Mathf.Sin(Time.time * weaveFrequency + weavePhase) * weaveAmplitude;
            transform.position += (dir + perp * weave) * moveSpeed * Time.deltaTime;
            transform.forward = dir;
        }

        void OnCollisionStay(Collision col)
        {
            if (Time.time < nextContact) return;
            if (col.collider.TryGetComponent(out PlayerHealth ph))
            {
                ph.TakeDamage(contactDamage, DamageType.Contact);
                nextContact = Time.time + contactInterval;
            }
        }
    }
}
