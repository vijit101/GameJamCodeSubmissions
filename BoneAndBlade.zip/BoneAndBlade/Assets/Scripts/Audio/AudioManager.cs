using System.Collections.Generic;
using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Audio
{
    public enum SfxId
    {
        SwordSwing, EnemyHit, MagicBoom, DaggerThrow,
        GemPickup, LevelUp, Death, ClassSwap,
        BossSpawn, GameWon
    }

    /// <summary>
    /// Plays procedurally-generated SFX (no audio files needed).
    /// Call AudioManager.Instance.Play(SfxId.X) anywhere.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        AudioSource[] sources;
        const int POOL_SIZE = 12;
        int nextSource;
        Dictionary<SfxId, AudioClip> clips;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            sources = new AudioSource[POOL_SIZE];
            for (int i = 0; i < POOL_SIZE; i++)
            {
                var go = new GameObject("AudioSource_" + i);
                go.transform.SetParent(transform);
                var s = go.AddComponent<AudioSource>();
                s.playOnAwake = false;
                s.volume = 0.5f;
                sources[i] = s;
            }

            clips = new Dictionary<SfxId, AudioClip>
            {
                [SfxId.SwordSwing]  = ProcGen.Whoosh(0.18f, 4000, 1500, 0.35f),
                [SfxId.EnemyHit]    = ProcGen.Thud(0.12f, 280, 0.5f),
                [SfxId.MagicBoom]   = ProcGen.Boom(0.35f, 80, 0.6f),
                [SfxId.DaggerThrow] = ProcGen.Whoosh(0.10f, 6000, 3000, 0.3f),
                [SfxId.GemPickup]   = ProcGen.Chime(0.15f, 1320, 0.35f),
                [SfxId.LevelUp]     = ProcGen.Arpeggio(0.5f, new[] { 523f, 659f, 784f, 1047f }, 0.5f),
                [SfxId.Death]       = ProcGen.Boom(0.6f, 120, 0.7f),
                [SfxId.ClassSwap]   = ProcGen.Whoosh(0.25f, 3000, 800, 0.4f),
                [SfxId.BossSpawn]   = ProcGen.Boom(1.0f, 60, 0.8f),
                [SfxId.GameWon]     = ProcGen.Arpeggio(1.2f, new[] { 523f, 659f, 784f, 1047f, 1319f }, 0.6f)
            };

            HookEvents();
        }

        void HookEvents()
        {
            GameEvents.OnEnemyKilled += (_) => Play(SfxId.EnemyHit);
            GameEvents.OnXPPickup += (_) => Play(SfxId.GemPickup, 0.3f);
            GameEvents.OnLevelUp += (_) => Play(SfxId.LevelUp);
            GameEvents.OnPlayerDied += () => Play(SfxId.Death);
            GameEvents.OnGameWon += () => Play(SfxId.GameWon);
        }

        void OnDestroy()
        {
            // not unsubscribing because singleton lives forever; but defensive:
            if (Instance == this) Instance = null;
        }

        public void Play(SfxId id, float volume = 0.5f, float pitchVariance = 0.05f)
        {
            if (!clips.TryGetValue(id, out var clip) || clip == null) return;
            var src = sources[nextSource];
            nextSource = (nextSource + 1) % POOL_SIZE;
            src.pitch = 1f + Random.Range(-pitchVariance, pitchVariance);
            src.volume = volume;
            src.PlayOneShot(clip);
        }

        // ============ Procedural clip generator ============
        static class ProcGen
        {
            const int SR = 44100;

            public static AudioClip Whoosh(float dur, float startHz, float endHz, float vol)
            {
                int len = (int)(SR * dur);
                var data = new float[len];
                for (int i = 0; i < len; i++)
                {
                    float t = (float)i / len;
                    float freq = Mathf.Lerp(startHz, endHz, t);
                    float env = (1f - t) * (1f - t);
                    float noise = (Random.value * 2f - 1f);
                    // Band-passed noise approximation: filter-by-mixing-with-sine
                    data[i] = (noise * 0.6f + Mathf.Sin(2f * Mathf.PI * freq * t * dur) * 0.4f) * env * vol;
                }
                return MakeClip("Whoosh", data);
            }

            public static AudioClip Thud(float dur, float baseHz, float vol)
            {
                int len = (int)(SR * dur);
                var data = new float[len];
                for (int i = 0; i < len; i++)
                {
                    float t = (float)i / len;
                    float env = Mathf.Exp(-t * 12f);
                    float freq = baseHz * (1f - t * 0.6f);
                    data[i] = Mathf.Sin(2f * Mathf.PI * freq * t * dur) * env * vol;
                    // bit of crunch
                    data[i] += (Random.value * 2f - 1f) * env * 0.15f;
                }
                return MakeClip("Thud", data);
            }

            public static AudioClip Boom(float dur, float baseHz, float vol)
            {
                int len = (int)(SR * dur);
                var data = new float[len];
                for (int i = 0; i < len; i++)
                {
                    float t = (float)i / len;
                    float env = Mathf.Exp(-t * 4f);
                    float freq = baseHz * (1f + t * 0.5f);
                    float sin = Mathf.Sin(2f * Mathf.PI * freq * t * dur);
                    float noise = (Random.value * 2f - 1f);
                    data[i] = (sin * 0.65f + noise * 0.35f) * env * vol;
                }
                return MakeClip("Boom", data);
            }

            public static AudioClip Chime(float dur, float hz, float vol)
            {
                int len = (int)(SR * dur);
                var data = new float[len];
                for (int i = 0; i < len; i++)
                {
                    float t = (float)i / len;
                    float env = Mathf.Exp(-t * 8f);
                    data[i] = Mathf.Sin(2f * Mathf.PI * hz * t * dur) * env * vol;
                }
                return MakeClip("Chime", data);
            }

            public static AudioClip Arpeggio(float dur, float[] notes, float vol)
            {
                int len = (int)(SR * dur);
                var data = new float[len];
                float noteDur = dur / notes.Length;
                int noteSamples = (int)(SR * noteDur);
                for (int n = 0; n < notes.Length; n++)
                {
                    int start = n * noteSamples;
                    int end = Mathf.Min(start + noteSamples, len);
                    for (int i = start; i < end; i++)
                    {
                        float lt = (float)(i - start) / noteSamples;
                        float env = Mathf.Exp(-lt * 4f);
                        float ts = (float)i / SR;
                        data[i] += Mathf.Sin(2f * Mathf.PI * notes[n] * ts) * env * vol;
                    }
                }
                return MakeClip("Arpeggio", data);
            }

            static AudioClip MakeClip(string name, float[] data)
            {
                var clip = AudioClip.Create(name, data.Length, 1, SR, false);
                clip.SetData(data, 0);
                return clip;
            }
        }
    }
}
