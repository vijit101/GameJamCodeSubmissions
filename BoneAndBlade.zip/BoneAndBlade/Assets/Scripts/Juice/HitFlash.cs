using System.Collections;
using UnityEngine;

namespace ClassSwap.Juice
{
    /// <summary>
    /// Briefly tints assigned Renderers white on hit. Attach to enemies and assign Renderers in inspector.
    /// MaterialPropertyBlock-free for jam simplicity — directly mutates material.color (acceptable since
    /// each enemy instance gets its own material instance via .material).
    /// </summary>
    public class HitFlash : MonoBehaviour
    {
        [SerializeField] Renderer[] renderers;
        [SerializeField] Color flashColor = Color.white;
        [SerializeField] float flashDuration = 0.08f;

        Color[] baseColors;
        Coroutine running;

        void Awake()
        {
            if (renderers == null || renderers.Length == 0)
            {
                renderers = GetComponentsInChildren<Renderer>();
            }
            baseColors = new Color[renderers.Length];
            for (int i = 0; i < renderers.Length; i++)
            {
                if (renderers[i] != null && renderers[i].sharedMaterial != null)
                {
                    baseColors[i] = renderers[i].sharedMaterial.color;
                }
            }
        }

        public void Flash()
        {
            if (running != null) StopCoroutine(running);
            running = StartCoroutine(Co());
        }

        IEnumerator Co()
        {
            for (int i = 0; i < renderers.Length; i++)
                if (renderers[i] != null) renderers[i].material.color = flashColor;
            yield return new WaitForSeconds(flashDuration);
            for (int i = 0; i < renderers.Length; i++)
                if (renderers[i] != null) renderers[i].material.color = baseColors[i];
            running = null;
        }
    }
}
