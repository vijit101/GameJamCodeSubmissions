using UnityEngine;

namespace ClassSwap.Visual
{
    /// <summary>
    /// Procedural character animation: idle bob, walk lean+bob, attack-swing weapon part rotation.
    /// Attach to a visual root GameObject (e.g. Visual_Knight). Auto-finds parts by name.
    /// </summary>
    public class CharacterAnimator : MonoBehaviour
    {
        [Header("Auto-found parts (by child name)")]
        [SerializeField] string weaponName = "Sword";
        [SerializeField] string capeName = "Cape";

        [Header("Idle bob")]
        [SerializeField] float idleBobAmplitude = 0.05f;
        [SerializeField] float idleBobFrequency = 1.6f;

        [Header("Walk")]
        [SerializeField] float walkBobAmplitude = 0.08f;
        [SerializeField] float walkBobFrequency = 5f;
        [SerializeField] float walkLeanDegrees = 10f;
        [SerializeField] float walkSpeedThreshold = 0.05f;

        [Header("Attack swing")]
        [SerializeField] float attackSwingDegrees = 90f;
        [SerializeField] float attackSwingDuration = 0.25f;

        Transform weapon;
        Quaternion weaponBaseRot;
        Transform cape;

        Vector3 baseLocalPos;
        Quaternion baseLocalRot;

        Vector3 lastWorldPos;
        float currentSpeed;

        float swingStartTime = -1f;
        float swingDuration;

        void Start()
        {
            baseLocalPos = transform.localPosition;
            baseLocalRot = transform.localRotation;

            weapon = FindChild(transform, weaponName);
            if (weapon != null) weaponBaseRot = weapon.localRotation;
            cape = FindChild(transform, capeName);

            lastWorldPos = transform.position;
        }

        void OnEnable()
        {
            // Reset state when activated (class swap)
            swingStartTime = -1f;
            if (weapon != null) weapon.localRotation = weaponBaseRot;
        }

        void Update()
        {
            // Estimate speed from world position change
            float dt = Time.deltaTime;
            if (dt > 0)
            {
                Vector3 deltaWorld = transform.position - lastWorldPos;
                currentSpeed = deltaWorld.magnitude / dt;
            }
            lastWorldPos = transform.position;

            bool walking = currentSpeed > walkSpeedThreshold;
            float t = Time.time;

            // Bob the visual root up/down
            float bobAmp = walking ? walkBobAmplitude : idleBobAmplitude;
            float bobFreq = walking ? walkBobFrequency : idleBobFrequency;
            float bob = Mathf.Sin(t * bobFreq * Mathf.PI * 2f) * bobAmp;
            var pos = baseLocalPos;
            pos.y += bob;
            transform.localPosition = pos;

            // Lean forward when walking
            float leanAngle = walking ? walkLeanDegrees : 0f;
            Quaternion targetRot = baseLocalRot * Quaternion.Euler(leanAngle, 0, 0);
            transform.localRotation = Quaternion.Slerp(transform.localRotation, targetRot, dt * 8f);

            // Cape sway (offset bob)
            if (cape != null)
            {
                float swayAngle = walking ? Mathf.Sin(t * walkBobFrequency * Mathf.PI * 2f + 1f) * 8f : 0f;
                cape.localRotation = Quaternion.Euler(swayAngle, 0, 0);
            }

            // Weapon attack swing
            if (weapon != null)
            {
                if (swingStartTime > 0f)
                {
                    float p = (Time.time - swingStartTime) / swingDuration;
                    if (p >= 1f)
                    {
                        weapon.localRotation = weaponBaseRot;
                        swingStartTime = -1f;
                    }
                    else
                    {
                        // Sin curve: rises fast, falls back
                        float swing = Mathf.Sin(p * Mathf.PI) * attackSwingDegrees;
                        weapon.localRotation = weaponBaseRot * Quaternion.Euler(0, swing, -swing * 0.5f);
                    }
                }
            }
        }

        public void TriggerAttackSwing(float duration = -1f)
        {
            swingStartTime = Time.time;
            swingDuration = duration > 0 ? duration : attackSwingDuration;
        }

        static Transform FindChild(Transform parent, string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            foreach (Transform t in parent)
                if (t.name.Contains(name)) return t;
            return null;
        }
    }
}
