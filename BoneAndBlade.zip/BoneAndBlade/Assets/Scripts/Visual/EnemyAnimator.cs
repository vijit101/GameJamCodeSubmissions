using UnityEngine;

namespace ClassSwap.Visual
{
    public enum EnemyAnimStyle { Shamble, Flap, Stomp, Float }

    /// <summary>
    /// Procedural enemy idle/movement animation. Different styles per enemy type.
    /// </summary>
    public class EnemyAnimator : MonoBehaviour
    {
        [SerializeField] EnemyAnimStyle style = EnemyAnimStyle.Shamble;
        [SerializeField] float frequency = 4f;
        [SerializeField] float amplitude = 0.1f;

        Transform visual;
        Vector3 baseLocalPos;
        Quaternion baseLocalRot;
        float phase;

        void Start()
        {
            visual = transform.childCount > 0 ? transform.GetChild(0) : null;
            if (visual)
            {
                baseLocalPos = visual.localPosition;
                baseLocalRot = visual.localRotation;
            }
            phase = Random.value * Mathf.PI * 2f;
        }

        void Update()
        {
            if (!visual) return;
            float t = Time.time * frequency + phase;
            switch (style)
            {
                case EnemyAnimStyle.Shamble:
                    visual.localRotation = baseLocalRot * Quaternion.Euler(0, 0, Mathf.Sin(t) * amplitude * 100f);
                    break;
                case EnemyAnimStyle.Flap:
                    var p = baseLocalPos;
                    p.y += Mathf.Abs(Mathf.Sin(t * 2f)) * amplitude * 1.5f;
                    visual.localPosition = p;
                    visual.localRotation = baseLocalRot * Quaternion.Euler(0, 0, Mathf.Sin(t * 4f) * 15f);
                    break;
                case EnemyAnimStyle.Stomp:
                    var p2 = baseLocalPos;
                    p2.y += (Mathf.Sin(t) > 0 ? Mathf.Sin(t) : 0) * amplitude * 0.5f;
                    visual.localPosition = p2;
                    break;
                case EnemyAnimStyle.Float:
                    var p3 = baseLocalPos;
                    p3.y += Mathf.Sin(t * 0.5f) * amplitude * 1.2f;
                    visual.localPosition = p3;
                    visual.localRotation = baseLocalRot * Quaternion.Euler(0, t * 30f, 0);
                    break;
            }
        }
    }
}
