using UnityEngine;

namespace ClassSwap.Visual
{
    /// <summary>
    /// Fades a Light's intensity to 0 over duration, then destroys its GameObject.
    /// </summary>
    [RequireComponent(typeof(Light))]
    public class LightFadeOut : MonoBehaviour
    {
        [SerializeField] float duration = 0.5f;
        Light l;
        float startIntensity;
        float t;

        void Start()
        {
            l = GetComponent<Light>();
            startIntensity = l.intensity;
        }

        void Update()
        {
            t += Time.deltaTime;
            float p = Mathf.Clamp01(t / duration);
            l.intensity = Mathf.Lerp(startIntensity, 0f, p);
            if (p >= 1f) Destroy(gameObject);
        }
    }
}
