using UnityEngine;

namespace ClassSwap.Visual
{
    /// <summary>
    /// Fruit-Ninja-style arcing blade trail. Spawns at player, sweeps a trail pivot through
    /// an arc centered on aimDirection, destroys itself after duration.
    /// Set TrailRenderer on the "Pivot" child.
    /// </summary>
    public class SlashArc : MonoBehaviour
    {
        [SerializeField] Transform pivot;
        [SerializeField] float radius = 2.2f;
        [SerializeField] float arcDegrees = 160f;
        [SerializeField] float duration = 0.18f;
        [SerializeField] TrailRenderer trail;

        float t;
        Vector3 aimDir = Vector3.forward;

        public void Setup(Vector3 direction)
        {
            if (direction.sqrMagnitude > 0.001f)
            {
                direction.y = 0;
                aimDir = direction.normalized;
            }
            transform.forward = aimDir;
            if (pivot)
            {
                // Start pivot at left edge of arc
                float startAngle = -arcDegrees * 0.5f;
                pivot.localPosition = PointOnArc(startAngle);
            }
            // Clear trail so it doesn't connect from a previous use
            if (trail) trail.Clear();
        }

        void Start()
        {
            if (pivot == null)
            {
                var p = transform.Find("Pivot");
                if (p) pivot = p;
            }
            if (trail == null && pivot) trail = pivot.GetComponent<TrailRenderer>();
        }

        void Update()
        {
            t += Time.deltaTime;
            float p = Mathf.Clamp01(t / duration);
            if (pivot)
            {
                // Ease-out curve for satisfying snap
                float eased = 1f - Mathf.Pow(1f - p, 2.5f);
                float angle = Mathf.Lerp(-arcDegrees * 0.5f, arcDegrees * 0.5f, eased);
                pivot.localPosition = PointOnArc(angle);
            }
            if (p >= 1f)
            {
                // Wait for trail to fade
                Destroy(gameObject, trail ? trail.time : 0.1f);
                enabled = false;
            }
        }

        Vector3 PointOnArc(float degrees)
        {
            float rad = degrees * Mathf.Deg2Rad;
            return new Vector3(Mathf.Sin(rad) * radius, 0.9f, Mathf.Cos(rad) * radius);
        }
    }
}
