namespace ClassSwap.Combat
{
    public enum DamageType
    {
        Slash,    // Knight melee — bypasses Armored Knight reduction
        Magic,    // Wizard fireballs — AoE, normal damage
        Pierce,   // Assassin daggers — single-target, normal damage
        Contact   // Enemy contact damage to player
    }

    /// <summary>
    /// Implemented by anything that can take damage: PlayerHealth, EnemyBase subclasses, BossAI.
    /// </summary>
    public interface IDamageable
    {
        void TakeDamage(int amount, DamageType type);
    }
}
