using UnityEngine;

namespace ClassSwap.Combat
{
    /// <summary>
    /// Wizard projectile. Travels forward, explodes on contact or after lifetime,
    /// dealing AoE Magic damage in radius.
    /// </summary>
    public class Fireball : MonoBehaviour
    {
        [SerializeField] float speed = 8f;
        [SerializeField] float lifetime = 3f;
        [SerializeField] float explosionRadius = 3f;
        [SerializeField] int damage = 20;
        [SerializeField] LayerMask enemyLayer;
        [SerializeField] GameObject explosionVfxPrefab;

        float t;

        void OnEnable()
        {
            t = 0f;
        }

        void Update()
        {
            transform.position += transform.forward * speed * Time.deltaTime;
            t += Time.deltaTime;
            if (t >= lifetime)
            {
                Explode();
                return;
            }

            // Direct hit detection (small overlap at projectile head)
            var direct = Physics.OverlapSphere(transform.position, 0.3f, enemyLayer);
            if (direct.Length > 0) Explode();
        }

        void Explode()
        {
            if (explosionVfxPrefab != null)
                Instantiate(explosionVfxPrefab, transform.position, Quaternion.identity);

            var hits = Physics.OverlapSphere(transform.position, explosionRadius, enemyLayer);
            foreach (var h in hits)
            {
                if (h.TryGetComponent(out IDamageable d))
                    d.TakeDamage(damage, DamageType.Magic);
            }
            gameObject.SetActive(false);
        }

        // Upgrade hooks
        public void ModifyDamage(float multiplier) => damage = Mathf.RoundToInt(damage * multiplier);
        public void ModifyRadius(float multiplier) => explosionRadius *= multiplier;
    }
}
