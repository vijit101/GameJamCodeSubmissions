using UnityEngine;

namespace ClassSwap.Combat
{
    /// <summary>
    /// Assassin projectile — fast, single-target, low damage. First enemy hit absorbs it.
    /// </summary>
    public class Dagger : MonoBehaviour
    {
        [SerializeField] float speed = 18f;
        [SerializeField] float lifetime = 1.5f;
        [SerializeField] int damage = 8;
        [SerializeField] LayerMask enemyLayer;

        float t;

        void OnEnable() { t = 0f; }

        void Update()
        {
            transform.position += transform.forward * speed * Time.deltaTime;
            t += Time.deltaTime;
            if (t >= lifetime)
            {
                gameObject.SetActive(false);
                return;
            }

            var hits = Physics.OverlapSphere(transform.position, 0.25f, enemyLayer);
            foreach (var h in hits)
            {
                if (h.TryGetComponent(out IDamageable d))
                {
                    d.TakeDamage(damage, DamageType.Pierce);
                    gameObject.SetActive(false);
                    return;
                }
            }
        }

        public void ModifyDamage(float multiplier) => damage = Mathf.RoundToInt(damage * multiplier);
        public void ModifySpeed(float multiplier) => speed *= multiplier;
    }
}
