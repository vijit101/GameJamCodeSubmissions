using UnityEngine;

namespace ClassSwap.Combat
{
    /// <summary>
    /// Helper to find the nearest enemy on the configured layer.
    /// Used by all class attacks for auto-aim.
    /// </summary>
    public static class AutoAim
    {
        const int MAX_CANDIDATES = 64;
        static readonly Collider[] buffer = new Collider[MAX_CANDIDATES];

        /// <summary>Returns the nearest enemy Transform within scanRadius, or null if none.</summary>
        public static Transform NearestEnemy(Vector3 from, float scanRadius, LayerMask enemyLayer)
        {
            int count = Physics.OverlapSphereNonAlloc(from, scanRadius, buffer, enemyLayer);
            float bestSqr = float.MaxValue;
            Transform best = null;
            for (int i = 0; i < count; i++)
            {
                if (buffer[i] == null) continue;
                Vector3 d = buffer[i].transform.position - from;
                d.y = 0;
                float sqr = d.sqrMagnitude;
                if (sqr < bestSqr) { bestSqr = sqr; best = buffer[i].transform; }
            }
            return best;
        }
    }
}
