using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Activates the matching prop group when a round changes; only one group active at a time.
    /// </summary>
    public class EnvironmentPropsManager : MonoBehaviour
    {
        [SerializeField] GameObject[] propGroups;
        [SerializeField] float autoAdvanceSeconds = 60f;

        int currentIdx = -1;
        float lastAdvance;

        void Start()
        {
            Apply(0);
            lastAdvance = Time.time;
            GameEvents.OnRoundChanged += OnRound;
        }

        void OnDestroy() { GameEvents.OnRoundChanged -= OnRound; }

        void OnRound(int round) => Apply(Mathf.Clamp(round - 1, 0, propGroups.Length - 1));

        void Update()
        {
            if (Time.time - lastAdvance >= autoAdvanceSeconds && currentIdx < propGroups.Length - 1)
            {
                Apply(currentIdx + 1);
                lastAdvance = Time.time;
            }
        }

        public void Apply(int idx)
        {
            if (propGroups == null || idx < 0 || idx >= propGroups.Length || idx == currentIdx) return;
            currentIdx = idx;
            for (int i = 0; i < propGroups.Length; i++)
                if (propGroups[i] != null) propGroups[i].SetActive(i == idx);
            lastAdvance = Time.time;
        }
    }
}
