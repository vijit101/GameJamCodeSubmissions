using UnityEngine;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Triggers boss spawn after delaySeconds from scene start. Single-shot.
    /// Boss raises GameWon on death (via BossAI.Die override).
    /// </summary>
    public class BossSpawnTrigger : MonoBehaviour
    {
        [SerializeField] GameObject bossPrefab;
        [SerializeField] float delaySeconds = 130f;
        [SerializeField] Vector3 spawnOffset = new Vector3(0, 0.5f, 0);

        bool spawned;
        float startTime;

        void Start() { startTime = Time.time; }

        void Update()
        {
            if (spawned) return;
            if (Time.time - startTime >= delaySeconds)
            {
                if (bossPrefab != null)
                {
                    Instantiate(bossPrefab, spawnOffset, Quaternion.identity);
                }
                spawned = true;
            }
        }
    }
}
