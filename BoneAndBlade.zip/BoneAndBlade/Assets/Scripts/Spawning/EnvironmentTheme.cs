using UnityEngine;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Visual theme applied at round transitions: floor/wall materials, ambient/light color tint, brazier color.
    /// </summary>
    [CreateAssetMenu(menuName = "ClassSwap/EnvironmentTheme")]
    public class EnvironmentTheme : ScriptableObject
    {
        public string displayName = "Round";
        public string subtitle = "";
        public Material floorMaterial;
        public Material wallMaterial;
        public Color ambientLight = Color.gray;
        public Color directionalLightColor = new Color(0.55f, 0.7f, 0.95f);
        public float directionalLightIntensity = 0.6f;
        public Color brazierColor = new Color(1f, 0.55f, 0.2f);
        public float brazierIntensity = 4f;
        public Color emberColor = new Color(1f, 0.7f, 0.3f, 0.5f);
        public Color titleColor = new Color(1f, 0.85f, 0.5f);
    }
}
