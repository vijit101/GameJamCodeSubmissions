using System.Collections;
using UnityEngine;
using ClassSwap.Core;
using ClassSwap.UI;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Listens for round transitions, applies the matching EnvironmentTheme + shows banner overlay.
    /// </summary>
    public class EnvironmentSwapper : MonoBehaviour
    {
        [SerializeField] EnvironmentTheme[] themes;       // index 0 = Round 1
        [SerializeField] Renderer floorRenderer;
        [SerializeField] Renderer[] wallRenderers;
        [SerializeField] Light directionalLight;
        [SerializeField] Light[] brazierLights;
        [SerializeField] ParticleSystem emberParticles;
        [SerializeField] RoundIntroBanner banner;
        [SerializeField] float autoAdvanceSeconds = 60f;

        int currentTheme = -1;
        float lastAdvance;

        void Start()
        {
            if (themes != null && themes.Length > 0) Apply(0);
            lastAdvance = Time.time;
            GameEvents.OnRoundChanged += OnRound;
        }

        void OnDestroy() { GameEvents.OnRoundChanged -= OnRound; }

        void OnRound(int roundOneIndexed)
        {
            int idx = Mathf.Clamp(roundOneIndexed - 1, 0, themes.Length - 1);
            Apply(idx);
        }

        void Update()
        {
            // Auto-advance in case RoundController isn't driving it
            if (Time.time - lastAdvance >= autoAdvanceSeconds && currentTheme < themes.Length - 1)
            {
                Apply(currentTheme + 1);
                lastAdvance = Time.time;
            }
        }

        public void Apply(int idx)
        {
            if (themes == null || idx < 0 || idx >= themes.Length || idx == currentTheme) return;
            currentTheme = idx;
            var t = themes[idx];

            if (floorRenderer && t.floorMaterial) floorRenderer.sharedMaterial = t.floorMaterial;
            if (wallRenderers != null && t.wallMaterial)
                foreach (var r in wallRenderers) if (r) r.sharedMaterial = t.wallMaterial;

            if (directionalLight)
            {
                directionalLight.color = t.directionalLightColor;
                directionalLight.intensity = t.directionalLightIntensity;
            }
            if (brazierLights != null)
            {
                foreach (var l in brazierLights)
                {
                    if (!l) continue;
                    l.color = t.brazierColor;
                    l.intensity = t.brazierIntensity;
                }
            }
            if (emberParticles)
            {
                var main = emberParticles.main;
                main.startColor = t.emberColor;
            }

            RenderSettings.ambientLight = t.ambientLight;

            if (banner) banner.Show(t.displayName, t.subtitle, t.titleColor);
            lastAdvance = Time.time;
        }
    }
}
