using System.Collections.Generic;
using UnityEngine;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Simple wave manager — emits enemy prefabs from random spawn points at a configurable rate.
    /// Will be swapped out to use UMFOSS Spawner when its API is wired up; this class works as fallback.
    /// </summary>
    public class WaveManager : MonoBehaviour
    {
        [System.Serializable]
        public class WavePhase
        {
            public float startTime;            // seconds since round start
            public float spawnInterval = 1.5f;
            public GameObject[] enemyPrefabs;  // weighted random pick
        }

        [SerializeField] Transform[] spawnPoints;
        [SerializeField] List<WavePhase> phases = new List<WavePhase>();
        [Tooltip("If true, starts spawning on Start() using configured phases (no RoundController needed).")]
        [SerializeField] bool autoStart = false;

        bool spawning;
        float roundStart;
        float nextSpawn;

        void Start()
        {
            if (autoStart) StartRoundFromInspector();
        }

        public void StartRoundFromInspector()
        {
            spawning = true;
            roundStart = Time.time;
            nextSpawn = Time.time;
        }

        public void StartRound(List<WavePhase> roundPhases)
        {
            phases = roundPhases;
            spawning = true;
            roundStart = Time.time;
            nextSpawn = Time.time;
        }

        public void StopSpawning() => spawning = false;

        void Update()
        {
            if (!spawning) return;
            if (Time.time < nextSpawn) return;

            var phase = CurrentPhase();
            if (phase == null) return;

            SpawnOne(phase);
            nextSpawn = Time.time + phase.spawnInterval;
        }

        WavePhase CurrentPhase()
        {
            float t = Time.time - roundStart;
            WavePhase chosen = null;
            foreach (var p in phases)
                if (p.startTime <= t) chosen = p;
            return chosen;
        }

        void SpawnOne(WavePhase phase)
        {
            if (phase.enemyPrefabs == null || phase.enemyPrefabs.Length == 0) return;
            if (spawnPoints == null || spawnPoints.Length == 0) return;

            var prefab = phase.enemyPrefabs[Random.Range(0, phase.enemyPrefabs.Length)];
            var point = spawnPoints[Random.Range(0, spawnPoints.Length)];
            Instantiate(prefab, point.position, Quaternion.identity);
        }
    }
}
