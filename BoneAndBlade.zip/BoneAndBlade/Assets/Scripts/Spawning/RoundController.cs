using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Drives the 3-round game flow: Dungeon (90s) → Forest (90s) → Coliseum (80s + Boss).
    /// Each round swaps environment prefab, fades, and reconfigures WaveManager.
    /// </summary>
    public class RoundController : MonoBehaviour
    {
        [System.Serializable]
        public class RoundConfig
        {
            public string name = "Round";
            public GameObject environmentPrefab;
            public List<WaveManager.WavePhase> phases = new List<WaveManager.WavePhase>();
            public float duration = 90f;
        }

        [SerializeField] RoundConfig[] rounds;
        [SerializeField] WaveManager waveManager;
        [SerializeField] CanvasGroup fadeOverlay;
        [SerializeField] float fadeDuration = 0.5f;

        [Header("Boss wave (Round 3 end)")]
        [SerializeField] GameObject bossPrefab;
        [SerializeField] Transform bossSpawnPoint;
        [SerializeField] int minionCountAtBoss = 30;
        [SerializeField] GameObject minionPrefab;

        public int CurrentRound { get; private set; } = 1;
        public float RoundTimeRemaining { get; private set; }

        GameObject currentEnv;

        void Start()
        {
            GameEvents.OnPlayerDied += () => StopAllCoroutines();
            StartCoroutine(RunRounds());
        }

        IEnumerator RunRounds()
        {
            for (int i = 0; i < rounds.Length; i++)
            {
                CurrentRound = i + 1;
                yield return SwitchEnvironment(rounds[i].environmentPrefab);
                GameEvents.RaiseRoundChanged(CurrentRound);
                waveManager.StartRound(rounds[i].phases);

                RoundTimeRemaining = rounds[i].duration;
                while (RoundTimeRemaining > 0f)
                {
                    RoundTimeRemaining -= Time.deltaTime;
                    yield return null;
                }
                waveManager.StopSpawning();
            }

            // Boss wave at the end of the last round
            yield return new WaitForSeconds(0.5f);
            yield return SpawnBoss();
        }

        IEnumerator SwitchEnvironment(GameObject envPrefab)
        {
            if (fadeOverlay != null) yield return Fade(1f);
            if (currentEnv != null) Destroy(currentEnv);
            if (envPrefab != null) currentEnv = Instantiate(envPrefab);
            if (fadeOverlay != null) yield return Fade(0f);
        }

        IEnumerator Fade(float target)
        {
            float start = fadeOverlay.alpha;
            float t = 0f;
            while (t < fadeDuration)
            {
                t += Time.unscaledDeltaTime;
                fadeOverlay.alpha = Mathf.Lerp(start, target, t / fadeDuration);
                yield return null;
            }
            fadeOverlay.alpha = target;
        }

        IEnumerator SpawnBoss()
        {
            GameObject boss = null;
            if (bossPrefab != null && bossSpawnPoint != null)
                boss = Instantiate(bossPrefab, bossSpawnPoint.position, Quaternion.identity);

            // Spawn minions over a short window
            for (int i = 0; i < minionCountAtBoss; i++)
            {
                if (minionPrefab != null && bossSpawnPoint != null)
                {
                    Vector3 offset = Random.insideUnitCircle * 5f;
                    Vector3 pos = bossSpawnPoint.position + new Vector3(offset.x, 0, offset.y);
                    Instantiate(minionPrefab, pos, Quaternion.identity);
                }
                yield return new WaitForSeconds(0.3f);
            }

            // Wait for boss to die. EnemyBase.Die() calls SetActive(false) — so check activeSelf.
            while (boss != null && boss.activeSelf) yield return null;

            GameEvents.RaiseGameWon();
        }
    }
}
