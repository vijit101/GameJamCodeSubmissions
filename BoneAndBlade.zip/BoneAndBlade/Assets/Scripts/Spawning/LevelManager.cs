using System.Collections;
using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Spawning
{
    /// <summary>
    /// Discrete-level progression: kill the boss → "Level X Complete" panel → SPACE advances → next environment + waves + boss.
    /// Replaces auto-advance timer in EnvironmentSwapper / EnvironmentPropsManager.
    /// </summary>
    public class LevelManager : MonoBehaviour
    {
        [SerializeField] EnvironmentSwapper environmentSwapper;
        [SerializeField] EnvironmentPropsManager propsManager;
        [SerializeField] GameObject[] bossSpawnerGameObjects; // index = level - 1
        [SerializeField] int totalLevels = 3;
        [SerializeField] UI.LevelCompleteUI completeUI;       // panel that pauses + waits for SPACE

        public int CurrentLevel { get; private set; } = 1;

        void Start()
        {
            // Disable all boss spawners initially; we enable per-level
            if (bossSpawnerGameObjects != null)
                foreach (var b in bossSpawnerGameObjects) if (b) b.SetActive(false);
            BeginLevel(1);
            GameEvents.OnBossDefeated += OnBossDefeated;
            GameEvents.OnGameWon += OnGameWon;
        }

        void OnDestroy()
        {
            GameEvents.OnBossDefeated -= OnBossDefeated;
            GameEvents.OnGameWon -= OnGameWon;
        }

        void BeginLevel(int level)
        {
            CurrentLevel = level;
            int idx = Mathf.Clamp(level - 1, 0, totalLevels - 1);
            if (environmentSwapper != null) environmentSwapper.Apply(idx);
            if (propsManager != null) propsManager.Apply(idx);
            // Activate THIS level's boss spawner (deactivate others)
            if (bossSpawnerGameObjects != null)
            {
                for (int i = 0; i < bossSpawnerGameObjects.Length; i++)
                    if (bossSpawnerGameObjects[i]) bossSpawnerGameObjects[i].SetActive(i == idx);
            }
            GameEvents.RaiseRoundChanged(level);
        }

        void OnBossDefeated(int killedLevel)
        {
            if (killedLevel < totalLevels)
            {
                if (completeUI != null) completeUI.Show(killedLevel, () => BeginLevel(killedLevel + 1));
                else BeginLevel(killedLevel + 1);
            }
        }

        void OnGameWon()
        {
            // Final boss → WinUI handles it; nothing to do here.
        }
    }
}
