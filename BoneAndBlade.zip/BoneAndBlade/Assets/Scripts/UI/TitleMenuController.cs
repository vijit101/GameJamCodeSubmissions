using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

namespace ClassSwap.UI
{
    /// <summary>
    /// Title screen menu — Play / Leaderboard / Settings panels.
    /// Keyboard: SPACE play, L leaderboard, S settings, ESC back.
    /// </summary>
    public class TitleMenuController : MonoBehaviour
    {
        [SerializeField] string gameSceneName = "Game";
        [SerializeField] GameObject mainPanel;
        [SerializeField] GameObject leaderboardPanel;
        [SerializeField] GameObject settingsPanel;
        [SerializeField] TMP_Text leaderboardText;
        [SerializeField] Slider volumeSlider;

        const string VOL_KEY = "MasterVolume";

        void Start()
        {
            float v = PlayerPrefs.GetFloat(VOL_KEY, 0.7f);
            AudioListener.volume = v;
            if (volumeSlider) {
                volumeSlider.value = v;
                volumeSlider.onValueChanged.AddListener(OnVolumeChanged);
            }
            ShowMain();
        }

        void Update()
        {
            if (mainPanel && mainPanel.activeSelf)
            {
                if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return)) PlayPressed();
                else if (Input.GetKeyDown(KeyCode.L)) LeaderboardPressed();
                else if (Input.GetKeyDown(KeyCode.S)) SettingsPressed();
            }
            else if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.Backspace))
            {
                ShowMain();
            }
        }

        public void PlayPressed() => SceneManager.LoadScene(gameSceneName);

        public void LeaderboardPressed()
        {
            if (mainPanel) mainPanel.SetActive(false);
            if (settingsPanel) settingsPanel.SetActive(false);
            if (leaderboardPanel) leaderboardPanel.SetActive(true);
            RefreshLeaderboard();
        }

        public void SettingsPressed()
        {
            if (mainPanel) mainPanel.SetActive(false);
            if (leaderboardPanel) leaderboardPanel.SetActive(false);
            if (settingsPanel) settingsPanel.SetActive(true);
        }

        public void ShowMain()
        {
            if (leaderboardPanel) leaderboardPanel.SetActive(false);
            if (settingsPanel) settingsPanel.SetActive(false);
            if (mainPanel) mainPanel.SetActive(true);
        }

        void OnVolumeChanged(float v)
        {
            AudioListener.volume = v;
            PlayerPrefs.SetFloat(VOL_KEY, v);
            PlayerPrefs.Save();
        }

        void RefreshLeaderboard()
        {
            if (leaderboardText == null) return;
            var entries = Leaderboard.Load();
            if (entries.Count == 0)
            {
                leaderboardText.text = "No runs yet — be the first!";
                return;
            }
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("<b>RANK    SCORE   KILLS   TIME</b>");
            sb.AppendLine("");
            for (int i = 0; i < entries.Count; i++)
            {
                var e = entries[i];
                sb.AppendLine($"  #{i + 1,-3}  {e.score,6}   {e.kills,5}   {e.seconds}s");
            }
            leaderboardText.text = sb.ToString();
        }
    }
}
