using UnityEngine;
using TMPro;
using ClassSwap.Core;

namespace ClassSwap.UI
{
    /// <summary>
    /// Displays the current round number as a Roman numeral on the StoryGate panel.
    /// Listens to GameEvents.OnRoundChanged.
    /// </summary>
    public class RoundNumberDisplay : MonoBehaviour
    {
        TMP_Text target;
        StoryGate gate;

        public void Setup(StoryGate gate, TMP_Text target)
        {
            this.gate = gate;
            this.target = target;
            UpdateNumber(1);
        }

        void OnEnable() { GameEvents.OnRoundChanged += UpdateNumber; }
        void OnDisable() { GameEvents.OnRoundChanged -= UpdateNumber; }

        void UpdateNumber(int round)
        {
            if (!target) return;
            string roman = round switch { 1 => "I", 2 => "II", 3 => "III", _ => round.ToString() };
            target.text = roman;
        }
    }
}
