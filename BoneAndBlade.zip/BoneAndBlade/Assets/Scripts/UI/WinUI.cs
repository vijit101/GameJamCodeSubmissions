using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using ClassSwap.Core;

namespace ClassSwap.UI
{
    /// <summary>
    /// Shows a "You Survived" panel on game won. Press R to restart, ESC to return to menu.
    /// </summary>
    public class WinUI : MonoBehaviour
    {
        [SerializeField] GameObject panel;
        [SerializeField] TMP_Text statsText;
        [SerializeField] Progression.ScoreManager score;

        bool shown;

        void OnEnable() { GameEvents.OnGameWon += Show; }
        void OnDisable() { GameEvents.OnGameWon -= Show; }

        void Show()
        {
            shown = true;
            Time.timeScale = 0f;
            panel.SetActive(true);
            if (statsText != null && score != null)
            {
                statsText.text = $"VICTORY!\n\nScore: {score.Score}\nKills: {score.Kills}\nTime: {Mathf.RoundToInt(score.SecondsSurvived)}s";
            }
        }

        void Update()
        {
            if (!shown) return;
            if (Input.GetKeyDown(KeyCode.R))
            {
                Time.timeScale = 1f;
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
            else if (Input.GetKeyDown(KeyCode.Escape))
            {
                Time.timeScale = 1f;
                SceneManager.LoadScene("MainMenu");
            }
        }
    }
}
