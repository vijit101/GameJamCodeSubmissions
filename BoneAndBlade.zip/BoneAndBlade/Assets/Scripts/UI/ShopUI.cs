using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ClassSwap.Progression;

namespace ClassSwap.UI
{
    /// <summary>
    /// Press U mid-game to open the Shop. Shows coin balance + items.
    /// Items: 1/2/3/4 keys to buy; ESC closes.
    /// Pauses game while open.
    /// </summary>
    public class ShopUI : MonoBehaviour
    {
        [SerializeField] GameObject panel;
        [SerializeField] TMP_Text coinsText;
        [SerializeField] Transform itemContainer;
        [SerializeField] GameObject itemRowPrefab;       // any prefab with TMP_Text — first child name + cost; second child desc
        [SerializeField] ShopItem[] items;

        readonly List<TMP_Text> rowTexts = new List<TMP_Text>();
        bool open;
        float prevTimeScale = 1f;
        GameObject hudCoinText, hudCoinIcon, hudCoinBg;

        // OnGUI-captured key-down events (works even when Editor window focus is wonky)
        readonly HashSet<KeyCode> guiKeyDowns = new HashSet<KeyCode>();

        // Saved scene state starts panel inactive; do NOT re-disable in Awake.

        void OnGUI()
        {
            var e = Event.current;
            if (e == null || e.type != EventType.KeyDown) return;
            guiKeyDowns.Add(e.keyCode);
        }

        bool KeyDown(KeyCode k)
        {
            if (Input.GetKeyDown(k)) return true;
            if (guiKeyDowns.Contains(k)) return true;
            return false;
        }

        void LateUpdate() { guiKeyDowns.Clear(); }

        void Update()
        {
            if (KeyDown(KeyCode.U)) Toggle();
            if (!open) return;
            if (KeyDown(KeyCode.Escape)) Close();
            if (KeyDown(KeyCode.Alpha1)) TryBuy(0);
            if (KeyDown(KeyCode.Alpha2)) TryBuy(1);
            if (KeyDown(KeyCode.Alpha3)) TryBuy(2);
            if (KeyDown(KeyCode.Alpha4)) TryBuy(3);
        }

        public void Toggle() { if (open) Close(); else Open(); }

        public void Open()
        {
            if (panel) panel.SetActive(true);
            prevTimeScale = Time.timeScale;
            Time.timeScale = 0f;
            open = true;
            ToggleHudCoin(false);
            Refresh();
        }

        public void Close()
        {
            if (panel) panel.SetActive(false);
            Time.timeScale = prevTimeScale > 0 ? prevTimeScale : 1f;
            open = false;
            ToggleHudCoin(true);
        }

        void ToggleHudCoin(bool visible)
        {
            if (hudCoinText == null) hudCoinText = GameObject.Find("CoinHUDText");
            if (hudCoinIcon == null) hudCoinIcon = GameObject.Find("CoinHUDIcon");
            if (hudCoinBg == null) hudCoinBg = GameObject.Find("CoinHUDBg");
            if (hudCoinText) hudCoinText.SetActive(visible);
            if (hudCoinIcon) hudCoinIcon.SetActive(visible);
            if (hudCoinBg) hudCoinBg.SetActive(visible);
        }

        void TryBuy(int index)
        {
            if (items == null || index < 0 || index >= items.Length) return;
            if (ShopState.TryBuy(items[index]))
            {
                // Bought — refresh display
                Refresh();
            }
        }

        void Refresh()
        {
            if (CoinSystem.Instance != null && coinsText != null)
                coinsText.text = $"COINS: {CoinSystem.Instance.Total}";

            // Build rows
            if (itemContainer != null && itemRowPrefab != null)
            {
                foreach (Transform c in itemContainer) Destroy(c.gameObject);
                rowTexts.Clear();
                if (items == null) return;
                for (int i = 0; i < items.Length; i++)
                {
                    var item = items[i];
                    if (item == null) continue;
                    var row = Instantiate(itemRowPrefab, itemContainer);
                    var labels = row.GetComponentsInChildren<TMP_Text>();
                    int tier = ShopState.GetTier(item.id);
                    bool maxed = tier >= item.maxTiers;
                    string status = maxed ? "MAX" : $"({item.cost} coins)";
                    if (labels.Length > 0)
                        labels[0].text = $"[{i + 1}] {item.displayName}  Lv {tier}/{item.maxTiers}  {status}";
                    if (labels.Length > 1)
                        labels[1].text = item.description;
                    rowTexts.Add(labels.Length > 0 ? labels[0] : null);

                    // Mouse-click support: wire row Button onClick to TryBuy
                    var btn = row.GetComponent<Button>();
                    if (btn == null) btn = row.GetComponentInChildren<Button>();
                    if (btn != null)
                    {
                        int captured = i;
                        btn.onClick.RemoveAllListeners();
                        btn.onClick.AddListener(() => TryBuy(captured));
                    }

                    // Cost badge text: search for "CostText" child if present, fallback to last TMP
                    var costText = row.transform.Find("CostBg/CostText")?.GetComponent<TMP_Text>();
                    if (costText == null && labels.Length > 2) costText = labels[2];
                    if (costText != null)
                    {
                        costText.text = maxed ? "MAX" : item.cost.ToString();
                    }
                }
            }
        }
    }
}
