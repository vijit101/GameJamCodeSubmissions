using UnityEngine;
using TMPro;
using ClassSwap.Progression;

namespace ClassSwap.UI
{
    [RequireComponent(typeof(TextMeshProUGUI))]
    public class CoinHUDUpdater : MonoBehaviour
    {
        TextMeshProUGUI txt;

        void Awake() { txt = GetComponent<TextMeshProUGUI>(); }

        void Update()
        {
            if (CoinSystem.Instance == null) return;
            txt.text = $"Coins: {CoinSystem.Instance.Total}";
        }
    }
}
