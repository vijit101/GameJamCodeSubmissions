using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ClassSwap.Player;
using ClassSwap.Progression;
using ClassSwap.Spawning;
using ClassSwap.Core;

namespace ClassSwap.UI
{
    /// <summary>
    /// HUD: HP bar, XP bar (active class), round timer, kill counter, active class indicator.
    /// </summary>
    public class HUD : MonoBehaviour
    {
        [Header("Bars")]
        [SerializeField] Image hpFill;
        [SerializeField] Image xpFill;

        [Header("Text")]
        [SerializeField] TMP_Text timerText;
        [SerializeField] TMP_Text killText;
        [SerializeField] TMP_Text classText;

        [Header("Sources")]
        [SerializeField] PlayerHealth playerHealth;
        [SerializeField] XPSystem xpSystem;
        [SerializeField] RoundController roundController;

        int kills;

        void OnEnable()
        {
            if (playerHealth != null) playerHealth.OnChanged += UpdateHp;
            GameEvents.OnEnemyKilled += OnKill;
            UpdateHp(playerHealth != null ? playerHealth.Current : 0);
        }

        void OnDisable()
        {
            if (playerHealth != null) playerHealth.OnChanged -= UpdateHp;
            GameEvents.OnEnemyKilled -= OnKill;
        }

        void Update()
        {
            UpdateXp();
            UpdateTimer();
            UpdateClass();
        }

        void UpdateHp(int current)
        {
            if (hpFill == null || playerHealth == null) return;
            hpFill.fillAmount = playerHealth.Max > 0 ? (float)current / playerHealth.Max : 0f;
        }

        void UpdateXp()
        {
            if (xpFill == null || xpSystem == null) return;
            int next = xpSystem.ActiveXpToNext;
            xpFill.fillAmount = next > 0 ? Mathf.Clamp01((float)xpSystem.ActiveXp / next) : 0f;
        }

        void UpdateTimer()
        {
            if (timerText == null || roundController == null) return;
            int s = Mathf.CeilToInt(Mathf.Max(0f, roundController.RoundTimeRemaining));
            timerText.text = $"Round {roundController.CurrentRound}: {s/60}:{(s%60):D2}";
        }

        void UpdateClass()
        {
            if (classText == null || xpSystem == null) return;
            classText.text = $"{xpSystem.ActiveClass}  Lv {xpSystem.ActiveLevel}";
        }

        void OnKill(int _)
        {
            kills++;
            if (killText != null) killText.text = $"Kills: {kills}";
        }
    }
}
