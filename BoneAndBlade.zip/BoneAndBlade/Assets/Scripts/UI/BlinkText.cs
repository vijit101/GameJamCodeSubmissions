using UnityEngine;
using TMPro;

namespace ClassSwap.UI
{
    /// <summary>
    /// Pulses the alpha of a TextMeshProUGUI for an attention-grabbing blink.
    /// </summary>
    [RequireComponent(typeof(TextMeshProUGUI))]
    public class BlinkText : MonoBehaviour
    {
        [SerializeField] float frequency = 3f;
        [SerializeField] float minAlpha = 0.35f;
        [SerializeField] float maxAlpha = 1f;
        TextMeshProUGUI txt;

        void Awake() { txt = GetComponent<TextMeshProUGUI>(); }

        void Update()
        {
            float t = (Mathf.Sin(Time.time * frequency) + 1f) * 0.5f; // 0..1
            var c = txt.color;
            c.a = Mathf.Lerp(minAlpha, maxAlpha, t);
            txt.color = c;
        }
    }
}
