using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ClassSwap.Enemies;
using System.Reflection;

namespace ClassSwap.UI
{
    /// <summary>
    /// Shows a top-center boss health bar when a BossAI is alive in the scene.
    /// Polls for any active BossAI.
    /// </summary>
    public class BossHealthBar : MonoBehaviour
    {
        [SerializeField] GameObject panel;
        [SerializeField] Image fill;
        [SerializeField] TMP_Text nameText;
        [SerializeField] float findInterval = 0.5f;

        BossAI currentBoss;
        FieldInfo hpField;
        FieldInfo maxField;
        float nextFind;
        bool playerDead;

        void Awake()
        {
            hpField = typeof(EnemyBase).GetField("hp", BindingFlags.NonPublic | BindingFlags.Instance);
            maxField = typeof(EnemyBase).GetField("maxHp", BindingFlags.NonPublic | BindingFlags.Instance);
            if (panel) panel.SetActive(false);
        }

        void OnEnable() { ClassSwap.Core.GameEvents.OnPlayerDied += () => { playerDead = true; if (panel) panel.SetActive(false); }; }

        void Update()
        {
            if (playerDead) { if (panel && panel.activeSelf) panel.SetActive(false); return; }
            if (Time.timeScale == 0f) { if (panel && panel.activeSelf) panel.SetActive(false); return; }
            if (currentBoss == null || !currentBoss.gameObject.activeInHierarchy)
            {
                if (Time.time >= nextFind)
                {
                    nextFind = Time.time + findInterval;
                    currentBoss = GameObject.FindObjectOfType<BossAI>();
                }
                if (currentBoss == null || !currentBoss.gameObject.activeInHierarchy)
                {
                    if (panel && panel.activeSelf) panel.SetActive(false);
                    return;
                }
            }

            int hp = (int)hpField.GetValue(currentBoss);
            int max = (int)maxField.GetValue(currentBoss);

            if (panel && !panel.activeSelf) panel.SetActive(true);
            if (fill) fill.fillAmount = max > 0 ? Mathf.Clamp01((float)hp / max) : 0f;
            if (nameText) nameText.text = currentBoss.gameObject.name.Replace("Boss_", "").Replace("(Clone)", "").Replace("_", " ").ToUpperInvariant();

            if (hp <= 0)
            {
                if (panel) panel.SetActive(false);
                currentBoss = null;
            }
        }
    }
}
