using UnityEngine;
using TMPro;
using ClassSwap.Core;

namespace ClassSwap.UI
{
    /// <summary>
    /// Pauses the game and shows a full-screen story panel before each round starts.
    /// Player presses SPACE/ENTER to continue. Triggered by GameEvents.OnRoundChanged.
    /// </summary>
    public class StoryGate : MonoBehaviour
    {
        [System.Serializable]
        public class RoundStory
        {
            public string title = "Round";
            [TextArea] public string body = "";
            public string bossName = "";
        }

        [SerializeField] GameObject panel;
        [SerializeField] TMP_Text titleText;
        [SerializeField] TMP_Text bodyText;
        [SerializeField] TMP_Text bossText;
        [SerializeField] TMP_Text continueHint;
        [SerializeField] RoundStory[] stories;

        bool waiting;
        float prevTimeScale = 1f;
        readonly System.Collections.Generic.HashSet<KeyCode> guiKeys = new System.Collections.Generic.HashSet<KeyCode>();

        // Saved scene state starts panel inactive; do NOT re-disable in Awake (would self-defeat Show()).
        void OnEnable() { GameEvents.OnRoundChanged += Show; }
        void OnDisable() { GameEvents.OnRoundChanged -= Show; }

        void OnGUI() { var e = Event.current; if (e != null && e.type == EventType.KeyDown) guiKeys.Add(e.keyCode); }
        void LateUpdate() { guiKeys.Clear(); }
        bool KeyDown(KeyCode k) => Input.GetKeyDown(k) || guiKeys.Contains(k);

        void Start()
        {
            // Show round 1 story shortly after scene start (no OnRoundChanged fires for round 1)
            if (stories != null && stories.Length > 0) Show(1);
        }

        void Show(int roundOneIndexed)
        {
            int idx = Mathf.Clamp(roundOneIndexed - 1, 0, stories.Length - 1);
            var s = stories[idx];
            if (titleText) titleText.text = s.title;
            if (bodyText) bodyText.text = s.body;
            if (bossText) bossText.text = string.IsNullOrEmpty(s.bossName) ? "" : "BOSS: " + s.bossName;
            if (continueHint) continueHint.text = "Press SPACE to begin";
            if (panel) panel.SetActive(true);
            prevTimeScale = Time.timeScale;
            Time.timeScale = 0f;
            waiting = true;
        }

        void Update()
        {
            if (!waiting) return;
            if (KeyDown(KeyCode.Space) || KeyDown(KeyCode.Return) || KeyDown(KeyCode.KeypadEnter))
            {
                Dismiss();
            }
        }

        void Dismiss()
        {
            waiting = false;
            if (panel) panel.SetActive(false);
            Time.timeScale = prevTimeScale > 0 ? prevTimeScale : 1f;
        }
    }
}
