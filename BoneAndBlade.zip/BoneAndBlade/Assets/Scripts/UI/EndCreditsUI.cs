using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using ClassSwap.Core;

namespace ClassSwap.UI
{
    /// <summary>
    /// Plays after final boss is defeated — shows closure story + credits.
    /// Press SPACE/ENTER to return to MainMenu.
    /// </summary>
    public class EndCreditsUI : MonoBehaviour
    {
        [SerializeField] GameObject panel;
        [SerializeField] TMP_Text bodyText;
        [SerializeField] string menuSceneName = "MainMenu";
        [SerializeField, TextArea(8, 20)] string credits =
            "The Skeleton King falls. His crown clatters to the sand.\n\n" +
            "The Coliseum's roar fades. The torches dim, one by one. " +
            "Above the broken pillars, dawn breaks for the first time in a hundred years.\n\n" +
            "You walk out into the morning sun.\n\n\n" +
            "<b>CLASS SWAP SURVIVOR</b>\n" +
            "A 24-hour solo game jam entry by\n" +
            "<color=#FFD24A>Satish Rathod</color>  (Scaler School of Technology)\n\n" +
            "Built with Unity 6 + Claude Code + ai-game-developer MCP\n\n" +
            "All visuals procedurally generated\n" +
            "All audio procedurally synthesized\n\n" +
            "Press SPACE to return to the menu";

        bool waiting;

        void OnEnable() { GameEvents.OnGameWon += Show; }
        void OnDisable() { GameEvents.OnGameWon -= Show; }

        void Show()
        {
            if (panel) panel.SetActive(true);
            if (bodyText) bodyText.text = credits;
            waiting = true;
            Time.timeScale = 0f;
        }

        void Update()
        {
            if (!waiting) return;
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            {
                waiting = false;
                Time.timeScale = 1f;
                SceneManager.LoadScene(menuSceneName);
            }
        }
    }
}
