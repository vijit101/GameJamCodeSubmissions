using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

namespace ClassSwap.UI
{
    /// <summary>
    /// Title screen — shows high score, press SPACE to start.
    /// </summary>
    public class TitleUI : MonoBehaviour
    {
        [SerializeField] TMP_Text highScoreText;
        [SerializeField] string gameSceneName = "Game";

        void Start()
        {
            int hs = PlayerPrefs.GetInt("HighScore", 0);
            if (highScoreText != null) highScoreText.text = $"Best: {hs}";
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                SceneManager.LoadScene(gameSceneName);
            }
        }
    }
}
