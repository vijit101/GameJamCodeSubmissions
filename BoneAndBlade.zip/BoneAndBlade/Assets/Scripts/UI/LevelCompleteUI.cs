using System;
using UnityEngine;
using TMPro;

namespace ClassSwap.UI
{
    /// <summary>
    /// Pauses the game on boss death, shows "LEVEL X COMPLETE" + tip + SPACE-to-continue.
    /// Player can press U to open shop first (still works since ShopUI checks U globally).
    /// </summary>
    public class LevelCompleteUI : MonoBehaviour
    {
        [SerializeField] GameObject panel;
        [SerializeField] TMP_Text titleText;
        [SerializeField] TMP_Text bodyText;
        [SerializeField] TMP_Text continueHint;

        Action continueCallback;
        bool waiting;
        float prevTimeScale = 1f;
        readonly System.Collections.Generic.HashSet<KeyCode> guiKeys = new System.Collections.Generic.HashSet<KeyCode>();

        // Don't auto-deactivate panel in Awake — when LevelManager activates it, this would re-disable it.
        // Saved scene state already starts panel inactive.
        void OnGUI() { var e = Event.current; if (e != null && e.type == EventType.KeyDown) guiKeys.Add(e.keyCode); }
        void LateUpdate() { guiKeys.Clear(); }
        bool KeyDown(KeyCode k) => Input.GetKeyDown(k) || guiKeys.Contains(k);

        public void Show(int levelJustCleared, Action onContinue)
        {
            continueCallback = onContinue;
            if (titleText) titleText.text = $"LEVEL {levelJustCleared} COMPLETE";
            if (bodyText) bodyText.text = "Boss defeated.\n\nPress U to spend coins in the shop, then SPACE when ready.";
            if (continueHint) continueHint.text = "Press SPACE to advance";
            if (panel) panel.SetActive(true);
            prevTimeScale = Time.timeScale;
            Time.timeScale = 0f;
            waiting = true;
        }

        void Update()
        {
            if (!waiting) return;
            if (KeyDown(KeyCode.Space) || KeyDown(KeyCode.Return) || KeyDown(KeyCode.KeypadEnter))
            {
                Dismiss();
            }
        }

        void Dismiss()
        {
            waiting = false;
            if (panel) panel.SetActive(false);
            Time.timeScale = prevTimeScale > 0 ? prevTimeScale : 1f;
            continueCallback?.Invoke();
        }
    }
}
