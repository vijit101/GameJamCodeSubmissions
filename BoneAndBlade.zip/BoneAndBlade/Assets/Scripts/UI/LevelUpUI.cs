using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ClassSwap.Core;
using ClassSwap.Classes;
using ClassSwap.Progression;

namespace ClassSwap.UI
{
    /// <summary>
    /// Pauses time on LevelUp event, shows 3 random upgrade cards for the active class,
    /// applies the chosen one, and resumes.
    /// </summary>
    public class LevelUpUI : MonoBehaviour
    {
        [Header("UI references")]
        [SerializeField] GameObject panel;
        [SerializeField] Transform cardContainer;
        [SerializeField] GameObject cardPrefab;       // prefab with: TMP_Text 'name', TMP_Text 'desc', Button

        [Header("Sources")]
        [SerializeField] ClassSwapper classSwapper;
        [SerializeField] UpgradeApplier applier;
        [SerializeField] List<UpgradeData> allUpgrades = new List<UpgradeData>();   // drag every UpgradeData SO here

        readonly System.Collections.Generic.List<UpgradeData> currentChoices = new System.Collections.Generic.List<UpgradeData>();

        // Auto-popup disabled — all upgrades now happen via the shop (press U).
        // Level-up event still fires (HUD shows level), but no panel interrupts gameplay.
        void OnEnable() { /* GameEvents.OnLevelUp += Show; */ }
        void OnDisable() { /* GameEvents.OnLevelUp -= Show; */ }

        void Update()
        {
            if (!panel || !panel.activeSelf) return;
            // Keyboard shortcuts as fallback (Editor input often misses Button clicks at timeScale=0)
            if (Input.GetKeyDown(KeyCode.Alpha1) && currentChoices.Count > 0) Choose(currentChoices[0]);
            else if (Input.GetKeyDown(KeyCode.Alpha2) && currentChoices.Count > 1) Choose(currentChoices[1]);
            else if (Input.GetKeyDown(KeyCode.Alpha3) && currentChoices.Count > 2) Choose(currentChoices[2]);
        }

        void Show(int newLevel)
        {
            ClassId active = classSwapper != null ? classSwapper.ActiveClass : ClassId.Knight;
            UpgradeTier maxTier = newLevel >= 7 ? UpgradeTier.T3
                                : newLevel >= 4 ? UpgradeTier.T2
                                : UpgradeTier.T1;

            var pool = allUpgrades
                .Where(u => u != null && u.cls == active && u.tier <= maxTier)
                .ToList();

            if (pool.Count == 0)
            {
                Debug.LogWarning($"[LevelUpUI] No upgrades available for {active} at level {newLevel}");
                return;
            }

            // Pick up to 3 unique upgrades
            var picks = pool.OrderBy(_ => Random.value).Take(Mathf.Min(3, pool.Count)).ToList();

            currentChoices.Clear();
            currentChoices.AddRange(picks);

            Time.timeScale = 0f;
            panel.SetActive(true);
            foreach (Transform c in cardContainer) Destroy(c.gameObject);
            for (int i = 0; i < picks.Count; i++) SpawnCard(picks[i], i + 1);
        }

        void SpawnCard(UpgradeData up, int hotkey)
        {
            var go = Instantiate(cardPrefab, cardContainer);

            // Set text via TMP fields (find first two TMP_Text children)
            var labels = go.GetComponentsInChildren<TMP_Text>();
            if (labels.Length > 0) labels[0].text = $"[{hotkey}]  {up.displayName}";
            if (labels.Length > 1) labels[1].text = up.description;

            var btn = go.GetComponent<Button>();
            if (btn == null) btn = go.GetComponentInChildren<Button>();
            if (btn != null) btn.onClick.AddListener(() => Choose(up));
        }

        void Choose(UpgradeData up)
        {
            applier.Apply(up);
            panel.SetActive(false);
            Time.timeScale = 1f;
        }
    }
}
