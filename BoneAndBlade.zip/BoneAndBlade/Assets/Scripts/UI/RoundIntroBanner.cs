using System.Collections;
using UnityEngine;
using TMPro;

namespace ClassSwap.UI
{
    /// <summary>
    /// Centered title + subtitle that fades in/out at round transitions.
    /// </summary>
    public class RoundIntroBanner : MonoBehaviour
    {
        [SerializeField] CanvasGroup group;
        [SerializeField] TMP_Text titleText;
        [SerializeField] TMP_Text subtitleText;
        [SerializeField] float fadeIn = 0.6f;
        [SerializeField] float hold = 2.5f;
        [SerializeField] float fadeOut = 1.0f;

        Coroutine running;

        void Awake() { if (group) group.alpha = 0f; }

        public void Show(string title, string subtitle, Color color)
        {
            if (!gameObject.activeInHierarchy) gameObject.SetActive(true);
            if (titleText) { titleText.text = title; titleText.color = color; }
            if (subtitleText) subtitleText.text = subtitle;
            if (running != null) StopCoroutine(running);
            running = StartCoroutine(Animate());
        }

        IEnumerator Animate()
        {
            if (!group) yield break;
            float t = 0;
            while (t < fadeIn) { t += Time.unscaledDeltaTime; group.alpha = Mathf.Clamp01(t / fadeIn); yield return null; }
            yield return new WaitForSecondsRealtime(hold);
            t = 0;
            while (t < fadeOut) { t += Time.unscaledDeltaTime; group.alpha = 1f - Mathf.Clamp01(t / fadeOut); yield return null; }
            group.alpha = 0f;
            running = null;
        }
    }
}
