using System;
using System.Collections.Generic;
using UnityEngine;

namespace ClassSwap.UI
{
    /// <summary>
    /// Local top-10 leaderboard persisted via PlayerPrefs (CSV-encoded).
    /// </summary>
    public static class Leaderboard
    {
        const string KEY = "Leaderboard_v1";
        const int MAX_ENTRIES = 10;

        [Serializable]
        public class Entry
        {
            public int score;
            public int kills;
            public int seconds;
            public long timestamp;
        }

        public static List<Entry> Load()
        {
            string s = PlayerPrefs.GetString(KEY, "");
            var list = new List<Entry>();
            if (string.IsNullOrEmpty(s)) return list;
            foreach (var line in s.Split('|'))
            {
                if (string.IsNullOrEmpty(line)) continue;
                var parts = line.Split(',');
                if (parts.Length < 4) continue;
                if (int.TryParse(parts[0], out int sc) &&
                    int.TryParse(parts[1], out int k) &&
                    int.TryParse(parts[2], out int sec) &&
                    long.TryParse(parts[3], out long ts))
                {
                    list.Add(new Entry { score = sc, kills = k, seconds = sec, timestamp = ts });
                }
            }
            list.Sort((a, b) => b.score.CompareTo(a.score));
            return list;
        }

        public static void Submit(int score, int kills, int seconds)
        {
            var list = Load();
            list.Add(new Entry { score = score, kills = kills, seconds = seconds, timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds() });
            list.Sort((a, b) => b.score.CompareTo(a.score));
            if (list.Count > MAX_ENTRIES) list = list.GetRange(0, MAX_ENTRIES);
            var sb = new System.Text.StringBuilder();
            foreach (var e in list)
            {
                if (sb.Length > 0) sb.Append('|');
                sb.Append(e.score).Append(',').Append(e.kills).Append(',').Append(e.seconds).Append(',').Append(e.timestamp);
            }
            PlayerPrefs.SetString(KEY, sb.ToString());
            PlayerPrefs.Save();
        }
    }
}
