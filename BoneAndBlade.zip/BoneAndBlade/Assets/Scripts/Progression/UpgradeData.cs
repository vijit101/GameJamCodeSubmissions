using UnityEngine;
using ClassSwap.Classes;

namespace ClassSwap.Progression
{
    public enum UpgradeTier { T1, T2, T3 }

    public enum UpgradeEffect
    {
        // Knight
        KnightDamage,
        KnightAttackSpeed,
        KnightArcWidth,
        KnightRange,
        KnightMaxHP,
        KnightWhirlwind,        // T2
        KnightShockwave,        // T3

        // Wizard
        WizardDamage,
        WizardCooldown,
        WizardRadius,
        WizardPiercingBeam,     // T2
        WizardLightningChain,   // T3

        // Assassin
        AssassinDamage,
        AssassinExtraDagger,
        AssassinDaggerSpeed,
        AssassinDashCd,
        AssassinPoisonCloud,    // T2
        AssassinShadowClone     // T3
    }

    /// <summary>
    /// ScriptableObject for an upgrade card. Created via Assets → Create → ClassSwap → Upgrade.
    /// </summary>
    [CreateAssetMenu(menuName = "ClassSwap/Upgrade", fileName = "Upgrade_New")]
    public class UpgradeData : ScriptableObject
    {
        public string displayName = "Upgrade";
        [TextArea] public string description = "";
        public Sprite icon;
        public ClassId cls = ClassId.Knight;
        public UpgradeTier tier = UpgradeTier.T1;
        public UpgradeEffect effect;
        [Tooltip("Magnitude meaning depends on effect — e.g. 0.20 = +20% multiplier; 20 = flat +20")]
        public float magnitude = 0.20f;
    }
}
