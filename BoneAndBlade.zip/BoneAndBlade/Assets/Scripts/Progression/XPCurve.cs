using System;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Pure-logic XP curve. Used by XPSystem.
    /// Curve: lvl 2 needs 5 XP, scales by 1.5x per level.
    /// </summary>
    public static class XPCurve
    {
        const int BaseXP = 5;
        const double Scale = 1.5;

        /// <summary>XP required to advance from (level-1) to level.</summary>
        public static int RequiredFor(int level)
        {
            if (level <= 1) return 0;
            return (int)Math.Floor(BaseXP * Math.Pow(Scale, level - 2));
        }

        /// <summary>Total cumulative XP needed from level 1 to reach this level.</summary>
        public static int TotalFor(int level)
        {
            if (level <= 1) return 0;
            int total = 0;
            for (int l = 2; l <= level; l++) total += RequiredFor(l);
            return total;
        }
    }
}
