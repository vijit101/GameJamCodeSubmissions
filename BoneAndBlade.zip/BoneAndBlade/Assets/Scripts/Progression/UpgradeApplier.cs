using UnityEngine;
using ClassSwap.Player;
using ClassSwap.Classes;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Applies a chosen UpgradeData to the relevant class component on the player.
    /// Wire references in Inspector.
    /// </summary>
    public class UpgradeApplier : MonoBehaviour
    {
        [SerializeField] KnightAttack knight;
        [SerializeField] WizardAttack wizard;
        [SerializeField] AssassinAttack assassin;
        [SerializeField] PlayerHealth health;

        public void Apply(UpgradeData u)
        {
            if (u == null) return;
            float m = u.magnitude;

            switch (u.effect)
            {
                // Knight
                case UpgradeEffect.KnightDamage: knight?.ModifyDamage(1f + m); break;
                case UpgradeEffect.KnightAttackSpeed: knight?.ModifyAttackSpeed(1f + m); break;
                case UpgradeEffect.KnightArcWidth: knight?.ModifyArcWidth(1f + m); break;
                case UpgradeEffect.KnightRange: knight?.ModifyRange(1f + m); break;
                case UpgradeEffect.KnightMaxHP: health?.IncreaseMaxHP(Mathf.RoundToInt(m)); break;
                case UpgradeEffect.KnightWhirlwind:
                case UpgradeEffect.KnightShockwave:
                    Debug.Log($"[Upgrade] Knight T2/T3 effect {u.effect} not yet implemented (planned).");
                    break;

                // Wizard
                case UpgradeEffect.WizardCooldown: wizard?.ModifyAttackSpeed(1f + m); break;
                case UpgradeEffect.WizardDamage:
                case UpgradeEffect.WizardRadius:
                case UpgradeEffect.WizardPiercingBeam:
                case UpgradeEffect.WizardLightningChain:
                    Debug.Log($"[Upgrade] Wizard effect {u.effect} requires Fireball prefab tuning at upgrade time (planned).");
                    break;

                // Assassin
                case UpgradeEffect.AssassinExtraDagger: assassin?.ModifyDaggersPerVolley(1); break;
                case UpgradeEffect.AssassinDaggerSpeed: assassin?.ModifyAttackSpeed(1f + m); break;
                case UpgradeEffect.AssassinDamage:
                case UpgradeEffect.AssassinDashCd:
                case UpgradeEffect.AssassinPoisonCloud:
                case UpgradeEffect.AssassinShadowClone:
                    Debug.Log($"[Upgrade] Assassin effect {u.effect} not yet implemented (planned).");
                    break;
            }
        }
    }
}
