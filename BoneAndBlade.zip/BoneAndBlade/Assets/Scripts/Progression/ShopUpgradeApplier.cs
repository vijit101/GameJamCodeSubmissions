using UnityEngine;
using ClassSwap.Player;
using ClassSwap.Classes;

namespace ClassSwap.Progression
{
    /// <summary>
    /// At run start, applies purchased shop upgrades to the player components.
    /// Attach to Player GameObject. Assign the catalogue of ShopItems.
    /// </summary>
    public class ShopUpgradeApplier : MonoBehaviour
    {
        [SerializeField] ShopItem[] catalogue;

        void Start()
        {
            if (catalogue == null) return;
            var hp = GetComponent<PlayerHealth>();
            var knight = GetComponent<KnightAttack>();
            var wizard = GetComponent<WizardAttack>();
            var assassin = GetComponent<AssassinAttack>();
            var ctrl = GetComponent<PlayerController>();

            foreach (var item in catalogue)
            {
                if (item == null) continue;
                int tier = ShopState.GetTier(item.id);
                if (tier <= 0) continue;
                float stacked = item.magnitude * tier;
                switch (item.effect)
                {
                    case ShopEffect.StartingMaxHp:
                        hp?.IncreaseMaxHP(Mathf.RoundToInt(stacked));
                        break;
                    case ShopEffect.StartingDamageMult:
                        knight?.ModifyDamage(1f + stacked);
                        // WizardAttack doesn't have ModifyDamage; handled via Fireball at spawn-time in future
                        break;
                    case ShopEffect.StartingSpeedMult:
                        // PlayerController doesn't expose moveSpeed — skip for jam; reserved for future
                        break;
                    case ShopEffect.StartingArmor:
                        // No armor system yet — could mitigate in PlayerHealth.TakeDamage
                        break;
                    case ShopEffect.ExtraXpGain:
                    case ShopEffect.ExtraCoinGain:
                        // Apply via multiplier hooks in XP/CoinSystem — skipped for jam brevity
                        break;
                }
            }
        }
    }
}
