using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Tracks run stats and computes score. Persists high score to PlayerPrefs on death/win.
    /// </summary>
    public class ScoreManager : MonoBehaviour
    {
        public int Kills { get; private set; }
        public float SecondsSurvived { get; private set; }
        public int RoundsCompleted { get; private set; }
        public bool BossKilled { get; private set; }

        public int Score =>
            Kills * 10 +
            Mathf.RoundToInt(SecondsSurvived) * 5 +
            RoundsCompleted * 500 +
            (BossKilled ? 2000 : 0);

        bool gameEnded;

        void OnEnable()
        {
            GameEvents.OnEnemyKilled += OnKill;
            GameEvents.OnRoundChanged += OnRound;
            GameEvents.OnGameWon += OnWin;
            GameEvents.OnPlayerDied += OnDeath;
        }

        void OnDisable()
        {
            GameEvents.OnEnemyKilled -= OnKill;
            GameEvents.OnRoundChanged -= OnRound;
            GameEvents.OnGameWon -= OnWin;
            GameEvents.OnPlayerDied -= OnDeath;
        }

        void Update()
        {
            if (!gameEnded) SecondsSurvived += Time.deltaTime;
        }

        void OnKill(int _) => Kills++;
        void OnRound(int r) => RoundsCompleted = Mathf.Max(RoundsCompleted, r - 1); // completing round r-1 when r starts
        void OnWin()
        {
            BossKilled = true;
            RoundsCompleted = 3;
            SaveHighScore();
            gameEnded = true;
        }
        void OnDeath()
        {
            SaveHighScore();
            gameEnded = true;
        }

        void SaveHighScore()
        {
            int hs = PlayerPrefs.GetInt("HighScore", 0);
            if (Score > hs)
            {
                PlayerPrefs.SetInt("HighScore", Score);
                PlayerPrefs.Save();
            }
            // Submit run to local top-10 leaderboard
            ClassSwap.UI.Leaderboard.Submit(Score, Kills, Mathf.RoundToInt(SecondsSurvived));
        }
    }
}
