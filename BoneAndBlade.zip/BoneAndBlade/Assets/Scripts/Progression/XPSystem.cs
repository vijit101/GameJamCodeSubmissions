using UnityEngine;
using ClassSwap.Core;
using ClassSwap.Classes;
using System.Collections.Generic;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Per-class XP tracking. Active class gets the XP from each gem pickup.
    /// </summary>
    public class XPSystem : MonoBehaviour
    {
        [SerializeField] ClassSwapper swapper;

        readonly Dictionary<ClassId, int> currentXp = new Dictionary<ClassId, int>();
        readonly Dictionary<ClassId, int> level = new Dictionary<ClassId, int>();

        public ClassId ActiveClass => swapper != null ? swapper.ActiveClass : ClassId.Knight;
        public int LevelOf(ClassId c) => level.TryGetValue(c, out var l) ? l : 1;
        public int CurrentXpOf(ClassId c) => currentXp.TryGetValue(c, out var x) ? x : 0;
        public int XpToNext(ClassId c) => XPCurve.RequiredFor(LevelOf(c) + 1);
        public int ActiveLevel => LevelOf(ActiveClass);
        public int ActiveXp => CurrentXpOf(ActiveClass);
        public int ActiveXpToNext => XpToNext(ActiveClass);

        void Awake()
        {
            foreach (ClassId c in System.Enum.GetValues(typeof(ClassId)))
            {
                currentXp[c] = 0;
                level[c] = 1;
            }
        }

        void OnEnable() { GameEvents.OnXPPickup += OnPickup; }
        void OnDisable() { GameEvents.OnXPPickup -= OnPickup; }

        void OnPickup(int amount)
        {
            var cls = ActiveClass;
            EnsureClassInitialized(cls);
            currentXp[cls] += amount;
            while (currentXp[cls] >= XpToNext(cls))
            {
                currentXp[cls] -= XpToNext(cls);
                level[cls]++;
                GameEvents.RaiseLevelUp(level[cls]);
            }
        }

        void EnsureClassInitialized(ClassId c)
        {
            if (!currentXp.ContainsKey(c)) currentXp[c] = 0;
            if (!level.ContainsKey(c)) level[c] = 1;
        }
    }
}
