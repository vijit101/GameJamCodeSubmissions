using UnityEngine;

namespace ClassSwap.Progression
{
    public enum ShopEffect
    {
        StartingMaxHp,        // +N flat HP at run start
        StartingDamageMult,   // +X% all-class damage multiplier
        StartingSpeedMult,    // +X% movement speed
        StartingArmor,        // -X% damage taken (cap to 0)
        ExtraXpGain,          // +X% XP from gems
        ExtraCoinGain         // +X% coins from drops
    }

    /// <summary>
    /// Permanent purchasable upgrade. Bought items persist across runs (PlayerPrefs flag).
    /// Multiple purchases stack via 'tier' field.
    /// </summary>
    [CreateAssetMenu(menuName = "ClassSwap/ShopItem")]
    public class ShopItem : ScriptableObject
    {
        public string id = "item_id";
        public string displayName = "Upgrade";
        [TextArea] public string description = "";
        public int cost = 50;
        public ShopEffect effect;
        public float magnitude = 0.1f;   // 0.1 = +10% or +10 etc.
        public int maxTiers = 3;         // how many times it can be bought
    }
}
