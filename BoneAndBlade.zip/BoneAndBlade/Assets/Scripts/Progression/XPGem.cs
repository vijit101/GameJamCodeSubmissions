using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Progression
{
    /// <summary>
    /// XP gem dropped by enemies. Magnets to player when within magnetRadius;
    /// raises GameEvents.OnXPPickup when player touches it.
    /// </summary>
    public class XPGem : MonoBehaviour
    {
        [SerializeField] int value = 1;
        [SerializeField] float magnetRadius = 3f;
        [SerializeField] float pickupRadius = 0.6f;
        [SerializeField] float flySpeed = 12f;

        Transform player;

        void OnEnable()
        {
            var go = GameObject.FindWithTag("Player");
            if (go != null) player = go.transform;
        }

        public void SetValue(int v) => value = v;

        void Update()
        {
            if (player == null) return;
            Vector3 toPlayer = player.position - transform.position;
            toPlayer.y = 0;
            float d = toPlayer.magnitude;

            if (d <= pickupRadius)
            {
                GameEvents.RaiseXPPickup(value);
                gameObject.SetActive(false);
                return;
            }

            if (d <= magnetRadius)
            {
                Vector3 step = toPlayer.normalized * flySpeed * Time.deltaTime;
                transform.position += step;
            }
        }
    }
}
