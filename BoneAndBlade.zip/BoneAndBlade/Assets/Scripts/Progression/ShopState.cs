using UnityEngine;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Persistent record of how many tiers of each ShopItem the player has bought.
    /// Stored as PlayerPrefs int per item id.
    /// </summary>
    public static class ShopState
    {
        public static int GetTier(string id) => PlayerPrefs.GetInt("Shop_" + id, 0);
        public static void SetTier(string id, int tier)
        {
            PlayerPrefs.SetInt("Shop_" + id, tier);
            PlayerPrefs.Save();
        }
        public static bool TryBuy(ShopItem item)
        {
            int t = GetTier(item.id);
            if (t >= item.maxTiers) return false;
            if (CoinSystem.Instance == null || !CoinSystem.Instance.TrySpend(item.cost)) return false;
            SetTier(item.id, t + 1);
            return true;
        }
    }
}
