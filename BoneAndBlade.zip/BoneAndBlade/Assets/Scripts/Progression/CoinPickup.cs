using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Gold coin world pickup. Magnets to player + raises OnCoinPickup.
    /// </summary>
    public class CoinPickup : MonoBehaviour
    {
        [SerializeField] int value = 1;
        [SerializeField] float magnetRadius = 4f;
        [SerializeField] float pickupRadius = 0.7f;
        [SerializeField] float flySpeed = 14f;

        Transform player;

        void OnEnable()
        {
            var go = GameObject.FindWithTag("Player");
            if (go) player = go.transform;
        }

        void Update()
        {
            if (player == null) return;
            Vector3 toPlayer = player.position - transform.position;
            toPlayer.y = 0;
            float d = toPlayer.magnitude;
            if (d <= pickupRadius)
            {
                GameEvents.RaiseCoinPickup(value);
                gameObject.SetActive(false);
                return;
            }
            if (d <= magnetRadius)
            {
                transform.position += toPlayer.normalized * flySpeed * Time.deltaTime;
            }
            // gentle spin for visual flair
            transform.Rotate(0, 180f * Time.deltaTime, 0);
        }
    }
}
