using System;
using UnityEngine;
using ClassSwap.Core;

namespace ClassSwap.Progression
{
    /// <summary>
    /// Tracks player coins (persistent PlayerPrefs balance + per-run earned).
    /// Singleton — accessible anywhere via CoinSystem.Instance.
    /// </summary>
    public class CoinSystem : MonoBehaviour
    {
        public static CoinSystem Instance { get; private set; }
        const string KEY = "Coins";

        public int Total { get; private set; }
        public int RunEarned { get; private set; }

        public event Action<int> OnTotalChanged;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Total = PlayerPrefs.GetInt(KEY, 0);
            GameEvents.OnCoinPickup += AddCoin;
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
            GameEvents.OnCoinPickup -= AddCoin;
        }

        void AddCoin(int amount)
        {
            Total += amount;
            RunEarned += amount;
            PlayerPrefs.SetInt(KEY, Total);
            PlayerPrefs.Save();
            OnTotalChanged?.Invoke(Total);
        }

        public bool TrySpend(int amount)
        {
            if (Total < amount) return false;
            Total -= amount;
            PlayerPrefs.SetInt(KEY, Total);
            PlayerPrefs.Save();
            OnTotalChanged?.Invoke(Total);
            return true;
        }
    }
}
