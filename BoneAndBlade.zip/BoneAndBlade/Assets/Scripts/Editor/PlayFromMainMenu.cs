using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ClassSwap.Build
{
    /// <summary>
    /// Forces play mode to always start from MainMenu.unity, no matter which scene is open in the Editor.
    /// Toggle via: Build → Toggle Play From MainMenu.
    /// </summary>
    [InitializeOnLoad]
    public static class PlayFromMainMenu
    {
        const string MENU_PATH = "Build/Toggle Play From MainMenu";
        const string PREF_KEY = "PlayFromMainMenu_Enabled";
        const string MAIN_SCENE = "Assets/Scenes/MainMenu.unity";

        static PlayFromMainMenu()
        {
            EditorApplication.delayCall += Apply;
        }

        static void Apply()
        {
            bool on = EditorPrefs.GetBool(PREF_KEY, true); // default ON
            Menu.SetChecked(MENU_PATH, on);
            var scene = AssetDatabase.LoadAssetAtPath<SceneAsset>(MAIN_SCENE);
            EditorSceneManager.playModeStartScene = on ? scene : null;
        }

        [MenuItem(MENU_PATH)]
        public static void Toggle()
        {
            bool on = !EditorPrefs.GetBool(PREF_KEY, true);
            EditorPrefs.SetBool(PREF_KEY, on);
            Apply();
            Debug.Log($"[PlayFromMainMenu] {(on ? "ENABLED" : "DISABLED")} — Play will {(on ? "always start from MainMenu" : "use the active scene")}");
        }
    }
}
