using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace ClassSwap.Build
{
    public static class WebGLBuilder
    {
        const string BUILD_PATH = "Builds/WebGL";

        [MenuItem("Build/WebGL %#b")]   // Cmd+Shift+B
        public static void BuildMenu() => Build();

        public static void Build()
        {
            // Ensure scenes are in build settings (MainMenu first, Game second)
            var scenes = new EditorBuildSettingsScene[]
            {
                new EditorBuildSettingsScene("Assets/Scenes/MainMenu.unity", true),
                new EditorBuildSettingsScene("Assets/Scenes/Game.unity", true)
            };
            EditorBuildSettings.scenes = scenes;

            // Player settings tweaks for WebGL
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.WebGL, ScriptingImplementation.IL2CPP);
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled; // simpler local serving
            PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.None;
            PlayerSettings.WebGL.memorySize = 512;
            PlayerSettings.WebGL.template = "PROJECT:Default";
            PlayerSettings.runInBackground = true;
            PlayerSettings.defaultScreenWidth = 1280;
            PlayerSettings.defaultScreenHeight = 720;
            PlayerSettings.productName = "BONE & BLADE";
            PlayerSettings.companyName = "satish-rathod";

            // Output dir
            string fullPath = Path.GetFullPath(Path.Combine(Application.dataPath, "..", BUILD_PATH));
            Directory.CreateDirectory(fullPath);

            var opts = new BuildPlayerOptions
            {
                scenes = new[] { "Assets/Scenes/MainMenu.unity", "Assets/Scenes/Game.unity" },
                locationPathName = fullPath,
                target = BuildTarget.WebGL,
                options = BuildOptions.None
            };

            Debug.Log($"[WebGLBuilder] Starting build to {fullPath}");
            BuildReport report = BuildPipeline.BuildPlayer(opts);
            BuildSummary summary = report.summary;

            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"[WebGLBuilder] BUILD OK — {summary.totalSize / (1024f * 1024f):F1} MB at {fullPath}");
                EditorUtility.DisplayDialog("WebGL Build", $"Build succeeded.\n\n{summary.totalSize / (1024f * 1024f):F1} MB\nLocation: {fullPath}", "OK");
            }
            else
            {
                Debug.LogError($"[WebGLBuilder] BUILD FAILED: {summary.result} — {summary.totalErrors} errors");
                EditorUtility.DisplayDialog("WebGL Build", $"Build FAILED ({summary.totalErrors} errors). Check console.", "OK");
            }
        }
    }
}
