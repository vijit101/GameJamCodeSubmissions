using UnityEngine;
using System.Collections.Generic;
#if USE_NEW_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace ClassSwap.Player
{
    /// <summary>
    /// WASD movement + facing. Dash (double-tap direction) unlocks when AssassinAttack is active.
    /// Rigidbody-based — FreezeY + FreezeRotation so player stays on floor plane.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] float moveSpeed = 6f;

        [Header("Dash (enabled by Assassin class)")]
        [SerializeField] float dashImpulse = 14f;
        [SerializeField] float dashDuration = 0.25f;
        [SerializeField] float dashCooldown = 2f;
        [SerializeField] float doubleTapWindow = 0.25f;

        Rigidbody rb;
        Vector3 moveDir;
        Vector3 facing = Vector3.forward;

        // Dash state
        public bool DashEnabled { get; set; }        // flipped on/off by AssassinAttack
        public bool IsDashing { get; private set; }
        public bool IFrames => IsDashing;
        float dashTimer;
        float dashCdTimer;
        KeyCode lastKey;
        float lastKeyTime;

        void Awake()
        {
            rb = GetComponent<Rigidbody>();
            rb.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionY;
            rb.useGravity = false;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
        }

        public Vector3 AimDirection => facing;

        float dbgLogTimer;

        // OnGUI-captured held keys (works even when standard Input.GetKey is dead due to focus issues)
        readonly HashSet<KeyCode> heldKeys = new HashSet<KeyCode>();

        void OnGUI()
        {
            var e = Event.current;
            if (e == null || !e.isKey) return;
            if (e.type == EventType.KeyDown) heldKeys.Add(e.keyCode);
            else if (e.type == EventType.KeyUp) heldKeys.Remove(e.keyCode);
        }

        bool Pressed(KeyCode k)
        {
#if USE_NEW_INPUT_SYSTEM
            var kb = Keyboard.current;
            if (kb != null)
            {
                if (k == KeyCode.W) return kb.wKey.isPressed;
                if (k == KeyCode.A) return kb.aKey.isPressed;
                if (k == KeyCode.S) return kb.sKey.isPressed;
                if (k == KeyCode.D) return kb.dKey.isPressed;
            }
#endif
            return Input.GetKey(k) || heldKeys.Contains(k);
        }

        void Update()
        {
            float h = 0f, v = 0f;
            if (Pressed(KeyCode.A) || Pressed(KeyCode.LeftArrow)) h -= 1f;
            if (Pressed(KeyCode.D) || Pressed(KeyCode.RightArrow)) h += 1f;
            if (Pressed(KeyCode.S) || Pressed(KeyCode.DownArrow)) v -= 1f;
            if (Pressed(KeyCode.W) || Pressed(KeyCode.UpArrow)) v += 1f;
            moveDir = new Vector3(h, 0, v).normalized;

            if (moveDir.sqrMagnitude > 0.01f)
            {
                facing = moveDir;
                transform.forward = facing;
            }

            if (DashEnabled) HandleDashInput();
            TickTimers();

            // Debug log every 0.5s
            dbgLogTimer -= Time.unscaledDeltaTime;
            if (dbgLogTimer <= 0f)
            {
                dbgLogTimer = 0.5f;
                Debug.Log($"[PC] H={h} V={v} moveDir={moveDir} pos={transform.position} vel={rb.linearVelocity} dash={IsDashing}");
            }
        }

        void FixedUpdate()
        {
            if (IsDashing) return; // velocity is set by dash
            rb.linearVelocity = moveDir * moveSpeed;
        }

        void HandleDashInput()
        {
            if (dashCdTimer > 0f) return;
            // Detect double-tap on WASD
            TryDash(KeyCode.W, Vector3.forward);
            TryDash(KeyCode.A, Vector3.left);
            TryDash(KeyCode.S, Vector3.back);
            TryDash(KeyCode.D, Vector3.right);
        }

        void TryDash(KeyCode k, Vector3 dir)
        {
            if (!Input.GetKeyDown(k)) return;
            if (lastKey == k && Time.time - lastKeyTime <= doubleTapWindow)
            {
                StartDash(dir);
                lastKey = KeyCode.None;
            }
            else
            {
                lastKey = k;
                lastKeyTime = Time.time;
            }
        }

        void StartDash(Vector3 dir)
        {
            IsDashing = true;
            dashTimer = dashDuration;
            dashCdTimer = dashCooldown;
            rb.linearVelocity = dir * dashImpulse;
        }

        void TickTimers()
        {
            if (IsDashing)
            {
                dashTimer -= Time.deltaTime;
                if (dashTimer <= 0f) IsDashing = false;
            }
            if (dashCdTimer > 0f) dashCdTimer -= Time.deltaTime;
        }
    }
}
