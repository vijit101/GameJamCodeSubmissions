using System;

namespace ClassSwap.Player
{
    /// <summary>
    /// Pure C# health logic — testable without Unity.
    /// MonoBehaviour wrapper PlayerHealth bridges this to GameEvents and IDamageable.
    /// </summary>
    public class PlayerHealthLogic
    {
        public int Max { get; private set; }
        public int Current { get; private set; }

        public event Action OnDeath;
        public event Action<int> OnChanged;

        public PlayerHealthLogic(int max)
        {
            if (max <= 0) throw new ArgumentException("max must be > 0", nameof(max));
            Max = max;
            Current = max;
        }

        public void TakeDamage(int amount)
        {
            if (amount < 0) throw new ArgumentException("amount must be >= 0", nameof(amount));
            if (Current <= 0) return;
            Current = Math.Max(0, Current - amount);
            OnChanged?.Invoke(Current);
            if (Current == 0) OnDeath?.Invoke();
        }

        public void Heal(int amount)
        {
            if (amount < 0) throw new ArgumentException("amount must be >= 0", nameof(amount));
            if (Current <= 0) return; // can't heal the dead
            Current = Math.Min(Max, Current + amount);
            OnChanged?.Invoke(Current);
        }

        public void IncreaseMaxHP(int delta)
        {
            Max += delta;
            Current = Math.Min(Max, Current + delta); // also heal by the gain
            OnChanged?.Invoke(Current);
        }
    }
}
