using UnityEngine;
using ClassSwap.Combat;
using ClassSwap.Core;

namespace ClassSwap.Player
{
    /// <summary>
    /// MonoBehaviour wrapper around PlayerHealthLogic.
    /// Bridges to GameEvents (RaisePlayerDamaged, RaisePlayerDied) and exposes Inspector-tunable max HP.
    /// </summary>
    public class PlayerHealth : MonoBehaviour, IDamageable
    {
        [SerializeField] int maxHp = 100;

        PlayerHealthLogic logic;
        PlayerController controller;

        public int Current => logic.Current;
        public int Max => logic.Max;

        public event System.Action<int> OnChanged;

        void Awake()
        {
            logic = new PlayerHealthLogic(maxHp);
            logic.OnChanged += v => OnChanged?.Invoke(v);
            logic.OnDeath += () => GameEvents.RaisePlayerDied();
            controller = GetComponent<PlayerController>();
        }

        public void TakeDamage(int amount, DamageType type)
        {
            // Assassin dash i-frames
            if (controller != null && controller.IFrames) return;

            logic.TakeDamage(amount);
            GameEvents.RaisePlayerDamaged(amount);
        }

        public void IncreaseMaxHP(int delta) => logic.IncreaseMaxHP(delta);
        public void Heal(int amount) => logic.Heal(amount);
    }
}
