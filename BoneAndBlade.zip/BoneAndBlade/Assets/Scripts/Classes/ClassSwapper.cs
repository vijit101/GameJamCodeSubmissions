using UnityEngine;
#if USE_NEW_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace ClassSwap.Classes
{
    /// <summary>
    /// Swaps the active class via 1/2/3. Disables previous attack component, enables new one,
    /// fires transformation burst VFX. Tier-2 dash unlock is handled by AssassinAttack toggling
    /// PlayerController.DashEnabled.
    /// </summary>
    public class ClassSwapper : MonoBehaviour
    {
        [Tooltip("Indices match ClassId enum: 0=Knight, 1=Wizard, 2=Assassin")]
        [SerializeField] ClassAttackBase[] attacks = new ClassAttackBase[3];

        [Tooltip("Optional VFX prefabs; index matches ClassId")]
        [SerializeField] GameObject[] swapBurstVfx = new GameObject[3];

        [Tooltip("Per-class visual GameObjects (children of Player); index matches ClassId")]
        [SerializeField] GameObject[] visuals = new GameObject[3];

        int activeIdx = -1;   // sentinel — first SetActive call always applies
        public ClassId ActiveClass => (ClassId)Mathf.Max(0, activeIdx);

        void Start()
        {
            // Force-apply the initial state via SetActive (no early-return because activeIdx == -1)
            SetActive(0);
        }

        void Update()
        {
#if USE_NEW_INPUT_SYSTEM
            var kb = Keyboard.current;
            if (kb != null)
            {
                if (kb.digit1Key.wasPressedThisFrame) { SetActive(0); return; }
                if (kb.digit2Key.wasPressedThisFrame) { SetActive(1); return; }
                if (kb.digit3Key.wasPressedThisFrame) { SetActive(2); return; }
            }
#else
            if (Input.GetKeyDown(KeyCode.Alpha1)) SetActive(0);
            else if (Input.GetKeyDown(KeyCode.Alpha2)) SetActive(1);
            else if (Input.GetKeyDown(KeyCode.Alpha3)) SetActive(2);
#endif
        }

        void SetActive(int idx)
        {
            if (idx < 0 || idx >= attacks.Length) return;
            if (idx == activeIdx) return;  // no work needed if same class

            // Always reapply enable/disable state across ALL attacks
            for (int i = 0; i < attacks.Length; i++)
            {
                if (attacks[i] == null) continue;
                if (i == idx) attacks[i].EnableAttack();
                else attacks[i].DisableAttack();
            }

            // Swap visible visual hierarchy for this class
            for (int i = 0; i < visuals.Length; i++)
            {
                if (visuals[i] == null) continue;
                visuals[i].SetActive(i == idx);
            }

            // Fire VFX only on actual swap (skip on initial Start activation)
            if (activeIdx >= 0 && idx < swapBurstVfx.Length && swapBurstVfx[idx] != null)
            {
                Instantiate(swapBurstVfx[idx], transform.position, Quaternion.identity);
            }

            activeIdx = idx;
        }
    }
}
