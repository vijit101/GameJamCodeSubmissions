using UnityEngine;

namespace ClassSwap.Classes
{
    public enum ClassId { Knight, Wizard, Assassin }

    /// <summary>
    /// Base class for all attack components. ClassSwapper enables/disables these on 1/2/3.
    /// </summary>
    public abstract class ClassAttackBase : MonoBehaviour
    {
        public abstract ClassId Id { get; }

        protected bool active = false;

        public virtual void EnableAttack() { active = true; }
        public virtual void DisableAttack() { active = false; }
    }
}
