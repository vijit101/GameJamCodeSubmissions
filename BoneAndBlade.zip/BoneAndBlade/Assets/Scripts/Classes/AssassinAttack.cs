using UnityEngine;
using ClassSwap.Player;
using ClassSwap.Combat;

namespace ClassSwap.Classes
{
    /// <summary>
    /// Assassin rapid-fire daggers in a spread, auto-aimed at nearest enemy. Enables PlayerController dash while active.
    /// Counter for elite enemies (single-target burst + dash through teleports).
    /// </summary>
    public class AssassinAttack : ClassAttackBase
    {
        public override ClassId Id => ClassId.Assassin;

        [SerializeField] GameObject daggerPrefab;
        [SerializeField] float attackInterval = 0.5f;
        [SerializeField] int daggersPerVolley = 3;
        [SerializeField] float spreadDegrees = 30f;
        [SerializeField] float scanRadius = 20f;
        [SerializeField] LayerMask enemyLayer;

        PlayerController controller;
        float cd;

        void Awake()
        {
            controller = GetComponent<PlayerController>();
        }

        public override void EnableAttack()
        {
            base.EnableAttack();
            if (controller != null) controller.DashEnabled = true;
        }

        public override void DisableAttack()
        {
            base.DisableAttack();
            if (controller != null) controller.DashEnabled = false;
        }

        void Update()
        {
            if (!active) return;
            cd -= Time.deltaTime;
            if (cd <= 0f)
            {
                Volley();
                cd = attackInterval;
            }
        }

        void Volley()
        {
            if (daggerPrefab == null) return;

            var anim = GetComponentInChildren<ClassSwap.Visual.CharacterAnimator>(false);
            if (anim != null) anim.TriggerAttackSwing();

            // Auto-aim at nearest enemy
            Transform target = AutoAim.NearestEnemy(transform.position, scanRadius, enemyLayer);
            Vector3 aimDir;
            if (target != null)
            {
                aimDir = target.position - transform.position;
                aimDir.y = 0;
                if (aimDir.sqrMagnitude > 0.001f) aimDir.Normalize();
                else aimDir = transform.forward;
            }
            else
            {
                aimDir = transform.forward;
            }
            Quaternion baseRot = Quaternion.LookRotation(aimDir);

            float halfSpread = spreadDegrees * 0.5f;
            float step = daggersPerVolley > 1 ? spreadDegrees / (daggersPerVolley - 1) : 0f;
            float startAngle = daggersPerVolley > 1 ? -halfSpread : 0f;

            for (int i = 0; i < daggersPerVolley; i++)
            {
                float angle = startAngle + step * i;
                Quaternion rot = baseRot * Quaternion.AngleAxis(angle, Vector3.up);
                Vector3 spawn = transform.position + rot * Vector3.forward * 0.6f;
                spawn.y = Mathf.Max(spawn.y, 0.5f);
                Instantiate(daggerPrefab, spawn, rot);
            }
        }

        public void ModifyDaggersPerVolley(int delta) => daggersPerVolley = Mathf.Max(1, daggersPerVolley + delta);
        public void ModifyAttackSpeed(float multiplier) => attackInterval = Mathf.Max(0.05f, attackInterval / multiplier);
    }
}
