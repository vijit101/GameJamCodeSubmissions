using UnityEngine;
using ClassSwap.Combat;

namespace ClassSwap.Classes
{
    /// <summary>
    /// Wizard ranged AoE — slow fireball every attackInterval seconds, auto-aimed at nearest enemy.
    /// Counter for swarm enemies (AoE wipes packs).
    /// </summary>
    public class WizardAttack : ClassAttackBase
    {
        public override ClassId Id => ClassId.Wizard;

        [SerializeField] GameObject fireballPrefab;
        [SerializeField] Transform muzzle;            // optional — defaults to player position + aim*1m
        [SerializeField] float attackInterval = 1.0f;
        [SerializeField] float scanRadius = 20f;
        [SerializeField] LayerMask enemyLayer;

        float cd;

        void Update()
        {
            if (!active) return;
            cd -= Time.deltaTime;
            if (cd <= 0f)
            {
                Cast();
                cd = attackInterval;
            }
        }

        void Cast()
        {
            if (fireballPrefab == null) return;

            var anim = GetComponentInChildren<ClassSwap.Visual.CharacterAnimator>(false);
            if (anim != null) anim.TriggerAttackSwing();

            // Auto-aim at nearest enemy
            Transform target = AutoAim.NearestEnemy(transform.position, scanRadius, enemyLayer);
            Vector3 aimDir;
            if (target != null)
            {
                aimDir = target.position - transform.position;
                aimDir.y = 0;
                if (aimDir.sqrMagnitude > 0.001f) aimDir.Normalize();
                else aimDir = transform.forward;
            }
            else
            {
                aimDir = transform.forward;
            }

            Vector3 spawn = muzzle != null ? muzzle.position : transform.position + aimDir * 1f;
            spawn.y = Mathf.Max(spawn.y, 0.5f);
            Quaternion rot = aimDir.sqrMagnitude > 0.001f ? Quaternion.LookRotation(aimDir) : transform.rotation;
            Instantiate(fireballPrefab, spawn, rot);
        }

        public void ModifyAttackSpeed(float multiplier) => attackInterval = Mathf.Max(0.05f, attackInterval / multiplier);
    }
}
