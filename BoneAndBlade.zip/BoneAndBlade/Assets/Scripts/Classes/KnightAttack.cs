using UnityEngine;
using ClassSwap.Combat;

namespace ClassSwap.Classes
{
    /// <summary>
    /// Knight melee sweep — wide arc in facing direction, hits up to maxTargets enemies.
    /// Damage type Slash bypasses Armored Knight enemy reduction.
    /// </summary>
    public class KnightAttack : ClassAttackBase
    {
        public override ClassId Id => ClassId.Knight;

        [Header("Attack")]
        [SerializeField] float attackInterval = 0.7f;
        [SerializeField] float range = 2.5f;
        [SerializeField] float arcDegrees = 120f;
        [SerializeField] int damage = 25;
        [SerializeField] int maxTargets = 3;
        [SerializeField] LayerMask enemyLayer;

        [Header("VFX/SFX hooks")]
        [SerializeField] GameObject arcVfxPrefab;

        float cooldown;

        void Update()
        {
            if (!active) return;
            cooldown -= Time.deltaTime;
            if (cooldown <= 0f)
            {
                // Only attack if there's actually an enemy in range
                var hits = Physics.OverlapSphere(transform.position, range, enemyLayer);
                if (hits.Length == 0) return; // no swing, no cooldown reset — keeps responsiveness
                AttackWithHits(hits);
                cooldown = attackInterval;
            }
        }

        void AttackWithHits(Collider[] hits)
        {
            // Sort by distance — nearest first
            System.Array.Sort(hits, (a, b) =>
                (a.transform.position - transform.position).sqrMagnitude.CompareTo(
                (b.transform.position - transform.position).sqrMagnitude));

            // Aim slash toward the nearest enemy
            Vector3 nearestPos = hits[0].transform.position;
            Vector3 aimDir = nearestPos - transform.position;
            aimDir.y = 0;
            if (aimDir.sqrMagnitude < 0.001f) aimDir = transform.forward;
            aimDir.Normalize();

            // Trigger weapon swing animation on active visual
            var anim = GetComponentInChildren<ClassSwap.Visual.CharacterAnimator>(false);
            if (anim != null) anim.TriggerAttackSwing();

            // Spawn arc slash aimed at nearest target (Fruit-Ninja-style trail)
            if (arcVfxPrefab != null)
            {
                var vfx = Instantiate(arcVfxPrefab, transform.position + Vector3.up * 0.1f, Quaternion.identity);
                var slash = vfx.GetComponent<ClassSwap.Visual.SlashArc>();
                if (slash != null) slash.Setup(aimDir);
                else vfx.transform.forward = aimDir;
            }

            // Apply damage up to maxTargets
            int hitCount = 0;
            foreach (var h in hits)
            {
                if (h.TryGetComponent(out IDamageable target))
                {
                    target.TakeDamage(damage, DamageType.Slash);
                    if (++hitCount >= maxTargets) break;
                }
            }
        }

        // Upgrade hooks
        public void ModifyDamage(float multiplier) => damage = Mathf.RoundToInt(damage * multiplier);
        public void ModifyAttackSpeed(float multiplier) => attackInterval = Mathf.Max(0.05f, attackInterval / multiplier);
        public void ModifyArcWidth(float multiplier) => arcDegrees = Mathf.Min(360f, arcDegrees * multiplier);
        public void ModifyRange(float multiplier) => range *= multiplier;
    }
}
