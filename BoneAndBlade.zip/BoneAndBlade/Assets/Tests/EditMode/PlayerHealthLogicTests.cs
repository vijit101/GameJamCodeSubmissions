using NUnit.Framework;
using ClassSwap.Player;

public class PlayerHealthLogicTests
{
    [Test]
    public void Constructor_SetsCurrentToMax()
    {
        var h = new PlayerHealthLogic(100);
        Assert.AreEqual(100, h.Max);
        Assert.AreEqual(100, h.Current);
    }

    [Test]
    public void TakeDamage_ReducesCurrent()
    {
        var h = new PlayerHealthLogic(100);
        h.TakeDamage(30);
        Assert.AreEqual(70, h.Current);
    }

    [Test]
    public void TakeDamage_ClampsAtZero()
    {
        var h = new PlayerHealthLogic(50);
        h.TakeDamage(80);
        Assert.AreEqual(0, h.Current);
    }

    [Test]
    public void TakeDamage_AtZero_DoesNothing()
    {
        var h = new PlayerHealthLogic(50);
        h.TakeDamage(50);
        int deaths = 0;
        h.OnDeath += () => deaths++;
        h.TakeDamage(10); // already dead
        Assert.AreEqual(0, h.Current);
        Assert.AreEqual(0, deaths); // OnDeath not re-fired
    }

    [Test]
    public void TakeDamage_AtZero_FiresOnDeathOnce()
    {
        var h = new PlayerHealthLogic(50);
        int deaths = 0;
        h.OnDeath += () => deaths++;
        h.TakeDamage(50);
        Assert.AreEqual(1, deaths);
    }

    [Test]
    public void TakeDamage_FiresOnChanged()
    {
        var h = new PlayerHealthLogic(100);
        int captured = -1;
        h.OnChanged += (v) => captured = v;
        h.TakeDamage(20);
        Assert.AreEqual(80, captured);
    }

    [Test]
    public void Heal_AddsButCapsAtMax()
    {
        var h = new PlayerHealthLogic(100);
        h.TakeDamage(40); // 60
        h.Heal(50);
        Assert.AreEqual(100, h.Current); // capped
    }

    [Test]
    public void Heal_DeadCannotBeHealed()
    {
        var h = new PlayerHealthLogic(50);
        h.TakeDamage(50);
        h.Heal(20);
        Assert.AreEqual(0, h.Current);
    }

    [Test]
    public void IncreaseMaxHP_ExpandsMaxAndCurrentTogether()
    {
        var h = new PlayerHealthLogic(100);
        h.TakeDamage(20); // 80
        h.IncreaseMaxHP(30);
        Assert.AreEqual(130, h.Max);
        Assert.AreEqual(110, h.Current);
    }

    [Test]
    public void Constructor_ThrowsOnNonPositiveMax()
    {
        Assert.Throws<System.ArgumentException>(() => new PlayerHealthLogic(0));
        Assert.Throws<System.ArgumentException>(() => new PlayerHealthLogic(-5));
    }

    [Test]
    public void TakeDamage_ThrowsOnNegativeAmount()
    {
        var h = new PlayerHealthLogic(100);
        Assert.Throws<System.ArgumentException>(() => h.TakeDamage(-1));
    }
}
