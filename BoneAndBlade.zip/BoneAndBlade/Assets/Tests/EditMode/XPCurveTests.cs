using NUnit.Framework;
using ClassSwap.Progression;

public class XPCurveTests
{
    [Test]
    public void Level1_RequiresZero()
    {
        Assert.AreEqual(0, XPCurve.RequiredFor(1));
    }

    [Test]
    public void Level2_RequiresFive()
    {
        Assert.AreEqual(5, XPCurve.RequiredFor(2));
    }

    [Test]
    public void Level3_RequiresSeven()
    {
        // 5 * 1.5^1 = 7.5 → floor = 7
        Assert.AreEqual(7, XPCurve.RequiredFor(3));
    }

    [Test]
    public void Level4_RequiresEleven()
    {
        // 5 * 1.5^2 = 11.25 → floor = 11
        Assert.AreEqual(11, XPCurve.RequiredFor(4));
    }

    [Test]
    public void TotalForLevel3_IsCumulativeSum()
    {
        // Level 2 needs 5, Level 3 needs 7 → total to reach level 3 = 12
        Assert.AreEqual(12, XPCurve.TotalFor(3));
    }

    [Test]
    public void TotalForLevel1_IsZero()
    {
        Assert.AreEqual(0, XPCurve.TotalFor(1));
    }

    [Test]
    public void RequiredForZero_IsZero()
    {
        Assert.AreEqual(0, XPCurve.RequiredFor(0));
    }
}
