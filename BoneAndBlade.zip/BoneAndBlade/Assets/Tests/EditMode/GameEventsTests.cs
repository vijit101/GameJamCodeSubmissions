using NUnit.Framework;
using ClassSwap.Core;

public class GameEventsTests
{
    [SetUp]
    public void Clear() => GameEvents.ResetAll();

    [Test]
    public void RaiseEnemyKilled_InvokesListeners_WithXPValue()
    {
        int captured = 0;
        GameEvents.OnEnemyKilled += (xp) => captured = xp;
        GameEvents.RaiseEnemyKilled(7);
        Assert.AreEqual(7, captured);
    }

    [Test]
    public void RaisePlayerDied_InvokesListenersWithoutArgs()
    {
        bool called = false;
        GameEvents.OnPlayerDied += () => called = true;
        GameEvents.RaisePlayerDied();
        Assert.IsTrue(called);
    }

    [Test]
    public void RaiseLevelUp_InvokesWithNewLevel()
    {
        int newLevel = 0;
        GameEvents.OnLevelUp += (l) => newLevel = l;
        GameEvents.RaiseLevelUp(3);
        Assert.AreEqual(3, newLevel);
    }

    [Test]
    public void ResetAll_RemovesAllSubscribers()
    {
        int counter = 0;
        GameEvents.OnEnemyKilled += (_) => counter++;
        GameEvents.OnPlayerDied += () => counter++;
        GameEvents.ResetAll();
        GameEvents.RaiseEnemyKilled(1);
        GameEvents.RaisePlayerDied();
        Assert.AreEqual(0, counter);
    }

    [Test]
    public void RaiseWithNoSubscribers_DoesNotThrow()
    {
        Assert.DoesNotThrow(() => GameEvents.RaiseEnemyKilled(5));
        Assert.DoesNotThrow(() => GameEvents.RaiseGameWon());
    }
}
