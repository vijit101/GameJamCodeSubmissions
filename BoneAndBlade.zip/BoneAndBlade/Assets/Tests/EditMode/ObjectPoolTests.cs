using NUnit.Framework;
using ClassSwap.Core;

public class ObjectPoolTests
{
    class Fake { public bool active; public int initCount; }

    [Test]
    public void Get_CreatesNewWhenEmpty()
    {
        var pool = new ObjectPool<Fake>(() => new Fake());
        var inst = pool.Get();
        Assert.IsNotNull(inst);
    }

    [Test]
    public void Get_ReusesReleasedInstance()
    {
        var pool = new ObjectPool<Fake>(() => new Fake());
        var a = pool.Get();
        pool.Release(a);
        var b = pool.Get();
        Assert.AreSame(a, b);
    }

    [Test]
    public void Prewarm_FillsIdleStack()
    {
        var pool = new ObjectPool<Fake>(() => new Fake(), prewarm: 3);
        Assert.AreEqual(3, pool.IdleCount);
    }

    [Test]
    public void OnGet_IsInvokedOnEveryGet()
    {
        var pool = new ObjectPool<Fake>(
            () => new Fake(),
            onGet: f => f.active = true,
            onRelease: f => f.active = false
        );
        var inst = pool.Get();
        Assert.IsTrue(inst.active);
        pool.Release(inst);
        Assert.IsFalse(inst.active);
        pool.Get();
        Assert.IsTrue(inst.active);
    }

    [Test]
    public void Release_IncreasesIdleCount()
    {
        var pool = new ObjectPool<Fake>(() => new Fake());
        var a = pool.Get();
        var b = pool.Get();
        pool.Release(a);
        pool.Release(b);
        Assert.AreEqual(2, pool.IdleCount);
    }

    [Test]
    public void Constructor_ThrowsOnNullCreate()
    {
        Assert.Throws<System.ArgumentNullException>(() => new ObjectPool<Fake>(null));
    }
}
