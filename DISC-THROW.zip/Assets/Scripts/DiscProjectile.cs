using UnityEngine;

public class DiscProjectile : MonoBehaviour
{
    public float flySpeed = 15f;
    private bool isFlying = false;
    private Vector2 direction;
    private BoxCollider2D boxCol;
    private int groundLayerIndex;

    void Awake()
    {
        boxCol = GetComponent<BoxCollider2D>();
        groundLayerIndex = LayerMask.NameToLayer("Ground");
        
        // Ensure starting as trigger so we don't physically shove the player when spawned
        if (boxCol != null)
        {
            boxCol.isTrigger = true;
        }
    }

    public void Initialize(Vector2 dir)
    {
        direction = dir.normalized;
        isFlying = true;
        
        // Ensure it doesn't immediately act as ground while flying
        gameObject.layer = LayerMask.NameToLayer("Default");
    }

    void Update()
    {
        if (isFlying)
        {
            float moveDist = flySpeed * Time.deltaTime;

            if (boxCol != null)
            {
                // BoxCast ahead to ensure we don't tunnel through thin walls/ground
                Vector2 size = new Vector2(boxCol.size.x * transform.localScale.x, boxCol.size.y * transform.localScale.y);
                
                // We cast against ALL collision layers just in case the user missed setting the Ground layer
                RaycastHit2D[] hits = Physics2D.BoxCastAll(transform.position, size, 0f, direction, moveDist);

                foreach (RaycastHit2D hit in hits)
                {
                    // Ignore ourself and the player
                    if (hit.collider != null && hit.collider.gameObject != this.gameObject && hit.collider.gameObject.name != "Player")
                    {
                        // Stop if we hit the Ground layer OR anything with the new 'ground' tag!
                        if (hit.collider.gameObject.layer == groundLayerIndex ||
                            hit.collider.gameObject.tag.Trim().Equals("ground", System.StringComparison.OrdinalIgnoreCase))
                        {
                            transform.Translate(direction * hit.distance);
                            StickToSurface();
                            return;
                        }
                    }
                }
            }

            // Normal movement if no collision detected this frame
            transform.Translate(direction * moveDist);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (!isFlying) return;
        if (collision.gameObject.name == "Player") return;

        // Failsafe trigger check utilizing the exact same omnipotent Tag/Layer check
        if (collision.gameObject.layer == groundLayerIndex || 
            collision.gameObject.tag.Trim().Equals("ground", System.StringComparison.OrdinalIgnoreCase))
        {
            StickToSurface();
        }
    }

    void StickToSurface()
    {
        isFlying = false;
        
        // Disable physics movement constraints
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.bodyType = RigidbodyType2D.Static; 
        }

        // Become solid ground so the player can stand on it
        if (boxCol != null)
        {
            boxCol.isTrigger = false;
        }
        
        gameObject.layer = groundLayerIndex;
    }
}
