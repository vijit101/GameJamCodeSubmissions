using UnityEngine;
using UnityEngine.InputSystem; // Added for New Input System
using UnityEngine.UI;
using TMPro;

public class PlatformThrower : MonoBehaviour
{
    public GameObject platformPrefab;
    public int maxThrows = -1;       // -1 means unlimited

    private GameObject activePlatform;
    private int throwsUsed = 0;
    public TextMeshProUGUI throwCountText;

    void Update()
    {
        // Replaced Input.GetKeyDown with New Input System equivalent
        if (Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame)
        {
            TryThrowPlatform();
        }

        UpdateUI();
    }

    void TryThrowPlatform()
    {
        // Check if we have throws remaining
        if (maxThrows != -1 && throwsUsed >= maxThrows)
        {
            Debug.Log("No throws left!");
            return;
        }

        // Destroy old platform
        if (activePlatform != null)
        {
            Destroy(activePlatform);
        }

        // Spawn new platform slightly ahead of player
        float dir = transform.localScale.x > 0 ? 1f : -1f;
        Vector3 spawnPos = transform.position + new Vector3(dir * 1f, 0f, 0f);
        activePlatform = Instantiate(platformPrefab, spawnPos, Quaternion.identity);

        DiscProjectile proj = activePlatform.GetComponent<DiscProjectile>();
        if (proj != null)
        {
            proj.Initialize(new Vector2(dir, 0));
        }

        throwsUsed++;
    }

    void UpdateUI()
    {
        if (throwCountText == null) return;
        if (maxThrows == -1)
            throwCountText.text = "Throws: ∞";
        else
            throwCountText.text = "Throws: " + (maxThrows - throwsUsed);
    }

    public void ResetThrows()
    {
        throwsUsed = 0;
        if (activePlatform != null) Destroy(activePlatform);
        activePlatform = null;
    }
}
