using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.InputSystem;

public class LevelManager : MonoBehaviour
{
    // This attribute ensures the LevelManager is automatically created when the game starts
    // so you never have to remember to drag/drop it into your new levels!
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Initialize()
    {
        // Prevent duplication if one somehow already exists
        if (FindAnyObjectByType<LevelManager>() != null) return;

        GameObject go = new GameObject("- LevelManager Persistent -");
        go.AddComponent<LevelManager>();
        DontDestroyOnLoad(go); // Keeps it alive across all levels
    }

    void Update()
    {
        // Use New Input System for 'R' key detection
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
        {
            RestartLevel();
        }
    }

    public void RestartLevel()
    {
        Debug.Log("Restarting Level: " + SceneManager.GetActiveScene().name);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
