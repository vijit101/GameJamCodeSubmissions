using UnityEngine;
using UnityEngine.SceneManagement;

public class WinScreen : MonoBehaviour
{
    public void PlayAgain()
    {
        SceneManager.LoadScene(1);  // Level1
    }

    public void MainMenu()
    {
        SceneManager.LoadScene(0);  // MainMenu
    }
}
