using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 3.5f;
    public float jumpForce = 10f;
    public LayerMask groundLayer;

    private Rigidbody2D rb;
    private bool isGrounded;

    // Ground check settings
    private Vector2 groundCheckSize = new Vector2(0.9f, 0.1f);
    private float groundCheckOffset = 0.55f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;
    }

    void Update()
    {
        HandleMovement();
        CheckGround();
        HandleJump();
    }

    void HandleMovement()
    {
        float move = 0f;

        if (Keyboard.current != null)
        {
            if (Keyboard.current.leftArrowKey.isPressed || Keyboard.current.aKey.isPressed)
                move = -1f;

            if (Keyboard.current.rightArrowKey.isPressed || Keyboard.current.dKey.isPressed)
                move = 1f;
        }

        rb.linearVelocity = new Vector2(move * moveSpeed, rb.linearVelocity.y);

        // Flip sprite
        if (move != 0)
        {
            Vector3 scale = transform.localScale;
            scale.x = Mathf.Abs(scale.x) * Mathf.Sign(move);
            transform.localScale = scale;
        }
    }

    void CheckGround()
    {
        Vector2 boxCenter = new Vector2(transform.position.x, transform.position.y - groundCheckOffset);
        
        // Capture everything we are touching
        Collider2D[] colliders = Physics2D.OverlapBoxAll(boxCenter, groundCheckSize, 0f);
        
        isGrounded = false;
        foreach (Collider2D col in colliders)
        {
            // Ignore ourselves
            if (col.gameObject == this.gameObject) continue;

            string objTag = col.gameObject.tag;

            // Safely check if the tag matches "ground", totally ignoring accidental spaces and capital letters
            if (objTag.Trim().Equals("ground", System.StringComparison.OrdinalIgnoreCase))
            {
                isGrounded = true;
                break;
            }
            else
            {
                // Helpful debug feature so we can see in the console WHY a jump failed
                Debug.Log($"[Jump Check] Failed to jump! You are standing on '{col.gameObject.name}' which has the tag strictly set to: '{objTag}'");
            }
        }
    }

    void HandleJump()
    {
        if (Keyboard.current != null &&
            Keyboard.current.spaceKey.wasPressedThisFrame &&
            isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        }
    }

    // Debug ground check box in Scene view
    void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Vector2 boxCenter = new Vector2(transform.position.x, transform.position.y - groundCheckOffset);
        Gizmos.DrawWireCube(boxCenter, groundCheckSize);
    }
}