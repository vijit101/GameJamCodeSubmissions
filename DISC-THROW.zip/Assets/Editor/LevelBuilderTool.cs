using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using TMPro;

public class LevelBuilderTool
{
    [MenuItem("Tools/Build All Levels Automatically")]
    public static void BuildAllLevels()
    {
        BuildLevel1();
        BuildLevel2();
        BuildLevel3();
        BuildLevel4();

        EditorSceneManager.OpenScene("Assets/Scenes/Level1.unity");
        Debug.Log("ALL LEVELS PERFECTLY CONSTRUCTED using your whitelisted 6 prefabs!");
    }

    private static void ClearScene()
    {
        foreach (GameObject go in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects())
        {
            GameObject.DestroyImmediate(go);
        }
    }

    private static void EnsurePlatformPrefab()
    {
        // Rebuilds the vital sticky disc that you throw, since you might have accidentally deleted it!
        string path = "Assets/Prefabs/Platform.prefab";
        if (AssetDatabase.LoadAssetAtPath<GameObject>(path) == null)
        {
            GameObject platform = new GameObject("Platform");
            SpriteRenderer sr = platform.AddComponent<SpriteRenderer>();
            sr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
            sr.color = new Color(0.2f, 0.8f, 0.2f); // Neon green thrown discs
            platform.AddComponent<BoxCollider2D>();
            Rigidbody2D rb = platform.AddComponent<Rigidbody2D>();
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            platform.AddComponent<DiscProjectile>();
            platform.layer = LayerMask.NameToLayer("Ground");
            platform.transform.localScale = new Vector3(2f, 0.5f, 1f);
            
            if (!AssetDatabase.IsValidFolder("Assets/Prefabs"))
                AssetDatabase.CreateFolder("Assets", "Prefabs");
            
            PrefabUtility.SaveAsPrefabAsset(platform, path);
            GameObject.DestroyImmediate(platform);
        }
    }

    private static GameObject InstantiatePrefab(string name, string guidSearch)
    {
        string[] guids = AssetDatabase.FindAssets(guidSearch + " t:Prefab");
        if (guids.Length > 0)
        {
            string path = AssetDatabase.GUIDToAssetPath(guids[0]);
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab != null)
            {
                GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
                if (instance != null)
                {
                    PrefabUtility.UnpackPrefabInstance(instance, PrefabUnpackMode.OutermostRoot, InteractionMode.AutomatedAction);
                    instance.name = name;
                    return instance;
                }
            }
        }
        return null;
    }

    private static void SetupCore(int doorIndex, int maxThrows)
    {
        ClearScene();
        EnsurePlatformPrefab();

        // Add Camera
        GameObject camObj = new GameObject("Main Camera");
        Camera cam = camObj.AddComponent<Camera>();
        camObj.tag = "MainCamera";
        cam.orthographic = true;
        cam.orthographicSize = 6f;
        cam.backgroundColor = new Color(0.2f, 0.2f, 0.2f);
        cam.transform.position = new Vector3(0, 0, -10);
        camObj.AddComponent<AudioListener>();

        GameObject player = InstantiatePrefab("Player", "Player");
        if (player != null) player.transform.position = new Vector3(-8, -2, 0);

        GameObject door = InstantiatePrefab("ExitDoor", "ExitDoor");
        if (door != null)
        {
            door.transform.position = new Vector3(10, -2.5f, 0);
            door.GetComponent<ExitDoor>().nextSceneIndex = doorIndex;
        }

        InstantiatePrefab("DeathZone", "DeathZone");

        UISetupTool.SetupUI();

        // Safe config for player throwing limits AND relinking the deleted Platform!
        if (player != null)
        {
            PlatformThrower thrower = player.GetComponent<PlatformThrower>();
            if (thrower != null) 
            {
                thrower.maxThrows = maxThrows;
                thrower.platformPrefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Platform.prefab");
                thrower.ResetThrows();
            }
        }
    }

    private static GameObject CreateGround(string name, float x, float y, float width, float height)
    {
        // Strictly uses only your remaining "Floor" prefab!
        GameObject go = InstantiatePrefab(name, "Floor");

        if (go == null)
        {
            go = new GameObject(name);
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
            go.AddComponent<BoxCollider2D>();
            go.layer = LayerMask.NameToLayer("Ground");
        }

        go.transform.position = new Vector3(x, y, 0);
        go.transform.localScale = new Vector3(width, height, 1f);
        return go;
    }

    private static void BuildLevel1()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/Level1.unity");
        SetupCore(2, -1);
        
        GameObject bg = new GameObject("Background");
        SpriteRenderer bgSr = bg.AddComponent<SpriteRenderer>();
        bgSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        bgSr.color = new Color(0.94f, 0.96f, 0.92f); 
        bg.transform.position = new Vector3(0, 0, 5); 
        bg.transform.localScale = new Vector3(40, 25, 1);

        CreateGround("Floor", 0f, -4.5f, 24f, 1f); 
        CreateGround("Ceiling", 0f, 6.5f, 24f, 1f); 

        GameObject lw = InstantiatePrefab("LeftWall", "LeftWall");
        GameObject rw = InstantiatePrefab("RightWall", "RightWall");
        if (lw) lw.transform.position = new Vector3(-11, 0, 0);
        if (rw) rw.transform.position = new Vector3(11, 0, 0);

        GameObject player = GameObject.Find("Player");
        if (player != null) player.transform.position = new Vector3(-9.5f, -3.5f, 0);

        CreateGround("Obstacle1", -6f, -2f, 1f, 4f);
        CreateGround("T1_Stem", -1.5f, 1.5f, 1f, 9f);
        CreateGround("T1_Bar", -1.5f, 5.5f, 5f, 1f);
        CreateGround("CenterPillar", 3f, -2.5f, 1f, 2f);
        
        GameObject movingBlock = CreateGround("MovingPlatform", 3f, -3.5f, 4f, 0.5f);
        MovingPlatform mp = movingBlock.AddComponent<MovingPlatform>();
        mp.moveDistance = 2.5f;
        mp.speed = 1.5f;

        CreateGround("T2_Stem", 7f, 1f, 1f, 10f);
        CreateGround("T2_Bar", 7f, 5.5f, 5f, 1f);
        CreateGround("GuardWall", 9f, -2f, 1f, 4f);

        GameObject door = GameObject.Find("ExitDoor");
        if (door != null) door.transform.position = new Vector3(10f, -3f, 0);

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
    }

    private static void BuildLevel2()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/Level2.unity");
        SetupCore(3, -1);

        CreateGround("Floor", 0f, -4f, 24f, 1f);
        CreateGround("FloatingPlatform1", -1f, -1f, 2f, 1f);  
        CreateGround("FloatingPlatform2", 5f, 0f, 2f, 1f);    

        InstantiatePrefab("LeftWall", "LeftWall");
        InstantiatePrefab("RightWall", "RightWall");

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
    }

    private static void BuildLevel3()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/Level3.unity");
        SetupCore(4, 3); // Max throws = 3!

        CreateGround("Floor", 0f, -4f, 24f, 1f);

        GameObject textObj = new GameObject("RulesText");
        textObj.transform.position = new Vector3(-8, 2, 0);
        TextMeshPro tmp = textObj.AddComponent<TextMeshPro>();
        tmp.text = "Only 3 throws allowed!";
        tmp.fontSize = 6;
        tmp.alignment = TextAlignmentOptions.Center;

        InstantiatePrefab("LeftWall", "LeftWall");
        InstantiatePrefab("RightWall", "RightWall");

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
    }

    private static void BuildLevel4()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/Level4.unity");
        SetupCore(5, 2); // Max throws = 2

        CreateGround("Floor", 0f, -4f, 24f, 1f);
        
        GameObject movingBlock = CreateGround("MovingPlatform", 3f, 0f, 3f, 1f);
        MovingPlatform mp = movingBlock.AddComponent<MovingPlatform>();
        mp.moveDistance = 3f;
        mp.speed = 2f;

        InstantiatePrefab("LeftWall", "LeftWall");
        InstantiatePrefab("RightWall", "RightWall");

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
    }
}
