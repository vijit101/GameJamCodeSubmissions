using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using UnityEditor.SceneManagement;

public class UISetupTool
{
    [MenuItem("Tools/Setup UI Overlay")]
    public static void SetupUI()
    {
        // 1. Create Canvas
        Canvas canvas = GameObject.FindFirstObjectByType<Canvas>();
        GameObject canvasObj = canvas != null ? canvas.gameObject : new GameObject("Canvas");
        
        if (canvas == null)
        {
            canvas = canvasObj.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
        }

        // Add Event System if missing
        EventSystem evSys = GameObject.FindFirstObjectByType<EventSystem>();
        if (evSys == null)
        {
            GameObject eventSystemObj = new GameObject("EventSystem");
            evSys = eventSystemObj.AddComponent<EventSystem>();
        }
        
        // Fix for New Input System: Remove legacy UI module and add the correct one.
        var standalone = evSys.GetComponent<StandaloneInputModule>();
        if (standalone != null) GameObject.DestroyImmediate(standalone);

        var inputSysModule = evSys.GetComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
        if (inputSysModule == null) evSys.gameObject.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();

        // 2. Create ThrowCountText
        GameObject throwCountObj = GameObject.Find("ThrowCountText");
        if (throwCountObj == null) throwCountObj = new GameObject("ThrowCountText");
        throwCountObj.transform.SetParent(canvasObj.transform, false);

        TextMeshProUGUI throwCountText = throwCountObj.GetComponent<TextMeshProUGUI>();
        if (throwCountText == null) throwCountText = throwCountObj.AddComponent<TextMeshProUGUI>();
        
        throwCountText.text = "Throws: ∞";
        throwCountText.fontSize = 28;
        
        RectTransform tcRect = throwCountObj.GetComponent<RectTransform>();
        tcRect.anchorMin = new Vector2(0, 1); // Top Left
        tcRect.anchorMax = new Vector2(0, 1);
        tcRect.pivot = new Vector2(0, 1);
        tcRect.anchoredPosition = new Vector2(20, -20);
        tcRect.sizeDelta = new Vector2(300, 50);

        // 3. Create HintText
        GameObject hintObj = GameObject.Find("HintText");
        if (hintObj == null) hintObj = new GameObject("HintText");
        hintObj.transform.SetParent(canvasObj.transform, false);

        TextMeshProUGUI hintTextObj = hintObj.GetComponent<TextMeshProUGUI>();
        if (hintTextObj == null) hintTextObj = hintObj.AddComponent<TextMeshProUGUI>();
        
        hintTextObj.text = "E = Throw Platform    Space = Jump    R = Restart";
        hintTextObj.fontSize = 18;
        hintTextObj.alignment = TextAlignmentOptions.Center; // Keep text centered
        
        RectTransform hintRect = hintObj.GetComponent<RectTransform>();
        hintRect.anchorMin = new Vector2(0.5f, 0); // Bottom Center
        hintRect.anchorMax = new Vector2(0.5f, 0);
        hintRect.pivot = new Vector2(0.5f, 0);
        hintRect.anchoredPosition = new Vector2(0, 20);
        hintRect.sizeDelta = new Vector2(800, 50);

        // 4. Attach to Player's PlatformThrower
        GameObject player = GameObject.Find("Player");
        if (player != null)
        {
            PlatformThrower thrower = player.GetComponent<PlatformThrower>();
            if (thrower != null)
            {
                thrower.throwCountText = throwCountText;
                Debug.Log("Successfully attached ThrowCountText to the Player!");
            }
            else
            {
                Debug.LogError("Player does not have a PlatformThrower component!");
            }
        }
        else
        {
            Debug.LogError("Could not find 'Player' in the scene.");
        }

        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
        EditorSceneManager.SaveOpenScenes();

        Debug.Log("UI Setup Complete! Press play and test throwing.");
    }
}
