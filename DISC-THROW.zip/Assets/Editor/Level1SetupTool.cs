using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public class Level1SetupTool
{
    [MenuItem("Tools/Setup Level1 Scene")]
    public static void SetupScene()
    {
        // Open Level1 Scene
        string scenePath = "Assets/Scenes/Level1.unity";
        EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);

        // --- Create Camera ---
        if (Camera.main == null && GameObject.Find("Main Camera") == null)
        {
            GameObject camObj = new GameObject("Main Camera");
            Camera cam = camObj.AddComponent<Camera>();
            camObj.tag = "MainCamera";
            cam.orthographic = true;
            cam.orthographicSize = 6f; // Zoomed out a bit to see everything
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.2f, 0.2f, 0.2f);
            cam.transform.position = new Vector3(0, 0, -10);
            camObj.AddComponent<AudioListener>();
        }

        // --- Create Ground ---
        GameObject ground = GameObject.Find("Ground");
        if (ground == null) ground = new GameObject("Ground");
        
        SpriteRenderer groundSr = ground.GetComponent<SpriteRenderer>();
        if (groundSr == null) groundSr = ground.AddComponent<SpriteRenderer>();
        groundSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        
        ground.transform.position = new Vector3(0, -4, 0);
        ground.transform.localScale = new Vector3(20, 1, 1);
        
        if (ground.GetComponent<BoxCollider2D>() == null) ground.AddComponent<BoxCollider2D>();
        ground.layer = LayerMask.NameToLayer("Ground");

        // --- Create Left Wall ---
        GameObject leftWall = GameObject.Find("LeftWall");
        if (leftWall == null) leftWall = new GameObject("LeftWall");
        SpriteRenderer lwSr = leftWall.GetComponent<SpriteRenderer>();
        if (lwSr == null) lwSr = leftWall.AddComponent<SpriteRenderer>();
        lwSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        leftWall.transform.position = new Vector3(-9.5f, 0, 0);
        leftWall.transform.localScale = new Vector3(1, 10, 1);
        if (leftWall.GetComponent<BoxCollider2D>() == null) leftWall.AddComponent<BoxCollider2D>();
        leftWall.layer = LayerMask.NameToLayer("Ground");

        // --- Create Right Wall ---
        GameObject rightWall = GameObject.Find("RightWall");
        if (rightWall == null) rightWall = new GameObject("RightWall");
        SpriteRenderer rwSr = rightWall.GetComponent<SpriteRenderer>();
        if (rwSr == null) rwSr = rightWall.AddComponent<SpriteRenderer>();
        rwSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        rightWall.transform.position = new Vector3(9.5f, 0, 0);
        rightWall.transform.localScale = new Vector3(1, 10, 1);
        if (rightWall.GetComponent<BoxCollider2D>() == null) rightWall.AddComponent<BoxCollider2D>();
        rightWall.layer = LayerMask.NameToLayer("Ground");

        // --- Create Player ---
        GameObject player = GameObject.Find("Player");
        if (player == null) player = new GameObject("Player");
        
        SpriteRenderer playerSr = player.GetComponent<SpriteRenderer>();
        if (playerSr == null) playerSr = player.AddComponent<SpriteRenderer>();
        playerSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        playerSr.color = Color.blue;
        
        // Reset player velocity and position if it fell off out of bounds
        player.transform.position = new Vector3(0, 0, 0);
        player.transform.localScale = new Vector3(0.8f, 1.2f, 1f);
        
        Rigidbody2D rb = player.GetComponent<Rigidbody2D>();
        if (rb == null) rb = player.AddComponent<Rigidbody2D>();
        rb.gravityScale = 3f;
        rb.freezeRotation = true;
        rb.linearVelocity = Vector2.zero; // Reset falling velocity

        if (player.GetComponent<BoxCollider2D>() == null) player.AddComponent<BoxCollider2D>();
        player.tag = "Player";
        player.layer = LayerMask.NameToLayer("Ground");

        PlayerController pc = player.GetComponent<PlayerController>();
        if (pc == null) pc = player.AddComponent<PlayerController>();
        pc.groundLayer = LayerMask.GetMask("Ground");

        // Save scene
        EditorSceneManager.SaveOpenScenes();

        Debug.Log("Level1 Setup Updated Complete! Play to test!");
    }
}
