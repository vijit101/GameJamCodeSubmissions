using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public class WinLoseSetupTool
{
    [MenuItem("Tools/Setup Win & Lose Mechanics")]
    public static void SetupWinLose()
    {
        // 1. Create Exit Door
        GameObject exitDoor = GameObject.Find("ExitDoor");
        if (exitDoor == null) exitDoor = new GameObject("ExitDoor");
        
        SpriteRenderer exitSr = exitDoor.GetComponent<SpriteRenderer>();
        if (exitSr == null) exitSr = exitDoor.AddComponent<SpriteRenderer>();
        exitSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        exitSr.color = Color.green;
        
        exitDoor.transform.position = new Vector3(10, -2.5f, 0);
        exitDoor.transform.localScale = new Vector3(1.5f, 2.5f, 1f);
        
        BoxCollider2D exitCol = exitDoor.GetComponent<BoxCollider2D>();
        if (exitCol == null) exitCol = exitDoor.AddComponent<BoxCollider2D>();
        exitCol.isTrigger = true;

        ExitDoor exitScript = exitDoor.GetComponent<ExitDoor>();
        if (exitScript == null) exitScript = exitDoor.AddComponent<ExitDoor>();
        exitScript.nextSceneIndex = 2; // Level 2

        // 2. Create Death Zone
        GameObject deathZone = GameObject.Find("DeathZone");
        if (deathZone == null) deathZone = new GameObject("DeathZone");

        SpriteRenderer deathSr = deathZone.GetComponent<SpriteRenderer>();
        if (deathSr == null) deathSr = deathZone.AddComponent<SpriteRenderer>();
        deathSr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        deathSr.color = new Color(1, 1, 1, 0); // Transparent
        
        deathZone.transform.position = new Vector3(0, -10, 0);
        deathZone.transform.localScale = new Vector3(40, 1, 1);
        
        BoxCollider2D deathCol = deathZone.GetComponent<BoxCollider2D>();
        if (deathCol == null) deathCol = deathZone.AddComponent<BoxCollider2D>();
        deathCol.isTrigger = true;

        DeathZone deathScript = deathZone.GetComponent<DeathZone>();
        if (deathScript == null) deathScript = deathZone.AddComponent<DeathZone>();

        // Ensure R Key Restart is functioning (it is already handled globally by LevelManager but we can log it)
        Debug.Log("Win/Lose Zones added! R-Key global restart was previously completed via LevelManager.");
        
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
        EditorSceneManager.SaveOpenScenes();
    }
}
