using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public class MechanicUpdateTool
{
    [MenuItem("Tools/Update Sticky Disc Projectile Mechanic")]
    public static void UpdateMechanic()
    {
        string prefabPath = "Assets/Prefabs/Platform.prefab";
        GameObject platformPref = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
        
        if (platformPref != null)
        {
            // Open prefab for editing
            GameObject contentsRoot = PrefabUtility.LoadPrefabContents(prefabPath);
            
            // Add DiscProjectile script
            if (contentsRoot.GetComponent<DiscProjectile>() == null)
            {
                contentsRoot.AddComponent<DiscProjectile>();
            }

            // Ensure BoxCollider2D is set correctly
            BoxCollider2D bc2d = contentsRoot.GetComponent<BoxCollider2D>();
            if (bc2d != null)
            {
                bc2d.isTrigger = true; // Default to trigger while flying
            }
            
            // Add Rigidbody2D (kinematic so it doesn't fall) to detect triggers properly
            Rigidbody2D rb = contentsRoot.GetComponent<Rigidbody2D>();
            if (rb == null)
            {
                rb = contentsRoot.AddComponent<Rigidbody2D>();
            }
            rb.bodyType = RigidbodyType2D.Kinematic;
            
            // Save prefab
            PrefabUtility.SaveAsPrefabAsset(contentsRoot, prefabPath);
            PrefabUtility.UnloadPrefabContents(contentsRoot);
            
            Debug.Log("Updated Platform prefab natively for DiscProjectile mechanic!");
        }
        else
        {
            Debug.LogError("Could not find Platform prefab at " + prefabPath);
        }
    }
}
