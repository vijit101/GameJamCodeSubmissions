using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;
using System.Collections.Generic;

public class ProjectSetupTool
{
    [MenuItem("Tools/Setup Disc Throw Project")]
    public static void SetupProject()
    {
        // 2. Create Folders
        string[] folders = { "Scripts", "Prefabs", "Scenes", "Sprites", "Audio", "Fonts" };
        foreach (string folder in folders)
        {
            string path = Path.Combine("Assets", folder);
            if (!AssetDatabase.IsValidFolder(path))
            {
                AssetDatabase.CreateFolder("Assets", folder);
            }
        }

        // 3. Create Scenes
        string[] sceneNames = { "MainMenu", "Level1", "Level2", "Level3", "Level4", "WinScreen" };
        List<EditorBuildSettingsScene> buildScenes = new List<EditorBuildSettingsScene>();

        for (int i = 0; i < sceneNames.Length; i++)
        {
            string scenePath = $"Assets/Scenes/{sceneNames[i]}.unity";
            if (!File.Exists(scenePath))
            {
                Scene newScene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                EditorSceneManager.SaveScene(newScene, scenePath);
            }
            buildScenes.Add(new EditorBuildSettingsScene(scenePath, true));
        }

        // 4. Add scenes to Build Settings
        EditorBuildSettings.scenes = buildScenes.ToArray();

        // 5. Create Layer "Ground"
        CreateLayer("Ground", 8);

        Debug.Log("Project structure created successfully!");
    }

    private static void CreateLayer(string layerName, int layerIndex)
    {
        SerializedObject tagManager = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
        SerializedProperty layersProp = tagManager.FindProperty("layers");
        
        if (layerIndex >= 8 && layerIndex < layersProp.arraySize)
        {
            SerializedProperty layerProp = layersProp.GetArrayElementAtIndex(layerIndex);
            if (layerProp.stringValue != layerName)
            {
                layerProp.stringValue = layerName;
                tagManager.ApplyModifiedProperties();
                Debug.Log($"Layer {layerIndex} set to '{layerName}'.");
            }
        }
        else
        {
            Debug.LogError($"Cannot set layer {layerName} at index {layerIndex}. It's out of range or restricted.");
        }
    }
}
