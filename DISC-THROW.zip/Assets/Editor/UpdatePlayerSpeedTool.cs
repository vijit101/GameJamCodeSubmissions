using UnityEditor;
using UnityEngine;

public class UpdatePlayerSpeedTool
{
    [MenuItem("Tools/Apply Slow Player Speed")]
    public static void UpdateSpeed()
    {
        string prefabPath = "Assets/Prefabs/Player.prefab";
        GameObject playerPref = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
        
        if (playerPref != null)
        {
            GameObject contentsRoot = PrefabUtility.LoadPrefabContents(prefabPath);
            
            PlayerController pc = contentsRoot.GetComponent<PlayerController>();
            if (pc != null)
            {
                pc.moveSpeed = 3.5f;
                pc.jumpForce = 10f;
            }
            
            PrefabUtility.SaveAsPrefabAsset(contentsRoot, prefabPath);
            PrefabUtility.UnloadPrefabContents(contentsRoot);
            
            Debug.Log("Player prefab permanently updated to slower, restricted movement!");
        }
    }
}
