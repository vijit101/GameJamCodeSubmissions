using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using System.IO;

public class MechanicSetupTool
{
    [MenuItem("Tools/Setup Platform Thrower Mechanic")]
    public static void SetupMechanic()
    {
        // 1. Create a platform prefab
        string prefabFolder = "Assets/Prefabs";
        if (!AssetDatabase.IsValidFolder(prefabFolder)) AssetDatabase.CreateFolder("Assets", "Prefabs");
        string prefabPath = prefabFolder + "/Platform.prefab";

        GameObject platformPref = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
        if (platformPref == null)
        {
            GameObject platformObj = new GameObject("Platform");
            SpriteRenderer sr = platformObj.AddComponent<SpriteRenderer>();
            sr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
            sr.color = new Color(1f, 0.5f, 0f); // Orange
            platformObj.transform.localScale = new Vector3(4f, 0.5f, 1f);
            
            platformObj.AddComponent<BoxCollider2D>();
            platformObj.layer = LayerMask.NameToLayer("Ground");
            
            platformPref = PrefabUtility.SaveAsPrefabAsset(platformObj, prefabPath);
            GameObject.DestroyImmediate(platformObj);
            Debug.Log("Created Platform prefab!");
        }

        // 2 & 3. Attach PlatformThrower to Player
        GameObject player = GameObject.Find("Player");
        if (player != null)
        {
            PlatformThrower thrower = player.GetComponent<PlatformThrower>();
            if (thrower == null) thrower = player.AddComponent<PlatformThrower>();

            // 4, 5, 6. Set fields
            thrower.platformPrefab = platformPref;
            thrower.maxThrows = -1;
            Debug.Log("Configured PlatformThrower on Player!");
            
            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            EditorSceneManager.SaveOpenScenes();
        }
        else
        {
            Debug.LogError("Could not find 'Player' in the scene. Please open Level1.");
        }
        
        Debug.Log("Mechanic setup complete! Press Play to test.");
    }
}
