using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public class BookendSetupTool
{
    [MenuItem("Tools/Build Bookend Scenes (Main Menu & Win)")]
    public static void BuildBookends()
    {
        BuildMainMenu();
        BuildWinScreen();

        EditorSceneManager.OpenScene("Assets/Scenes/MainMenu.unity");
        Debug.Log("Both Main Menu and Win Screen perfectly constructed!");
    }

    private static void BuildMainMenu()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/MainMenu.unity");
        ClearScene();

        // Camera
        GameObject camObj = new GameObject("Main Camera");
        Camera cam = camObj.AddComponent<Camera>();
        camObj.tag = "MainCamera";
        cam.backgroundColor = new Color(0.1f, 0.1f, 0.2f);
        cam.clearFlags = CameraClearFlags.SolidColor;

        // UI Base
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject eventSystem = new GameObject("EventSystem");
        eventSystem.AddComponent<EventSystem>();
        eventSystem.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();

        // Manager
        GameObject manager = new GameObject("MenuManager");
        MainMenu menuScript = manager.AddComponent<MainMenu>();

        // Title
        GameObject titleObj = new GameObject("TitleText");
        titleObj.transform.SetParent(canvasObj.transform, false);
        TextMeshProUGUI title = titleObj.AddComponent<TextMeshProUGUI>();
        title.text = "LEDGE THROW";
        title.fontSize = 72;
        title.alignment = TextAlignmentOptions.Center;
        title.rectTransform.anchoredPosition = new Vector2(0, 150);

        // Subtitle
        GameObject subObj = new GameObject("SubtitleText");
        subObj.transform.SetParent(canvasObj.transform, false);
        TextMeshProUGUI sub = subObj.AddComponent<TextMeshProUGUI>();
        sub.text = "Create platforms. Reach the door.";
        sub.fontSize = 24;
        sub.alignment = TextAlignmentOptions.Center;
        sub.rectTransform.anchoredPosition = new Vector2(0, 70);

        // HowToPlayPanel
        GameObject panelObj = new GameObject("HowToPlayPanel");
        panelObj.transform.SetParent(canvasObj.transform, false);
        Image panelImg = panelObj.AddComponent<Image>();
        panelImg.color = new Color(0, 0, 0, 0.8f);
        panelObj.GetComponent<RectTransform>().sizeDelta = new Vector2(600, 400);

        GameObject howTextObj = new GameObject("Text");
        howTextObj.transform.SetParent(panelObj.transform, false);
        TextMeshProUGUI howText = howTextObj.AddComponent<TextMeshProUGUI>();
        howText.text = "Use A/D or Arrow Keys to move.\nPress Space to jump.\nPress E to throw a platform.\nYour last platform is destroyed when you throw a new one.\nReach the green door to advance.\nPress R to restart the level.";
        howText.fontSize = 24;
        howText.alignment = TextAlignmentOptions.Center;
        howText.rectTransform.sizeDelta = new Vector2(550, 350);
        
        panelObj.SetActive(false);
        menuScript.howToPlayPanel = panelObj;

        // Buttons
        CreateButton(canvasObj, "PlayButton", "Play", new Vector2(0, -20), menuScript, "PlayGame");
        CreateButton(canvasObj, "HowButton", "How to Play", new Vector2(0, -80), menuScript, "ToggleHowToPlay");
        CreateButton(canvasObj, "QuitButton", "Quit", new Vector2(0, -140), menuScript, "QuitGame");

        // Note: For simplicity and since UnityEvents hooked via Editor scripts don't persist automatically 
        // without UnityEditor.Events.UnityEventTools logic which is editor-only and complex, 
        // we'll hook these specific buttons up by adding a quick script wrapper to trigger the manager!
        // (See wrapper logic implementation in CreateButton)

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
    }

    private static void BuildWinScreen()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/WinScreen.unity");
        ClearScene();

        // Camera
        GameObject camObj = new GameObject("Main Camera");
        Camera cam = camObj.AddComponent<Camera>();
        camObj.tag = "MainCamera";
        cam.backgroundColor = new Color(0.1f, 0.4f, 0.1f);
        cam.clearFlags = CameraClearFlags.SolidColor;

        // UI Base
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject eventSystem = new GameObject("EventSystem");
        eventSystem.AddComponent<EventSystem>();
        eventSystem.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();

        // Manager
        GameObject manager = new GameObject("WinManager");
        WinScreen winScript = manager.AddComponent<WinScreen>();

        // Title
        GameObject titleObj = new GameObject("TitleText");
        titleObj.transform.SetParent(canvasObj.transform, false);
        TextMeshProUGUI title = titleObj.AddComponent<TextMeshProUGUI>();
        title.text = "You Win!";
        title.fontSize = 80;
        title.alignment = TextAlignmentOptions.Center;
        title.rectTransform.anchoredPosition = new Vector2(0, 100);

        // Subtitle
        GameObject subObj = new GameObject("SubtitleText");
        subObj.transform.SetParent(canvasObj.transform, false);
        TextMeshProUGUI sub = subObj.AddComponent<TextMeshProUGUI>();
        sub.text = "You mastered all 4 levels.";
        sub.fontSize = 28;
        sub.alignment = TextAlignmentOptions.Center;
        sub.rectTransform.anchoredPosition = new Vector2(0, 20);

        // Unity Editor serialization of onClick hooks takes special effort, so we use string-based method hooks visually 
        // Wiring via explicit component references for ButtonProxy
        CreateButton(canvasObj, "PlayAgainButton", "Play Again", new Vector2(0, -80), winScript, "PlayAgain");
        CreateButton(canvasObj, "MenuButton", "Main Menu", new Vector2(0, -140), winScript, "MainMenu");

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
    }

    private static void ClearScene()
    {
        foreach (GameObject go in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects())
        {
            GameObject.DestroyImmediate(go);
        }
    }

    private static void CreateButton(GameObject canvas, string name, string text, Vector2 pos, Component targetComp, string methodName)
    {
        GameObject btnObj = new GameObject(name);
        btnObj.transform.SetParent(canvas.transform, false);
        Image bg = btnObj.AddComponent<Image>();
        bg.color = new Color(0.2f, 0.2f, 0.2f);
        Button btn = btnObj.AddComponent<Button>();
        
        RectTransform rt = btnObj.GetComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(200, 50);

        GameObject txtObj = new GameObject("Text");
        txtObj.transform.SetParent(btnObj.transform, false);
        TextMeshProUGUI tmp = txtObj.AddComponent<TextMeshProUGUI>();
        tmp.text = text;
        tmp.color = Color.white;
        tmp.fontSize = 24;
        tmp.alignment = TextAlignmentOptions.Center;

        ButtonProxy proxy = btnObj.AddComponent<ButtonProxy>();
        proxy.methodName = methodName;
        proxy.targetComponent = targetComp;
    }
}
