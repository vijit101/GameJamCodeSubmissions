using UnityEditor;
using UnityEngine;
using UnityEditor.SceneManagement;

public class PrefabExtractionTool
{
    [MenuItem("Tools/Extract Core Objects to Prefabs")]
    public static void ExtractPrefabs()
    {
        string[] objectNames = { "LeftWall", "RightWall", "Player", "ExitDoor", "DeathZone", "Ground" };

        if (!AssetDatabase.IsValidFolder("Assets/Prefabs"))
        {
            AssetDatabase.CreateFolder("Assets", "Prefabs");
        }

        foreach (string objName in objectNames)
        {
            GameObject go = GameObject.Find(objName);
            if (go != null)
            {
                // Check if it's already connected to a prefab to prevent errors
                if (PrefabUtility.IsPartOfAnyPrefab(go) && !PrefabUtility.IsOutermostPrefabInstanceRoot(go))
                {
                    Debug.Log(objName + " is already part of a prefab. Skipping...");
                    continue;
                }

                string localPath = "Assets/Prefabs/" + objName + ".prefab";
                
                // Create the prefab asset and automatically link the Level1 object to it!
                PrefabUtility.SaveAsPrefabAssetAndConnect(go, localPath, InteractionMode.AutomatedAction);
                Debug.Log("Successfully created prefab for: " + objName);
            }
            else
            {
                Debug.LogWarning("Could not find object in scene: " + objName);
            }
        }
        
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
        EditorSceneManager.SaveOpenScenes();
        
        Debug.Log("Prefab extraction complete! Your core assets are now ready for Level2!");
    }
}
