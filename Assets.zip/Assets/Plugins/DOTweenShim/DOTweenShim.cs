// Minimal DOTween-compatible shim. Delete this folder after importing the real DOTween package.
#if !DOTWEEN
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DG.Tweening
{
    public enum Ease { Linear, OutBack, InOutQuad }

    public class Tween
    {
        internal Coroutine co;
        internal object target;
        public Tween SetEase(Ease e) { return this; }
        public Tween SetDelay(float d) { delay = d; return this; }
        internal float delay;
    }

    public static class DOTween
    {
        static readonly Dictionary<object, List<Tween>> active = new Dictionary<object, List<Tween>>();

        public static void Kill(object target)
        {
            if (target == null) return;
            if (active.TryGetValue(target, out var list))
            {
                foreach (var t in list) if (t.co != null && TweenRunner.I) TweenRunner.I.StopCoroutine(t.co);
                list.Clear();
            }
        }

        internal static Tween Run(object target, IEnumerator routine)
        {
            var t = new Tween { target = target };
            t.co = TweenRunner.Ensure().StartCoroutine(Wrap(t, routine));
            if (!active.TryGetValue(target, out var list)) { list = new List<Tween>(); active[target] = list; }
            list.Add(t);
            return t;
        }

        static IEnumerator Wrap(Tween t, IEnumerator inner)
        {
            if (t.delay > 0f) yield return new WaitForSeconds(t.delay);
            while (inner.MoveNext()) yield return inner.Current;
        }
    }

    class TweenRunner : MonoBehaviour
    {
        public static TweenRunner I;
        public static TweenRunner Ensure()
        {
            if (I == null)
            {
                var go = new GameObject("~DOTweenShim");
                Object.DontDestroyOnLoad(go);
                I = go.AddComponent<TweenRunner>();
            }
            return I;
        }
    }

    public static class DOTweenTransformExtensions
    {
        public static Tween DOScale(this Transform tr, float end, float dur)
            => DOTween.Run(tr, ScaleRoutine(tr, Vector3.one * end, dur));
        public static Tween DOScale(this Transform tr, Vector3 end, float dur)
            => DOTween.Run(tr, ScaleRoutine(tr, end, dur));
        public static Tween DOPunchScale(this Transform tr, Vector3 punch, float dur, int vibrato = 10, float elasticity = 1f)
            => DOTween.Run(tr, PunchRoutine(tr, punch, dur));

        static IEnumerator ScaleRoutine(Transform tr, Vector3 end, float dur)
        {
            if (tr == null) yield break;
            Vector3 start = tr.localScale; float t = 0f;
            while (t < dur)
            {
                if (tr == null) yield break;
                t += Time.deltaTime;
                tr.localScale = Vector3.Lerp(start, end, Mathf.Clamp01(t / dur));
                yield return null;
            }
            if (tr != null) tr.localScale = end;
        }

        static IEnumerator PunchRoutine(Transform tr, Vector3 punch, float dur)
        {
            if (tr == null) yield break;
            Vector3 start = tr.localScale; float t = 0f;
            while (t < dur)
            {
                if (tr == null) yield break;
                t += Time.deltaTime;
                float p = t / dur;
                float wave = Mathf.Sin(p * Mathf.PI * 4f) * (1f - p);
                tr.localScale = start + punch * wave;
                yield return null;
            }
            if (tr != null) tr.localScale = start;
        }
    }
}
#endif
