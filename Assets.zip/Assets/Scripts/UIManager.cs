using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("HUD")]
    public TMP_Text levelNameText;
    public TMP_Text wallCountText;
    public TMP_Text timerText;
    public TMP_Text bombText, vaccineText, freezeText;
    public Button bombBtn, vaccineBtn, freezeBtn;
    public Image bombBg, vaccineBg, freezeBg;

    [Header("Win")]
    public GameObject winPanel;
    public TMP_Text winScoreText;
    public TMP_Text winStarsText;
    public Button winNextButton, winMenuButton;

    [Header("Lose")]
    public GameObject losePanel;
    public TMP_Text loseFlavorText;
    public TMP_Text loseStatsText;
    public Button loseRetryButton, loseMenuButton;

    [Header("Transition")]
    public GameObject transitionPanel;
    public TMP_Text transitionTitle, transitionName, transitionFlavor;

    [Header("Final")]
    public GameObject finalPanel;
    public TMP_Text finalScoreText;
    public Button finalPlayAgainButton;

    [Header("Story")]
    public GameObject storyPanel;
    public GameObject rulesPanel;

    float levelTime;
    LevelConfig current;
    bool levelActive;
    Color normalPowerUpBg = new Color(0.15f, 0.15f, 0.15f, 0.9f);
    Color activePowerUpBg = new Color(0.80f, 0f, 0f, 0.9f);

    void Awake() { Instance = this; }

    void Start()
    {
        if (WallSystem.Instance != null)
        {
            WallSystem.Instance.OnWallPlaced += RefreshWalls;
            WallSystem.Instance.OnWallRemoved += RefreshWalls;
        }
        if (GameStateManager.Instance != null)
            GameStateManager.Instance.OnStateChanged += OnState;
        if (PowerUpSystem.Instance != null)
            PowerUpSystem.Instance.OnCountsChanged += RefreshPowerUps;

        HideAll();

        if (winNextButton) winNextButton.onClick.AddListener(() => { winPanel.SetActive(false); LevelManager.Instance.AddScore(GetScore()); LevelManager.Instance.NextLevel(); });
        if (winMenuButton) winMenuButton.onClick.AddListener(() => { winPanel.SetActive(false); ShowStory(); });
        if (loseRetryButton) loseRetryButton.onClick.AddListener(() => { losePanel.SetActive(false); LevelManager.Instance.RetryLevel(); });
        if (loseMenuButton) loseMenuButton.onClick.AddListener(() => { losePanel.SetActive(false); ShowStory(); });
        if (finalPlayAgainButton) finalPlayAgainButton.onClick.AddListener(() => { finalPanel.SetActive(false); ShowStory(); });

        if (bombBtn) bombBtn.onClick.AddListener(() => PowerUpSystem.Instance?.SelectPowerUp(PowerUpType.Bomb));
        if (vaccineBtn) vaccineBtn.onClick.AddListener(() => PowerUpSystem.Instance?.SelectPowerUp(PowerUpType.Vaccine));
        if (freezeBtn) freezeBtn.onClick.AddListener(() => PowerUpSystem.Instance?.SelectPowerUp(PowerUpType.Freeze));
    }

    void HideAll()
    {
        if (winPanel) winPanel.SetActive(false);
        if (losePanel) losePanel.SetActive(false);
        if (transitionPanel) transitionPanel.SetActive(false);
        if (finalPanel) finalPanel.SetActive(false);
    }

    public void OnLevelLoaded(LevelConfig cfg)
    {
        current = cfg;
        levelTime = 0f;
        levelActive = true;
        if (levelNameText) levelNameText.text = cfg.levelName;
        RefreshWalls();
        RefreshPowerUps();
        HideAll();
    }

    void Update()
    {
        if (GameStateManager.Instance == null || GameStateManager.Instance.State != GameState.Playing) return;
        levelTime += Time.deltaTime;
        if (timerText)
        {
            int m = (int)(levelTime / 60f); int s = (int)(levelTime % 60f);
            timerText.text = $"Time: {m:00}:{s:00}";
        }
        UpdatePowerUpHighlight();
    }

    void RefreshWalls()
    {
        if (wallCountText && WallSystem.Instance != null)
            wallCountText.text = $"Walls: {WallSystem.Instance.WallBudget}";
    }

    void RefreshPowerUps()
    {
        var ps = PowerUpSystem.Instance;
        if (ps == null) return;
        if (bombText) bombText.text = $"B:{ps.bombCount}";
        if (vaccineText) vaccineText.text = $"V:{ps.vaccineCount}";
        if (freezeText) freezeText.text = $"F:{ps.freezeCount}";
    }

    void UpdatePowerUpHighlight()
    {
        var ps = PowerUpSystem.Instance;
        if (ps == null) return;
        if (bombBg) bombBg.color = ps.activePowerUp == PowerUpType.Bomb ? activePowerUpBg : normalPowerUpBg;
        if (vaccineBg) vaccineBg.color = ps.activePowerUp == PowerUpType.Vaccine ? activePowerUpBg : normalPowerUpBg;
        if (freezeBg) freezeBg.color = ps.activePowerUp == PowerUpType.Freeze ? activePowerUpBg : normalPowerUpBg;
    }

    int GetScore()
    {
        int bonus = Mathf.Max(0, 120 - (int)levelTime);
        return (WallSystem.Instance ? WallSystem.Instance.WallBudget : 0) * 10 + bonus;
    }

    int GetStars()
    {
        if (PowerUpSystem.Instance != null && !PowerUpSystem.Instance.anyPowerUpUsed) return 3;
        if (WallSystem.Instance != null && WallSystem.Instance.WallBudget > 0) return 2;
        return 1;
    }

    void OnState(GameState s)
    {
        if (!levelActive) return;
        if (s == GameState.Win && winPanel)
        {
            levelActive = false;
            winPanel.SetActive(true);
            int score = GetScore(); int stars = GetStars();
            if (winScoreText) winScoreText.text = $"Score: {score}";
            if (winStarsText) winStarsText.text = new string('\u2605', stars) + new string('\u2606', 3 - stars);
            LevelManager.Instance.SaveStars(stars);
        }
        else if (s == GameState.Lose && losePanel)
        {
            levelActive = false;
            losePanel.SetActive(true);
            if (loseFlavorText && current != null) loseFlavorText.text = current.flavorText;
            if (loseStatsText)
            {
                int m = (int)(levelTime / 60f); int sec = (int)(levelTime % 60f);
                loseStatsText.text = $"Survived: {m:00}:{sec:00}    Walls left: {(WallSystem.Instance ? WallSystem.Instance.WallBudget : 0)}";
            }
        }
    }

    public void ShowTransition(int levelNum, LevelConfig cfg, Action onDone) { StartCoroutine(TransitionRoutine(levelNum, cfg, onDone)); }
    IEnumerator TransitionRoutine(int levelNum, LevelConfig cfg, Action onDone)
    {
        if (transitionPanel)
        {
            transitionPanel.SetActive(true);
            if (transitionTitle) transitionTitle.text = $"LEVEL {levelNum}";
            if (transitionName) transitionName.text = cfg.levelName;
            if (transitionFlavor) transitionFlavor.text = cfg.flavorText;
        }
        yield return new WaitForSeconds(3f);
        if (transitionPanel) transitionPanel.SetActive(false);
        onDone?.Invoke();
    }

    public void ShowFinalWin(int score)
    {
        if (finalPanel) finalPanel.SetActive(true);
        if (finalScoreText) finalScoreText.text = $"Total Score: {score}";
    }

    public void ShowStory()
    {
        HideAll();
        if (rulesPanel) rulesPanel.SetActive(false);
        if (storyPanel) storyPanel.SetActive(true);
        if (GridManager.Instance != null) GridManager.Instance.Clear();
        if (WallSystem.Instance != null) WallSystem.Instance.ClearAll();
        if (InfectionSystem.Instance != null) InfectionSystem.Instance.StopRunning();
        if (LevelManager.Instance != null) LevelManager.Instance.totalScore = 0;
        levelActive = false;
    }
}
