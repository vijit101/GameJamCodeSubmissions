using UnityEngine;
using UnityEngine.InputSystem;

public class DebugHelper : MonoBehaviour
{
    void Update()
    {
        var kb = Keyboard.current;
        if (kb == null) return;

        bool bracketCombo =
            (kb.leftBracketKey.isPressed && kb.rightBracketKey.wasPressedThisFrame) ||
            (kb.rightBracketKey.isPressed && kb.leftBracketKey.wasPressedThisFrame);

        bool ctrl = kb.leftCtrlKey.isPressed || kb.rightCtrlKey.isPressed
                 || kb.leftCommandKey.isPressed || kb.rightCommandKey.isPressed;
        bool shift = kb.leftShiftKey.isPressed || kb.rightShiftKey.isPressed;

        if (bracketCombo || (ctrl && shift && kb.nKey.wasPressedThisFrame))
            LevelManager.Instance?.NextLevel();
        if (ctrl && shift && kb.rKey.wasPressedThisFrame)
            LevelManager.Instance?.RetryLevel();
    }
}
