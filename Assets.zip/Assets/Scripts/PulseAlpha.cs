using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PulseAlpha : MonoBehaviour
{
    public float minAlpha = 0.05f;
    public float maxAlpha = 0.15f;
    public float duration = 1.5f;
    public bool colorPulse = false;
    public Color colorA = Color.white;
    public Color colorB = Color.red;

    Image img;
    TMP_Text txt;

    void Awake()
    {
        img = GetComponent<Image>();
        txt = GetComponent<TMP_Text>();
    }

    void Update()
    {
        float d = Mathf.Max(0.05f, duration);
        float t = Mathf.PingPong(Time.time / d, 1f);
        if (colorPulse)
        {
            Color c = Color.Lerp(colorA, colorB, t);
            if (img != null) img.color = c;
            if (txt != null) txt.color = c;
        }
        else
        {
            float a = Mathf.Lerp(minAlpha, maxAlpha, t);
            if (img != null) { var c = img.color; c.a = a; img.color = c; }
            if (txt != null) { var c = txt.color; c.a = a; txt.color = c; }
        }
    }
}
