using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using TMPro;

public class GameBootstrap : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<EventSystem>() == null)
        {
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<InputSystemUIInputModule>();
        }

        SetupCamera();
        var grid = new GameObject("Grid").AddComponent<GridManager>();
        var walls = new GameObject("Walls").AddComponent<WallSystem>();
        var infection = new GameObject("Infection").AddComponent<InfectionSystem>();
        var lvlMgr = new GameObject("LevelManager").AddComponent<LevelManager>();
        var state = new GameObject("GameState").AddComponent<GameStateManager>();
        var audio = new GameObject("Audio").AddComponent<AudioManager>();
        var powerUps = new GameObject("PowerUps").AddComponent<PowerUpSystem>();

        BuildLevels(lvlMgr);
        BuildUI();
    }

    void SetupCamera()
    {
        var cam = Camera.main;
        if (cam == null)
        {
            var go = new GameObject("Main Camera");
            cam = go.AddComponent<Camera>();
            go.tag = "MainCamera";
        }
        cam.orthographic = true;
        cam.orthographicSize = 6f;
        cam.backgroundColor = new Color(0.051f, 0.067f, 0.090f);
        cam.transform.position = new Vector3(0, 0, -10);
    }

    void BuildLevels(LevelManager lm)
    {
        // Level 1: Patient Zero — simple square
        lm.levels.Add(MakeLevel("Patient Zero", 7, 7, 12, 4.5f,
            new[] { V(3, 3) }, new[] { V(0, 0), V(6, 6) },
            "A single case. Contain it before it spreads.",
            null, 0, 0, 0));

        // Level 2: The Bridge — hourglass, unlock bomb
        lm.levels.Add(MakeLevel("The Bridge", 9, 7, 10, 4.0f,
            new[] { V(2, 1) }, new[] { V(6, 5) },
            "One way across. Use your bomb wisely.",
            GridShapes.Hourglass(9, 7), 1, 0, 0));

        // Level 3: Outbreak — L-shape, unlock vaccine
        lm.levels.Add(MakeLevel("Outbreak", 8, 8, 12, 3.5f,
            new[] { V(1, 6), V(6, 1) }, new[] { V(0, 7), V(3, 0) },
            "Two fronts. The vaccine can turn the tide.",
            GridShapes.LShape(8, 8), 1, 1, 0));

        // Level 4: Crossfire — plus shape, unlock freeze
        lm.levels.Add(MakeLevel("Crossfire", 9, 9, 14, 3.0f,
            new[] { V(4, 0), V(0, 4), V(8, 4) }, new[] { V(4, 4), V(4, 8) },
            "They're coming from every direction. Freeze them.",
            GridShapes.Plus(9, 9), 1, 1, 1));

        // Level 5: Pandemic — diamond, all power-ups, fast
        lm.levels.Add(MakeLevel("Pandemic", 11, 11, 16, 2.5f,
            new[] { V(3, 5), V(7, 5), V(5, 3), V(5, 7) },
            new[] { V(5, 5), V(5, 0), V(0, 5), V(10, 5), V(5, 10) },
            "This is how it ends. Unless you stop it.",
            GridShapes.Diamond(11, 11), 1, 1, 1));

        lm.Init(lm.levels.Count);
    }

    Vector2Int V(int x, int y) => new Vector2Int(x, y);

    LevelConfig MakeLevel(string name, int w, int h, int budget, float interval,
        Vector2Int[] infection, Vector2Int[] prot, string flavor,
        bool[,] shape, int bombs, int vaccines, int freezes)
    {
        var cfg = ScriptableObject.CreateInstance<LevelConfig>();
        cfg.levelName = name; cfg.gridWidth = w; cfg.gridHeight = h;
        cfg.wallBudget = budget; cfg.spreadInterval = interval;
        cfg.initialInfectionCells = infection; cfg.protectedCells = prot;
        cfg.flavorText = flavor; cfg.gridShape = shape;
        cfg.bombCount = bombs; cfg.vaccineCount = vaccines; cfg.freezeCount = freezes;
        return cfg;
    }

    // ============================================================
    //  UI BUILDING
    // ============================================================

    void BuildUI()
    {
        // Main canvas for HUD
        var canvasGo = new GameObject("Canvas");
        var canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 1f;
        canvasGo.AddComponent<GraphicRaycaster>();

        var ui = canvasGo.AddComponent<UIManager>();
        BuildHUD(canvasGo.transform, ui);

        // Overlay canvas for panels (higher sort order)
        var overlayGo = new GameObject("OverlayCanvas");
        var oc = overlayGo.AddComponent<Canvas>();
        oc.renderMode = RenderMode.ScreenSpaceOverlay;
        oc.sortingOrder = 10;
        var os = overlayGo.AddComponent<CanvasScaler>();
        os.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        os.referenceResolution = new Vector2(1920, 1080);
        os.matchWidthOrHeight = 1f;
        overlayGo.AddComponent<GraphicRaycaster>();

        BuildPanels(overlayGo.transform, ui);
        BuildStoryRules(overlayGo.transform, ui);

        // Debug helper
        var dbg = new GameObject("DebugHelper").AddComponent<DebugHelper>();
    }

    void BuildHUD(Transform parent, UIManager ui)
    {
        var bar = new GameObject("TopBar");
        bar.transform.SetParent(parent, false);
        var brt = bar.AddComponent<RectTransform>();
        brt.anchorMin = new Vector2(0, 1); brt.anchorMax = new Vector2(1, 1);
        brt.pivot = new Vector2(0.5f, 1f);
        brt.sizeDelta = new Vector2(0, 70);
        bar.AddComponent<Image>().color = new Color(0, 0, 0, 0.4f);

        ui.levelNameText = HUDText(bar.transform, "LevelName", 0f, 0.25f, TextAlignmentOptions.Left, 24);
        ui.wallCountText = HUDText(bar.transform, "Walls", 0.25f, 0.45f, TextAlignmentOptions.Center, 28);
        ui.timerText = HUDText(bar.transform, "Timer", 0.75f, 1f, TextAlignmentOptions.Right, 24);

        // Power-up buttons between walls and timer
        float pbStart = 0.46f; float pbW = 0.09f;
        ui.bombBg = PowerUpBtn(bar.transform, "Bomb", pbStart, pbStart + pbW, out ui.bombBtn, out ui.bombText, new Color(1f, 0.5f, 0.2f));
        ui.vaccineBg = PowerUpBtn(bar.transform, "Vaccine", pbStart + pbW + 0.005f, pbStart + 2 * pbW + 0.005f, out ui.vaccineBtn, out ui.vaccineText, new Color(0.3f, 0.7f, 1f));
        ui.freezeBg = PowerUpBtn(bar.transform, "Freeze", pbStart + 2 * (pbW + 0.005f), pbStart + 3 * pbW + 0.01f, out ui.freezeBtn, out ui.freezeText, new Color(0.5f, 0.9f, 1f));
    }

    TMP_Text HUDText(Transform parent, string name, float xMin, float xMax, TextAlignmentOptions align, float size)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(xMin, 0); rt.anchorMax = new Vector2(xMax, 1);
        rt.offsetMin = new Vector2(12, 4); rt.offsetMax = new Vector2(-12, -4);
        var t = go.AddComponent<TextMeshProUGUI>();
        t.text = name; t.fontSize = size; t.color = Color.white;
        t.alignment = align; t.enableWordWrapping = false;
        t.overflowMode = TextOverflowModes.Overflow;
        t.raycastTarget = false;
        return t;
    }

    Image PowerUpBtn(Transform parent, string name, float xMin, float xMax, out Button btn, out TMP_Text text, Color tintColor)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(xMin, 0.1f); rt.anchorMax = new Vector2(xMax, 0.9f);
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        var img = go.AddComponent<Image>();
        img.color = new Color(0.15f, 0.15f, 0.15f, 0.9f);
        btn = go.AddComponent<Button>();

        var tgo = new GameObject("Text");
        tgo.transform.SetParent(go.transform, false);
        var trt = tgo.AddComponent<RectTransform>();
        trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one;
        trt.offsetMin = Vector2.zero; trt.offsetMax = Vector2.zero;
        text = tgo.AddComponent<TextMeshProUGUI>();
        text.text = name[0] + ":0"; text.fontSize = 20; text.color = tintColor;
        text.alignment = TextAlignmentOptions.Center;
        text.fontStyle = FontStyles.Bold;
        text.enableWordWrapping = false;
        text.raycastTarget = false;
        return img;
    }

    void BuildPanels(Transform parent, UIManager ui)
    {
        Color panelBg = new Color(0.03f, 0.03f, 0.04f, 0.97f);

        // Win panel
        ui.winPanel = FullPanel(parent, "WinPanel", panelBg);
        ui.winPanel.SetActive(false);
        PanelLabel(ui.winPanel.transform, "CONTAINED", 72, new Color(0.3f, 1f, 0.4f), true, -280);
        ui.winStarsText = PanelLabel(ui.winPanel.transform, "\u2605\u2605\u2605", 60, new Color(1f, 0.84f, 0f), false, -370);
        ui.winScoreText = PanelLabel(ui.winPanel.transform, "Score: 0", 36, Color.white, false, -450);
        ui.winNextButton = PanelButton(ui.winPanel.transform, "Next Level", new Vector2(0.5f, 0), new Vector2(-120, 120));
        ui.winMenuButton = PanelButton(ui.winPanel.transform, "Main Menu", new Vector2(0.5f, 0), new Vector2(120, 120));

        // Lose panel
        ui.losePanel = FullPanel(parent, "LosePanel", panelBg);
        ui.losePanel.SetActive(false);
        PanelLabel(ui.losePanel.transform, "OUTBREAK", 72, new Color(1f, 0.2f, 0.2f), true, -300);
        ui.loseFlavorText = PanelLabel(ui.losePanel.transform, "", 24, Color.white, false, -400);
        ui.loseStatsText = PanelLabel(ui.losePanel.transform, "", 20, new Color(0.7f, 0.7f, 0.7f), false, -450);
        ui.loseRetryButton = PanelButton(ui.losePanel.transform, "Retry", new Vector2(0.5f, 0), new Vector2(-120, 120));
        ui.loseMenuButton = PanelButton(ui.losePanel.transform, "Main Menu", new Vector2(0.5f, 0), new Vector2(120, 120));

        // Transition panel
        ui.transitionPanel = FullPanel(parent, "TransitionPanel", new Color(0, 0, 0, 1));
        ui.transitionPanel.SetActive(false);
        ui.transitionTitle = PanelLabel(ui.transitionPanel.transform, "LEVEL 1", 80, Color.white, true, -340);
        ui.transitionName = PanelLabel(ui.transitionPanel.transform, "", 40, new Color(0.8f, 0.2f, 0.2f), false, -430);
        ui.transitionFlavor = PanelLabel(ui.transitionPanel.transform, "", 24, new Color(0.7f, 0.7f, 0.7f), false, -500);

        // Final win panel
        ui.finalPanel = FullPanel(parent, "FinalPanel", new Color(0.02f, 0.04f, 0.02f, 1));
        ui.finalPanel.SetActive(false);
        PanelLabel(ui.finalPanel.transform, "PANDEMIC CONTAINED", 64, new Color(0.3f, 1f, 0.4f), true, -320);
        PanelLabel(ui.finalPanel.transform, "You saved the world. For now.", 28, Color.white, false, -410);
        ui.finalScoreText = PanelLabel(ui.finalPanel.transform, "Total Score: 0", 36, Color.white, false, -470);
        ui.finalPlayAgainButton = PanelButton(ui.finalPanel.transform, "Play Again", new Vector2(0.5f, 0), new Vector2(0, 120));
    }

    void BuildStoryRules(Transform parent, UIManager ui)
    {
        Color bg = new Color(0.051f, 0.051f, 0.051f, 1f);
        Color red = new Color(0.80f, 0f, 0f, 1f);

        // Story panel
        ui.storyPanel = FullPanel(parent, "StoryPanel", bg);
        MakePulsingBorder(ui.storyPanel.transform, red);
        PanelLabel(ui.storyPanel.transform, "YEAR 2020", 48, Color.white, true, -100);
        PanelLabel(ui.storyPanel.transform, "THE WORLD CHANGED.", 28, red, false, -170);
        FixedDivider(ui.storyPanel.transform, red, -215);

        string body = "A novel coronavirus has escaped containment.\nScientists watch helplessly as it spreads \u2014\neach petri dish a mirror of our cities, our lives.\n\nYour job: contain the infection.\nPlace walls. Isolate the spread.\nProtect what remains.\n\nYou are the last line of defense.";
        var bodyText = PanelLabel(ui.storyPanel.transform, body, 18, Color.white, false, -260);
        bodyText.enableWordWrapping = true; bodyText.lineSpacing = 8;
        bodyText.alignment = TextAlignmentOptions.Top;
        var brt = bodyText.GetComponent<RectTransform>();
        brt.sizeDelta = new Vector2(brt.sizeDelta.x, 320);

        var finale = PanelLabel(ui.storyPanel.transform, "CONTAIN IT.", 36, red, true, -620);
        var p = finale.gameObject.AddComponent<PulseAlpha>();
        p.colorPulse = true; p.duration = 2f; p.colorA = Color.white; p.colorB = red;

        var storyBtn = PanelButton(ui.storyPanel.transform, "I UNDERSTAND", new Vector2(0.5f, 0), new Vector2(0, 100));
        storyBtn.GetComponent<Image>().color = red;

        // Rules panel
        ui.rulesPanel = FullPanel(parent, "RulesPanel", bg);
        MakePulsingBorder(ui.rulesPanel.transform, red);
        PanelLabel(ui.rulesPanel.transform, "CONTAINMENT PROTOCOL", 40, Color.white, true, -80);
        FixedDivider(ui.rulesPanel.transform, red, -135);

        string[] rules = {
            "GREEN \u2014 Healthy tissue. Protect it.",
            "RED \u2014 Infected. Spreads every few seconds.",
            "GOLD \u2014 Critical zone. If infected, you LOSE.",
            "LEFT CLICK gap between cells to place a wall.",
            "RIGHT CLICK a wall to remove it.",
            "Press B for BOMB \u2014 destroy a cell permanently.",
            "Press V for VACCINE \u2014 cure a cell + neighbors.",
            "Press F for FREEZE \u2014 pause infection 5 seconds.",
            "Seal ALL infected areas to WIN."
        };
        Color[] cols = {
            new Color(0.3f, 0.69f, 0.31f), new Color(0.8f, 0, 0), new Color(1, 0.84f, 0),
            Color.white, Color.white,
            new Color(1f, 0.5f, 0.2f), new Color(0.3f, 0.7f, 1f), new Color(0.5f, 0.9f, 1f),
            Color.white
        };
        for (int i = 0; i < rules.Length; i++)
        {
            float y = -180 - i * 38;
            RuleRow(ui.rulesPanel.transform, cols[i], rules[i], y);
        }

        var rulesBtn = PanelButton(ui.rulesPanel.transform, "BEGIN CONTAINMENT", new Vector2(0.5f, 0), new Vector2(0, 100));
        rulesBtn.GetComponent<Image>().color = red;
        var rbt = rulesBtn.GetComponentInChildren<TMP_Text>();
        if (rbt) rbt.color = Color.white;
        ui.rulesPanel.SetActive(false);

        storyBtn.onClick.AddListener(() => { ui.storyPanel.SetActive(false); ui.rulesPanel.SetActive(true); });
        rulesBtn.onClick.AddListener(() => { ui.rulesPanel.SetActive(false); LevelManager.Instance.LoadLevel(0); });
    }

    // ============================================================
    //  UI HELPERS
    // ============================================================

    GameObject FullPanel(Transform parent, string name, Color bg)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        go.AddComponent<Image>().color = bg;
        return go;
    }

    TMP_Text PanelLabel(Transform parent, string text, float size, Color color, bool bold, float yFromTop)
    {
        var go = new GameObject("Label");
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, 1); rt.anchorMax = new Vector2(1, 1);
        rt.pivot = new Vector2(0.5f, 1f);
        rt.offsetMin = new Vector2(60, 0); rt.offsetMax = new Vector2(-60, 0);
        rt.sizeDelta = new Vector2(rt.sizeDelta.x, size + 20);
        rt.anchoredPosition = new Vector2(0, yFromTop);
        var t = go.AddComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = size; t.color = color;
        t.alignment = TextAlignmentOptions.Center;
        t.enableWordWrapping = false; t.overflowMode = TextOverflowModes.Overflow;
        t.raycastTarget = false;
        if (bold) t.fontStyle = FontStyles.Bold;
        return t;
    }

    Button PanelButton(Transform parent, string label, Vector2 anchor, Vector2 offset)
    {
        var go = new GameObject(label);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0);
        rt.sizeDelta = new Vector2(220, 50);
        rt.anchoredPosition = offset;
        var img = go.AddComponent<Image>();
        img.color = new Color(0.2f, 0.2f, 0.2f, 0.9f);
        var btn = go.AddComponent<Button>();

        var tgo = new GameObject("Text");
        tgo.transform.SetParent(go.transform, false);
        var trt = tgo.AddComponent<RectTransform>();
        trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one;
        trt.offsetMin = Vector2.zero; trt.offsetMax = Vector2.zero;
        var t = tgo.AddComponent<TextMeshProUGUI>();
        t.text = label; t.fontSize = 20; t.color = Color.white;
        t.alignment = TextAlignmentOptions.Center; t.fontStyle = FontStyles.Bold;
        t.enableWordWrapping = false; t.raycastTarget = false;
        return btn;
    }

    void FixedDivider(Transform parent, Color color, float yFromTop)
    {
        var go = new GameObject("Divider");
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.1f, 1); rt.anchorMax = new Vector2(0.9f, 1);
        rt.pivot = new Vector2(0.5f, 1f);
        rt.sizeDelta = new Vector2(0, 2);
        rt.anchoredPosition = new Vector2(0, yFromTop);
        go.AddComponent<Image>().color = color;
    }

    void RuleRow(Transform parent, Color dotColor, string text, float yFromTop)
    {
        var sq = new GameObject("Dot");
        sq.transform.SetParent(parent, false);
        var srt = sq.AddComponent<RectTransform>();
        srt.anchorMin = new Vector2(0, 1); srt.anchorMax = new Vector2(0, 1);
        srt.pivot = new Vector2(0, 0.5f);
        srt.sizeDelta = new Vector2(18, 18);
        srt.anchoredPosition = new Vector2(100, yFromTop);
        sq.AddComponent<Image>().color = dotColor;

        var tgo = new GameObject("RuleText");
        tgo.transform.SetParent(parent, false);
        var trt = tgo.AddComponent<RectTransform>();
        trt.anchorMin = new Vector2(0, 1); trt.anchorMax = new Vector2(1, 1);
        trt.pivot = new Vector2(0, 0.5f);
        trt.offsetMin = new Vector2(130, 0); trt.offsetMax = new Vector2(-60, 0);
        trt.sizeDelta = new Vector2(trt.sizeDelta.x, 30);
        trt.anchoredPosition = new Vector2(0, yFromTop);
        var t = tgo.AddComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = 18; t.color = Color.white;
        t.alignment = TextAlignmentOptions.Left;
        t.enableWordWrapping = false; t.overflowMode = TextOverflowModes.Overflow;
        t.raycastTarget = false;
    }

    void MakePulsingBorder(Transform parent, Color color)
    {
        MakeEdgeStrip(parent, color, new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, 4));
        MakeEdgeStrip(parent, color, new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 4));
        MakeEdgeStrip(parent, color, new Vector2(0, 0), new Vector2(0, 1), new Vector2(4, 0));
        MakeEdgeStrip(parent, color, new Vector2(1, 0), new Vector2(1, 1), new Vector2(4, 0));
    }

    void MakeEdgeStrip(Transform parent, Color color, Vector2 aMin, Vector2 aMax, Vector2 size)
    {
        var go = new GameObject("Edge");
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.sizeDelta = size; rt.anchoredPosition = Vector2.zero;
        var img = go.AddComponent<Image>();
        img.color = color; img.raycastTarget = false;
        var p = go.AddComponent<PulseAlpha>();
        p.minAlpha = 0.3f; p.maxAlpha = 0.8f; p.duration = 1.5f;
    }
}
