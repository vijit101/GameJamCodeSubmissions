using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour
{
    public static LevelManager Instance;
    public List<LevelConfig> levels = new List<LevelConfig>();
    public int currentIndex = 0;
    public int totalScore = 0;
    public int[] levelStars;
    public LevelConfig Current => (currentIndex >= 0 && currentIndex < levels.Count) ? levels[currentIndex] : null;

    void Awake() { Instance = this; }

    public void Init(int levelCount) { levelStars = new int[levelCount]; }

    public void LoadLevel(int index)
    {
        if (index < 0 || index >= levels.Count) return;
        currentIndex = index;
        var cfg = levels[index];
        GridManager.Instance.Build(cfg);
        FitCamera(cfg);
        WallSystem.Instance.ClearAll();
        WallSystem.Instance.SetBudget(cfg.wallBudget);
        InfectionSystem.Instance.Configure(cfg.spreadInterval);
        InfectionSystem.Instance.StartRunning();
        if (PowerUpSystem.Instance != null)
            PowerUpSystem.Instance.Configure(cfg.bombCount, cfg.vaccineCount, cfg.freezeCount);
        if (UIManager.Instance != null) UIManager.Instance.OnLevelLoaded(cfg);
        if (GameStateManager.Instance != null) GameStateManager.Instance.SetState(GameState.Playing);
    }

    public void NextLevel()
    {
        int next = currentIndex + 1;
        if (next < levels.Count)
        {
            if (UIManager.Instance != null) UIManager.Instance.ShowTransition(next + 1, levels[next], () => LoadLevel(next));
            else LoadLevel(next);
        }
        else
        {
            InfectionSystem.Instance.StopRunning();
            if (UIManager.Instance != null) UIManager.Instance.ShowFinalWin(totalScore);
        }
    }

    public void ResetRun() { totalScore = 0; LoadLevel(0); }
    public void RetryLevel() { LoadLevel(currentIndex); }
    public void AddScore(int s) { totalScore += s; }

    public void SaveStars(int stars)
    {
        if (levelStars != null && currentIndex < levelStars.Length)
            levelStars[currentIndex] = Mathf.Max(levelStars[currentIndex], stars);
    }

    void FitCamera(LevelConfig cfg)
    {
        var cam = Camera.main;
        if (cam == null) return;
        float s = GridManager.Instance.spacing;
        float dim = Mathf.Max(cfg.gridWidth, cfg.gridHeight) * s;
        cam.orthographicSize = dim / (2f * 0.72f);
    }
}
