using UnityEngine;

public static class GridShapes
{
    public static bool[,] Hourglass(int w, int h)
    {
        var m = new bool[w, h];
        int midY = h / 2;
        for (int y = 0; y < h; y++)
        {
            float t = Mathf.Abs(y - midY) / (float)Mathf.Max(1, midY);
            int halfW = Mathf.RoundToInt(Mathf.Lerp(1, w / 2, t));
            int cx = w / 2;
            for (int x = cx - halfW; x <= cx + halfW; x++)
                if (x >= 0 && x < w) m[x, y] = true;
        }
        return m;
    }

    public static bool[,] LShape(int w, int h)
    {
        var m = new bool[w, h];
        int splitX = w / 2;
        int splitY = h / 2;
        for (int x = 0; x < w; x++)
        for (int y = 0; y < h; y++)
            m[x, y] = (x < splitX) || (y < splitY);
        return m;
    }

    public static bool[,] Plus(int w, int h)
    {
        var m = new bool[w, h];
        int armW = w / 3;
        int armH = h / 3;
        for (int x = 0; x < w; x++)
        for (int y = 0; y < h; y++)
            m[x, y] = (x >= armW && x < w - armW) || (y >= armH && y < h - armH);
        return m;
    }

    public static bool[,] Diamond(int w, int h)
    {
        var m = new bool[w, h];
        int cx = w / 2, cy = h / 2;
        int r = Mathf.Min(cx, cy);
        for (int x = 0; x < w; x++)
        for (int y = 0; y < h; y++)
            m[x, y] = Mathf.Abs(x - cx) + Mathf.Abs(y - cy) <= r;
        return m;
    }
}
