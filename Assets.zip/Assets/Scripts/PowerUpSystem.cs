using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;

public enum PowerUpType { None, Bomb, Vaccine, Freeze }

public class PowerUpSystem : MonoBehaviour
{
    public static PowerUpSystem Instance;
    public PowerUpType activePowerUp = PowerUpType.None;
    public int bombCount, vaccineCount, freezeCount;
    public bool isFrozen;
    public bool anyPowerUpUsed;

    public event Action OnBombUsed;
    public event Action OnVaccineUsed;
    public event Action OnFreezeUsed;
    public event Action OnCountsChanged;

    float freezeTimer;
    Camera cam;

    void Awake() { Instance = this; }

    public void Configure(int bombs, int vaccines, int freezes)
    {
        bombCount = bombs; vaccineCount = vaccines; freezeCount = freezes;
        activePowerUp = PowerUpType.None;
        isFrozen = false; freezeTimer = 0f;
        anyPowerUpUsed = false;
        OnCountsChanged?.Invoke();
    }

    public void SelectPowerUp(PowerUpType type)
    {
        if (activePowerUp == type) { activePowerUp = PowerUpType.None; return; }
        if (type == PowerUpType.Bomb && bombCount <= 0) return;
        if (type == PowerUpType.Vaccine && vaccineCount <= 0) return;
        if (type == PowerUpType.Freeze && freezeCount <= 0) return;
        activePowerUp = type;
    }

    void Update()
    {
        if (GameStateManager.Instance != null && GameStateManager.Instance.State != GameState.Playing) return;

        var kb = Keyboard.current;
        if (kb != null)
        {
            if (kb.bKey.wasPressedThisFrame) SelectPowerUp(PowerUpType.Bomb);
            if (kb.vKey.wasPressedThisFrame) SelectPowerUp(PowerUpType.Vaccine);
            if (kb.fKey.wasPressedThisFrame) SelectPowerUp(PowerUpType.Freeze);
            if (kb.escapeKey.wasPressedThisFrame) activePowerUp = PowerUpType.None;
        }

        if (isFrozen)
        {
            freezeTimer -= Time.unscaledDeltaTime;
            if (freezeTimer <= 0f) EndFreeze();
        }

        if (activePowerUp == PowerUpType.None) return;
        if (Mouse.current == null) return;
        if (!Mouse.current.leftButton.wasPressedThisFrame) return;

        if (activePowerUp == PowerUpType.Freeze)
        {
            UseFreeze(); return;
        }

        if (cam == null) cam = Camera.main;
        if (cam == null) return;
        Vector2 screen = Mouse.current.position.ReadValue();
        Vector3 world = cam.ScreenToWorldPoint(new Vector3(screen.x, screen.y, -cam.transform.position.z));
        var cell = FindClosestCell(world);
        if (cell == null) return;

        if (activePowerUp == PowerUpType.Bomb) UseBomb(cell);
        else if (activePowerUp == PowerUpType.Vaccine) UseVaccine(cell);
    }

    Cell FindClosestCell(Vector3 world)
    {
        var gm = GridManager.Instance;
        if (gm == null) return null;
        Cell best = null; float bestD = 0.55f;
        foreach (var c in gm.AllCells())
        {
            float d = Vector2.Distance(world, c.transform.position);
            if (d < bestD) { bestD = d; best = c; }
        }
        return best;
    }

    void UseBomb(Cell cell)
    {
        if (bombCount <= 0) return;
        if (cell.state == CellState.Dead || cell.state == CellState.Protected) return;
        cell.SetState(CellState.Dead);
        bombCount--; anyPowerUpUsed = true;
        activePowerUp = PowerUpType.None;
        AnimateBomb(cell);
        OnBombUsed?.Invoke();
        OnCountsChanged?.Invoke();
    }

    void UseVaccine(Cell cell)
    {
        if (vaccineCount <= 0) return;
        if (cell.state != CellState.Infected) return;
        var toCure = new List<Cell> { cell };
        foreach (var n in GridManager.Instance.GetNeighbors(cell))
            if (n.state == CellState.Infected) toCure.Add(n);
        foreach (var c in toCure) { c.SetState(CellState.Healthy); AnimateVaccine(c); }
        vaccineCount--; anyPowerUpUsed = true;
        activePowerUp = PowerUpType.None;
        OnVaccineUsed?.Invoke();
        OnCountsChanged?.Invoke();
    }

    void UseFreeze()
    {
        if (freezeCount <= 0 || isFrozen) return;
        freezeCount--; anyPowerUpUsed = true;
        activePowerUp = PowerUpType.None;
        isFrozen = true; freezeTimer = 5f;
        if (InfectionSystem.Instance != null) InfectionSystem.Instance.StopRunning();
        OnFreezeUsed?.Invoke();
        OnCountsChanged?.Invoke();
    }

    void EndFreeze()
    {
        isFrozen = false;
        if (InfectionSystem.Instance != null && GameStateManager.Instance.State == GameState.Playing)
            InfectionSystem.Instance.StartRunning();
    }

    void AnimateBomb(Cell c)
    {
        DOTween.Kill(c.transform);
        c.transform.DOPunchScale(Vector3.one * 0.4f, 0.3f, 8, 0.5f);
        StartCoroutine(CameraShake(0.15f, 0.08f));
    }

    void AnimateVaccine(Cell c)
    {
        DOTween.Kill(c.transform);
        var sr = c.sr;
        if (sr != null) { sr.color = new Color(0.3f, 0.6f, 1f); }
        c.transform.DOPunchScale(Vector3.one * 0.25f, 0.25f, 6, 0.3f);
    }

    IEnumerator CameraShake(float dur, float mag)
    {
        var cam = Camera.main;
        if (cam == null) yield break;
        Vector3 orig = cam.transform.position;
        float t = 0f;
        while (t < dur)
        {
            cam.transform.position = orig + (Vector3)(UnityEngine.Random.insideUnitCircle * mag);
            t += Time.unscaledDeltaTime;
            yield return null;
        }
        cam.transform.position = orig;
    }
}
