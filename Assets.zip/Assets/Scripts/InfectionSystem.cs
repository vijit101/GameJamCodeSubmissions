using System;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class InfectionSystem : MonoBehaviour
{
    public static InfectionSystem Instance;
    public event Action<Cell> OnCellInfected;
    public event Action OnWin;
    public event Action OnLose;
    public event Action OnTick;

    public float spreadInterval = 2.5f;
    public bool running = false;
    float timer;

    void Awake() { Instance = this; }

    public void Configure(float interval) { spreadInterval = interval; timer = 0f; }
    public void StartRunning() { running = true; timer = 0f; }
    public void StopRunning() { running = false; }

    void Update()
    {
        if (!running) return;
        if (PowerUpSystem.Instance != null && PowerUpSystem.Instance.isFrozen) return;
        timer += Time.deltaTime;
        if (timer >= spreadInterval) { timer = 0f; Tick(); }
    }

    void Tick()
    {
        OnTick?.Invoke();
        var gm = GridManager.Instance;
        var ws = WallSystem.Instance;
        var toInfect = new List<Cell>();
        foreach (var c in gm.AllCells())
        {
            if (c.state != CellState.Infected) continue;
            foreach (var n in gm.GetNeighbors(c))
            {
                if (ws.HasWall(c, n)) continue;
                if (n.state == CellState.Healthy || n.state == CellState.Protected)
                    if (!toInfect.Contains(n)) toInfect.Add(n);
            }
        }

        bool loseTriggered = false;
        foreach (var c in toInfect)
        {
            bool wasProtected = c.state == CellState.Protected;
            c.SetState(CellState.Infected);
            AnimateInfect(c);
            OnCellInfected?.Invoke(c);
            if (wasProtected) loseTriggered = true;
        }

        if (loseTriggered) { running = false; OnLose?.Invoke(); return; }
        if (!AnyReachable()) { running = false; SealContained(); OnWin?.Invoke(); }
    }

    bool AnyReachable()
    {
        var gm = GridManager.Instance;
        var ws = WallSystem.Instance;
        var visited = new HashSet<Cell>();
        var queue = new Queue<Cell>();
        foreach (var c in gm.AllCells())
            if (c.state == CellState.Infected) { queue.Enqueue(c); visited.Add(c); }
        while (queue.Count > 0)
        {
            var c = queue.Dequeue();
            foreach (var n in gm.GetNeighbors(c))
            {
                if (visited.Contains(n)) continue;
                if (ws.HasWall(c, n)) continue;
                if (n.state == CellState.Healthy || n.state == CellState.Protected) return true;
                if (n.state == CellState.Infected) { visited.Add(n); queue.Enqueue(n); }
            }
        }
        return false;
    }

    void SealContained()
    {
        var gm = GridManager.Instance;
        foreach (var c in gm.AllCells())
            if (c.state == CellState.Healthy) c.SetState(CellState.Contained);
    }

    void AnimateInfect(Cell c)
    {
        DOTween.Kill(c.transform);
        c.transform.DOPunchScale(Vector3.one * 0.3f, 0.2f, 6, 0.5f);
    }
}
