using UnityEngine;

[CreateAssetMenu(fileName = "LevelConfig", menuName = "Quarantine/LevelConfig")]
public class LevelConfig : ScriptableObject
{
    public int gridWidth = 6;
    public int gridHeight = 6;
    public int wallBudget = 8;
    public float spreadInterval = 2.5f;
    public Vector2Int[] initialInfectionCells;
    public Vector2Int[] protectedCells;
    public string levelName = "Level";
    [TextArea] public string flavorText;
    public bool[,] gridShape;
    public int bombCount;
    public int vaccineCount;
    public int freezeCount;
}
