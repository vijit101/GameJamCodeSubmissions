using System.Collections.Generic;
using UnityEngine;

public enum CellState { Healthy, Infected, Contained, Protected, Dead }

public class Cell : MonoBehaviour
{
    public int gridX, gridY;
    public CellState state;
    public SpriteRenderer sr;
    public SpriteRenderer glow;
    public SpriteRenderer starIcon;

    public void SetState(CellState s)
    {
        state = s;
        if (sr == null) sr = GetComponent<SpriteRenderer>();
        sr.color = GridManager.ColorFor(s);
        if (glow != null)
        {
            var gc = GridManager.ColorFor(s); gc.a = 0.35f;
            glow.color = gc;
            glow.enabled = s != CellState.Dead && s != CellState.Contained;
        }
        if (starIcon != null) starIcon.gameObject.SetActive(s == CellState.Protected);
    }

    void Update()
    {
        if (state == CellState.Infected)
        {
            float p = 1f + Mathf.Sin(Time.time * 4f) * 0.05f;
            transform.localScale = Vector3.one * GridManager.Instance.cellSize * p;
        }
    }
}

public class GridManager : MonoBehaviour
{
    public static GridManager Instance;
    public float cellSize = 0.9f;
    public float spacing = 1.0f;
    public int width { get; private set; }
    public int height { get; private set; }
    Cell[,] cells;

    void Awake() { Instance = this; }

    public static Color ColorFor(CellState s)
    {
        switch (s)
        {
            case CellState.Healthy:   return new Color(0.298f, 0.686f, 0.314f);
            case CellState.Infected:  return new Color(0.957f, 0.263f, 0.212f);
            case CellState.Contained: return new Color(0.620f, 0.620f, 0.620f);
            case CellState.Protected: return new Color(1.000f, 0.843f, 0.000f);
            case CellState.Dead:      return new Color(0.12f, 0.12f, 0.12f);
        }
        return Color.white;
    }

    public void Build(LevelConfig cfg)
    {
        Clear();
        width = cfg.gridWidth; height = cfg.gridHeight;
        cells = new Cell[width, height];
        Vector2 offset = new Vector2((width - 1) * spacing * 0.5f, (height - 1) * spacing * 0.5f);

        var sprite = MakeRoundedSprite();
        var glowSprite = MakeGlowSprite();
        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            if (cfg.gridShape != null && !cfg.gridShape[x, y]) continue;

            var go = new GameObject($"Cell_{x}_{y}");
            go.transform.SetParent(transform, false);
            go.transform.position = new Vector3(x * spacing - offset.x, y * spacing - offset.y, 0);
            go.transform.localScale = Vector3.one * cellSize;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite; sr.sortingOrder = 1;

            var glowGo = new GameObject("Glow");
            glowGo.transform.SetParent(go.transform, false);
            glowGo.transform.localScale = Vector3.one * 1.25f;
            var glow = glowGo.AddComponent<SpriteRenderer>();
            glow.sprite = glowSprite; glow.sortingOrder = 0;

            var starGo = new GameObject("StarIcon");
            starGo.transform.SetParent(go.transform, false);
            starGo.transform.localPosition = new Vector3(0, 0, -0.1f);
            starGo.transform.localScale = Vector3.one * 0.45f;
            var star = starGo.AddComponent<SpriteRenderer>();
            star.sprite = glowSprite;
            star.color = new Color(0.25f, 0.15f, 0f, 1f);
            star.sortingOrder = 2;
            starGo.SetActive(false);

            var c = go.AddComponent<Cell>();
            c.gridX = x; c.gridY = y; c.sr = sr; c.glow = glow; c.starIcon = star;
            c.SetState(CellState.Healthy);
            cells[x, y] = c;
        }

        foreach (var p in cfg.protectedCells)
            if (GetCell(p.x, p.y) != null) cells[p.x, p.y].SetState(CellState.Protected);
        foreach (var p in cfg.initialInfectionCells)
            if (GetCell(p.x, p.y) != null) cells[p.x, p.y].SetState(CellState.Infected);
    }

    public void Clear()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
            if (Application.isPlaying) Destroy(transform.GetChild(i).gameObject);
            else DestroyImmediate(transform.GetChild(i).gameObject);
        cells = null;
    }

    public bool InBounds(int x, int y) => cells != null && x >= 0 && y >= 0 && x < width && y < height;
    public Cell GetCell(int x, int y) => InBounds(x, y) ? cells[x, y] : null;

    public List<Cell> GetNeighbors(Cell c)
    {
        var list = new List<Cell>(4);
        int[] dx = { 1, -1, 0, 0 }; int[] dy = { 0, 0, 1, -1 };
        for (int i = 0; i < 4; i++)
        {
            var n = GetCell(c.gridX + dx[i], c.gridY + dy[i]);
            if (n != null) list.Add(n);
        }
        return list;
    }

    public IEnumerable<Cell> AllCells()
    {
        if (cells == null) yield break;
        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
            if (cells[x, y] != null) yield return cells[x, y];
    }

    static Sprite cachedRounded, cachedGlow;

    Sprite MakeRoundedSprite()
    {
        if (cachedRounded != null) return cachedRounded;
        int size = 64; int r = 14;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        var px = new Color[size * size];
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            int cx = x < r ? r : (x > size - 1 - r ? size - 1 - r : x);
            int cy = y < r ? r : (y > size - 1 - r ? size - 1 - r : y);
            float d = Mathf.Sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
            float a = Mathf.Clamp01(r - d + 0.5f);
            float ndx = Mathf.Abs(x - size * 0.5f) / (size * 0.5f);
            float ndy = Mathf.Abs(y - size * 0.5f) / (size * 0.5f);
            float bright = 0.85f + (1f - Mathf.Max(ndx, ndy)) * 0.3f;
            px[y * size + x] = new Color(bright, bright, bright, a);
        }
        tex.SetPixels(px); tex.Apply();
        cachedRounded = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        return cachedRounded;
    }

    Sprite MakeGlowSprite()
    {
        if (cachedGlow != null) return cachedGlow;
        int size = 64;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        var px = new Color[size * size];
        Vector2 c = new Vector2(size * 0.5f, size * 0.5f);
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float d = Vector2.Distance(new Vector2(x, y), c) / (size * 0.5f);
            float a = Mathf.Clamp01(1f - d); a *= a;
            px[y * size + x] = new Color(1, 1, 1, a);
        }
        tex.SetPixels(px); tex.Apply();
        cachedGlow = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        return cachedGlow;
    }
}
