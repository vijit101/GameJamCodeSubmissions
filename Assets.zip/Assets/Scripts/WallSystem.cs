using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;

public class WallSystem : MonoBehaviour
{
    public static WallSystem Instance;
    public event Action OnWallPlaced;
    public event Action OnWallRemoved;

    public int wallBudget;
    public int WallBudget => wallBudget;

    HashSet<(int, int, int, int)> walls = new HashSet<(int, int, int, int)>();
    Dictionary<(int, int, int, int), GameObject> wallObjects = new Dictionary<(int, int, int, int), GameObject>();
    Camera cam;
    LineRenderer ghostLine;

    void Awake() { Instance = this; cam = Camera.main; }

    public void SetBudget(int b) { wallBudget = b; }

    public void ClearAll()
    {
        foreach (var kv in wallObjects) if (kv.Value) Destroy(kv.Value);
        walls.Clear(); wallObjects.Clear();
        if (ghostLine) ghostLine.enabled = false;
    }

    static (int, int, int, int) Key(Cell a, Cell b)
    {
        if (a.gridX < b.gridX || (a.gridX == b.gridX && a.gridY < b.gridY))
            return (a.gridX, a.gridY, b.gridX, b.gridY);
        return (b.gridX, b.gridY, a.gridX, a.gridY);
    }

    public bool HasWall(Cell a, Cell b)
    {
        if (a == null || b == null) return false;
        return walls.Contains(Key(a, b));
    }

    void Update()
    {
        if (GameStateManager.Instance != null && GameStateManager.Instance.State != GameState.Playing)
        { if (ghostLine) ghostLine.enabled = false; return; }
        if (cam == null) cam = Camera.main;
        if (cam == null || GridManager.Instance == null) return;
        if (Mouse.current == null) return;

        // Power-up active: don't handle wall placement
        if (PowerUpSystem.Instance != null && PowerUpSystem.Instance.activePowerUp != PowerUpType.None)
        { if (ghostLine) ghostLine.enabled = false; return; }

        Vector2 screen = Mouse.current.position.ReadValue();
        Vector3 mw = cam.ScreenToWorldPoint(new Vector3(screen.x, screen.y, -cam.transform.position.z));
        mw.z = 0;
        bool hasEdge = TryFindEdge(mw, out Cell a, out Cell b);
        UpdateGhost(hasEdge, a, b);
        if (!hasEdge) return;

        if (Mouse.current.leftButton.wasPressedThisFrame) TryPlace(a, b);
        else if (Mouse.current.rightButton.wasPressedThisFrame) TryRemove(a, b);
    }

    bool TryFindEdge(Vector3 world, out Cell a, out Cell b)
    {
        a = null; b = null;
        var gm = GridManager.Instance;
        float best = 0.3f;
        for (int x = 0; x < gm.width; x++)
        for (int y = 0; y < gm.height; y++)
        {
            var c = gm.GetCell(x, y);
            if (c == null) continue;
            foreach (var n in gm.GetNeighbors(c))
            {
                if (n.gridX < c.gridX || (n.gridX == c.gridX && n.gridY < c.gridY)) continue;
                Vector3 mid = (c.transform.position + n.transform.position) * 0.5f;
                float d = Vector2.Distance(world, mid);
                if (d < best) { best = d; a = c; b = n; }
            }
        }
        return a != null;
    }

    public static bool TouchesProtected(Cell a, Cell b)
    {
        return a.state == CellState.Protected || b.state == CellState.Protected;
    }

    void TryPlace(Cell a, Cell b)
    {
        var k = Key(a, b);
        if (walls.Contains(k) || wallBudget <= 0) return;
        if (TouchesProtected(a, b)) { FlashInvalid(a, b); return; }
        walls.Add(k);
        wallBudget--;
        var go = BuildWallObject(a, b);
        wallObjects[k] = go;
        FlashWall(go);
        OnWallPlaced?.Invoke();
    }

    void TryRemove(Cell a, Cell b)
    {
        var k = Key(a, b);
        if (!walls.Contains(k)) return;
        walls.Remove(k);
        wallBudget++;
        if (wallObjects.TryGetValue(k, out var go) && go) Destroy(go);
        wallObjects.Remove(k);
        OnWallRemoved?.Invoke();
    }

    void FlashInvalid(Cell a, Cell b)
    {
        var go = new GameObject("FlashLine");
        go.transform.SetParent(transform, false);
        Vector3 mid = (a.transform.position + b.transform.position) * 0.5f;
        Vector3 dir = (b.transform.position - a.transform.position).normalized;
        Vector3 perp = new Vector3(-dir.y, dir.x, 0) * 0.5f;
        var lr = go.AddComponent<LineRenderer>();
        lr.useWorldSpace = true; lr.startWidth = lr.endWidth = 0.18f;
        lr.material = new Material(Shader.Find("Sprites/Default"));
        lr.startColor = lr.endColor = new Color(1f, 0.25f, 0.25f, 0.85f);
        lr.numCapVertices = 4; lr.sortingOrder = 11;
        lr.SetPosition(0, mid - perp); lr.SetPosition(1, mid + perp);
        Destroy(go, 0.35f);
    }

    GameObject BuildWallObject(Cell a, Cell b)
    {
        var go = new GameObject($"Wall_{a.gridX}_{a.gridY}_{b.gridX}_{b.gridY}");
        go.transform.SetParent(transform, false);
        Vector3 mid = (a.transform.position + b.transform.position) * 0.5f;
        Vector3 dir = (b.transform.position - a.transform.position).normalized;
        Vector3 perp = new Vector3(-dir.y, dir.x, 0) * 0.5f;

        var glowGo = new GameObject("Glow");
        glowGo.transform.SetParent(go.transform, false);
        var glow = glowGo.AddComponent<LineRenderer>();
        glow.useWorldSpace = true; glow.startWidth = glow.endWidth = 0.28f;
        glow.material = new Material(Shader.Find("Sprites/Default"));
        glow.startColor = glow.endColor = new Color(0.45f, 0.75f, 1f, 0.45f);
        glow.numCapVertices = 4; glow.sortingOrder = 9;
        glow.SetPosition(0, mid - perp); glow.SetPosition(1, mid + perp);

        var lr = go.AddComponent<LineRenderer>();
        lr.useWorldSpace = true; lr.startWidth = lr.endWidth = 0.15f;
        lr.material = new Material(Shader.Find("Sprites/Default"));
        lr.startColor = lr.endColor = Color.white;
        lr.numCapVertices = 4; lr.sortingOrder = 10;
        lr.SetPosition(0, mid - perp); lr.SetPosition(1, mid + perp);
        return go;
    }

    void FlashWall(GameObject go)
    {
        if (!go) return;
        go.transform.localScale = Vector3.one * 1.3f;
        DOTween.Kill(go.transform);
        go.transform.DOScale(1f, 0.2f).SetEase(Ease.OutBack);
    }

    void UpdateGhost(bool hasEdge, Cell a, Cell b)
    {
        if (!hasEdge) { if (ghostLine) ghostLine.enabled = false; return; }
        if (ghostLine == null)
        {
            var gg = new GameObject("Ghost");
            gg.transform.SetParent(transform, false);
            ghostLine = gg.AddComponent<LineRenderer>();
            ghostLine.useWorldSpace = true; ghostLine.startWidth = ghostLine.endWidth = 0.15f;
            ghostLine.material = new Material(Shader.Find("Sprites/Default"));
            ghostLine.numCapVertices = 4; ghostLine.sortingOrder = 8;
        }
        bool invalid = TouchesProtected(a, b) || walls.Contains(Key(a, b)) || wallBudget <= 0;
        Color col = invalid ? new Color(1f, 0.3f, 0.3f, 0.4f) : new Color(1f, 1f, 1f, 0.4f);
        ghostLine.startColor = ghostLine.endColor = col;
        Vector3 mid = (a.transform.position + b.transform.position) * 0.5f;
        Vector3 dir = (b.transform.position - a.transform.position).normalized;
        Vector3 perp = new Vector3(-dir.y, dir.x, 0) * 0.5f;
        ghostLine.SetPosition(0, mid - perp); ghostLine.SetPosition(1, mid + perp);
        ghostLine.enabled = true;
    }
}
