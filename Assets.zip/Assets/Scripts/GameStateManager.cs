using System;
using System.Collections;
using UnityEngine;
using DG.Tweening;

public enum GameState { MainMenu, Playing, Paused, Win, Lose }

public class GameStateManager : MonoBehaviour
{
    public static GameStateManager Instance;
    public GameState State { get; private set; } = GameState.MainMenu;
    public event Action<GameState> OnStateChanged;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this; DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        if (InfectionSystem.Instance != null)
        {
            InfectionSystem.Instance.OnWin += HandleWin;
            InfectionSystem.Instance.OnLose += HandleLose;
        }
    }

    public void SetState(GameState s)
    {
        State = s;
        OnStateChanged?.Invoke(s);
    }

    void HandleWin()
    {
        SetState(GameState.Win);
        StartCoroutine(WinRipple());
    }

    void HandleLose()
    {
        SetState(GameState.Lose);
        StartCoroutine(CameraShake());
    }

    IEnumerator WinRipple()
    {
        var gm = GridManager.Instance;
        Cell first = null;
        foreach (var c in gm.AllCells()) if (c.state == CellState.Contained) { first = c; break; }
        if (first != null)
        {
            foreach (var c in gm.AllCells())
            {
                float d = Vector2.Distance(new Vector2(c.gridX, c.gridY), new Vector2(first.gridX, first.gridY));
                DOTween.Kill(c.transform);
                c.transform.DOPunchScale(Vector3.one * 0.2f, 0.3f).SetDelay(d * 0.08f);
            }
        }
        yield return new WaitForSeconds(0.4f);
    }

    IEnumerator CameraShake()
    {
        var cam = Camera.main;
        if (cam == null) yield break;
        Vector3 origin = cam.transform.position;
        float dur = 0.3f; int cycles = 10;
        for (int i = 0; i < cycles; i++)
        {
            cam.transform.position = origin + (Vector3)(UnityEngine.Random.insideUnitCircle * 0.1f);
            yield return new WaitForSeconds(dur / cycles);
        }
        cam.transform.position = origin;
    }

    public void ReturnToMenu()
    {
        SetState(GameState.MainMenu);
        if (GridManager.Instance != null) GridManager.Instance.Clear();
        if (WallSystem.Instance != null) WallSystem.Instance.ClearAll();
        if (InfectionSystem.Instance != null) InfectionSystem.Instance.StopRunning();
    }
}
