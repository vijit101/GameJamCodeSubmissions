using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;
    AudioSource src;

    public AudioClip sfxWallPlace, sfxWallRemove, sfxInfect, sfxWin, sfxLose, sfxTick;
    public AudioClip sfxBomb, sfxVaccine, sfxFreeze;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this; DontDestroyOnLoad(gameObject);
        src = GetComponent<AudioSource>();
        if (src == null) src = gameObject.AddComponent<AudioSource>();
    }

    void Start()
    {
        if (WallSystem.Instance != null)
        {
            WallSystem.Instance.OnWallPlaced += () => PlaySFX("wallPlace");
            WallSystem.Instance.OnWallRemoved += () => PlaySFX("wallRemove");
        }
        if (InfectionSystem.Instance != null)
        {
            InfectionSystem.Instance.OnCellInfected += _ => PlaySFX("infect");
            InfectionSystem.Instance.OnWin += () => PlaySFX("win");
            InfectionSystem.Instance.OnLose += () => PlaySFX("lose");
            InfectionSystem.Instance.OnTick += () => PlaySFX("tick");
        }
        if (PowerUpSystem.Instance != null)
        {
            PowerUpSystem.Instance.OnBombUsed += () => PlaySFX("bomb");
            PowerUpSystem.Instance.OnVaccineUsed += () => PlaySFX("vaccine");
            PowerUpSystem.Instance.OnFreezeUsed += () => PlaySFX("freeze");
        }
    }

    public void PlaySFX(string key)
    {
        AudioClip c = null;
        switch (key)
        {
            case "wallPlace":  c = sfxWallPlace; break;
            case "wallRemove": c = sfxWallRemove; break;
            case "infect":     c = sfxInfect; break;
            case "win":        c = sfxWin; break;
            case "lose":       c = sfxLose; break;
            case "tick":       c = sfxTick; break;
            case "bomb":       c = sfxBomb; break;
            case "vaccine":    c = sfxVaccine; break;
            case "freeze":     c = sfxFreeze; break;
        }
        if (c != null && src != null) src.PlayOneShot(c);
    }
}
