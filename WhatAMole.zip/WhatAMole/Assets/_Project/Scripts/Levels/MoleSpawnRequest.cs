using WhackAMole.Moles;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Data class returned by Level.GetNextSpawn() to tell the spawner
    /// which mole type to create.
    /// </summary>
    public struct MoleSpawnRequest
    {
        public MoleType MoleType;
        public bool IsPowerUp;

        public MoleSpawnRequest(MoleType moleType, bool isPowerUp = false)
        {
            MoleType = moleType;
            IsPowerUp = isPowerUp;
        }
    }
}
