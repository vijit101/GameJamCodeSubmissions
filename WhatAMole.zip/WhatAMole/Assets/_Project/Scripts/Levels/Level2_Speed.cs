using UnityEngine;
using WhackAMole.Moles;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Level 2: Speed Garden — Introduces Fast moles.
    /// </summary>
    [CreateAssetMenu(fileName = "Level2_Speed", menuName = "Whack-a-Mole/Levels/Level 2 - Speed")]
    public class Level2_Speed : Level
    {
        public override MoleSpawnRequest GetNextSpawn(float timeElapsed, int activeMoleCount)
        {
            float roll = Random.value;
            float progress = Mathf.Clamp01(timeElapsed / duration);
            float fastChance = Mathf.Lerp(0.25f, 0.45f, progress);

            if (roll < fastChance)
                return new MoleSpawnRequest(MoleType.Fast);
            return new MoleSpawnRequest(MoleType.Normal);
        }

        public override float GetSpawnInterval(float timeElapsed)
        {
            float progress = Mathf.Clamp01(timeElapsed / duration);
            return Mathf.Lerp(1.2f, 0.7f, progress);
        }
    }
}
