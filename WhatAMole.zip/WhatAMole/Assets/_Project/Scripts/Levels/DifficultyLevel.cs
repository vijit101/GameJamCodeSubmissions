using UnityEngine;
using WhackAMole.Core;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Level subclass that bridges the MoleSpawner's Level interface to the
    /// DifficultyManager's real-time DDA system. Demonstrates polymorphism:
    /// MoleSpawner calls GetNextSpawn()/GetSpawnInterval() without knowing
    /// this concrete type delegates to DifficultyManager.
    /// </summary>
    public class DifficultyLevel : Level
    {
        /// <summary>
        /// Delegates mole type selection to DifficultyManager's weighted
        /// random distribution based on current difficulty.
        /// </summary>
        public override MoleSpawnRequest GetNextSpawn(float timeElapsed, int activeMoleCount)
        {
            var dm = DifficultyManager.Instance;
            if (dm == null)
                return new MoleSpawnRequest(Moles.MoleType.Normal);

            // Respect max simultaneous moles
            if (activeMoleCount >= dm.GetMaxSimultaneousMoles())
                return new MoleSpawnRequest(Moles.MoleType.Normal) { IsPowerUp = true }; // skip spawn

            return new MoleSpawnRequest(dm.GetNextMoleType());
        }

        /// <summary>
        /// Delegates spawn interval to DifficultyManager's difficulty curve.
        /// </summary>
        public override float GetSpawnInterval(float timeElapsed)
        {
            var dm = DifficultyManager.Instance;
            return dm != null ? dm.GetSpawnInterval() : 1.5f;
        }
    }
}
