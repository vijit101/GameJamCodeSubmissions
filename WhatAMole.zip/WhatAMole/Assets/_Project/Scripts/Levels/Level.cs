using UnityEngine;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Abstract base for level definitions. ScriptableObject-backed so level
    /// designers can tune spawn rates and difficulty in the Inspector.
    ///
    /// Each level subclass overrides GetNextSpawn() to define its own mole
    /// distribution and difficulty curve. The MoleSpawner polls this polymorphically.
    /// </summary>
    public abstract class Level : ScriptableObject
    {
        [Header("Level Info")]
        public int levelNumber;
        public string displayName;
        public string description;

        [Header("Timing")]
        public float duration = 60f;
        public float baseSpawnInterval = 1.0f;

        [Header("Scoring")]
        public int scoreTarget;
        public int threeStarScore;
        public int twoStarScore;

        [Header("Visual")]
        public Sprite backgroundSprite;
        public bool useDimLighting;

        /// <summary>
        /// Polymorphic spawn rule — each level defines which mole types appear
        /// and at what probability based on elapsed time.
        /// </summary>
        public abstract MoleSpawnRequest GetNextSpawn(float timeElapsed, int activeMoleCount);

        /// <summary>
        /// Polymorphic difficulty curve — spawn interval decreases as time passes.
        /// </summary>
        public virtual float GetSpawnInterval(float timeElapsed)
        {
            // Default: linearly decrease spawn interval over time (faster spawns later)
            float progress = Mathf.Clamp01(timeElapsed / duration);
            return Mathf.Lerp(baseSpawnInterval, baseSpawnInterval * 0.5f, progress);
        }

        /// <summary>Called when level starts. Override for custom setup (e.g., Level 4 dim lighting).</summary>
        public virtual void OnLevelStart(LevelContext ctx) { }

        /// <summary>Called when level ends. Override for custom teardown.</summary>
        public virtual void OnLevelEnd(LevelContext ctx) { }

        /// <summary>Calculate star rating based on score achieved.</summary>
        public int GetStarRating(int score)
        {
            if (score >= threeStarScore) return 3;
            if (score >= twoStarScore) return 2;
            if (score >= scoreTarget) return 1;
            return 0;
        }
    }

    /// <summary>
    /// Runtime context passed to Level callbacks — provides scene access
    /// without the SO holding scene references.
    /// </summary>
    public class LevelContext
    {
        public Camera MainCamera;
        public Transform[] Holes;
    }
}
