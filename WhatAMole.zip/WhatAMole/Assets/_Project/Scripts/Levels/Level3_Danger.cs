using UnityEngine;
using WhackAMole.Moles;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Level 3: Danger Zone — Introduces Bomb and Armored moles.
    /// </summary>
    [CreateAssetMenu(fileName = "Level3_Danger", menuName = "Whack-a-Mole/Levels/Level 3 - Danger")]
    public class Level3_Danger : Level
    {
        public override MoleSpawnRequest GetNextSpawn(float timeElapsed, int activeMoleCount)
        {
            float roll = Random.value;
            float progress = Mathf.Clamp01(timeElapsed / duration);

            float bombChance = Mathf.Lerp(0.08f, 0.18f, progress);
            float armoredChance = 0.15f;
            float fastChance = 0.20f;

            if (roll < bombChance)
                return new MoleSpawnRequest(MoleType.Bomb);
            if (roll < bombChance + armoredChance)
                return new MoleSpawnRequest(MoleType.Armored);
            if (roll < bombChance + armoredChance + fastChance)
                return new MoleSpawnRequest(MoleType.Fast);
            return new MoleSpawnRequest(MoleType.Normal);
        }

        public override float GetSpawnInterval(float timeElapsed)
        {
            float progress = Mathf.Clamp01(timeElapsed / duration);
            return Mathf.Lerp(1.0f, 0.6f, progress);
        }
    }
}
