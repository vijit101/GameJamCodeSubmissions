using UnityEngine;
using WhackAMole.Moles;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Level 4: Twilight Burrow — Introduces Stealth and Golden moles.
    /// </summary>
    [CreateAssetMenu(fileName = "Level4_Twilight", menuName = "Whack-a-Mole/Levels/Level 4 - Twilight")]
    public class Level4_Twilight : Level
    {
        public override MoleSpawnRequest GetNextSpawn(float timeElapsed, int activeMoleCount)
        {
            float roll = Random.value;
            float progress = Mathf.Clamp01(timeElapsed / duration);

            float goldenChance = 0.07f;
            float stealthChance = Mathf.Lerp(0.12f, 0.25f, progress);
            float bombChance = 0.12f;
            float armoredChance = 0.10f;
            float fastChance = 0.15f;

            float cumulative = 0f;

            cumulative += goldenChance;
            if (roll < cumulative) return new MoleSpawnRequest(MoleType.Golden);

            cumulative += stealthChance;
            if (roll < cumulative) return new MoleSpawnRequest(MoleType.Stealth);

            cumulative += bombChance;
            if (roll < cumulative) return new MoleSpawnRequest(MoleType.Bomb);

            cumulative += armoredChance;
            if (roll < cumulative) return new MoleSpawnRequest(MoleType.Armored);

            cumulative += fastChance;
            if (roll < cumulative) return new MoleSpawnRequest(MoleType.Fast);

            return new MoleSpawnRequest(MoleType.Normal);
        }

        public override float GetSpawnInterval(float timeElapsed)
        {
            float progress = Mathf.Clamp01(timeElapsed / duration);
            return Mathf.Lerp(0.9f, 0.5f, progress);
        }
    }
}
