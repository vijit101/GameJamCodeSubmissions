using UnityEngine;
using WhackAMole.Moles;

namespace WhackAMole.Levels
{
    /// <summary>
    /// Level 1: Backyard Basics — Tutorial level.
    /// Normal moles only, Hammer only, generous timing.
    /// </summary>
    [CreateAssetMenu(fileName = "Level1_Backyard", menuName = "Whack-a-Mole/Levels/Level 1 - Backyard")]
    public class Level1_Backyard : Level
    {
        public override MoleSpawnRequest GetNextSpawn(float timeElapsed, int activeMoleCount)
        {
            return new MoleSpawnRequest(MoleType.Normal);
        }

        public override float GetSpawnInterval(float timeElapsed)
        {
            // Very generous: ~1.5s down to ~1s
            float progress = Mathf.Clamp01(timeElapsed / duration);
            return Mathf.Lerp(1.5f, 1.0f, progress);
        }
    }
}
