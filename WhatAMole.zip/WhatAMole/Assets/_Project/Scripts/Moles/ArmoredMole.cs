using UnityEngine;
using WhackAMole.Weapons;

namespace WhackAMole.Moles
{
    /// <summary>
    /// Armored mole — 3 HP, reduces most incoming damage to 1. Katana slashes
    /// through for 2 damage (2-shot), Bomb blasts ignore armor entirely (1-shot).
    /// Overrides: CalculateDamage, PlayHitFeedback (shows damage states).
    /// </summary>
    public class ArmoredMole : Mole
    {
        private static readonly Color[] DamageColors = new[]
        {
            new Color(0.6f, 0.6f, 0.6f), // Full armor (3 HP)
            new Color(0.8f, 0.6f, 0.4f), // Cracked (2 HP)
            new Color(1f, 0.4f, 0.3f),   // Nearly broken (1 HP)
        };

        public override MoleType Type => MoleType.Armored;
        public override bool IsPositiveScore => true;

        public override int GetScoreValue()
        {
            return data.scoreValue; // 30
        }

        /// <summary>
        /// Armor caps most damage to 1, but certain weapons cut straight through:
        ///   • Bomb blast ignores armor entirely (one-shot via weapon.BaseDamage).
        ///   • Katana slashes for 2 damage per hit — 3HP armored dies in two.
        /// Demonstrates polymorphic damage calculation based on the incoming weapon.
        /// </summary>
        protected override int CalculateDamage(Weapon weapon)
        {
            if (weapon is BombWeapon) return weapon.BaseDamage;
            if (weapon is KatanaWeapon) return 2;
            return 1;
        }

        protected override void OnSpawned()
        {
            UpdateArmorVisual();
        }

        protected override void PlayHitFeedback(Vector2 hitPoint)
        {
            base.PlayHitFeedback(hitPoint);
            UpdateArmorVisual();
        }

        private void UpdateArmorVisual()
        {
            if (spriteRenderer != null && currentHitPoints > 0)
            {
                int index = Mathf.Clamp(data.maxHitPoints - currentHitPoints, 0, DamageColors.Length - 1);
                spriteRenderer.color = DamageColors[index];
            }
        }
    }
}
