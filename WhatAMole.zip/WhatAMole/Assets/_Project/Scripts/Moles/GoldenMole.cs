using UnityEngine;
using WhackAMole.Core;

namespace WhackAMole.Moles
{
    /// <summary>
    /// Golden mole — rare (5% spawn rate), very short window (0.8s),
    /// high score (50 pts). On death it also restores half of the currently-
    /// stolen carrots (chosen at random), as a reward for catching it in time.
    /// Golden particles on hit, shining idle effect.
    /// Overrides: OnSpawned (idle particles), OnDefeated (carrot bonus).
    /// </summary>
    public class GoldenMole : Mole
    {
        private GameObject _idleParticles;

        public override MoleType Type => MoleType.Golden;
        public override bool IsPositiveScore => true;

        public override int GetScoreValue()
        {
            return data.scoreValue; // 50
        }

        protected override void OnSpawned()
        {
            // Start idle golden shimmer
            if (data.idleParticlePrefab != null)
            {
                _idleParticles = Instantiate(data.idleParticlePrefab, transform);
                _idleParticles.transform.localPosition = Vector3.zero;
            }
        }

        protected override void OnDefeated()
        {
            CleanupIdleParticles();

            // Bonus: bring back half of whatever carrots have been stolen so far.
            if (CarrotManager.Instance != null)
                CarrotManager.Instance.RestoreRandomHalfStolen();
        }

        public override void Despawn()
        {
            CleanupIdleParticles();
            base.Despawn();
        }

        private void CleanupIdleParticles()
        {
            if (_idleParticles != null)
            {
                Destroy(_idleParticles);
                _idleParticles = null;
            }
        }
    }
}
