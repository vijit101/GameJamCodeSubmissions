namespace WhackAMole.Moles
{
    /// <summary>
    /// The basic mole. No special behavior — pure base class implementation.
    /// Brown sprite, 1 HP, 10 points, 1.5s visible.
    /// </summary>
    public class NormalMole : Mole
    {
        public override MoleType Type => MoleType.Normal;
        public override bool IsPositiveScore => true;

        public override int GetScoreValue()
        {
            return data.scoreValue; // 10
        }
    }
}
