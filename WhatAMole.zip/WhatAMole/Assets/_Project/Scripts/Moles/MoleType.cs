namespace WhackAMole.Moles
{
    public enum MoleType
    {
        Normal,
        Fast,
        Armored,
        Golden,
        Bomb,
        Stealth,
        Splitter
    }
}
