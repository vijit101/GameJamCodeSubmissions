using System.Collections;
using UnityEngine;

namespace WhackAMole.Moles
{
    /// <summary>
    /// Stealth mole — semi-transparent (alpha 0.3), flickers between visible
    /// and near-invisible. Hard to spot, worth 40 points.
    /// Overrides: OnSpawned (sets low alpha), has a flicker coroutine.
    /// </summary>
    public class StealthMole : Mole
    {
        private const float LOW_ALPHA = 0.15f;
        private const float HIGH_ALPHA = 0.5f;
        private const float FLICKER_INTERVAL = 0.3f;

        private Coroutine _flickerCoroutine;

        public override MoleType Type => MoleType.Stealth;
        public override bool IsPositiveScore => true;

        public override int GetScoreValue()
        {
            return data.scoreValue; // 40
        }

        protected override void OnSpawned()
        {
            SetAlpha(LOW_ALPHA);
            _flickerCoroutine = StartCoroutine(FlickerRoutine());
        }

        protected override void OnDefeated()
        {
            StopFlicker();
            SetAlpha(1f);
        }

        public override void Despawn()
        {
            StopFlicker();
            base.Despawn();
        }

        private IEnumerator FlickerRoutine()
        {
            bool isHigh = false;
            while (IsAlive)
            {
                isHigh = !isHigh;
                SetAlpha(isHigh ? HIGH_ALPHA : LOW_ALPHA);
                yield return new WaitForSeconds(FLICKER_INTERVAL);
            }
        }

        private void SetAlpha(float alpha)
        {
            if (spriteRenderer != null)
            {
                var color = spriteRenderer.color;
                color.a = alpha;
                spriteRenderer.color = color;
            }
        }

        private void StopFlicker()
        {
            if (_flickerCoroutine != null)
            {
                StopCoroutine(_flickerCoroutine);
                _flickerCoroutine = null;
            }
        }
    }
}
