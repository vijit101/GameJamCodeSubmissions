using UnityEngine;

namespace WhackAMole.Moles
{
    /// <summary>
    /// ScriptableObject holding per-mole-type configuration.
    /// One asset per mole type — tunable in the Inspector without code changes.
    /// </summary>
    [CreateAssetMenu(fileName = "New MoleData", menuName = "Whack-a-Mole/Mole Data")]
    public class MoleData : ScriptableObject
    {
        [Header("Identity")]
        public string moleName = "Mole";
        public Sprite sprite;
        public Color tintColor = Color.white;

        [Header("Stats")]
        public int maxHitPoints = 1;
        public int scoreValue = 10;
        public float visibleTime = 1.5f;

        [Header("Animation")]
        public float popUpDuration = 0.2f;
        public float hideDuration = 0.15f;
        public float popUpHeight = 1.0f;

        [Header("Audio")]
        public AudioClip hitSound;
        public AudioClip spawnSound;
        public AudioClip deathSound;

        [Header("VFX")]
        public GameObject hitParticlePrefab;
        public GameObject deathParticlePrefab;
        public GameObject idleParticlePrefab;
    }
}
