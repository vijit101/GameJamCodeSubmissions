using System.Collections;
using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Weapons;

namespace WhackAMole.Moles
{
    /// <summary>
    /// Bomb mole — hitting it PENALIZES the player. Score is negative (-25).
    /// Triggers heavy screen shake and distinct red/black visuals.
    /// The only mole where IsPositiveScore = false.
    /// Overrides: OnHit (fires BombHit event for camera shake).
    /// </summary>
    public class BombMole : Mole
    {
        public override MoleType Type => MoleType.Bomb;
        public override bool IsPositiveScore => false;

        public override int GetScoreValue()
        {
            return -Mathf.Abs(data.scoreValue); // Ensure negative (-25)
        }

        public override void OnHit(Weapon weapon, Vector2 hitPoint)
        {
            if (!IsAlive || isHiding) return;

            currentHitPoints = 0;

            // Fire bomb-specific event for heavy screen shake
            EventBus.FireBombHit(hitPoint);

            // Bomb explosion destroys the carrot in this hole
            if (currentHole != null && currentHole.HasCarrot)
                currentHole.StealCarrot();

            PlayHitFeedback(hitPoint);
            ScoreManager.Instance.AddScore(GetScoreValue());
            EventBus.FireMoleHit(hitPoint, GetScoreValue());
            OnDefeated();
            Despawn();
        }

        /// <summary>
        /// Bomb moles do NOT steal carrots when they hide — only destroy on hit.
        /// </summary>
        protected override IEnumerator LifetimeRoutine()
        {
            yield return new WaitForSeconds(data.visibleTime);

            if (IsAlive)
            {
                isHiding = true;
                EventBus.FireMoleMissed();
                Despawn();
            }
        }

        protected override void PlayHitFeedback(Vector2 hitPoint)
        {
            // Bomb uses its own explosion particles (configured in MoleData)
            if (data.deathParticlePrefab != null)
            {
                Instantiate(data.deathParticlePrefab, hitPoint, Quaternion.identity);
            }

            if (data.hitSound != null)
            {
                AudioManager.Instance.PlaySFX(data.hitSound);
            }
        }
    }
}
