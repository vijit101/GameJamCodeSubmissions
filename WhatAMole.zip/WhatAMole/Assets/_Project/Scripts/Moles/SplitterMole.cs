using System.Collections.Generic;
using UnityEngine;
using WhackAMole.Spawning;

namespace WhackAMole.Moles
{
    /// <summary>
    /// Splitter mole — both outcomes hurt:
    ///   • Defeated → spawns <see cref="childrenToSpawn"/> NormalMoles in adjacent holes.
    ///   • Missed → the base steal plus <see cref="extraCarrotsOnMiss"/> random carrots disappear.
    /// </summary>
    public class SplitterMole : Mole
    {
        [Header("Splitter Config")]
        [SerializeField] private int childrenToSpawn = 2;
        [SerializeField] private int extraCarrotsOnMiss = 2;

        public override MoleType Type => MoleType.Splitter;
        public override bool IsPositiveScore => true;

        public override int GetScoreValue()
        {
            return data.scoreValue; // 15
        }

        /// <summary>On defeat, spawn NormalMoles in adjacent free holes.</summary>
        protected override void OnDefeated()
        {
            if (currentHole == null) return;

            var spawner = FindAnyObjectByType<MoleSpawner>();
            if (spawner == null) return;

            for (int i = 0; i < childrenToSpawn; i++)
            {
                Hole freeHole = spawner.GetFreeAdjacentHole(currentHole);
                if (freeHole != null)
                    MoleFactory.Instance.Spawn(MoleType.Normal, freeHole);
            }
        }

        /// <summary>
        /// On miss, steal extra random carrots on top of the base steal.
        /// Each removal goes through <see cref="Hole.StealCarrot"/> so the regen
        /// queue and game-over check run exactly as for a normal steal.
        /// </summary>
        protected override void OnMissed()
        {
            var spawner = FindAnyObjectByType<MoleSpawner>();
            if (spawner == null || spawner.Holes == null) return;

            var candidates = new List<Hole>();
            foreach (var h in spawner.Holes)
            {
                if (h != null && h != currentHole && h.HasCarrot)
                    candidates.Add(h);
            }

            int toSteal = Mathf.Min(extraCarrotsOnMiss, candidates.Count);
            for (int i = 0; i < toSteal; i++)
            {
                int pick = Random.Range(0, candidates.Count);
                candidates[pick].StealCarrot();
                candidates.RemoveAt(pick);
            }
        }
    }
}
