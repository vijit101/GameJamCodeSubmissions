using System.Collections;
using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Interfaces;
using WhackAMole.Spawning;
using WhackAMole.Weapons;

namespace WhackAMole.Moles
{
    /// <summary>
    /// Abstract base class for all mole types. Full lifecycle with fluid animations:
    /// Spawn (pop up with bounce) → Idle (gentle bob) → Hit (squash + flash) →
    /// Death (spin + shrink + slide down) → Despawn
    /// </summary>
    public abstract class Mole : MonoBehaviour, IHittable, IScoreProvider, ISpawnable
    {
        [Header("Base Mole Config")]
        [SerializeField] protected MoleData data;

        protected Hole currentHole;
        protected int currentHitPoints;
        protected bool isFrozen;
        protected bool isHiding;
        private Coroutine _lifetimeCoroutine;
        private Coroutine _idleCoroutine;

        protected SpriteRenderer spriteRenderer;

        public bool IsAlive => currentHitPoints > 0;
        public MoleData Data => data;
        public Hole CurrentHole => currentHole;
        public abstract MoleType Type { get; }

        protected virtual void Awake()
        {
            spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        }

        // ─── SPAWN ───

        public virtual void Spawn(Hole hole)
        {
            currentHole = hole;
            currentHole.SetOccupied(true);
            currentHitPoints = data.maxHitPoints;
            isFrozen = false;
            isHiding = false;

            transform.position = hole.SpawnPoint.position;
            transform.localRotation = Quaternion.identity;

            if (spriteRenderer != null)
            {
                if (data.sprite != null) spriteRenderer.sprite = data.sprite;
                spriteRenderer.color = data.tintColor;
            }

            gameObject.SetActive(true);
            StopAllCoroutines();
            StartCoroutine(PopUpAnimation());
            OnSpawned();
            _lifetimeCoroutine = StartCoroutine(LifetimeRoutine());
        }

        public virtual void Despawn()
        {
            StopAllCoroutines();
            _lifetimeCoroutine = null;
            _idleCoroutine = null;

            if (currentHole != null)
            {
                currentHole.SetOccupied(false);
                currentHole = null;
            }

            transform.localScale = Vector3.one;
            transform.localRotation = Quaternion.identity;
            gameObject.SetActive(false);

            if (MoleFactory.Instance != null)
                MoleFactory.Instance.Return(this);
        }

        // ─── HIT ───

        public virtual void OnHit(Weapon weapon, Vector2 hitPoint)
        {
            if (!IsAlive || isHiding) return;

            int damage = CalculateDamage(weapon);
            currentHitPoints -= damage;

            if (!IsAlive)
            {
                // Kill — play death animation then despawn
                int score = GetScoreValue();
                ScoreManager.Instance.AddScore(score);
                EventBus.FireMoleHit(hitPoint, score);
                if (IsPositiveScore) EventBus.FireMoleKilled(Type);
                OnDefeated();
                StopAllCoroutines();
                StartCoroutine(DeathAnimation());
            }
            else
            {
                // Still alive — play hit feedback (squash)
                StartCoroutine(HitSquashAnimation());
                PlayHitFeedback(hitPoint);
            }
        }

        // ─── ABSTRACT ───

        public abstract int GetScoreValue();
        public abstract bool IsPositiveScore { get; }

        // ─── VIRTUAL HOOKS ───

        protected virtual int CalculateDamage(Weapon weapon) => weapon.BaseDamage;
        protected virtual void OnSpawned() { }
        protected virtual void OnDefeated() { }

        protected virtual void PlayHitFeedback(Vector2 hitPoint)
        {
            if (data.hitSound != null)
                AudioManager.Instance.PlaySFX(data.hitSound);
        }

        // ─── ANIMATIONS ───

        /// <summary>Pop up from hole with overshoot bounce.</summary>
        private IEnumerator PopUpAnimation()
        {
            float dur = data.popUpDuration > 0 ? data.popUpDuration : 0.25f;
            Vector3 startPos = transform.position - Vector3.up * 0.8f;
            Vector3 endPos = transform.position;

            transform.position = startPos;
            transform.localScale = new Vector3(0.6f, 0.4f, 1f); // Start squashed

            float elapsed = 0f;
            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / dur);

                // OutBack ease for bounce
                float overshoot = 1.70158f;
                float t1 = t - 1f;
                float eased = t1 * t1 * ((overshoot + 1f) * t1 + overshoot) + 1f;

                transform.position = Vector3.LerpUnclamped(startPos, endPos, eased);

                // Scale: squashed → stretched → normal
                float scaleX, scaleY;
                if (t < 0.4f)
                {
                    float st = t / 0.4f;
                    scaleX = Mathf.Lerp(0.6f, 0.85f, st);
                    scaleY = Mathf.Lerp(0.4f, 1.15f, st);
                }
                else
                {
                    float st = (t - 0.4f) / 0.6f;
                    scaleX = Mathf.Lerp(0.85f, 1f, st);
                    scaleY = Mathf.Lerp(1.15f, 1f, st);
                }
                transform.localScale = new Vector3(scaleX, scaleY, 1f);
                yield return null;
            }

            transform.position = endPos;
            transform.localScale = Vector3.one;

            // Start idle bob
            _idleCoroutine = StartCoroutine(IdleBobAnimation());
        }

        /// <summary>Gentle idle bobbing while waiting to be hit.</summary>
        private IEnumerator IdleBobAnimation()
        {
            Vector3 basePos = transform.position;
            float bobSpeed = 2f;
            float bobAmount = 0.04f;

            while (true)
            {
                float bob = Mathf.Sin(Time.time * bobSpeed) * bobAmount;
                transform.position = basePos + Vector3.up * bob;

                // Subtle breathing scale
                float breathe = 1f + Mathf.Sin(Time.time * 1.5f) * 0.02f;
                transform.localScale = new Vector3(breathe, breathe, 1f);

                yield return null;
            }
        }

        /// <summary>Quick squash-stretch on hit (still alive).</summary>
        private IEnumerator HitSquashAnimation()
        {
            float dur = 0.15f;
            float elapsed = 0f;

            // Flash white
            if (spriteRenderer != null)
                spriteRenderer.color = Color.white;

            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / dur;

                // Squash then recover
                float squash;
                if (t < 0.3f)
                {
                    squash = Mathf.Lerp(1f, 0.6f, t / 0.3f);
                }
                else
                {
                    squash = Mathf.Lerp(0.6f, 1f, (t - 0.3f) / 0.7f);
                }

                transform.localScale = new Vector3(2f - squash, squash, 1f);
                yield return null;
            }

            transform.localScale = Vector3.one;

            // Restore color
            if (spriteRenderer != null)
                spriteRenderer.color = data.tintColor;
        }

        /// <summary>Death animation — flash, squash flat, spin, shrink, slide into hole.</summary>
        private IEnumerator DeathAnimation()
        {
            isHiding = true;
            float dur = 0.4f;
            float elapsed = 0f;

            Vector3 startPos = transform.position;
            Vector3 endPos = startPos - Vector3.up * 0.6f; // Slide down into hole

            // Flash white on death
            if (spriteRenderer != null)
                spriteRenderer.color = Color.white;

            yield return new WaitForSeconds(0.05f);

            if (spriteRenderer != null)
                spriteRenderer.color = data.tintColor;

            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / dur);

                // InBack ease — accelerates into hole
                float t1 = t;
                float eased = t1 * t1 * (2.70158f * t1 - 1.70158f);
                eased = Mathf.Clamp01(eased);

                // Slide down
                transform.position = Vector3.Lerp(startPos, endPos, eased);

                // Shrink + squash flat
                float scale = Mathf.Lerp(1f, 0f, t);
                float squashX = Mathf.Lerp(1f, 1.5f, t); // Widen as it flattens
                float squashY = Mathf.Lerp(1f, 0.1f, t); // Flatten
                transform.localScale = new Vector3(squashX * scale, squashY * scale, 1f);

                // Slight rotation
                float rot = Mathf.Lerp(0f, 15f, t);
                transform.localRotation = Quaternion.Euler(0, 0, rot);

                // Fade out in last 30%
                if (t > 0.7f && spriteRenderer != null)
                {
                    float alpha = Mathf.Lerp(1f, 0f, (t - 0.7f) / 0.3f);
                    var c = spriteRenderer.color;
                    c.a = alpha;
                    spriteRenderer.color = c;
                }

                yield return null;
            }

            // Reset visual state before pooling
            if (spriteRenderer != null)
            {
                var c = spriteRenderer.color;
                c.a = 1f;
                spriteRenderer.color = c;
            }

            Despawn();
        }

        /// <summary>Hide animation — sink back into hole when time runs out.</summary>
        private IEnumerator HideAnimation()
        {
            float dur = data.hideDuration > 0 ? data.hideDuration : 0.2f;
            float elapsed = 0f;
            Vector3 startPos = transform.position;
            Vector3 endPos = startPos - Vector3.up * 0.8f;

            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / dur);

                // Smooth ease in
                float eased = t * t;
                transform.position = Vector3.Lerp(startPos, endPos, eased);

                // Slight squash as it goes down
                float scaleY = Mathf.Lerp(1f, 0.5f, eased);
                transform.localScale = new Vector3(1f, scaleY, 1f);

                yield return null;
            }
        }

        // ─── FREEZE ───

        public virtual void Freeze(float duration)
        {
            if (!IsAlive) return;
            isFrozen = true;
            StopAllCoroutines();
            StartCoroutine(FreezeRoutine(duration));
        }

        private IEnumerator FreezeRoutine(float duration)
        {
            if (spriteRenderer != null)
                spriteRenderer.color = new Color(0.5f, 0.8f, 1f, 1f);

            yield return new WaitForSeconds(duration);

            isFrozen = false;
            if (spriteRenderer != null)
                spriteRenderer.color = data.tintColor;

            _lifetimeCoroutine = StartCoroutine(LifetimeRoutine());
        }

        // ─── LIFETIME ───

        protected virtual IEnumerator LifetimeRoutine()
        {
            yield return new WaitForSeconds(data.visibleTime);

            if (IsAlive)
            {
                isHiding = true;
                if (_idleCoroutine != null) { StopCoroutine(_idleCoroutine); _idleCoroutine = null; }
                yield return StartCoroutine(HideAnimation());

                // Steal the carrot from this hole if it still has one
                if (currentHole != null && currentHole.HasCarrot)
                    currentHole.StealCarrot();

                EventBus.FireMoleMissed();
                OnMissed();
                Despawn();
            }
        }

        /// <summary>
        /// Hook called after the base miss flow (carrot stolen, FireMoleMissed)
        /// and before Despawn. Subclasses override to add extra consequences.
        /// </summary>
        protected virtual void OnMissed() { }
    }
}
