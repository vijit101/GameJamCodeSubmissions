namespace WhackAMole.Moles
{
    /// <summary>
    /// Fast mole — short visible time (0.6s), worth 20 points.
    /// Speed is driven by MoleData.visibleTime, no animation override needed.
    /// </summary>
    public class FastMole : Mole
    {
        public override MoleType Type => MoleType.Fast;
        public override bool IsPositiveScore => true;

        public override int GetScoreValue()
        {
            return data.scoreValue;
        }
    }
}
