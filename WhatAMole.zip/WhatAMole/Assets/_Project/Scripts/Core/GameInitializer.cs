using System.Collections;
using UnityEngine;

namespace WhackAMole.Core
{
    /// <summary>
    /// Placed in the Game scene to kick off level 1 when the scene loads.
    /// Handles both flows: coming from MainMenu AND pressing Play directly in Game scene.
    /// Uses a coroutine to ensure all Awake/Start calls have completed.
    /// </summary>
    public class GameInitializer : MonoBehaviour
    {
        private IEnumerator Start()
        {
            // Wait one frame so all Awake() and other Start() methods have run
            yield return null;

            if (GameManager.Instance == null)
            {
                Debug.LogError("GameInitializer: GameManager not found!");
                yield break;
            }

            // If we arrived from MainMenu, state is already Playing
            // If we pressed Play directly in the Game scene, force-start the game
            if (GameManager.Instance.CurrentState != GameState.Playing)
            {
                Debug.Log("GameInitializer: Direct play detected, starting game.");
                ScoreManager.Instance.ResetScore();
                GameManager.Instance.SetState(GameState.Playing);
            }

            if (LevelManager.Instance == null)
            {
                Debug.LogError("GameInitializer: LevelManager not found!");
                yield break;
            }

            if (DifficultyManager.Instance == null)
            {
                Debug.LogError("GameInitializer: DifficultyManager not found!");
                yield break;
            }

            Debug.Log("GameInitializer: Starting endless game.");
            LevelManager.Instance.StartGame();
        }
    }
}
