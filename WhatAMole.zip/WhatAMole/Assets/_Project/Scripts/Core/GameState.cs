namespace WhackAMole.Core
{
    public enum GameState
    {
        MainMenu,
        Playing,
        Paused,
        LevelComplete,
        GameOver,
        Victory
    }
}
