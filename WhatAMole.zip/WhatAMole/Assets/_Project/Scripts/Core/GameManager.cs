using UnityEngine;
using UnityEngine.SceneManagement;
using WhackAMole.Utils;

namespace WhackAMole.Core
{
    /// <summary>
    /// Central game state machine. Drives scene flow and exposes state changes
    /// via EventBus so other systems react without tight coupling.
    /// </summary>
    public class GameManager : Singleton<GameManager>
    {
        [Header("Config")]
        [SerializeField] private bool debugMode;

        private GameState _currentState = GameState.MainMenu;
        public GameState CurrentState => _currentState;

        public void SetState(GameState newState)
        {
            if (_currentState == newState) return;

            _currentState = newState;
            EventBus.FireGameStateChanged(newState);

            switch (newState)
            {
                case GameState.Playing:
                    Time.timeScale = 1f;
                    break;
                case GameState.Paused:
                    Time.timeScale = 0f;
                    break;
                case GameState.GameOver:
                    Time.timeScale = 1f;
                    break;
            }
        }

        public void StartGame()
        {
            ScoreManager.Instance.ResetScore();
            SetState(GameState.Playing);
            SceneManager.LoadScene(Constants.SCENE_GAME);
        }

        public void PauseGame()
        {
            if (_currentState == GameState.Playing)
                SetState(GameState.Paused);
        }

        public void ResumeGame()
        {
            if (_currentState == GameState.Paused)
                SetState(GameState.Playing);
        }

        public void TriggerGameOver()
        {
            EventBus.FireGameOver(ScoreManager.Instance.CurrentScore);
            SetState(GameState.GameOver);
        }

        public void ReturnToMainMenu()
        {
            Time.timeScale = 1f;
            EventBus.ClearAll();
            SetState(GameState.MainMenu);
            SceneManager.LoadScene(Constants.SCENE_MAIN_MENU);
        }

        public void RestartGame()
        {
            Time.timeScale = 1f;
            EventBus.ClearAll();
            ScoreManager.Instance.ResetScore();
            SetState(GameState.Playing);
            SceneManager.LoadScene(Constants.SCENE_GAME);
        }
    }
}
