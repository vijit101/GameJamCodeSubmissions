using UnityEngine;
using WhackAMole.Moles;
using WhackAMole.Utils;

namespace WhackAMole.Core
{
    /// <summary>
    /// Manages music and SFX playback. Uses a pool of AudioSources
    /// for concurrent SFX playback (critical for rapid whacking).
    /// Clips are loaded from Resources/Audio at startup. The singleton
    /// bootstraps itself before the first scene loads so MainMenu can
    /// kick off background music on Play click, and persists into the
    /// Game scene via DontDestroyOnLoad.
    /// </summary>
    public class AudioManager : Singleton<AudioManager>
    {
        [Header("Audio Sources")]
        [SerializeField] private AudioSource musicSource;
        [SerializeField] private AudioSource[] sfxSources;

        private int _nextSfxIndex;
        private float _musicVolume;
        private float _sfxVolume;

        private AudioClip _backgroundMusic;
        private AudioClip _moleKilledSfx;
        private AudioClip _gameOverSfx;

        // Ensure the singleton exists before any scene loads so music
        // starts on the main menu without needing an in-scene AudioManager.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Bootstrap() { _ = Instance; }

        protected override void Awake()
        {
            base.Awake();

            // The duplicate-destroy path in Singleton.Awake leaves this
            // instance's GameObject marked for destruction; skip init so
            // we don't touch AudioSources that are about to vanish.
            if (Instance != this) return;

            _musicVolume = PlayerPrefs.GetFloat(Constants.PREF_MUSIC_VOLUME, Constants.MUSIC_NORMAL_VOLUME);
            _sfxVolume = PlayerPrefs.GetFloat(Constants.PREF_SFX_VOLUME, 1f);

            if (musicSource == null)
            {
                musicSource = gameObject.AddComponent<AudioSource>();
                musicSource.loop = true;
                musicSource.playOnAwake = false;
            }

            if (sfxSources == null || sfxSources.Length == 0)
            {
                sfxSources = new AudioSource[Constants.SFX_POOL_SIZE];
                for (int i = 0; i < sfxSources.Length; i++)
                {
                    sfxSources[i] = gameObject.AddComponent<AudioSource>();
                    sfxSources[i].playOnAwake = false;
                }
            }

            _backgroundMusic = Resources.Load<AudioClip>("Audio/cid_theme_tone");
            _moleKilledSfx   = Resources.Load<AudioClip>("Audio/ghop_ghop");
            _gameOverSfx     = Resources.Load<AudioClip>("Audio/scream_chicken_tree");

            ApplyVolumes();
        }

        private void OnEnable()
        {
            if (Instance != this) return;
            EventBus.OnMoleKilled += HandleMoleKilled;
            EventBus.OnGameOver   += HandleGameOver;
        }

        private void OnDisable()
        {
            EventBus.OnMoleKilled -= HandleMoleKilled;
            EventBus.OnGameOver   -= HandleGameOver;
        }

        /// <summary>
        /// Starts the looped background music at a reduced volume so
        /// gameplay SFX (like the mole-kill thump) stay prominent.
        /// Called from MainMenuUI when the player clicks Play.
        /// </summary>
        public void StartBackgroundMusic()
        {
            PlayMusic(_backgroundMusic);
            if (musicSource != null)
                musicSource.volume = _musicVolume * BGM_SFX_DUCK_RATIO;
        }

        // BGM is quiet relative to SFX so kills punch through without
        // needing the clips to have identical mastering levels.
        private const float BGM_SFX_DUCK_RATIO = 0.35f;

        private void HandleMoleKilled(MoleType _) => PlaySFX(_moleKilledSfx);

        private void HandleGameOver(int _)
        {
            if (musicSource != null) musicSource.Pause();
            PlaySFX(_gameOverSfx);
        }

        public void PlaySFX(AudioClip clip, float volumeScale = 1f)
        {
            if (clip == null) return;

            var source = sfxSources[_nextSfxIndex];
            source.clip = clip;
            source.volume = _sfxVolume * volumeScale;
            source.Play();

            _nextSfxIndex = (_nextSfxIndex + 1) % sfxSources.Length;
        }

        public void PlayMusic(AudioClip clip)
        {
            if (clip == null) return;

            musicSource.clip = clip;
            musicSource.volume = _musicVolume;
            musicSource.Play();
        }

        public void StopMusic()
        {
            musicSource.Stop();
        }

        public void DuckMusic(bool duck)
        {
            musicSource.volume = duck ? Constants.MUSIC_DUCK_VOLUME : _musicVolume;
        }

        public void SetMusicVolume(float volume)
        {
            _musicVolume = Mathf.Clamp01(volume);
            musicSource.volume = _musicVolume;
            PlayerPrefs.SetFloat(Constants.PREF_MUSIC_VOLUME, _musicVolume);
        }

        public void SetSFXVolume(float volume)
        {
            _sfxVolume = Mathf.Clamp01(volume);
            PlayerPrefs.SetFloat(Constants.PREF_SFX_VOLUME, _sfxVolume);
        }

        private void ApplyVolumes()
        {
            musicSource.volume = _musicVolume;
        }
    }
}
