using UnityEngine;
using WhackAMole.Utils;

namespace WhackAMole.Core
{
    /// <summary>
    /// Manages score, combo multiplier, and high score persistence.
    /// Combo system: hits within COMBO_WINDOW increase multiplier up to 4x.
    /// </summary>
    public class ScoreManager : Singleton<ScoreManager>
    {
        private int _currentScore;
        private int _comboCount;
        private int _multiplier = 1;
        private float _lastHitTime;
        private bool _shieldActive;

        public int CurrentScore => _currentScore;
        public int ComboCount => _comboCount;
        public int Multiplier => _multiplier;

        public int HighScore
        {
            get => PlayerPrefs.GetInt(Constants.PREF_HIGH_SCORE, 0);
            private set
            {
                PlayerPrefs.SetInt(Constants.PREF_HIGH_SCORE, value);
                PlayerPrefs.Save();
            }
        }

        public bool ShieldActive
        {
            get => _shieldActive;
            set => _shieldActive = value;
        }

        public void AddScore(int baseScore)
        {
            float timeSinceLastHit = Time.time - _lastHitTime;
            _lastHitTime = Time.time;

            if (baseScore > 0)
            {
                // Combo logic: hits within the combo window increase multiplier
                if (timeSinceLastHit <= Constants.COMBO_WINDOW_SECONDS)
                {
                    _comboCount++;
                    _multiplier = Mathf.Min(1 + (_comboCount / 3), Constants.MAX_COMBO_MULTIPLIER);
                }
                else
                {
                    _comboCount = 0;
                    _multiplier = 1;
                }

                int finalScore = baseScore * _multiplier;
                _currentScore += finalScore;

                EventBus.FireComboChanged(_comboCount);
            }
            else
            {
                // Negative score (BombMole) — shield can negate it
                if (_shieldActive)
                {
                    _shieldActive = false;
                    return;
                }

                _currentScore += baseScore; // baseScore is already negative
                _comboCount = 0;
                _multiplier = 1;
                EventBus.FireComboChanged(0);
            }

            _currentScore = Mathf.Max(0, _currentScore);
            EventBus.FireScoreChanged(_currentScore, _multiplier);

            // Check high score
            if (_currentScore > HighScore)
            {
                HighScore = _currentScore;
                EventBus.FireHighScoreBeaten(_currentScore);
            }
        }

        public void ResetScore()
        {
            _currentScore = 0;
            _comboCount = 0;
            _multiplier = 1;
            _shieldActive = false;
            _lastHitTime = 0f;
            EventBus.FireScoreChanged(0, 1);
            EventBus.FireComboChanged(0);
        }
    }
}
