using UnityEngine;
using WhackAMole.Levels;
using WhackAMole.Spawning;

namespace WhackAMole.Core
{
    /// <summary>
    /// Simplified manager for endless DDA-driven gameplay.
    /// Uses a single DifficultyLevel that delegates spawn decisions
    /// to DifficultyManager in real time.
    /// </summary>
    public class LevelManager : MonoBehaviour
    {
        [SerializeField] private MoleSpawner moleSpawner;

        private DifficultyLevel _difficultyLevel;

        private static LevelManager _instance;
        public static LevelManager Instance => _instance;

        public Level CurrentLevel => _difficultyLevel;

        private void Awake()
        {
            _instance = this;

            // Try to load from Resources first, otherwise create at runtime
            _difficultyLevel = Resources.Load<DifficultyLevel>("Levels/DifficultyLevel");
            if (_difficultyLevel == null)
            {
                _difficultyLevel = ScriptableObject.CreateInstance<DifficultyLevel>();
                _difficultyLevel.levelNumber = 0;
                _difficultyLevel.displayName = "Endless";
                _difficultyLevel.duration = float.MaxValue;
                _difficultyLevel.baseSpawnInterval = 1.5f;
            }

            if (moleSpawner == null)
                moleSpawner = FindAnyObjectByType<MoleSpawner>();
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        /// <summary>
        /// Start endless gameplay. Resets difficulty and score, begins spawning.
        /// </summary>
        public void StartGame()
        {
            if (moleSpawner == null) moleSpawner = FindAnyObjectByType<MoleSpawner>();

            if (DifficultyManager.Instance != null)
                DifficultyManager.Instance.ResetDifficulty();

            ScoreManager.Instance.ResetScore();

            if (CarrotManager.Instance != null)
                CarrotManager.Instance.ResetCarrots();

            if (MoleFactory.Instance != null) MoleFactory.Instance.ReturnAll();
            if (moleSpawner != null)
            {
                moleSpawner.StopSpawning();
                moleSpawner.StartSpawning(_difficultyLevel);
            }

            EventBus.FireLevelStarted(0);
        }

        /// <summary>
        /// Restart from scratch — reset everything and start again.
        /// </summary>
        public void RestartGame()
        {
            StartGame();
        }
    }
}
