using System;
using UnityEngine;
using WhackAMole.Moles;

namespace WhackAMole.Core
{
    /// <summary>
    /// Static event bus for decoupled cross-system communication.
    /// Systems subscribe to events without referencing each other directly.
    /// </summary>
    public static class EventBus
    {
        // Game state
        public static event Action<GameState> OnGameStateChanged;
        public static event Action<int> OnLevelStarted;       // levelNumber
        public static event Action<int, int> OnLevelComplete;  // levelNumber, score
        public static event Action<int> OnGameOver;            // finalScore

        // Mole events
        public static event Action<Vector2, int> OnMoleHit;    // hitPoint, scoreValue
        public static event Action<MoleType> OnMoleKilled; // fires after a successful kill (positive-score moles)
        public static event Action OnMoleMissed;
        public static event Action<Vector2> OnBombHit;         // hitPoint (for screen shake)

        // Score events
        public static event Action<int, int> OnScoreChanged;   // newScore, multiplier
        public static event Action<int> OnComboChanged;        // comboCount
        public static event Action<int> OnHighScoreBeaten;     // newHighScore

        // Weapon events
        public static event Action<Vector2> OnWeaponSwung;     // worldPosition

        // Difficulty events
        public static event Action<float> OnDifficultyChanged;   // difficulty value (0.0–1.5)

        // Carrot events
        public static event Action<int> OnCarrotStolen;          // holeIndex
        public static event Action<int> OnCarrotRegenerated;     // holeIndex

        // Power-up events
        public static event Action<string> OnPowerUpActivated;   // powerUpName
        public static event Action<string> OnPowerUpDeactivated; // powerUpName

        // Fire methods — one per event for clean call sites
        public static void FireGameStateChanged(GameState state) => OnGameStateChanged?.Invoke(state);
        public static void FireLevelStarted(int level) => OnLevelStarted?.Invoke(level);
        public static void FireLevelComplete(int level, int score) => OnLevelComplete?.Invoke(level, score);
        public static void FireGameOver(int finalScore) => OnGameOver?.Invoke(finalScore);

        public static void FireMoleHit(Vector2 hitPoint, int scoreValue) => OnMoleHit?.Invoke(hitPoint, scoreValue);
        public static void FireMoleKilled(MoleType type) => OnMoleKilled?.Invoke(type);
        public static void FireMoleMissed() => OnMoleMissed?.Invoke();
        public static void FireBombHit(Vector2 hitPoint) => OnBombHit?.Invoke(hitPoint);

        public static void FireScoreChanged(int newScore, int multiplier) => OnScoreChanged?.Invoke(newScore, multiplier);
        public static void FireComboChanged(int comboCount) => OnComboChanged?.Invoke(comboCount);
        public static void FireHighScoreBeaten(int newHighScore) => OnHighScoreBeaten?.Invoke(newHighScore);

        public static void FireWeaponSwung(Vector2 worldPos) => OnWeaponSwung?.Invoke(worldPos);

        public static void FireDifficultyChanged(float difficulty) => OnDifficultyChanged?.Invoke(difficulty);

        public static void FireCarrotStolen(int holeIndex) => OnCarrotStolen?.Invoke(holeIndex);
        public static void FireCarrotRegenerated(int holeIndex) => OnCarrotRegenerated?.Invoke(holeIndex);

        public static void FirePowerUpActivated(string name) => OnPowerUpActivated?.Invoke(name);
        public static void FirePowerUpDeactivated(string name) => OnPowerUpDeactivated?.Invoke(name);

        /// <summary>
        /// Call on scene unload or game reset to prevent stale subscriptions.
        /// </summary>
        public static void ClearAll()
        {
            OnGameStateChanged = null;
            OnLevelStarted = null;
            OnLevelComplete = null;
            OnGameOver = null;
            OnMoleHit = null;
            OnMoleKilled = null;
            OnMoleMissed = null;
            OnBombHit = null;
            OnScoreChanged = null;
            OnComboChanged = null;
            OnHighScoreBeaten = null;
            OnWeaponSwung = null;
            OnDifficultyChanged = null;
            OnCarrotStolen = null;
            OnCarrotRegenerated = null;
            OnPowerUpActivated = null;
            OnPowerUpDeactivated = null;
        }
    }
}
