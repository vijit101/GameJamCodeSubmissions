using System.Collections.Generic;
using UnityEngine;
using WhackAMole.Spawning;
using WhackAMole.Utils;

namespace WhackAMole.Core
{
    /// <summary>
    /// Tracks the carrot grid, regenerates stolen carrots over time (oldest first
    /// with backoff), and checks the game-over condition: game ends when all
    /// carrots in any row, column, or diagonal are stolen.
    /// </summary>
    public class CarrotManager : MonoBehaviour
    {
        private bool[] _carrotGrid;
        private Hole[] _holes;

        // Regeneration: FIFO queue of stolen hole indices (oldest first)
        private readonly Queue<int> _stolenQueue = new Queue<int>();
        private float _regenTimer;
        private float _currentRegenInterval;
        private int _consecutiveRegens; // how many regens since last steal

        private static CarrotManager _instance;
        public static CarrotManager Instance => _instance;

        private void Awake()
        {
            _instance = this;
            _carrotGrid = new bool[Constants.HOLE_COUNT];
            for (int i = 0; i < _carrotGrid.Length; i++)
                _carrotGrid[i] = true;
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        private void OnEnable()
        {
            EventBus.OnCarrotStolen += HandleCarrotStolen;
        }

        private void OnDisable()
        {
            EventBus.OnCarrotStolen -= HandleCarrotStolen;
        }

        private void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.CurrentState != GameState.Playing)
                return;

            if (_stolenQueue.Count == 0) return;

            _regenTimer += Time.deltaTime;
            if (_regenTimer >= _currentRegenInterval)
            {
                RegenerateOldest();
                _regenTimer = 0f;
            }
        }

        public int GetRemainingCarrotCount()
        {
            int count = 0;
            if (_carrotGrid == null) return 0;
            for (int i = 0; i < _carrotGrid.Length; i++)
                if (_carrotGrid[i]) count++;
            return count;
        }

        /// <summary>Live view of the carrot grid (true = present, false = stolen). No allocation.</summary>
        public IReadOnlyList<bool> CarrotGrid => _carrotGrid;

        /// <summary>Returns true if the hole at the given index currently has a carrot.</summary>
        public bool HasCarrotAt(int holeIndex)
        {
            if (_carrotGrid == null || holeIndex < 0 || holeIndex >= _carrotGrid.Length) return false;
            return _carrotGrid[holeIndex];
        }

        /// <summary>Number of stolen carrots on the given line (index into <see cref="GridLines.Lines"/>).</summary>
        public int GetStolenCountOnLine(int lineIndex)
        {
            if (_carrotGrid == null) return 0;
            if (lineIndex < 0 || lineIndex >= GridLines.Lines.Length) return 0;
            var line = GridLines.Lines[lineIndex];
            int stolen = 0;
            for (int i = 0; i < line.Length; i++)
                if (!_carrotGrid[line[i]]) stolen++;
            return stolen;
        }

        public void ResetCarrots()
        {
            if (_carrotGrid == null)
                _carrotGrid = new bool[Constants.HOLE_COUNT];

            for (int i = 0; i < _carrotGrid.Length; i++)
                _carrotGrid[i] = true;

            _stolenQueue.Clear();
            _regenTimer = 0f;
            _consecutiveRegens = 0;
            _currentRegenInterval = Constants.CARROT_REGEN_BASE_INTERVAL;

            if (_holes == null || _holes.Length == 0)
            {
                _holes = FindObjectsByType<Hole>(FindObjectsInactive.Exclude);
                System.Array.Sort(_holes, (a, b) => a.HoleIndex.CompareTo(b.HoleIndex));
            }

            foreach (var hole in _holes)
                hole.ResetCarrot();
        }

        /// <summary>
        /// Regenerate a random ceil(count / 2) of the currently-stolen carrots.
        /// Used by <see cref="Moles.GoldenMole"/> on death as a bonus: killing
        /// a golden mole brings back half of what's been lost. Occupied holes
        /// are skipped so carrots never appear behind active moles.
        /// </summary>
        public void RestoreRandomHalfStolen()
        {
            if (_carrotGrid == null || _holes == null) return;

            // Collect stolen hole indices
            var stolen = new List<int>();
            for (int i = 0; i < _carrotGrid.Length; i++)
                if (!_carrotGrid[i]) stolen.Add(i);

            if (stolen.Count == 0) return;

            // Shuffle — Fisher-Yates — so restoration is random each time.
            for (int i = stolen.Count - 1; i > 0; i--)
            {
                int j = Random.Range(0, i + 1);
                (stolen[i], stolen[j]) = (stolen[j], stolen[i]);
            }

            // Half of the stolen carrots, rounded up (half-round-up). Using integer
            // arithmetic so the rounding is exact — no floating-point surprises:
            //   1 stolen → 1 back   (0.5 rounds up)
            //   2 stolen → 1 back
            //   3 stolen → 2 back   (1.5 rounds up)
            //   4 stolen → 2 back
            //   5 stolen → 3 back   (2.5 rounds up)
            //   6 stolen → 3 back
            int target = (stolen.Count + 1) / 2;
            int restored = 0;
            for (int i = 0; i < stolen.Count && restored < target; i++)
            {
                int idx = stolen[i];
                if (idx < 0 || idx >= _holes.Length) continue;
                // Don't restore under an active mole — the RegenerateOldest
                // tick will pick it up later if it's still stolen by then.
                if (_holes[idx].IsOccupied) continue;

                _carrotGrid[idx] = true;
                _holes[idx].RegenerateCarrot();
                restored++;
            }
        }

        private void HandleCarrotStolen(int holeIndex)
        {
            if (holeIndex < 0 || holeIndex >= _carrotGrid.Length) return;
            _carrotGrid[holeIndex] = false;
            _stolenQueue.Enqueue(holeIndex);

            // A new steal means the player is losing — reset consecutive regen count
            // so the next regen comes at the base rate (be kind to a struggling player)
            _consecutiveRegens = 0;
            _currentRegenInterval = Constants.CARROT_REGEN_BASE_INTERVAL;
            _regenTimer = 0f;

            CheckGameOverCondition();
        }

        private void RegenerateOldest()
        {
            // Find the oldest stolen carrot that is still missing
            while (_stolenQueue.Count > 0)
            {
                int idx = _stolenQueue.Dequeue();
                if (!_carrotGrid[idx] && _holes != null && idx < _holes.Length)
                {
                    // Don't regenerate if a mole is currently in that hole
                    if (_holes[idx].IsOccupied)
                    {
                        // Put it back at the end, try again next tick
                        _stolenQueue.Enqueue(idx);
                        return;
                    }

                    _carrotGrid[idx] = true;
                    _holes[idx].RegenerateCarrot();

                    // Apply backoff for the next regen
                    _consecutiveRegens++;
                    _currentRegenInterval = Mathf.Min(
                        Constants.CARROT_REGEN_BASE_INTERVAL * Mathf.Pow(Constants.CARROT_REGEN_BACKOFF, _consecutiveRegens),
                        Constants.CARROT_REGEN_MAX_INTERVAL
                    );
                    return;
                }
                // If carrot was already restored (e.g. game reset), skip it
            }
        }

        private void CheckGameOverCondition()
        {
            var lines = GridLines.Lines;
            for (int li = 0; li < lines.Length; li++)
            {
                var line = lines[li];
                bool allStolen = true;
                for (int k = 0; k < line.Length; k++)
                {
                    if (_carrotGrid[line[k]]) { allStolen = false; break; }
                }
                if (allStolen)
                {
                    TriggerGameOver();
                    return;
                }
            }
        }

        private void TriggerGameOver()
        {
            if (GameManager.Instance != null && GameManager.Instance.CurrentState == GameState.Playing)
                GameManager.Instance.TriggerGameOver();
        }
    }
}
