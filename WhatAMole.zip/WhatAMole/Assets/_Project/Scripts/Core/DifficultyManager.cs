using UnityEngine;
using WhackAMole.Moles;
using WhackAMole.Utils;

namespace WhackAMole.Core
{
    /// <summary>
    /// Dynamic Difficulty Adjustment engine. Adjusts difficulty on every player
    /// action (hit, miss, bomb) and passively over time. Controls spawn rate,
    /// mole type distribution, and max simultaneous moles.
    /// </summary>
    public class DifficultyManager : MonoBehaviour
    {
        private float _difficulty;
        private float _targetDifficulty;
        private float _lastDifficultyBroadcast = -1f;

        private static DifficultyManager _instance;
        public static DifficultyManager Instance => _instance;

        public float Difficulty => _difficulty;
        public float TargetDifficulty => _targetDifficulty;

        public string DifficultyLabel
        {
            get
            {
                if (_difficulty < 0.20f) return "Easy";
                if (_difficulty < 0.45f) return "Medium";
                if (_difficulty < 0.70f) return "Hard";
                if (_difficulty < 1.0f) return "Very Hard";
                return "Extreme";
            }
        }

        private void Awake()
        {
            _instance = this;
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        private void OnEnable()
        {
            EventBus.OnMoleHit += HandleMoleHit;
            EventBus.OnMoleMissed += HandleMoleMissed;
            EventBus.OnBombHit += HandleBombHit;
            EventBus.OnComboChanged += HandleComboChanged;
        }

        private void OnDisable()
        {
            EventBus.OnMoleHit -= HandleMoleHit;
            EventBus.OnMoleMissed -= HandleMoleMissed;
            EventBus.OnBombHit -= HandleBombHit;
            EventBus.OnComboChanged -= HandleComboChanged;
        }

        private void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.CurrentState != GameState.Playing)
                return;

            // Passive difficulty increase over time
            _targetDifficulty += Constants.DDA_PASSIVE_PER_SECOND * Time.deltaTime;
            _targetDifficulty = Mathf.Clamp(_targetDifficulty, 0f, Constants.DDA_CEILING);

            // Smooth toward target
            _difficulty = Mathf.Lerp(_difficulty, _targetDifficulty, Constants.DDA_SMOOTH_SPEED * Time.deltaTime);

            // Broadcast changes (throttle to avoid spamming — every 0.01 change)
            if (Mathf.Abs(_difficulty - _lastDifficultyBroadcast) >= 0.01f)
            {
                _lastDifficultyBroadcast = _difficulty;
                EventBus.FireDifficultyChanged(_difficulty);
            }
        }

        public void ResetDifficulty()
        {
            _difficulty = Constants.DDA_INITIAL_DIFFICULTY;
            _targetDifficulty = Constants.DDA_INITIAL_DIFFICULTY;
            _lastDifficultyBroadcast = -1f;
        }

        // --- Event Handlers ---

        private void HandleMoleHit(Vector2 hitPoint, int scoreValue)
        {
            // Only increase difficulty for positive-score hits (not bombs)
            if (scoreValue <= 0) return;
            float increase = Constants.DDA_HIT_INCREASE * (scoreValue / 10f);
            _targetDifficulty += increase;
            _targetDifficulty = Mathf.Clamp(_targetDifficulty, 0f, Constants.DDA_CEILING);
        }

        private void HandleMoleMissed()
        {
            _targetDifficulty -= Constants.DDA_MISS_DECREASE;
            _targetDifficulty = Mathf.Max(0f, _targetDifficulty);
        }

        private void HandleBombHit(Vector2 hitPoint)
        {
            _targetDifficulty -= Constants.DDA_BOMB_DECREASE;
            _targetDifficulty = Mathf.Max(0f, _targetDifficulty);
        }

        private void HandleComboChanged(int comboCount)
        {
            if (comboCount > 3)
            {
                _targetDifficulty += Constants.DDA_COMBO_BONUS;
                _targetDifficulty = Mathf.Clamp(_targetDifficulty, 0f, Constants.DDA_CEILING);
            }
        }

        // --- Spawn Control ---

        /// <summary>
        /// Returns spawn interval based on current difficulty.
        /// Tightened: even at zero difficulty we spawn every 1.0s, and the
        /// extreme end drops to 0.18s for a genuinely chaotic board.
        /// </summary>
        public float GetSpawnInterval()
        {
            float t = Mathf.Clamp01(_difficulty / Constants.DDA_CEILING);
            return Mathf.Lerp(1.0f, 0.18f, t);
        }

        /// <summary>
        /// Returns max simultaneous active moles based on difficulty.
        /// Bumped each tier up by ~2 and moved thresholds earlier so the board
        /// fills out fast — the player is never looking at an empty grid.
        /// </summary>
        public int GetMaxSimultaneousMoles()
        {
            if (_difficulty < 0.10f) return 4;
            if (_difficulty < 0.20f) return 6;
            if (_difficulty < 0.35f) return 8;
            if (_difficulty < 0.55f) return 10;
            if (_difficulty < 0.75f) return 12;
            if (_difficulty < 1.0f)  return 14;
            return 16;
        }

        /// <summary>
        /// Picks a mole type based on current difficulty using weighted random selection.
        /// Higher difficulty unlocks more types and shifts weights toward harder moles.
        /// </summary>
        public MoleType GetNextMoleType()
        {
            float d = _difficulty;
            float roll = Random.value;
            float cumulative = 0f;

            // Build weighted distribution based on difficulty. Unlock thresholds
            // are pulled down from the original values so variety kicks in fast:
            // Fast moles almost immediately, Armored/Bomb early, the full
            // roster by mid-session instead of late.
            float normalWeight = Mathf.Lerp(1.0f, 0.15f, Mathf.Clamp01(d / 1.0f));
            cumulative += normalWeight;

            float fastWeight     = d >= 0.05f ? Mathf.Lerp(0.10f, 0.25f, Mathf.Clamp01((d - 0.05f) / 0.95f)) : 0f;
            float armoredWeight  = d >= 0.15f ? Mathf.Lerp(0.08f, 0.18f, Mathf.Clamp01((d - 0.15f) / 0.85f)) : 0f;
            float bombWeight     = d >= 0.20f ? Mathf.Lerp(0.05f, 0.15f, Mathf.Clamp01((d - 0.20f) / 0.80f)) : 0f;
            float stealthWeight  = d >= 0.30f ? Mathf.Lerp(0.08f, 0.18f, Mathf.Clamp01((d - 0.30f) / 0.70f)) : 0f;
            float goldenWeight   = d >= 0.25f ? Mathf.Lerp(0.04f, 0.09f, Mathf.Clamp01((d - 0.25f) / 0.75f)) : 0f;
            float splitterWeight = d >= 0.45f ? Mathf.Lerp(0.05f, 0.12f, Mathf.Clamp01((d - 0.45f) / 0.55f)) : 0f;

            float total = normalWeight + fastWeight + armoredWeight + bombWeight
                        + stealthWeight + goldenWeight + splitterWeight;

            // Normalize and pick
            roll *= total;

            cumulative = 0f;
            cumulative += normalWeight;
            if (roll < cumulative) return MoleType.Normal;
            cumulative += fastWeight;
            if (roll < cumulative) return MoleType.Fast;
            cumulative += armoredWeight;
            if (roll < cumulative) return MoleType.Armored;
            cumulative += bombWeight;
            if (roll < cumulative) return MoleType.Bomb;
            cumulative += stealthWeight;
            if (roll < cumulative) return MoleType.Stealth;
            cumulative += goldenWeight;
            if (roll < cumulative) return MoleType.Golden;
            cumulative += splitterWeight;
            if (roll < cumulative) return MoleType.Splitter;

            return MoleType.Normal; // fallback
        }
    }
}
