using System.Collections.Generic;
using WhackAMole.Utils;

namespace WhackAMole.Core
{
    /// <summary>
    /// Precomputed line geometry for the hole grid. A "line" is a row, column,
    /// or diagonal — any sequence whose full steal ends the game
    /// (see <see cref="CarrotManager"/>).
    ///
    /// Single source of truth for both game-over detection and mole targeting.
    /// Built once from <see cref="Constants.HOLE_ROWS"/>/<see cref="Constants.HOLE_COLUMNS"/>.
    /// </summary>
    public static class GridLines
    {
        /// <summary>All lines as arrays of hole indices. Order: rows, columns, diagonals.</summary>
        public static readonly int[][] Lines;

        /// <summary>
        /// For each hole index, the indices into <see cref="Lines"/> that the hole belongs to.
        /// Corner = 3 lines, edge = 2, center (square grid) = 4.
        /// </summary>
        public static readonly int[][] LinesContaining;

        static GridLines()
        {
            int rows = Constants.HOLE_ROWS;
            int cols = Constants.HOLE_COLUMNS;
            var lines = new List<int[]>(rows + cols + 2);

            for (int r = 0; r < rows; r++)
            {
                var row = new int[cols];
                for (int c = 0; c < cols; c++) row[c] = r * cols + c;
                lines.Add(row);
            }

            for (int c = 0; c < cols; c++)
            {
                var col = new int[rows];
                for (int r = 0; r < rows; r++) col[r] = r * cols + c;
                lines.Add(col);
            }

            if (rows == cols)
            {
                var diag1 = new int[rows];
                var diag2 = new int[rows];
                for (int i = 0; i < rows; i++)
                {
                    diag1[i] = i * cols + i;
                    diag2[i] = i * cols + (cols - 1 - i);
                }
                lines.Add(diag1);
                lines.Add(diag2);
            }

            Lines = lines.ToArray();

            int holeCount = rows * cols;
            var perHole = new List<int>[holeCount];
            for (int i = 0; i < holeCount; i++) perHole[i] = new List<int>(4);

            for (int li = 0; li < Lines.Length; li++)
            {
                foreach (int holeIdx in Lines[li])
                    perHole[holeIdx].Add(li);
            }

            LinesContaining = new int[holeCount][];
            for (int i = 0; i < holeCount; i++)
                LinesContaining[i] = perHole[i].ToArray();
        }
    }
}
