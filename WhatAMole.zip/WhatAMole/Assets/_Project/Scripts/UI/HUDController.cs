using UnityEngine;
using UnityEngine.UI;
using TMPro;
using WhackAMole.Core;
using WhackAMole.Utils;

namespace WhackAMole.UI
{
    /// <summary>
    /// In-game HUD: score, combo, difficulty meter, carrot count, pause button.
    /// </summary>
    public class HUDController : MonoBehaviour
    {
        [Header("Score")]
        [SerializeField] private TextMeshProUGUI scoreText;
        [SerializeField] private TextMeshProUGUI comboText;
        [SerializeField] private TextMeshProUGUI multiplierText;

        [Header("Difficulty")]
        [SerializeField] private Image timerBar;
        [SerializeField] private TextMeshProUGUI timerText;

        [Header("Info")]
        [SerializeField] private TextMeshProUGUI levelText;
        [SerializeField] private TextMeshProUGUI carrotCountText;

        [Header("Pause")]
        [SerializeField] private Button pauseButton;

        private void OnEnable()
        {
            EventBus.OnScoreChanged += UpdateScore;
            EventBus.OnComboChanged += UpdateCombo;
            EventBus.OnDifficultyChanged += UpdateDifficulty;
            EventBus.OnCarrotStolen += UpdateCarrotCount;
            EventBus.OnCarrotRegenerated += UpdateCarrotCount;

            pauseButton?.onClick.AddListener(OnPauseClicked);
        }

        private void OnDisable()
        {
            EventBus.OnScoreChanged -= UpdateScore;
            EventBus.OnComboChanged -= UpdateCombo;
            EventBus.OnDifficultyChanged -= UpdateDifficulty;
            EventBus.OnCarrotStolen -= UpdateCarrotCount;
            EventBus.OnCarrotRegenerated -= UpdateCarrotCount;

            pauseButton?.onClick.RemoveListener(OnPauseClicked);
        }

        private void Start()
        {
            // Initialize carrot count display
            RefreshCarrotCount();
        }

        private void Update()
        {
            UpdateDifficultyBar();
        }

        private void UpdateScore(int newScore, int multiplier)
        {
            if (scoreText != null)
                scoreText.text = newScore.ToString("N0");

            if (multiplierText != null)
            {
                multiplierText.text = multiplier > 1 ? $"x{multiplier}" : "";
                multiplierText.gameObject.SetActive(multiplier > 1);
            }
        }

        private void UpdateCombo(int comboCount)
        {
            if (comboText != null)
            {
                comboText.text = comboCount > 1 ? $"Combo {comboCount}!" : "";
                comboText.gameObject.SetActive(comboCount > 1);
            }
        }

        private void UpdateDifficulty(float difficulty)
        {
            var dm = DifficultyManager.Instance;
            if (dm == null) return;

            if (levelText != null)
                levelText.text = dm.DifficultyLabel;

            if (timerText != null)
                timerText.text = $"{Mathf.RoundToInt(difficulty / Constants.DDA_CEILING * 100f)}%";
        }

        private void UpdateDifficultyBar()
        {
            var dm = DifficultyManager.Instance;
            if (dm == null || timerBar == null) return;

            timerBar.fillAmount = dm.Difficulty / Constants.DDA_CEILING;
        }

        private void UpdateCarrotCount(int holeIndex)
        {
            RefreshCarrotCount();
        }

        private void RefreshCarrotCount()
        {
            if (carrotCountText == null) return;
            var cm = CarrotManager.Instance;
            int remaining = cm != null ? cm.GetRemainingCarrotCount() : Constants.HOLE_COUNT;
            carrotCountText.text = $"Carrots: {remaining}/{Constants.HOLE_COUNT}";
        }

        private void OnPauseClicked()
        {
            GameManager.Instance.PauseGame();
        }
    }
}
