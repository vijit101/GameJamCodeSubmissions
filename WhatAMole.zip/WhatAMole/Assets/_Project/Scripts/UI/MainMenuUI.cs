using UnityEngine;
using UnityEngine.UI;
using TMPro;
using WhackAMole.Core;
using WhackAMole.Utils;

namespace WhackAMole.UI
{
    /// <summary>
    /// Main menu screen: Play, volume controls, high score display.
    /// </summary>
    public class MainMenuUI : MonoBehaviour
    {
        [Header("Buttons")]
        [SerializeField] private Button playButton;

        [Header("Display")]
        [SerializeField] private TextMeshProUGUI highScoreText;
        [SerializeField] private TextMeshProUGUI titleText;

        [Header("Volume")]
        [SerializeField] private Slider musicVolumeSlider;
        [SerializeField] private Slider sfxVolumeSlider;

        private void Start()
        {
            playButton?.onClick.AddListener(OnPlayClicked);

            if (musicVolumeSlider != null)
            {
                musicVolumeSlider.value = PlayerPrefs.GetFloat(Constants.PREF_MUSIC_VOLUME, Constants.MUSIC_NORMAL_VOLUME);
                musicVolumeSlider.onValueChanged.AddListener(OnMusicVolumeChanged);
            }

            if (sfxVolumeSlider != null)
            {
                sfxVolumeSlider.value = PlayerPrefs.GetFloat(Constants.PREF_SFX_VOLUME, 1f);
                sfxVolumeSlider.onValueChanged.AddListener(OnSFXVolumeChanged);
            }

            UpdateHighScore();
        }

        private void UpdateHighScore()
        {
            int highScore = PlayerPrefs.GetInt(Constants.PREF_HIGH_SCORE, 0);
            if (highScoreText != null)
                highScoreText.text = $"High Score: {highScore}";
        }

        private void OnPlayClicked()
        {
            AudioManager.Instance?.StartBackgroundMusic();
            GameManager.Instance.StartGame();
        }

        private void OnMusicVolumeChanged(float value)
        {
            AudioManager.Instance?.SetMusicVolume(value);
        }

        private void OnSFXVolumeChanged(float value)
        {
            AudioManager.Instance?.SetSFXVolume(value);
        }
    }
}
