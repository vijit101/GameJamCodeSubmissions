using UnityEngine;
using UnityEngine.UI;
using TMPro;
using WhackAMole.Core;

namespace WhackAMole.UI
{
    /// <summary>
    /// Kept for compatibility — panel is never shown in endless DDA mode.
    /// </summary>
    public class LevelCompleteUI : MonoBehaviour
    {
        [SerializeField] private GameObject panel;
        [SerializeField] private TextMeshProUGUI levelNameText;
        [SerializeField] private TextMeshProUGUI scoreText;
        [SerializeField] private GameObject[] starIcons;
        [SerializeField] private Button nextLevelButton;
        [SerializeField] private Button mainMenuButton;

        private void Start()
        {
            if (panel != null) panel.SetActive(false);
        }
    }
}
