using UnityEngine;
using UnityEngine.UI;
using TMPro;
using WhackAMole.Core;

namespace WhackAMole.UI
{
    /// <summary>
    /// Game Over screen for endless DDA mode. Shows final score and high score.
    /// </summary>
    public class GameOverUI : MonoBehaviour
    {
        [SerializeField] private GameObject panel;
        [SerializeField] private TextMeshProUGUI headerText;
        [SerializeField] private TextMeshProUGUI finalScoreText;
        [SerializeField] private TextMeshProUGUI highScoreText;
        [SerializeField] private Button retryButton;
        [SerializeField] private Button mainMenuButton;

        private void Start()
        {
            if (panel != null) panel.SetActive(false);
            retryButton?.onClick.AddListener(OnRetry);
            mainMenuButton?.onClick.AddListener(OnMainMenu);
        }

        private void OnEnable()
        {
            EventBus.OnGameOver += ShowGameOver;
            EventBus.OnGameStateChanged += OnStateChanged;
        }

        private void OnDisable()
        {
            EventBus.OnGameOver -= ShowGameOver;
            EventBus.OnGameStateChanged -= OnStateChanged;
        }

        private void ShowGameOver(int finalScore)
        {
            if (panel == null) return;
            panel.SetActive(true);

            if (headerText != null) headerText.text = "The Moles Got Your Carrots!";
            if (finalScoreText != null) finalScoreText.text = $"Score: {finalScore}";
            if (highScoreText != null) highScoreText.text = $"High Score: {ScoreManager.Instance.HighScore}";
            if (retryButton != null) retryButton.GetComponentInChildren<TextMeshProUGUI>().text = "Retry";
        }

        private void OnStateChanged(GameState state)
        {
            if (state != GameState.GameOver)
            {
                if (panel != null) panel.SetActive(false);
            }
        }

        private void OnRetry()
        {
            if (panel != null) panel.SetActive(false);
            GameManager.Instance.RestartGame();
        }

        private void OnMainMenu()
        {
            if (panel != null) panel.SetActive(false);
            GameManager.Instance.ReturnToMainMenu();
        }
    }
}
