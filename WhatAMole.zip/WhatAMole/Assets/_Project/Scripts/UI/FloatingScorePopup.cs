using System.Collections;
using UnityEngine;
using TMPro;

namespace WhackAMole.UI
{
    /// <summary>
    /// Floating score text ("+20", "-25") that rises and fades.
    /// Object-pooled for WebGL performance. Call Show() to display.
    /// </summary>
    public class FloatingScorePopup : MonoBehaviour
    {
        [Header("Config")]
        [SerializeField] private float floatSpeed = 1.5f;
        [SerializeField] private float lifetime = 0.8f;
        [SerializeField] private float startScale = 0.5f;
        [SerializeField] private float peakScale = 1.2f;

        private TextMeshPro _text;
        private Color _originalColor;

        private void Awake()
        {
            _text = GetComponent<TextMeshPro>();
            if (_text != null)
                _originalColor = _text.color;
        }

        public void Show(Vector3 worldPos, int score, Color color)
        {
            transform.position = worldPos;

            if (_text != null)
            {
                _text.text = score > 0 ? $"+{score}" : score.ToString();
                _text.color = color;
                _originalColor = color;
            }

            gameObject.SetActive(true);
            StartCoroutine(AnimateAndHide());
        }

        private IEnumerator AnimateAndHide()
        {
            float elapsed = 0f;
            Vector3 startPos = transform.position;
            transform.localScale = Vector3.one * startScale;

            while (elapsed < lifetime)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / lifetime;

                // Float upward
                transform.position = startPos + Vector3.up * (floatSpeed * t);

                // Scale: punch up then shrink
                float scale;
                if (t < 0.3f)
                    scale = Mathf.Lerp(startScale, peakScale, t / 0.3f);
                else
                    scale = Mathf.Lerp(peakScale, 0f, (t - 0.3f) / 0.7f);
                transform.localScale = Vector3.one * scale;

                // Fade out
                if (_text != null)
                {
                    var c = _originalColor;
                    c.a = 1f - t;
                    _text.color = c;
                }

                yield return null;
            }

            gameObject.SetActive(false);
        }
    }
}
