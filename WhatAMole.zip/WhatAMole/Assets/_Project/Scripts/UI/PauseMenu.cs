using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using WhackAMole.Core;
using WhackAMole.Utils;

namespace WhackAMole.UI
{
    /// <summary>
    /// Must live on an always-active GameObject (Canvas), NOT on the panel.
    /// </summary>
    public class PauseMenu : MonoBehaviour
    {
        [SerializeField] private GameObject panel;
        [SerializeField] private Button resumeButton;
        [SerializeField] private Button restartButton;
        [SerializeField] private Button mainMenuButton;
        [SerializeField] private Slider musicSlider;
        [SerializeField] private Slider sfxSlider;

        private void Start()
        {
            if (panel != null) panel.SetActive(false);
            resumeButton?.onClick.AddListener(OnResume);
            restartButton?.onClick.AddListener(OnRestart);
            mainMenuButton?.onClick.AddListener(OnMainMenu);
        }

        private void OnEnable()
        {
            EventBus.OnGameStateChanged += OnStateChanged;
        }

        private void OnDisable()
        {
            EventBus.OnGameStateChanged -= OnStateChanged;
        }

        private void Update()
        {
            var kb = Keyboard.current;
            if (kb == null) return;

            if (kb.escapeKey.wasPressedThisFrame || kb.pKey.wasPressedThisFrame)
            {
                if (GameManager.Instance.CurrentState == GameState.Playing)
                    GameManager.Instance.PauseGame();
                else if (GameManager.Instance.CurrentState == GameState.Paused)
                    GameManager.Instance.ResumeGame();
            }
        }

        private void OnStateChanged(GameState state)
        {
            if (panel != null) panel.SetActive(state == GameState.Paused);
        }

        private void OnResume() { GameManager.Instance.ResumeGame(); }
        private void OnRestart() { GameManager.Instance.RestartGame(); }
        private void OnMainMenu() { GameManager.Instance.ReturnToMainMenu(); }
    }
}
