using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Utils;

namespace WhackAMole.UI
{
    /// <summary>
    /// Listens to EventBus.OnMoleHit and spawns FloatingScorePopup instances.
    /// Uses an object pool for WebGL performance.
    /// </summary>
    public class FloatingScoreSpawner : MonoBehaviour
    {
        [SerializeField] private FloatingScorePopup popupPrefab;
        [SerializeField] private int poolSize = 10;

        [Header("Colors")]
        [SerializeField] private Color positiveColor = Color.white;
        [SerializeField] private Color negativeColor = Color.red;
        [SerializeField] private Color goldenColor = new Color(1f, 0.85f, 0f);
        [SerializeField] private Color comboColor = Color.cyan;

        private ObjectPool<FloatingScorePopup> _pool;

        private void Start()
        {
            if (popupPrefab != null)
            {
                _pool = new ObjectPool<FloatingScorePopup>(
                    popupPrefab, transform, poolSize
                );
            }
        }

        private void OnEnable()
        {
            EventBus.OnMoleHit += SpawnPopup;
        }

        private void OnDisable()
        {
            EventBus.OnMoleHit -= SpawnPopup;
        }

        private void SpawnPopup(Vector2 hitPoint, int score)
        {
            if (_pool == null) return;

            var popup = _pool.Get();

            Color color;
            if (score < 0)
                color = negativeColor;
            else if (score >= 50)
                color = goldenColor;
            else if (ScoreManager.Instance.Multiplier > 1)
                color = comboColor;
            else
                color = positiveColor;

            int displayScore = score * ScoreManager.Instance.Multiplier;
            popup.Show(hitPoint + Vector2.up * 0.5f, displayScore, color);
        }
    }
}
