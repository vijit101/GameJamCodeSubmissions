using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using WhackAMole.Spawning;
using WhackAMole.Core;
using WhackAMole.Weapons;
using WhackAMole.Moles;
using WhackAMole.Levels;
using WhackAMole.UI;
using WhackAMole.Utils;
using TMPro;
using UnityEngine.UI;

public static class ProjectSetup
{
    static string SP = "Assets/_Project/Art/Sprites/";
    static System.Collections.Generic.Dictionary<string, Sprite> _sprites = new();

    [MenuItem("Whack-a-Mole/Setup Project")]
    public static void Run()
    {
        CreateFolders();
        GenerateAllSprites();
        DeleteOldAssets();
        CreateMoleData();
        CreateWeapons();
        CreateLevels();
        CreateMolePrefabs();
        BuildGameScene();
        BuildMainMenuScene();
        SetBuildScenes();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("=== Setup complete! Open MainMenu scene and press Play. ===");
    }

    static void CreateFolders()
    {
        Folder("Assets/_Project/Resources/Levels");
        Folder("Assets/_Project/Resources/Weapons");
        Folder("Assets/_Project/Resources/MolePrefabs");
        Folder("Assets/_Project/ScriptableObjects/MoleData");
        Folder("Assets/_Project/Art/Sprites/Moles");
        Folder("Assets/_Project/Art/Sprites/Environment");
        Folder("Assets/_Project/Art/Sprites/Weapons");
        Folder("Assets/_Project/Art/Sprites/VFX");
        Folder("Assets/_Project/Prefabs/UI");
        Folder("Assets/_Project/Scenes");
    }

    static void DeleteOldAssets()
    {
        // Delete old prefabs so they get rebuilt with new sprites
        var oldPrefabs = AssetDatabase.FindAssets("t:Prefab", new[] { "Assets/_Project/Resources/MolePrefabs" });
        foreach (var guid in oldPrefabs)
            AssetDatabase.DeleteAsset(AssetDatabase.GUIDToAssetPath(guid));
        // Delete old MoleData so sprites get reassigned
        var oldData = AssetDatabase.FindAssets("t:ScriptableObject", new[] { "Assets/_Project/ScriptableObjects/MoleData" });
        foreach (var guid in oldData)
            AssetDatabase.DeleteAsset(AssetDatabase.GUIDToAssetPath(guid));
        // Delete old weapon SOs so cursor sprites get assigned
        var oldWeapons = AssetDatabase.FindAssets("t:ScriptableObject", new[] { "Assets/_Project/Resources/Weapons" });
        foreach (var guid in oldWeapons)
            AssetDatabase.DeleteAsset(AssetDatabase.GUIDToAssetPath(guid));
        AssetDatabase.Refresh();
    }

    // ════════════════════════════════════════════
    // SPRITE GENERATION
    // ════════════════════════════════════════════

    static void GenerateAllSprites()
    {
        _sprites.Clear();

        // Environment — Farm theme
        GenSprite("Environment/FarmBg", 256, 256, DrawFarmBackground);
        GenSprite("Environment/TilledSoil", 128, 128, DrawTilledSoil);
        GenSprite("Environment/SoilMound", 64, 48, DrawSoilMound);
        GenSprite("Environment/SoilMoundFront", 64, 24, DrawSoilMoundFront);
        GenSprite("Environment/Carrot", 32, 48, DrawCarrot);
        GenSprite("Environment/FenceH", 128, 16, DrawFenceRail);
        GenSprite("Environment/FencePost", 16, 48, DrawFencePost);

        // Weapons (cursor sprites)
        GenSprite("Weapons/Hammer", 64, 64, DrawHammerWeapon);
        GenSprite("Weapons/Katana", 64, 64, DrawKatanaWeapon);
        GenSprite("Weapons/Bomb",   64, 64, DrawBombWeapon);

        // VFX
        GenSprite("VFX/Smoke",      64, 64, DrawSmokePuff);

        // Moles
        GenSprite("Moles/NormalMole", 64, 64, t => DrawMole(t, new Color(0.55f,0.35f,0.18f), new Color(0.7f,0.5f,0.3f), MoleFeature.None));
        GenSprite("Moles/FastMole", 64, 64, t => DrawMole(t, new Color(0.2f,0.4f,0.85f), new Color(0.4f,0.6f,1f), MoleFeature.SpeedLines));
        GenSprite("Moles/ArmoredMole", 64, 64, t => DrawMole(t, new Color(0.5f,0.5f,0.55f), new Color(0.65f,0.65f,0.7f), MoleFeature.Helmet));
        GenSprite("Moles/GoldenMole", 64, 64, t => DrawMole(t, new Color(0.85f,0.7f,0.1f), new Color(1f,0.9f,0.3f), MoleFeature.Sparkle));
        GenSprite("Moles/BombMole", 64, 64, t => DrawMole(t, new Color(0.6f,0.08f,0.08f), new Color(0.2f,0.2f,0.2f), MoleFeature.Fuse));
        GenSprite("Moles/StealthMole", 64, 64, t => DrawMole(t, new Color(0.2f,0.2f,0.35f), new Color(0.3f,0.3f,0.45f), MoleFeature.Mask));
        GenSprite("Moles/SplitterMole", 64, 64, t => DrawMole(t, new Color(0.15f,0.6f,0.2f), new Color(0.3f,0.75f,0.35f), MoleFeature.SplitLine));

        AssetDatabase.Refresh();

        // Import all as sprites
        foreach (var kv in _sprites)
        {
            string path = SP + kv.Key + ".png";
            var imp = (TextureImporter)AssetImporter.GetAtPath(path);
            if (imp != null)
            {
                imp.textureType = TextureImporterType.Sprite;
                imp.spriteImportMode = SpriteImportMode.Single;
                imp.spritePixelsPerUnit = 64;
                imp.filterMode = FilterMode.Point; // Crisp pixel art
                imp.textureCompression = TextureImporterCompression.Uncompressed;
                // Per-weapon pivot. Hammer rotates from the pommel (bottom of sprite)
                // so its grip stays still while the head wiggles. Katana and Bomb
                // rotate/spin/pulse from their centre.
                if (kv.Key == "Weapons/Hammer")
                {
                    var settings = new TextureImporterSettings();
                    imp.ReadTextureSettings(settings);
                    settings.spriteAlignment = (int)SpriteAlignment.Custom;
                    settings.spritePivot = new Vector2(0.5f, 2f / 64f);
                    imp.SetTextureSettings(settings);
                }
                else if (kv.Key == "Weapons/Katana" || kv.Key == "Weapons/Bomb" || kv.Key == "VFX/Smoke")
                {
                    var settings = new TextureImporterSettings();
                    imp.ReadTextureSettings(settings);
                    settings.spriteAlignment = (int)SpriteAlignment.Center;
                    settings.spritePivot = new Vector2(0.5f, 0.5f);
                    imp.SetTextureSettings(settings);
                }
                imp.SaveAndReimport();
            }
        }
        AssetDatabase.Refresh();

        // Reload sprites
        var keys = new System.Collections.Generic.List<string>(_sprites.Keys);
        foreach (var key in keys)
            _sprites[key] = AssetDatabase.LoadAssetAtPath<Sprite>(SP + key + ".png");
    }

    static void GenSprite(string name, int w, int h, System.Action<Texture2D> draw)
    {
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        // Clear to transparent
        var clear = new Color[w * h];
        tex.SetPixels(clear);
        draw(tex);
        tex.Apply();
        string dir = System.IO.Path.GetDirectoryName(Application.dataPath + "/_Project/Art/Sprites/" + name + ".png");
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllBytes(Application.dataPath + "/_Project/Art/Sprites/" + name + ".png", tex.EncodeToPNG());
        _sprites[name] = null; // placeholder until reimport
    }

    static Sprite S(string name) => _sprites.TryGetValue(name, out var s) ? s : null;

    // ─── Drawing Helpers ───

    static void Px(Texture2D t, int x, int y, Color c)
    {
        if (x >= 0 && x < t.width && y >= 0 && y < t.height) t.SetPixel(x, y, c);
    }

    static void FillOval(Texture2D t, int cx, int cy, int rx, int ry, Color c)
    {
        for (int y = -ry; y <= ry; y++)
            for (int x = -rx; x <= rx; x++)
                if ((float)(x * x) / (rx * rx) + (float)(y * y) / (ry * ry) <= 1f)
                    Px(t, cx + x, cy + y, c);
    }

    static void FillRect(Texture2D t, int x, int y, int w, int h, Color c)
    {
        for (int dy = 0; dy < h; dy++)
            for (int dx = 0; dx < w; dx++)
                Px(t, x + dx, y + dy, c);
    }

    static void FillCircle(Texture2D t, int cx, int cy, int r, Color c)
    {
        FillOval(t, cx, cy, r, r, c);
    }

    // ─── Farm Environment Sprites ───

    static void DrawFarmBackground(Texture2D t)
    {
        var rng = new System.Random(42);
        // Sky gradient (top half)
        for (int y = t.height / 2; y < t.height; y++)
        {
            float skyT = (float)(y - t.height / 2) / (t.height / 2);
            Color sky = Color.Lerp(new Color(0.45f, 0.7f, 0.95f), new Color(0.6f, 0.82f, 1f), skyT);
            for (int x = 0; x < t.width; x++)
                t.SetPixel(x, y, sky);
        }
        // Clouds
        FillOval(t, 50, 200, 20, 8, new Color(1, 1, 1, 0.5f));
        FillOval(t, 65, 205, 15, 6, new Color(1, 1, 1, 0.4f));
        FillOval(t, 180, 210, 22, 9, new Color(1, 1, 1, 0.45f));
        FillOval(t, 200, 215, 16, 7, new Color(1, 1, 1, 0.35f));

        // Rolling hills (bottom half) — green grass field
        for (int y = 0; y < t.height / 2; y++)
        {
            float hillT = (float)y / (t.height / 2);
            for (int x = 0; x < t.width; x++)
            {
                float n = (float)rng.NextDouble() * 0.06f;
                // Farther hills are lighter (atmospheric perspective)
                float base_g = Mathf.Lerp(0.4f, 0.55f, hillT);
                Color grass = new Color(0.2f + n, base_g + n, 0.08f + n * 0.5f);
                t.SetPixel(x, y, grass);
            }
        }
        // Grass blade tips
        for (int i = 0; i < 300; i++)
        {
            int x = rng.Next(t.width);
            int y = rng.Next(t.height / 2);
            Px(t, x, y, new Color(0.3f, 0.62f, 0.15f));
            Px(t, x, y + 1, new Color(0.32f, 0.65f, 0.18f));
        }
        // Horizon line
        for (int x = 0; x < t.width; x++)
            Px(t, x, t.height / 2, new Color(0.35f, 0.6f, 0.2f));
    }

    static void DrawTilledSoil(Texture2D t)
    {
        var rng = new System.Random(99);
        // Rich dark farm soil
        for (int y = 0; y < t.height; y++)
            for (int x = 0; x < t.width; x++)
            {
                float n = (float)rng.NextDouble() * 0.08f;
                // Furrow lines every ~10px (darker grooves)
                bool isFurrow = (y % 10) < 2;
                if (y > t.height - 8)
                    t.SetPixel(x, y, new Color(0.25f + n, 0.5f + n, 0.12f + n)); // Grass edge top
                else if (isFurrow)
                    t.SetPixel(x, y, new Color(0.25f + n, 0.15f + n * 0.5f, 0.05f + n * 0.3f));
                else
                    t.SetPixel(x, y, new Color(0.38f + n, 0.22f + n * 0.5f, 0.08f + n * 0.3f));
            }
        // Pebbles and soil texture
        for (int i = 0; i < 80; i++)
        {
            int x = rng.Next(t.width); int y = rng.Next(t.height - 10);
            Px(t, x, y, new Color(0.45f, 0.3f, 0.15f));
        }
    }

    static void DrawSoilMound(Texture2D t)
    {
        // Rounded soil mound — where carrots grow
        int cx = t.width / 2, cy = t.height / 2;
        int rx = 28, ry = 18;
        var rng = new System.Random(77);

        // Shadow under mound
        FillOval(t, cx, cy - 3, rx + 2, ry - 4, new Color(0.15f, 0.08f, 0.03f, 0.5f));

        // Main mound
        for (int y = -ry; y <= ry; y++)
            for (int x = -rx; x <= rx; x++)
                if ((float)(x * x) / (rx * rx) + (float)(y * y) / (ry * ry) <= 1f)
                {
                    float height = (float)(y + ry) / (2 * ry); // 0 at bottom, 1 at top
                    float n = (float)rng.NextDouble() * 0.05f;
                    // Lighter at top (sunlit), darker at bottom
                    float v = 0.28f + height * 0.12f + n;
                    Px(t, cx + x, cy + y, new Color(v, v * 0.65f, v * 0.3f));
                }

        // Grass tufts on top rim
        for (int x = -rx + 4; x <= rx - 4; x += 3)
        {
            Px(t, cx + x, cy + ry - 1, new Color(0.3f, 0.58f, 0.15f));
            Px(t, cx + x, cy + ry, new Color(0.25f, 0.5f, 0.12f));
        }
    }

    static void DrawSoilMoundFront(Texture2D t)
    {
        // Front lip of soil mound — renders OVER moles for depth
        int cx = t.width / 2, cy = t.height / 2;
        int rx = 28, ry = 10;
        var rng = new System.Random(88);

        for (int y = -ry; y <= 0; y++)
            for (int x = -rx; x <= rx; x++)
                if ((float)(x * x) / (rx * rx) + (float)(y * y) / (ry * ry) <= 1f)
                {
                    float n = (float)rng.NextDouble() * 0.04f;
                    float shade = 0.32f + (float)(y + ry) / ry * 0.1f + n;
                    Px(t, cx + x, cy + y, new Color(shade, shade * 0.6f, shade * 0.3f));
                }

        // Small grass details
        Px(t, cx - rx + 6, cy + 1, new Color(0.3f, 0.55f, 0.15f));
        Px(t, cx + rx - 6, cy + 1, new Color(0.3f, 0.55f, 0.15f));
        Px(t, cx - rx + 4, cy + 2, new Color(0.28f, 0.52f, 0.14f));
        Px(t, cx + rx - 4, cy + 2, new Color(0.28f, 0.52f, 0.14f));
    }

    static void DrawCarrot(Texture2D t)
    {
        int cx = t.width / 2; // 16
        // Orange carrot body — tapers from wide at top to point at bottom
        for (int y = 0; y < 30; y++)
        {
            float taperT = (float)y / 30f;
            int halfWidth = (int)Mathf.Lerp(1f, 10f, 1f - taperT);
            for (int x = -halfWidth; x <= halfWidth; x++)
            {
                float n = Mathf.Abs(x) / (float)(halfWidth + 1) * 0.1f;
                Color c = new Color(0.95f - n, 0.5f - n * 0.5f, 0.05f);
                Px(t, cx + x, y + 2, c);
            }
            // Horizontal groove lines
            if (y % 6 == 3 && halfWidth > 2)
                for (int x = -halfWidth + 1; x <= halfWidth - 1; x++)
                    Px(t, cx + x, y + 2, new Color(0.8f, 0.4f, 0.04f));
        }
        // Carrot tip
        Px(t, cx, 1, new Color(0.9f, 0.45f, 0.05f));

        // Green leafy top — 3 fronds
        Color leaf = new Color(0.2f, 0.65f, 0.15f);
        Color leafLight = new Color(0.3f, 0.75f, 0.2f);
        // Center frond
        for (int y = 32; y < 46; y++) { Px(t, cx, y, leaf); Px(t, cx + 1, y, leafLight); }
        // Left frond
        for (int i = 0; i < 10; i++) { Px(t, cx - 2 - i / 3, 33 + i, leaf); Px(t, cx - 3 - i / 3, 34 + i, leafLight); }
        // Right frond
        for (int i = 0; i < 10; i++) { Px(t, cx + 2 + i / 3, 33 + i, leaf); Px(t, cx + 3 + i / 3, 34 + i, leafLight); }
    }

    static void DrawFenceRail(Texture2D t)
    {
        var wood = new Color(0.5f, 0.35f, 0.18f);
        var woodLight = new Color(0.6f, 0.42f, 0.22f);
        var woodDark = new Color(0.38f, 0.25f, 0.12f);

        // Main plank
        FillRect(t, 0, 4, t.width, 8, wood);
        // Top edge highlight
        for (int x = 0; x < t.width; x++) Px(t, x, 12, woodLight);
        // Bottom edge shadow
        for (int x = 0; x < t.width; x++) Px(t, x, 3, woodDark);
        // Wood grain
        var rng = new System.Random(55);
        for (int i = 0; i < 20; i++)
        {
            int x = rng.Next(t.width);
            int y = 5 + rng.Next(6);
            Px(t, x, y, woodDark);
        }
    }

    static void DrawFencePost(Texture2D t)
    {
        var wood = new Color(0.45f, 0.3f, 0.15f);
        var woodLight = new Color(0.55f, 0.38f, 0.2f);
        var woodDark = new Color(0.35f, 0.22f, 0.1f);

        // Post body
        FillRect(t, 4, 0, 8, 44, wood);
        // Tapered top
        FillRect(t, 5, 44, 6, 4, wood);
        // Left/right edge shadows
        for (int y = 0; y < 44; y++) { Px(t, 4, y, woodDark); Px(t, 11, y, woodDark); }
        // Right side highlight
        for (int y = 0; y < 44; y++) Px(t, 10, y, woodLight);
        // Top cap
        FillRect(t, 5, 44, 6, 2, woodLight);
    }

    // ─── Weapon Cursor Sprite (64x64 face-up square mallet) ───
    // Square striking head at the TOP of the sprite (facing up), handle hanging
    // below. Sprite pivot (0.5, 0.75) lands on the face centre so the cursor
    // points at the impact point. Swing animation lifts + tilts back, then
    // drops + tilts forward to slam the face onto the mole.

    static void DrawHammerWeapon(Texture2D t)
    {
        // Steel palette
        var steelCore  = new Color(0.612f, 0.616f, 0.655f);
        var steelHi    = new Color(0.824f, 0.827f, 0.859f);
        var steelSpec  = new Color(0.933f, 0.937f, 0.961f);
        var steelMid   = new Color(0.494f, 0.498f, 0.537f);
        var steelShade = new Color(0.369f, 0.376f, 0.416f);
        var steelDark  = new Color(0.239f, 0.247f, 0.286f);

        // Wood palette
        var wood      = new Color(0.549f, 0.357f, 0.173f);
        var woodHi    = new Color(0.729f, 0.490f, 0.243f);
        var woodShade = new Color(0.369f, 0.227f, 0.094f);
        var gripDark  = new Color(0.208f, 0.129f, 0.058f);
        var gripSeam  = new Color(0.761f, 0.541f, 0.302f);

        // ── Square mallet head (at top of sprite) ──
        // Spans x=16..48 (32 wide) × y=36..60 (24 tall). Centred at (32, 48).
        int fL = 16, fR = 48, fB = 36, fT = 60;
        int fw = fR - fL;  // 32
        int fh = fT - fB;  // 24

        // Outer dark border
        FillRect(t, fL, fB, fw, fh, steelDark);
        // Inset mid-tone body
        FillRect(t, fL + 2, fB + 2, fw - 4, fh - 4, steelMid);
        // Upper-left lit quadrant (light from upper-left)
        FillRect(t, fL + 2, fB + fh / 2, fw / 2 - 1, fh / 2 - 2, steelCore);
        // Lower-right shaded quadrant
        FillRect(t, fL + fw / 2, fB + 2, fw / 2 - 2, fh / 2 - 1, steelShade);
        // Edge accents
        for (int x = fL + 3; x < fR - 3; x++)
        {
            Px(t, x, fT - 3, steelHi);     // top edge highlight row
            Px(t, x, fB + 2, steelDark);   // bottom edge dark row
        }
        for (int y = fB + 3; y < fT - 3; y++)
        {
            Px(t, fL + 2, y, steelHi);     // left edge highlight column
            Px(t, fR - 3, y, steelShade);  // right edge shade column
        }
        // Bright specular block at upper-left
        FillRect(t, fL + 5, fT - 8, 7, 4, steelHi);
        FillRect(t, fL + 6, fT - 7, 4, 2, steelSpec);
        // Small secondary specular
        Px(t, fL + 14, fT - 5, steelSpec);
        Px(t, fL + 15, fT - 5, steelHi);
        // Corner rivets (small dark 2×2 squares)
        FillRect(t, fL + 3, fB + 3, 2, 2, steelDark);
        FillRect(t, fR - 5, fB + 3, 2, 2, steelDark);
        FillRect(t, fL + 3, fT - 5, 2, 2, steelDark);
        FillRect(t, fR - 5, fT - 5, 2, 2, steelDark);
        // Faint rivet shadows
        Px(t, fL + 3, fB + 4, steelShade);
        Px(t, fL + 3, fT - 4, steelShade);

        // ── Metal socket where handle meets head ──
        FillRect(t, 28, 33, 8, 3, steelDark);
        FillRect(t, 29, 34, 6, 1, steelShade);
        Px(t, 30, 35, steelHi); Px(t, 33, 35, steelHi);

        // ── Wooden shaft (below head) ──
        // x=29..34, y=4..33
        FillRect(t, 29, 4, 6, 29, wood);
        for (int y = 4; y < 33; y++)
        {
            Px(t, 28, y, woodShade);
            Px(t, 35, y, woodShade);
            Px(t, 30, y, woodHi);
        }
        // Wood grain flecks
        Px(t, 32, 9, woodShade);
        Px(t, 31, 17, woodShade);
        Px(t, 33, 26, woodShade);

        // ── Leather grip wraps (two bands on the lower half of the handle) ──
        FillRect(t, 27, 10, 10, 4, gripDark);
        for (int x = 27; x < 37; x++) Px(t, x, 14, gripSeam);
        FillRect(t, 27, 18, 10, 4, gripDark);
        for (int x = 27; x < 37; x++) Px(t, x, 22, gripSeam);

        // ── Pommel cap at the very bottom ──
        FillRect(t, 27, 0, 10, 4, gripDark);
        for (int x = 28; x < 36; x++) Px(t, x, 3, gripSeam);
    }

    // ─── Katana cursor sprite (64x64, centre pivot, spins continuously) ───
    static void DrawKatanaWeapon(Texture2D t)
    {
        // Steel palette (cool silver, strong edge)
        var bladeCore  = new Color(0.706f, 0.725f, 0.784f);
        var bladeHi    = new Color(0.859f, 0.878f, 0.925f);
        var bladeEdge  = new Color(0.957f, 0.969f, 0.992f);
        var bladeShade = new Color(0.455f, 0.478f, 0.541f);
        var bladeLow   = new Color(0.318f, 0.341f, 0.392f);

        // Fittings (bronze + gold)
        var bronze     = new Color(0.510f, 0.353f, 0.153f);
        var bronzeHi   = new Color(0.671f, 0.482f, 0.224f);
        var bronzeDark = new Color(0.322f, 0.204f, 0.071f);
        var gold       = new Color(0.902f, 0.749f, 0.275f);

        // Handle wrap (dark blue silk with tan cross-straps)
        var wrap       = new Color(0.094f, 0.133f, 0.267f);
        var wrapDark   = new Color(0.047f, 0.067f, 0.149f);
        var strap      = new Color(0.812f, 0.694f, 0.435f);
        var strapHi    = new Color(0.945f, 0.855f, 0.639f);

        // ── Pommel (kashira) at bottom ──
        FillRect(t, 27, 0, 10, 3, bronzeDark);
        FillRect(t, 28, 1, 8, 2, bronze);
        Px(t, 30, 2, gold); Px(t, 33, 2, gold);

        // ── Handle (tsuka) — wrapped silk ──
        // Base wrap column
        FillRect(t, 28, 3, 10, 14, wrap);
        for (int y = 3; y < 17; y++)
        {
            Px(t, 27, y, wrapDark);
            Px(t, 37, y, wrapDark);
            Px(t, 28, y, wrapDark);
            Px(t, 36, y, wrapDark);
        }
        // Diagonal cross-wrap pattern: forward (/) and back (\) straps every 4 px.
        for (int i = 0; i < 4; i++)
        {
            int y = 4 + i * 3;
            // Forward diagonal — crosses handle up-right
            Px(t, 29, y,     strap);
            Px(t, 30, y + 1, strapHi);
            Px(t, 31, y + 2, strap);
            // Back diagonal — crosses handle up-left
            Px(t, 35, y,     strap);
            Px(t, 34, y + 1, strapHi);
            Px(t, 33, y + 2, strap);
        }
        // Centre diamond accent (menuki)
        Px(t, 32, 9, gold);
        Px(t, 31, 10, gold); Px(t, 33, 10, gold);
        Px(t, 32, 11, gold);

        // ── Tsuba (guard) ──
        // Wide decorative oval guard
        FillRect(t, 22, 17, 20, 5, bronzeDark);
        FillRect(t, 23, 18, 18, 3, bronze);
        // Upper gold trim
        for (int x = 23; x < 41; x++) Px(t, x, 20, bronzeHi);
        Px(t, 22, 19, bronzeDark); Px(t, 41, 19, bronzeDark);
        // Gold pin in the middle
        FillRect(t, 31, 19, 2, 1, gold);
        // Small decorative dots
        Px(t, 25, 19, gold); Px(t, 38, 19, gold);

        // ── Habaki (blade collar) ──
        FillRect(t, 29, 22, 6, 3, bladeLow);
        FillRect(t, 30, 23, 4, 1, bladeCore);
        Px(t, 29, 22, bronzeDark);
        Px(t, 34, 22, bronzeDark);

        // ── Blade (long narrow steel, 4 px wide, 30 tall) ──
        for (int y = 25; y < 55; y++)
        {
            Px(t, 30, y, bladeShade); // spine/left shadow
            Px(t, 31, y, bladeCore);
            Px(t, 32, y, bladeHi);
            Px(t, 33, y, bladeEdge);  // cutting edge highlight
        }
        // Hamon (wavy temper line) — small lighter speckles along blade
        Px(t, 31, 29, bladeEdge);
        Px(t, 31, 34, bladeEdge);
        Px(t, 31, 40, bladeEdge);
        Px(t, 31, 47, bladeEdge);
        Px(t, 31, 52, bladeEdge);
        // Subtle shine streak
        Px(t, 32, 33, Color.white);
        Px(t, 32, 45, Color.white);

        // ── Kissaki (tapered tip) ──
        Px(t, 30, 55, bladeShade); Px(t, 33, 55, bladeEdge);
        Px(t, 31, 56, bladeCore);  Px(t, 32, 56, bladeHi);
        Px(t, 31, 57, bladeHi);    Px(t, 32, 57, bladeEdge);
        Px(t, 32, 58, bladeEdge);
        Px(t, 32, 59, Color.white); // tip sparkle
    }

    // ─── Bomb cursor sprite (64x64, centre pivot, idle pulse) ───
    static void DrawBombWeapon(Texture2D t)
    {
        // Body (near-black with cool shading)
        var bodyCore  = new Color(0.125f, 0.133f, 0.161f);
        var bodyDark  = new Color(0.055f, 0.063f, 0.086f);
        var bodyHi    = new Color(0.314f, 0.325f, 0.369f);
        var bodyShine = new Color(0.549f, 0.565f, 0.631f);
        var bodySpec  = new Color(0.839f, 0.855f, 0.902f);

        // Cap + band (brushed steel)
        var steel     = new Color(0.369f, 0.388f, 0.435f);
        var steelHi   = new Color(0.576f, 0.592f, 0.643f);
        var steelDark = new Color(0.212f, 0.224f, 0.263f);

        // Fuse (frayed rope)
        var fuse      = new Color(0.671f, 0.482f, 0.208f);
        var fuseDark  = new Color(0.431f, 0.294f, 0.094f);
        var fuseHi    = new Color(0.820f, 0.624f, 0.333f);

        // Flame
        var flameOut  = new Color(1.000f, 0.459f, 0.110f);
        var flameMid  = new Color(1.000f, 0.722f, 0.216f);
        var flameIn   = new Color(1.000f, 0.945f, 0.529f);
        var flameCore = new Color(1.000f, 1.000f, 0.855f);

        // Centre the whole bomb in the sprite so the centre pivot lands on the body.
        int cx = 28, cy = 24;

        // ── Body (round) ──
        FillCircle(t, cx, cy, 18, bodyDark);
        FillCircle(t, cx, cy, 16, bodyCore);
        // Upper-left shine crescent
        FillCircle(t, cx - 6, cy + 5, 6, bodyHi);
        FillCircle(t, cx - 7, cy + 6, 3, bodyShine);
        Px(t, cx - 8, cy + 7, bodySpec);
        Px(t, cx - 7, cy + 7, bodySpec);
        // Secondary small shine lower-left
        Px(t, cx - 11, cy - 1, bodyHi);
        Px(t, cx - 11, cy,     bodyShine);
        // Subtle bottom glow (light bounce)
        for (int x = -10; x <= 10; x++)
            if (x * x + 14 * 14 <= 16 * 16)
                Px(t, cx + x, cy - 14, bodyHi);

        // ── Metal band around the top (where the cap bolts on) ──
        FillRect(t, cx - 8, cy + 13, 16, 3, steelDark);
        FillRect(t, cx - 7, cy + 14, 14, 1, steel);
        for (int x = cx - 6; x < cx + 7; x++) Px(t, x, cy + 15, steelHi);

        // ── Cap (small cylinder on top) ──
        FillRect(t, cx - 4, cy + 16, 8, 4, steelDark);
        FillRect(t, cx - 3, cy + 17, 6, 2, steel);
        for (int x = cx - 3; x < cx + 3; x++) Px(t, x, cy + 19, steelHi);
        // Bolt heads on the cap
        Px(t, cx - 3, cy + 16, steelHi); Px(t, cx + 2, cy + 16, steelHi);

        // ── Fuse (wavy cord from cap up and to the right) ──
        for (int i = 0; i < 12; i++)
        {
            int fx = cx + i;
            int fy = cy + 20 + i + Mathf.RoundToInt(Mathf.Sin(i * 0.9f) * 1.5f);
            Px(t, fx,     fy,     fuseDark);
            Px(t, fx,     fy + 1, fuse);
            Px(t, fx + 1, fy + 1, fuseHi);
        }

        // ── Flame at the end of the fuse ──
        int ftx = cx + 14, fty = cy + 34;
        FillCircle(t, ftx,     fty,     4, flameOut);
        FillCircle(t, ftx,     fty + 1, 3, flameMid);
        FillCircle(t, ftx - 1, fty + 2, 2, flameIn);
        Px(t, ftx - 1, fty + 3, flameCore);
        // Upward flame tongue
        Px(t, ftx,     fty + 5, flameOut);
        Px(t, ftx - 1, fty + 5, flameMid);
        Px(t, ftx,     fty + 6, flameMid);
        // Sparks around the flame
        Px(t, ftx + 5, fty + 1, flameOut);
        Px(t, ftx + 4, fty + 4, flameIn);
        Px(t, ftx - 5, fty - 1, flameOut);
        Px(t, ftx + 2, fty + 7, flameMid);
    }

    // ─── Smoke puff VFX (64x64, centre pivot) ───
    // Soft grey cloud with noisy radial falloff. The SmokePuff component expands
    // and fades the sprite at runtime, so the texture itself is static.
    static void DrawSmokePuff(Texture2D t)
    {
        int cx = 32, cy = 32;
        int maxR = 30;
        var rng = new System.Random(314);

        // Base radial cloud
        for (int y = 0; y < 64; y++)
        {
            for (int x = 0; x < 64; x++)
            {
                int dx = x - cx, dy = y - cy;
                float dist = Mathf.Sqrt(dx * dx + dy * dy);
                if (dist > maxR) continue;

                float radial = 1f - dist / maxR;
                float noise = (float)rng.NextDouble();
                // Combine radial falloff with noise for a wispy edge.
                float alpha = Mathf.Clamp01(Mathf.Pow(radial, 1.8f) * (0.7f + noise * 0.6f));
                float shade = 0.72f + noise * 0.12f;
                Px(t, x, y, new Color(shade, shade, shade * 0.97f, alpha * 0.88f));
            }
        }

        // A handful of denser internal puffs for a cloudier, more structured look.
        int[][] puffs =
        {
            new[] { 28, 30, 8 },
            new[] { 38, 34, 7 },
            new[] { 24, 38, 6 },
            new[] { 36, 24, 6 },
            new[] { 32, 40, 5 },
        };
        foreach (var p in puffs)
        {
            int px = p[0], py = p[1], r = p[2];
            for (int y = -r; y <= r; y++)
            {
                for (int x = -r; x <= r; x++)
                {
                    float d = Mathf.Sqrt(x * x + y * y);
                    if (d > r) continue;
                    int tx = px + x, ty = py + y;
                    if (tx < 0 || tx >= 64 || ty < 0 || ty >= 64) continue;
                    float a = Mathf.Pow(1f - d / r, 2f) * 0.6f;
                    Color existing = t.GetPixel(tx, ty);
                    float aNew = Mathf.Min(1f, existing.a + a);
                    float sNew = 0.8f;
                    Px(t, tx, ty, new Color(sNew, sNew, sNew * 0.98f, aNew));
                }
            }
        }

        // A few bright highlight pixels on the upper-left of each puff for a pinch of volume.
        foreach (var p in puffs)
        {
            int hx = p[0] - 2, hy = p[1] + 2;
            Px(t, hx,     hy,     new Color(0.95f, 0.95f, 0.97f, 0.55f));
            Px(t, hx + 1, hy,     new Color(0.95f, 0.95f, 0.97f, 0.4f));
            Px(t, hx,     hy + 1, new Color(0.95f, 0.95f, 0.97f, 0.4f));
        }
    }

    // ─── Mole Sprites ───

    enum MoleFeature { None, SpeedLines, Helmet, Sparkle, Fuse, Mask, SplitLine }

    static void DrawMole(Texture2D t, Color body, Color belly, MoleFeature feature)
    {
        int cx = 32, cy = 28;

        // Body (main oval)
        FillOval(t, cx, cy, 22, 24, body);

        // Belly (lighter oval)
        FillOval(t, cx, cy - 4, 14, 16, belly);

        // Ears
        var earCol = Color.Lerp(body, Color.black, 0.2f);
        FillCircle(t, cx - 16, cy + 16, 6, earCol);
        FillCircle(t, cx + 16, cy + 16, 6, earCol);
        // Inner ear
        var innerEar = Color.Lerp(belly, new Color(0.8f, 0.5f, 0.5f), 0.5f);
        FillCircle(t, cx - 16, cy + 16, 3, innerEar);
        FillCircle(t, cx + 16, cy + 16, 3, innerEar);

        // Eyes (white + pupil)
        FillOval(t, cx - 8, cy + 8, 5, 6, Color.white);
        FillOval(t, cx + 8, cy + 8, 5, 6, Color.white);
        FillCircle(t, cx - 7, cy + 9, 3, new Color(0.1f, 0.1f, 0.1f));
        FillCircle(t, cx + 7, cy + 9, 3, new Color(0.1f, 0.1f, 0.1f));
        // Eye shine
        Px(t, cx - 6, cy + 11, Color.white);
        Px(t, cx + 8, cy + 11, Color.white);

        // Nose
        FillOval(t, cx, cy + 4, 4, 3, new Color(0.3f, 0.15f, 0.1f));
        // Nose shine
        Px(t, cx - 1, cy + 5, new Color(0.5f, 0.3f, 0.25f));

        // Mouth
        Px(t, cx - 2, cy + 1, new Color(0.25f, 0.12f, 0.08f));
        Px(t, cx - 1, cy, new Color(0.25f, 0.12f, 0.08f));
        Px(t, cx, cy, new Color(0.25f, 0.12f, 0.08f));
        Px(t, cx + 1, cy, new Color(0.25f, 0.12f, 0.08f));
        Px(t, cx + 2, cy + 1, new Color(0.25f, 0.12f, 0.08f));

        // Whiskers
        var whisker = new Color(0.3f, 0.2f, 0.15f, 0.7f);
        for (int i = 0; i < 8; i++) { Px(t, cx - 14 - i, cy + 5, whisker); Px(t, cx + 14 + i, cy + 5, whisker); }
        for (int i = 0; i < 7; i++) { Px(t, cx - 13 - i, cy + 3, whisker); Px(t, cx + 13 + i, cy + 3, whisker); }

        // Feature-specific additions
        switch (feature)
        {
            case MoleFeature.SpeedLines:
                var line = new Color(0.7f, 0.85f, 1f, 0.6f);
                for (int i = 0; i < 10; i++) { Px(t, cx - 26 + i, cy + 14, line); Px(t, cx - 28 + i, cy + 8, line); Px(t, cx - 25 + i, cy + 2, line); }
                break;

            case MoleFeature.Helmet:
                var helmet = new Color(0.4f, 0.4f, 0.45f);
                for (int x = -18; x <= 18; x++)
                    for (int y = 12; y <= 24; y++)
                        if (x * x + (y - 12) * (y - 12) < 20 * 20 && y > 12)
                            Px(t, cx + x, cy + y, helmet);
                // Visor shine
                for (int i = 0; i < 6; i++) Px(t, cx - 8 + i, cy + 22, new Color(0.7f, 0.7f, 0.75f, 0.5f));
                break;

            case MoleFeature.Sparkle:
                var spark = new Color(1f, 1f, 0.7f);
                int[] sx = { 5, 50, 28, 10, 48 }; int[] sy = { 50, 45, 55, 35, 20 };
                for (int i = 0; i < 5; i++) { Px(t, sx[i], sy[i], spark); Px(t, sx[i]+1, sy[i], spark); Px(t, sx[i], sy[i]+1, spark); Px(t, sx[i]-1, sy[i], spark); Px(t, sx[i], sy[i]-1, spark); }
                break;

            case MoleFeature.Fuse:
                // Fuse on top
                var fuse = new Color(0.3f, 0.3f, 0.3f);
                for (int i = 0; i < 8; i++) Px(t, cx + 2 + i / 2, cy + 24 + i, fuse);
                // Spark at tip
                Px(t, cx + 5, cy + 32, new Color(1f, 0.8f, 0f));
                Px(t, cx + 6, cy + 33, new Color(1f, 0.5f, 0f));
                Px(t, cx + 4, cy + 33, new Color(1f, 0.6f, 0.1f));
                // Warning X on eyes
                var warn = new Color(1f, 0.2f, 0.2f);
                Px(t, cx - 9, cy + 11, warn); Px(t, cx - 5, cy + 7, warn);
                Px(t, cx - 5, cy + 11, warn); Px(t, cx - 9, cy + 7, warn);
                Px(t, cx + 5, cy + 11, warn); Px(t, cx + 9, cy + 7, warn);
                Px(t, cx + 9, cy + 11, warn); Px(t, cx + 5, cy + 7, warn);
                break;

            case MoleFeature.Mask:
                var mask = new Color(0.1f, 0.1f, 0.15f, 0.85f);
                FillRect(t, cx - 14, cy + 6, 28, 8, mask);
                // Eye slits
                FillRect(t, cx - 10, cy + 8, 6, 4, Color.clear);
                FillRect(t, cx + 4, cy + 8, 6, 4, Color.clear);
                // Redraw eyes in slits
                FillOval(t, cx - 7, cy + 9, 3, 2, new Color(0.6f, 0.8f, 0.6f));
                FillOval(t, cx + 7, cy + 9, 3, 2, new Color(0.6f, 0.8f, 0.6f));
                break;

            case MoleFeature.SplitLine:
                var split = new Color(0.8f, 1f, 0.8f, 0.7f);
                for (int y2 = 4; y2 < 50; y2++) Px(t, cx, cy - 24 + y2, split);
                // Arrow tips
                Px(t, cx - 1, cy + 24, split); Px(t, cx + 1, cy + 24, split);
                Px(t, cx - 2, cy + 23, split); Px(t, cx + 2, cy + 23, split);
                break;
        }
    }

    // ════════════════════════════════════════════
    // SCRIPTABLE OBJECTS
    // ════════════════════════════════════════════

    static void CreateMoleData()
    {
        MoleDataSO("NormalMole", "Normal", 1, 10, 1.5f, "Moles/NormalMole");
        MoleDataSO("FastMole", "Fast", 1, 20, 0.6f, "Moles/FastMole");
        MoleDataSO("ArmoredMole", "Armored", 3, 30, 2.5f, "Moles/ArmoredMole");
        MoleDataSO("GoldenMole", "Golden", 1, 50, 0.8f, "Moles/GoldenMole");
        MoleDataSO("BombMole", "Bomb", 1, 25, 1.8f, "Moles/BombMole");
        MoleDataSO("StealthMole", "Stealth", 1, 40, 1.5f, "Moles/StealthMole");
        MoleDataSO("SplitterMole", "Splitter", 1, 15, 1.5f, "Moles/SplitterMole");
    }

    static void MoleDataSO(string file, string name, int hp, int score, float vis, string spriteKey)
    {
        string path = $"Assets/_Project/ScriptableObjects/MoleData/{file}.asset";
        var d = ScriptableObject.CreateInstance<MoleData>();
        d.moleName = name;
        d.maxHitPoints = hp;
        d.scoreValue = score;
        d.visibleTime = vis;
        d.sprite = S(spriteKey); // Assign the generated sprite
        d.tintColor = Color.white; // Sprite has baked colors
        AssetDatabase.CreateAsset(d, path);
    }

    static void CreateWeapons()
    {
        SO<HammerWeapon>("Assets/_Project/Resources/Weapons/Hammer.asset", w => {
            w.weaponName = "Hammer";
            w.BaseDamage = 1;
            w.Cooldown = 0.2f;
            w.HitRadius = 0.5f;
            w.cursorSprite = S("Weapons/Hammer");
            // Pommel pivot sits 46 px below the face centre (46/64 × 1.8 scale ≈ 1.29375).
            w.cursorWorldOffset = new Vector2(0f, 1.29375f);
        });
        SO<KatanaWeapon>("Assets/_Project/Resources/Weapons/Katana.asset", w => {
            w.weaponName = "Katana";
            w.BaseDamage = 1;
            w.Cooldown = 0.35f;
            w.HitRadius = 0.55f;
            w.cleaveRadius = 1.8f;
            w.cursorSprite = S("Weapons/Katana");
            w.cursorWorldOffset = Vector2.zero;
        });
        SO<BombWeapon>("Assets/_Project/Resources/Weapons/Bomb.asset", w => {
            w.weaponName = "Bomb";
            w.BaseDamage = 1;
            w.Cooldown = 0.8f;
            w.HitRadius = 0.8f;
            w.blastDamage = 99;
            w.cursorSprite = S("Weapons/Bomb");
            w.smokeSprite = S("VFX/Smoke");
            w.cursorWorldOffset = Vector2.zero;
        });
    }

    static void CreateLevels()
    {
        // Keep existing level SOs as polymorphism demonstrations
        SO<Level1_Backyard>("Assets/_Project/Resources/Levels/Level1_Backyard.asset", l => { l.levelNumber=1; l.displayName="Backyard Basics"; l.duration=60; l.baseSpawnInterval=1.5f; l.scoreTarget=80; l.twoStarScore=120; l.threeStarScore=180; });
        SO<Level2_Speed>("Assets/_Project/Resources/Levels/Level2_Speed.asset", l => { l.levelNumber=2; l.displayName="Speed Garden"; l.duration=75; l.baseSpawnInterval=1.2f; l.scoreTarget=150; l.twoStarScore=250; l.threeStarScore=400; });
        SO<Level3_Danger>("Assets/_Project/Resources/Levels/Level3_Danger.asset", l => { l.levelNumber=3; l.displayName="Danger Zone"; l.duration=75; l.baseSpawnInterval=1.0f; l.scoreTarget=200; l.twoStarScore=350; l.threeStarScore=500; });
        SO<Level4_Twilight>("Assets/_Project/Resources/Levels/Level4_Twilight.asset", l => { l.levelNumber=4; l.displayName="Twilight Burrow"; l.duration=90; l.baseSpawnInterval=0.9f; l.scoreTarget=300; l.twoStarScore=500; l.threeStarScore=700; });

        // DDA-driven endless level (used at runtime)
        SO<DifficultyLevel>("Assets/_Project/Resources/Levels/DifficultyLevel.asset", l => { l.levelNumber=0; l.displayName="Endless"; l.duration=float.MaxValue; l.baseSpawnInterval=1.5f; l.scoreTarget=int.MaxValue; });
    }

    // ════════════════════════════════════════════
    // MOLE PREFABS
    // ════════════════════════════════════════════

    static void CreateMolePrefabs()
    {
        MolePrefab<NormalMole>("NormalMole");
        MolePrefab<FastMole>("FastMole");
        MolePrefab<ArmoredMole>("ArmoredMole");
        MolePrefab<GoldenMole>("GoldenMole");
        MolePrefab<BombMole>("BombMole");
        MolePrefab<StealthMole>("StealthMole");
        MolePrefab<SplitterMole>("SplitterMole");
    }

    static void MolePrefab<T>(string name) where T : Mole
    {
        string path = $"Assets/_Project/Resources/MolePrefabs/{name}.prefab";

        var go = new GameObject(name);
        var spriteGO = new GameObject("Sprite");
        spriteGO.transform.SetParent(go.transform);
        var sr = spriteGO.AddComponent<SpriteRenderer>();
        sr.sortingOrder = 5;

        // Use the generated mole sprite
        var moleSprite = S($"Moles/{name}");
        sr.sprite = moleSprite;
        sr.color = Color.white; // Sprite has baked colors

        go.AddComponent<CircleCollider2D>().radius = 0.4f;
        var mole = go.AddComponent<T>();

        var data = AssetDatabase.LoadAssetAtPath<MoleData>($"Assets/_Project/ScriptableObjects/MoleData/{name}.asset");
        if (data != null)
        {
            var so = new SerializedObject(mole);
            so.FindProperty("data").objectReferenceValue = data;
            so.ApplyModifiedProperties();
        }

        go.SetActive(false);
        PrefabUtility.SaveAsPrefabAsset(go, path);
        Object.DestroyImmediate(go);
    }

    // ════════════════════════════════════════════
    // GAME SCENE
    // ════════════════════════════════════════════

    static void BuildGameScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Camera — larger ortho size for 5x5 board
        var cam = new GameObject("Main Camera");
        var c = cam.AddComponent<Camera>();
        c.orthographic = true; c.orthographicSize = 6.5f; c.clearFlags = CameraClearFlags.SolidColor;
        c.backgroundColor = new Color(0.45f, 0.7f, 0.95f); // Sky blue
        cam.transform.position = new Vector3(0, 0, -10);
        cam.tag = "MainCamera";
        cam.AddComponent<AudioListener>();
        cam.AddComponent<CameraShake>();

        // Farm background
        var bg = new GameObject("Background");
        var bgSR = bg.AddComponent<SpriteRenderer>();
        bgSR.sprite = S("Environment/FarmBg");
        bgSR.color = Color.white;
        bgSR.drawMode = SpriteDrawMode.Tiled;
        bgSR.size = new Vector2(28, 16);
        bg.transform.localScale = Vector3.one;
        bgSR.sortingOrder = -10;

        // Tilled soil platform under hole grid
        var soil = new GameObject("TilledSoil");
        var sSR = soil.AddComponent<SpriteRenderer>();
        sSR.sprite = S("Environment/TilledSoil");
        sSR.color = Color.white;
        sSR.drawMode = SpriteDrawMode.Tiled;
        sSR.size = new Vector2(11, 9);
        soil.transform.position = new Vector3(0, -0.5f, 0);
        sSR.sortingOrder = -9;

        // Fence decoration around the farm
        BuildFence();

        // Holes (5x5) with layered depth + carrots
        var grid = new GameObject("HoleGrid");
        grid.transform.position = Vector3.zero;

        float hSpacing = 1.7f, vSpacing = 1.5f;
        float startX = -hSpacing * 2, startY = vSpacing * 2 - 0.3f;

        for (int i = 0; i < 25; i++)
        {
            int row = i / 5, col = i % 5;
            float px = startX + col * hSpacing;
            float py = startY - row * vSpacing;

            var hole = new GameObject($"Hole_{i}");
            hole.transform.SetParent(grid.transform);
            hole.transform.localPosition = new Vector3(px, py, 0);

            // Soil mound back (behind moles)
            var moundBack = new GameObject("MoundBack");
            moundBack.transform.SetParent(hole.transform);
            moundBack.transform.localPosition = Vector3.zero;
            var mbSR = moundBack.AddComponent<SpriteRenderer>();
            mbSR.sprite = S("Environment/SoilMound");
            mbSR.color = Color.white;
            mbSR.sortingOrder = 1;

            // Carrot (between back and mole)
            var carrot = new GameObject("Carrot");
            carrot.transform.SetParent(hole.transform);
            carrot.transform.localPosition = new Vector3(0, 0.15f, 0);
            carrot.transform.localScale = new Vector3(0.7f, 0.7f, 1f);
            var crSR = carrot.AddComponent<SpriteRenderer>();
            crSR.sprite = S("Environment/Carrot");
            crSR.color = Color.white;
            crSR.sortingOrder = 3;

            // Spawn point (where moles appear)
            var sp = new GameObject("SpawnPoint");
            sp.transform.SetParent(hole.transform);
            sp.transform.localPosition = new Vector3(0, 0.15f, 0);

            // Soil mound front (in front of moles — creates depth)
            var moundFront = new GameObject("MoundFront");
            moundFront.transform.SetParent(hole.transform);
            moundFront.transform.localPosition = new Vector3(0, -0.2f, 0);
            var mfSR = moundFront.AddComponent<SpriteRenderer>();
            mfSR.sprite = S("Environment/SoilMoundFront");
            mfSR.color = Color.white;
            mfSR.sortingOrder = 10;

            var h = hole.AddComponent<Hole>();
            var so = new SerializedObject(h);
            so.FindProperty("spawnPoint").objectReferenceValue = sp.transform;
            so.FindProperty("holeIndex").intValue = i;
            so.FindProperty("carrotRenderer").objectReferenceValue = crSR;
            so.ApplyModifiedProperties();
        }

        // Managers
        new GameObject("GameManager").AddComponent<GameManager>();
        new GameObject("ScoreManager").AddComponent<ScoreManager>();
        new GameObject("AudioManager").AddComponent<AudioManager>();
        new GameObject("DifficultyManager").AddComponent<DifficultyManager>();
        new GameObject("CarrotManager").AddComponent<CarrotManager>();
        new GameObject("LevelManager").AddComponent<LevelManager>();
        new GameObject("MoleFactory").AddComponent<MoleFactory>();
        new GameObject("MoleSpawner").AddComponent<MoleSpawner>();
        new GameObject("GameInitializer").AddComponent<GameInitializer>();

        // Weapon controller
        var wcGO = new GameObject("WeaponController");
        var wc = wcGO.AddComponent<WeaponController>();

        // UI
        BuildGameUI();

        // EventSystem
        var es = new GameObject("EventSystem");
        es.AddComponent<UnityEngine.EventSystems.EventSystem>();
        es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();

        BuildFloatingScores();

        EditorSceneManager.SaveScene(scene, "Assets/_Project/Scenes/Game.unity");
    }

    static void BuildFence()
    {
        float boardLeft = -4.5f, boardRight = 4.5f;
        float boardTop = 3.8f, boardBot = -3.2f;

        // Top rail
        var topRail = new GameObject("FenceTopRail");
        var trSR = topRail.AddComponent<SpriteRenderer>();
        trSR.sprite = S("Environment/FenceH");
        trSR.drawMode = SpriteDrawMode.Tiled;
        trSR.size = new Vector2(10f, 0.25f);
        trSR.sortingOrder = -5;
        topRail.transform.position = new Vector3(0, boardTop + 0.3f, 0);

        // Bottom rail
        var botRail = new GameObject("FenceBotRail");
        var brSR = botRail.AddComponent<SpriteRenderer>();
        brSR.sprite = S("Environment/FenceH");
        brSR.drawMode = SpriteDrawMode.Tiled;
        brSR.size = new Vector2(10f, 0.25f);
        brSR.sortingOrder = -5;
        botRail.transform.position = new Vector3(0, boardBot - 0.3f, 0);

        // Corner posts
        float[] postX = { boardLeft - 0.3f, boardRight + 0.3f };
        float[] postY = { boardTop + 0.3f, boardBot - 0.3f };
        for (int px = 0; px < 2; px++)
            for (int py = 0; py < 2; py++)
            {
                var post = new GameObject($"FencePost_{px}_{py}");
                var pSR = post.AddComponent<SpriteRenderer>();
                pSR.sprite = S("Environment/FencePost");
                pSR.sortingOrder = -4;
                post.transform.position = new Vector3(postX[px], postY[py], 0);
                post.transform.localScale = new Vector3(0.8f, 0.8f, 1f);
            }
    }

    // ─── Color Palette (shared across all panels) ───
    static readonly Color COL_OVERLAY   = new(0, 0, 0, 0.82f);
    static readonly Color COL_CARD      = new(0.12f, 0.16f, 0.22f, 0.75f);
    static readonly Color COL_CARD_EDGE = new(0.25f, 0.55f, 0.3f, 0.6f);
    static readonly Color COL_BTN       = new(0.18f, 0.4f, 0.2f, 0.95f);
    static readonly Color COL_BTN_HI    = new(0.25f, 0.55f, 0.28f);
    static readonly Color COL_BTN_PR    = new(0.1f, 0.25f, 0.12f);
    static readonly Color COL_BTN_SEC   = new(0.25f, 0.25f, 0.3f, 0.9f);
    static readonly Color COL_BTN_SEC_HI= new(0.35f, 0.35f, 0.42f);
    static readonly Color COL_GOLD      = new(1f, 0.85f, 0.2f);
    static readonly Color COL_SUBTITLE  = new(0.7f, 0.8f, 0.7f);

    static void BuildGameUI()
    {
        var canvas = MakeCanvas("HUD Canvas", 10);

        // ─── HUD Bar (top) ───
        var hudBar = Img(canvas, "HudBar", new Vector2(0, 500), new Vector2(1920, 80), new Color(0.08f, 0.12f, 0.08f, 0.7f));
        var hudBarR = hudBar.GetComponent<RectTransform>();
        hudBarR.anchorMin = new Vector2(0, 1); hudBarR.anchorMax = new Vector2(1, 1);
        hudBarR.pivot = new Vector2(0.5f, 1); hudBarR.anchoredPosition = Vector2.zero;
        hudBarR.sizeDelta = new Vector2(0, 80);

        var score = Txt(hudBar, "ScoreText", "0", 44, new Vector2(-750, 0), TextAlignmentOptions.Left);
        var combo = Txt(hudBar, "ComboText", "", 26, new Vector2(-550, 0), TextAlignmentOptions.Left);
        combo.SetActive(false);
        var mult = Txt(hudBar, "MultText", "", 30, new Vector2(-550, 0));
        mult.SetActive(false);

        var timerBG = Img(hudBar, "TimerBG", new Vector2(0, -5), new Vector2(500, 20), new Color(0.15f, 0.15f, 0.18f));
        var timerFill = Img(timerBG, "TimerFill", Vector2.zero, Vector2.zero, new Color(0.3f, 0.75f, 0.35f));
        var tfR = timerFill.GetComponent<RectTransform>();
        tfR.anchorMin = Vector2.zero; tfR.anchorMax = Vector2.one; tfR.sizeDelta = Vector2.zero;
        var tfImg = timerFill.GetComponent<Image>();
        tfImg.type = Image.Type.Filled; tfImg.fillMethod = Image.FillMethod.Horizontal;

        var timerTxt = Txt(hudBar, "TimerText", "0%", 22, new Vector2(0, -30));
        var levelTxt = Txt(hudBar, "LevelText", "Easy", 30, new Vector2(450, 0), TextAlignmentOptions.Right);
        var carrotTxt = Txt(hudBar, "CarrotText", "Carrots: 25/25", 24, new Vector2(700, 0), TextAlignmentOptions.Right);
        carrotTxt.GetComponent<TextMeshProUGUI>().color = new Color(1f, 0.7f, 0.2f);
        var pauseBtn = BtnStyled(hudBar, "PauseBtn", "| |", new Vector2(850, 0), new Vector2(55, 45), COL_BTN_SEC, COL_BTN_SEC_HI, COL_BTN_PR, 22);

        var hud = canvas.AddComponent<HUDController>();
        Wire(hud, "scoreText", score.GetComponent<TextMeshProUGUI>());
        Wire(hud, "comboText", combo.GetComponent<TextMeshProUGUI>());
        Wire(hud, "multiplierText", mult.GetComponent<TextMeshProUGUI>());
        Wire(hud, "timerBar", tfImg);
        Wire(hud, "timerText", timerTxt.GetComponent<TextMeshProUGUI>());
        Wire(hud, "levelText", levelTxt.GetComponent<TextMeshProUGUI>());
        Wire(hud, "carrotCountText", carrotTxt.GetComponent<TextMeshProUGUI>());
        Wire(hud, "pauseButton", pauseBtn.GetComponent<Button>());

        // ─── LEVEL COMPLETE Panel ───
        var lcP = OverlayPanel(canvas, "LevelCompletePanel");
        var lcCard = Card(lcP, "LevelCompleteCard", new Vector2(500, 480));
        // Decorative top line
        Img(lcCard, "TopAccent", new Vector2(0, 210), new Vector2(400, 4), COL_GOLD);
        var lcTitle = Txt(lcCard, "Title", "LEVEL COMPLETE!", 42, new Vector2(0, 170));
        lcTitle.GetComponent<TextMeshProUGUI>().color = COL_GOLD;
        Img(lcCard, "Divider1", new Vector2(0, 140), new Vector2(300, 2), new Color(1,1,1,0.1f));
        var lcScore = Txt(lcCard, "Score", "Score: 0", 32, new Vector2(0, 100));
        // Stars row
        var s1 = Txt(lcCard, "S1", "★", 56, new Vector2(-55, 40));
        s1.GetComponent<TextMeshProUGUI>().color = COL_GOLD;
        var s2 = Txt(lcCard, "S2", "★", 56, new Vector2(0, 40));
        s2.GetComponent<TextMeshProUGUI>().color = COL_GOLD;
        var s3 = Txt(lcCard, "S3", "★", 56, new Vector2(55, 40));
        s3.GetComponent<TextMeshProUGUI>().color = COL_GOLD;
        Img(lcCard, "Divider2", new Vector2(0, -5), new Vector2(300, 2), new Color(1,1,1,0.1f));
        var lcNext = BtnStyled(lcCard, "NextLevel", "NEXT LEVEL", new Vector2(0, -55), new Vector2(300, 60), COL_BTN, COL_BTN_HI, COL_BTN_PR, 26);
        var lcMenu = BtnStyled(lcCard, "LCMenu", "Main Menu", new Vector2(0, -130), new Vector2(220, 48), COL_BTN_SEC, COL_BTN_SEC_HI, COL_BTN_PR, 22);
        // Bottom accent
        Img(lcCard, "BotAccent", new Vector2(0, -210), new Vector2(400, 4), COL_CARD_EDGE);

        var lc = canvas.AddComponent<LevelCompleteUI>();
        Wire(lc, "panel", lcP);
        Wire(lc, "levelNameText", lcTitle.GetComponent<TextMeshProUGUI>());
        Wire(lc, "scoreText", lcScore.GetComponent<TextMeshProUGUI>());
        Wire(lc, "nextLevelButton", lcNext.GetComponent<Button>());
        Wire(lc, "mainMenuButton", lcMenu.GetComponent<Button>());
        WireArray(lc, "starIcons", new Object[] { s1, s2, s3 });

        // ─── GAME OVER / VICTORY Panel ───
        var goP = OverlayPanel(canvas, "GameOverPanel");
        var goCard = Card(goP, "GameOverCard", new Vector2(500, 460));
        Img(goCard, "TopAccent", new Vector2(0, 200), new Vector2(400, 4), new Color(0.9f, 0.25f, 0.2f));
        var goH = Txt(goCard, "Header", "GAME OVER", 46, new Vector2(0, 155));
        goH.GetComponent<TextMeshProUGUI>().color = new Color(1f, 0.4f, 0.35f);
        Img(goCard, "Divider1", new Vector2(0, 125), new Vector2(300, 2), new Color(1,1,1,0.1f));
        var goS = Txt(goCard, "Score", "Score: 0", 32, new Vector2(0, 80));
        var goHS = Txt(goCard, "HighScore", "High Score: 0", 24, new Vector2(0, 35));
        goHS.GetComponent<TextMeshProUGUI>().color = COL_SUBTITLE;
        Img(goCard, "Divider2", new Vector2(0, 0), new Vector2(300, 2), new Color(1,1,1,0.1f));
        var goRetry = BtnStyled(goCard, "Retry", "RETRY", new Vector2(0, -55), new Vector2(300, 60), COL_BTN, COL_BTN_HI, COL_BTN_PR, 26);
        var goMenu = BtnStyled(goCard, "GOMenu", "Main Menu", new Vector2(0, -130), new Vector2(220, 48), COL_BTN_SEC, COL_BTN_SEC_HI, COL_BTN_PR, 22);
        Img(goCard, "BotAccent", new Vector2(0, -200), new Vector2(400, 4), new Color(0.9f, 0.25f, 0.2f, 0.4f));

        var goUI = canvas.AddComponent<GameOverUI>();
        Wire(goUI, "panel", goP);
        Wire(goUI, "headerText", goH.GetComponent<TextMeshProUGUI>());
        Wire(goUI, "finalScoreText", goS.GetComponent<TextMeshProUGUI>());
        Wire(goUI, "highScoreText", goHS.GetComponent<TextMeshProUGUI>());
        Wire(goUI, "retryButton", goRetry.GetComponent<Button>());
        Wire(goUI, "mainMenuButton", goMenu.GetComponent<Button>());

        // ─── PAUSE Panel ───
        var pP = OverlayPanel(canvas, "PausePanel");
        var pCard = Card(pP, "PauseCard", new Vector2(460, 420));
        Img(pCard, "TopAccent", new Vector2(0, 180), new Vector2(360, 4), COL_CARD_EDGE);
        var pTitle = Txt(pCard, "Title", "PAUSED", 46, new Vector2(0, 140));
        pTitle.GetComponent<TextMeshProUGUI>().color = COL_SUBTITLE;
        Img(pCard, "Divider", new Vector2(0, 105), new Vector2(280, 2), new Color(1,1,1,0.1f));
        var pRes = BtnStyled(pCard, "Resume", "RESUME", new Vector2(0, 50), new Vector2(300, 60), COL_BTN, COL_BTN_HI, COL_BTN_PR, 26);
        var pRst = BtnStyled(pCard, "Restart", "Restart", new Vector2(0, -25), new Vector2(260, 50), COL_BTN_SEC, COL_BTN_SEC_HI, COL_BTN_PR, 22);
        var pMnu = BtnStyled(pCard, "PauseMenu", "Main Menu", new Vector2(0, -95), new Vector2(260, 50), COL_BTN_SEC, COL_BTN_SEC_HI, COL_BTN_PR, 22);
        Img(pCard, "BotAccent", new Vector2(0, -180), new Vector2(360, 4), COL_CARD_EDGE);

        var pm = canvas.AddComponent<PauseMenu>();
        Wire(pm, "panel", pP);
        Wire(pm, "resumeButton", pRes.GetComponent<Button>());
        Wire(pm, "restartButton", pRst.GetComponent<Button>());
        Wire(pm, "mainMenuButton", pMnu.GetComponent<Button>());
    }

    static void BuildFloatingScores()
    {
        string path = "Assets/_Project/Prefabs/UI/FloatingScorePopup.prefab";
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        if (prefab == null)
        {
            var go = new GameObject("FloatingScorePopup");
            var t = go.AddComponent<TextMeshPro>();
            t.alignment = TextAlignmentOptions.Center; t.fontSize = 8; t.sortingOrder = 50;
            go.AddComponent<FloatingScorePopup>();
            go.SetActive(false);
            prefab = PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }
        var spawner = new GameObject("FloatingScoreSpawner").AddComponent<FloatingScoreSpawner>();
        Wire(spawner, "popupPrefab", prefab.GetComponent<FloatingScorePopup>());
    }

    // ════════════════════════════════════════════
    // MAIN MENU SCENE
    // ════════════════════════════════════════════

    static void BuildMainMenuScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Dark gradient-feel background
        var cam = new GameObject("Main Camera");
        var c = cam.AddComponent<Camera>();
        c.orthographic = true; c.orthographicSize = 5f; c.clearFlags = CameraClearFlags.SolidColor;
        c.backgroundColor = new Color(0.06f, 0.1f, 0.18f);
        cam.transform.position = new Vector3(0, 0, -10);
        cam.tag = "MainCamera"; cam.AddComponent<AudioListener>();

        // Mole gallery along the bottom so players see what they'll encounter.
        var gallery = new (string sprite, string label)[] {
            ("Moles/NormalMole",   "Normal"),
            ("Moles/FastMole",     "Fast"),
            ("Moles/ArmoredMole",  "Armored"),
            ("Moles/GoldenMole",   "Golden"),
            ("Moles/BombMole",     "Bomb"),
            ("Moles/StealthMole",  "Stealth"),
            ("Moles/SplitterMole", "Splitter"),
        };
        const float galleryY = -3.7f;
        const float gallerySpacing = 1.8f;
        const float galleryStartX = -gallerySpacing * 3;
        const float galleryScale = 0.7f;
        for (int i = 0; i < gallery.Length; i++)
        {
            float x = galleryStartX + i * gallerySpacing;
            AddMenuMole(gallery[i].sprite, gallery[i].label, new Vector3(x, galleryY, 0), galleryScale);
        }

        var canvas = MakeCanvas("Canvas", 0);

        // Central card — shorter than before so the gallery below has breathing room
        var menuCard = Card(canvas, "MenuCard", new Vector2(550, 500));

        // Title section
        Img(menuCard, "TopAccent", new Vector2(0, 220), new Vector2(450, 5), COL_GOLD);
        var title = Txt(menuCard, "Title", "WHAT A MOLE", 60, new Vector2(0, 160));
        title.GetComponent<TextMeshProUGUI>().color = COL_GOLD;
        Img(menuCard, "Divider1", new Vector2(0, 90), new Vector2(350, 2), new Color(1,1,1,0.08f));

        // High score
        var hi = Txt(menuCard, "HighScore", "High Score: 0", 24, new Vector2(0, 50));
        hi.GetComponent<TextMeshProUGUI>().color = new Color(0.8f, 0.8f, 0.6f);

        Img(menuCard, "Divider2", new Vector2(0, 5), new Vector2(350, 2), new Color(1,1,1,0.08f));

        // Buttons
        var play = BtnStyled(menuCard, "Play", "PLAY", new Vector2(0, -60), new Vector2(320, 70), COL_BTN, COL_BTN_HI, COL_BTN_PR, 30);

        Img(menuCard, "BotAccent", new Vector2(0, -220), new Vector2(450, 5), COL_CARD_EDGE);

        // Footer
        var footer = Txt(menuCard, "Footer", "A Hackathon Game", 16, new Vector2(0, -195));
        footer.GetComponent<TextMeshProUGUI>().color = new Color(0.4f, 0.45f, 0.4f);

        var menu = canvas.AddComponent<MainMenuUI>();
        Wire(menu, "playButton", play.GetComponent<Button>());
        Wire(menu, "highScoreText", hi.GetComponent<TextMeshProUGUI>());

        var es = new GameObject("EventSystem");
        es.AddComponent<UnityEngine.EventSystems.EventSystem>();
        es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();

        EditorSceneManager.SaveScene(scene, "Assets/_Project/Scenes/MainMenu.unity");
    }

    static void AddMenuMole(string spriteKey, string label, Vector3 pos, float scale)
    {
        var go = new GameObject("MenuMole_" + label);
        go.transform.position = pos;
        go.transform.localScale = new Vector3(scale, scale, 1);

        var spriteGO = new GameObject("Sprite");
        spriteGO.transform.SetParent(go.transform, false);
        var sr = spriteGO.AddComponent<SpriteRenderer>();
        sr.sprite = S(spriteKey);
        sr.color = Color.white;
        sr.sortingOrder = -1;

        var labelGO = new GameObject("Label");
        labelGO.transform.SetParent(go.transform, false);
        labelGO.transform.localPosition = new Vector3(0, -0.8f, 0);
        var tmp = labelGO.AddComponent<TextMeshPro>();
        tmp.text = label;
        tmp.fontSize = 3.5f;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.color = new Color(0.9f, 0.9f, 0.7f);
        tmp.sortingOrder = -1;
        var rt = tmp.rectTransform;
        rt.sizeDelta = new Vector2(3, 0.8f);
    }

    static void SetBuildScenes()
    {
        EditorBuildSettings.scenes = new[] {
            new EditorBuildSettingsScene("Assets/_Project/Scenes/MainMenu.unity", true),
            new EditorBuildSettingsScene("Assets/_Project/Scenes/Game.unity", true),
        };
    }

    // ════════════════════════════════════════════
    // UI HELPERS
    // ════════════════════════════════════════════

    static GameObject MakeCanvas(string name, int sort)
    {
        var go = new GameObject(name);
        var cv = go.AddComponent<Canvas>();
        cv.renderMode = RenderMode.ScreenSpaceOverlay; cv.sortingOrder = sort;
        var sc = go.AddComponent<CanvasScaler>();
        sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        sc.referenceResolution = new Vector2(1920, 1080);
        sc.matchWidthOrHeight = 0.5f;
        go.AddComponent<GraphicRaycaster>();
        return go;
    }

    /// <summary>Full-screen dark overlay that catches clicks behind the card.</summary>
    static GameObject OverlayPanel(GameObject parent, string name)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);
        go.AddComponent<Image>().color = COL_OVERLAY;
        var r = go.GetComponent<RectTransform>();
        r.anchorMin = Vector2.zero; r.anchorMax = Vector2.one; r.sizeDelta = Vector2.zero;
        return go;
    }

    /// <summary>Centered card with dark background and subtle border feel.</summary>
    static GameObject Card(GameObject parent, string name, Vector2 size)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);

        // Border/edge image (slightly larger)
        var border = new GameObject("Border");
        border.transform.SetParent(go.transform, false);
        border.AddComponent<Image>().color = COL_CARD_EDGE;
        var br = border.GetComponent<RectTransform>();
        br.anchorMin = Vector2.zero; br.anchorMax = Vector2.one;
        br.sizeDelta = new Vector2(4, 4); br.anchoredPosition = Vector2.zero;

        // Main card background
        go.AddComponent<Image>().color = COL_CARD;
        var r = go.GetComponent<RectTransform>();
        r.anchoredPosition = Vector2.zero; r.sizeDelta = size;
        return go;
    }

    static GameObject Txt(GameObject parent, string name, string text, int size, Vector2 p, TextAlignmentOptions a = TextAlignmentOptions.Center)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);
        var t = go.AddComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = size; t.alignment = a; t.color = Color.white;
        t.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
        go.GetComponent<RectTransform>().anchoredPosition = p;
        go.GetComponent<RectTransform>().sizeDelta = new Vector2(500, 80);
        return go;
    }

    /// <summary>Styled button with customizable colors.</summary>
    static GameObject BtnStyled(GameObject parent, string name, string label, Vector2 p, Vector2 sz,
        Color normal, Color highlight, Color pressed, int fontSize = 24)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);
        go.AddComponent<Image>().color = normal;
        var btn = go.AddComponent<Button>();
        var colors = btn.colors;
        colors.normalColor = Color.white;
        colors.highlightedColor = new Color(highlight.r/normal.r, highlight.g/Mathf.Max(normal.g,0.01f), highlight.b/Mathf.Max(normal.b,0.01f), 1f);
        colors.pressedColor = new Color(pressed.r/Mathf.Max(normal.r,0.01f), pressed.g/Mathf.Max(normal.g,0.01f), pressed.b/Mathf.Max(normal.b,0.01f), 1f);
        btn.colors = colors;
        // Just set direct colors instead of color multiply
        go.GetComponent<Image>().color = normal;
        var cb = btn.colors;
        cb.normalColor = normal;
        cb.highlightedColor = highlight;
        cb.pressedColor = pressed;
        cb.colorMultiplier = 1f;
        btn.colors = cb;

        var r = go.GetComponent<RectTransform>(); r.anchoredPosition = p; r.sizeDelta = sz;

        var tgo = new GameObject("Text");
        tgo.transform.SetParent(go.transform, false);
        var t = tgo.AddComponent<TextMeshProUGUI>();
        t.text = label; t.fontSize = fontSize; t.alignment = TextAlignmentOptions.Center; t.color = Color.white;
        t.fontStyle = FontStyles.Bold;
        var tr = tgo.GetComponent<RectTransform>();
        tr.anchorMin = Vector2.zero; tr.anchorMax = Vector2.one; tr.sizeDelta = Vector2.zero;
        return go;
    }

    static GameObject Img(GameObject parent, string name, Vector2 p, Vector2 sz, Color col)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);
        go.AddComponent<Image>().color = col;
        var r = go.GetComponent<RectTransform>(); r.anchoredPosition = p; r.sizeDelta = sz;
        return go;
    }

    // ════════════════════════════════════════════
    // WIRING HELPERS
    // ════════════════════════════════════════════

    static void Wire(Component comp, string prop, Object value)
    {
        var so = new SerializedObject(comp);
        so.FindProperty(prop).objectReferenceValue = value;
        so.ApplyModifiedProperties();
    }

    static void WireArray(Component comp, string prop, Object[] values)
    {
        var so = new SerializedObject(comp);
        var arr = so.FindProperty(prop);
        arr.arraySize = values.Length;
        for (int i = 0; i < values.Length; i++)
            arr.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
        so.ApplyModifiedProperties();
    }

    static void SO<T>(string path, System.Action<T> setup) where T : ScriptableObject
    {
        if (AssetDatabase.LoadAssetAtPath<T>(path) != null) return;
        var obj = ScriptableObject.CreateInstance<T>();
        setup(obj);
        AssetDatabase.CreateAsset(obj, path);
    }

    static void Folder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        var parts = path.Split('/');
        var cur = parts[0];
        for (int i = 1; i < parts.Length; i++)
        {
            var next = cur + "/" + parts[i];
            if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(cur, parts[i]);
            cur = next;
        }
    }
}
