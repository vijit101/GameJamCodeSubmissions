using UnityEngine;

namespace WhackAMole.Weapons
{
    /// <summary>
    /// Self-destroying smoke cloud. Expands + fades out over <see cref="duration"/>
    /// seconds then destroys its GameObject. Spawned by BombWeapon on detonation.
    /// </summary>
    public class SmokePuff : MonoBehaviour
    {
        [SerializeField] private float duration = 0.7f;

        private SpriteRenderer _sr;
        private float _elapsed;
        private float _startScale = 0.25f;
        private float _endScale = 1.5f;
        private float _startAlpha = 0.9f;

        public void Init(float endScale)
        {
            _endScale = Mathf.Max(0.1f, endScale);
            _sr = GetComponent<SpriteRenderer>();
            transform.localScale = Vector3.one * _startScale;
            if (_sr != null)
            {
                var c = _sr.color;
                c.a = _startAlpha;
                _sr.color = c;
            }
        }

        private void Update()
        {
            _elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(_elapsed / duration);

            // Ease-out on expansion so the puff blooms fast then settles.
            float easedScale = 1f - (1f - t) * (1f - t);
            transform.localScale = Vector3.one * Mathf.Lerp(_startScale, _endScale, easedScale);

            if (_sr != null)
            {
                var c = _sr.color;
                // Accelerating fade — stays visible early, disappears at the end.
                c.a = Mathf.Lerp(_startAlpha, 0f, t * t);
                _sr.color = c;
            }

            if (t >= 1f) Destroy(gameObject);
        }
    }
}
