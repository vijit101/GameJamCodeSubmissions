using System.Collections;
using UnityEngine;
using WhackAMole.Interfaces;
using WhackAMole.Utils;

namespace WhackAMole.Weapons
{
    /// <summary>
    /// Default weapon. Single-target, 1 damage, fastest cooldown.
    /// Hold the mouse for <see cref="Constants.HAMMER_CHARGE_TIME"/> seconds to
    /// deal <see cref="Constants.HAMMER_CHARGE_DAMAGE"/> damage on release —
    /// useful against ArmoredMole.
    /// </summary>
    [CreateAssetMenu(fileName = "HammerWeapon", menuName = "Whack-a-Mole/Weapons/Hammer")]
    public class HammerWeapon : Weapon
    {
        public override void Attack(Vector2 worldPos, WeaponContext ctx)
        {
            int damage = BaseDamage;
            if (ctx.ChargeTime >= Constants.HAMMER_CHARGE_TIME)
                damage = Constants.HAMMER_CHARGE_DAMAGE;

            var hit = Physics2D.OverlapCircle(worldPos, HitRadius, ctx.HittableLayer);
            if (hit == null) return;

            var hittable = hit.GetComponent<IHittable>();
            if (hittable == null || !hittable.IsAlive) return;

            int restore = BaseDamage;
            BaseDamage = damage;
            hittable.OnHit(this, worldPos);
            BaseDamage = restore;

            SpawnHitEffect(worldPos);
        }

        // Wiggle around the pommel pivot: bottom still, top swings.
        public override IEnumerator PlaySwingAnim(Transform sprite, Vector3 baseScale)
        {
            const float windupRot = 12f;
            const float slamRot = -22f;

            // Wind-up
            yield return Tween(sprite, 0.09f, (s, t) =>
            {
                float e = EaseOutCubic(t);
                s.localRotation = Quaternion.Euler(0, 0, Mathf.Lerp(0f, windupRot, e));
                s.localScale = baseScale * Mathf.Lerp(1f, 1.04f, e);
            });

            // Slam
            yield return Tween(sprite, 0.07f, (s, t) =>
            {
                float e = t * t;
                s.localRotation = Quaternion.Euler(0, 0, Mathf.Lerp(windupRot, slamRot, e));
                s.localScale = baseScale * Mathf.Lerp(1.04f, 1.0f, e);
            });

            // Impact hold + squash pop
            yield return Tween(sprite, 0.05f, (s, t) =>
            {
                s.localRotation = Quaternion.Euler(0, 0, slamRot);
                float k = Mathf.Lerp(1.0f, 1.08f, t);
                s.localScale = new Vector3(baseScale.x * k, baseScale.y * (2f - k), baseScale.z);
            });

            // Recovery
            yield return Tween(sprite, 0.14f, (s, t) =>
            {
                float e = EaseOutCubic(t);
                s.localRotation = Quaternion.Euler(0, 0, Mathf.Lerp(slamRot, 0f, e));
                s.localScale = Vector3.Lerp(
                    new Vector3(baseScale.x * 1.08f, baseScale.y * 0.92f, baseScale.z),
                    baseScale, e);
            });

            sprite.localRotation = Quaternion.identity;
            sprite.localScale = baseScale;
        }

        private static IEnumerator Tween(Transform s, float duration, System.Action<Transform, float> step)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                step(s, Mathf.Clamp01(elapsed / duration));
                yield return null;
            }
            step(s, 1f);
        }

        private static float EaseOutCubic(float t) { float f = 1f - t; return 1f - f * f * f; }
    }
}
