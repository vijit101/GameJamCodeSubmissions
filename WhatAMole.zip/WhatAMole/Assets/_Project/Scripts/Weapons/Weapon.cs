using System.Collections;
using UnityEngine;

namespace WhackAMole.Weapons
{
    /// <summary>
    /// Abstract base for weapons. ScriptableObject-backed so weapon data
    /// is configured in the Inspector, not in code.
    /// </summary>
    public abstract class Weapon : ScriptableObject
    {
        [Header("Identity")]
        public string weaponName;
        public Sprite icon;
        public Sprite cursorSprite;

        [Header("Stats")]
        public int BaseDamage = 1;
        public float Cooldown = 0.2f;
        public float HitRadius = 0.5f;

        [Header("Cursor Positioning")]
        [Tooltip("World-space offset subtracted from the mouse position before placing the cursor. Use this when the sprite pivot is not at the impact point (e.g. hammer pommel) so the impact point still lands on the mouse.")]
        public Vector2 cursorWorldOffset = Vector2.zero;

        [Header("Audio")]
        public AudioClip swingSound;
        public AudioClip hitSound;
        public AudioClip missSound;

        [Header("VFX")]
        public GameObject hitEffectPrefab;

        /// <summary>
        /// Polymorphic attack — applies damage/effects at <paramref name="worldPos"/>.
        /// Weapons that need pre-impact choreography (throw, drop, etc.) should
        /// override <see cref="ExecuteAttack"/> and call <see cref="Attack"/> at
        /// the exact moment of impact.
        /// </summary>
        public abstract void Attack(Vector2 worldPos, WeaponContext ctx);

        /// <summary>
        /// Full attack lifecycle as a coroutine. Default implementation fires
        /// damage instantly then plays the one-shot swing animation on the
        /// cursor sprite (hammer behaviour). Override to delay damage until
        /// mid-animation (katana throw, bomb drop, etc.).
        /// </summary>
        public virtual IEnumerator ExecuteAttack(Vector2 worldPos, WeaponContext ctx, Transform sprite, Vector3 baseScale)
        {
            Attack(worldPos, ctx);
            yield return PlaySwingAnim(sprite, baseScale);
        }

        /// <summary>
        /// Continuous idle animation played on the sprite child while this weapon
        /// is active and not swinging. Default: do nothing (sprite at rest).
        /// </summary>
        public virtual IEnumerator PlayIdleAnim(Transform sprite, Vector3 baseScale)
        {
            sprite.localRotation = Quaternion.identity;
            sprite.localScale = baseScale;
            yield break;
        }

        /// <summary>
        /// One-shot swing animation played on click. Runs to completion before
        /// the idle animation resumes.
        /// </summary>
        public virtual IEnumerator PlaySwingAnim(Transform sprite, Vector3 baseScale)
        {
            yield break;
        }

        /// <summary>Override for custom hit effect per weapon.</summary>
        public virtual GameObject SpawnHitEffect(Vector2 pos)
        {
            if (hitEffectPrefab != null)
                return Instantiate(hitEffectPrefab, pos, Quaternion.identity);
            return null;
        }
    }

    /// <summary>
    /// Runtime context passed to Weapon.Attack() — provides access to
    /// scene objects without the SO holding scene references.
    /// </summary>
    public class WeaponContext
    {
        public Camera MainCamera;
        public Transform CursorTransform;
        public LayerMask HittableLayer;
        public float ChargeTime;
    }
}
