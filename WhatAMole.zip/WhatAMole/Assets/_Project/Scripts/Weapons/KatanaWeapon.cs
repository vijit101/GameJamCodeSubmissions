using System.Collections;
using UnityEngine;
using WhackAMole.Interfaces;
using WhackAMole.Moles;

namespace WhackAMole.Weapons
{
    /// <summary>
    /// Spinning katana. Cuts through ArmoredMole shields (2 damage per hit, so a
    /// 3HP armored dies in two strikes — see <see cref="Moles.ArmoredMole"/>) and
    /// cleaves every Normal mole within <see cref="cleaveRadius"/> of the primary
    /// target. Fast/Stealth/Golden/Bomb/Splitter moles are untouched by the cleave.
    /// </summary>
    [CreateAssetMenu(fileName = "KatanaWeapon", menuName = "Whack-a-Mole/Weapons/Katana")]
    public class KatanaWeapon : Weapon
    {
        [Header("Katana Config")]
        [Tooltip("Radius around the primary hit in which Normal moles are cleaved too.")]
        public float cleaveRadius = 1.8f;

        public override void Attack(Vector2 worldPos, WeaponContext ctx)
        {
            // 1. Primary target at cursor
            var primary = Physics2D.OverlapCircle(worldPos, HitRadius, ctx.HittableLayer);
            if (primary == null) return;

            var primaryHittable = primary.GetComponent<IHittable>();
            if (primaryHittable == null || !primaryHittable.IsAlive) return;

            primaryHittable.OnHit(this, worldPos);
            SpawnHitEffect(worldPos);

            // 2. Cleave: AOE hits every nearby Normal mole within cleaveRadius.
            var nearby = Physics2D.OverlapCircleAll(worldPos, cleaveRadius, ctx.HittableLayer);
            foreach (var col in nearby)
            {
                if (col == null || col == primary) continue;
                var mole = col.GetComponent<Mole>();
                if (mole == null || !mole.IsAlive) continue;
                // Only Normal moles get cleaved — fast, armored, stealth, etc. are spared.
                if (mole.Type != MoleType.Normal) continue;

                mole.OnHit(this, mole.transform.position);
            }
        }

        // No idle spin — the katana sits still at the cursor; the spin only
        // happens mid-flight during ExecuteAttack. (Falls through to the base
        // Weapon.PlayIdleAnim which resets rotation + scale and holds.)

        // Swing fallback: fast spin burst + scale bulge in place. Used if a caller
        // invokes PlaySwingAnim directly. The full throw + return choreography
        // lives in ExecuteAttack below.
        public override IEnumerator PlaySwingAnim(Transform sprite, Vector3 baseScale)
        {
            const float duration = 0.25f;
            float elapsed = 0f;
            float startRot = sprite.localRotation.eulerAngles.z;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                sprite.localRotation = Quaternion.Euler(0, 0, startRot - 720f * t);
                float s = 1f + Mathf.Sin(t * Mathf.PI) * 0.25f;
                sprite.localScale = baseScale * s;
                yield return null;
            }
            sprite.localScale = baseScale;
        }

        // Throw-spin-impact-return. The katana flies from the cursor to the click
        // position, spinning rapidly; strikes the mole on arrival (this is where
        // Attack fires); holds briefly with a scale pop; then flies back so the
        // player can queue the next throw.
        public override IEnumerator ExecuteAttack(Vector2 worldPos, WeaponContext ctx, Transform sprite, Vector3 baseScale)
        {
            if (sprite == null || sprite.parent == null) { Attack(worldPos, ctx); yield break; }
            Transform parent = sprite.parent;

            // Keep a continuous rotation counter so the spin never resets between phases.
            float totalRot = sprite.localRotation.eulerAngles.z;

            // Phase 1 — fly to target.
            const float flight = 0.16f;
            float elapsed = 0f;
            while (elapsed < flight)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / flight);
                float eased = 1f - (1f - t) * (1f - t); // ease-out quad
                Vector3 targetLocal = (Vector3)worldPos - parent.position;
                sprite.localPosition = Vector3.Lerp(Vector3.zero, targetLocal, eased);
                totalRot -= Time.deltaTime * 1080f;
                sprite.localRotation = Quaternion.Euler(0, 0, totalRot);
                sprite.localScale = baseScale * Mathf.Lerp(0.95f, 1.15f, t);
                yield return null;
            }

            // Phase 2 — impact: apply damage + scale pop while still spinning in place.
            Attack(worldPos, ctx);

            const float impact = 0.10f;
            elapsed = 0f;
            while (elapsed < impact)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / impact);
                Vector3 targetLocal = (Vector3)worldPos - parent.position;
                sprite.localPosition = targetLocal;
                totalRot -= Time.deltaTime * 900f;
                sprite.localRotation = Quaternion.Euler(0, 0, totalRot);
                float k = 1f + Mathf.Sin(t * Mathf.PI) * 0.3f;
                sprite.localScale = baseScale * k;
                yield return null;
            }

            // Phase 3 — return to cursor. Rotation eases cleanly to zero so the
            // blade ends every throw in its rest pose, no matter how many cycles
            // or mid-flight swaps have happened.
            const float back = 0.14f;
            elapsed = 0f;
            Vector3 impactLocal = sprite.localPosition;
            float startRot = totalRot;
            // Finish one more full turn then settle at 0 (nearest multiple of 360 below startRot).
            float endRot = Mathf.Floor(startRot / 360f) * 360f - 360f;
            while (elapsed < back)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / back);
                float eased = 1f - (1f - t) * (1f - t);
                Vector3 targetLocal = (Vector3)worldPos - parent.position;
                Vector3 fromRef = Vector3.Lerp(impactLocal, targetLocal, 0.3f);
                sprite.localPosition = Vector3.Lerp(fromRef, Vector3.zero, eased);
                sprite.localRotation = Quaternion.Euler(0, 0, Mathf.Lerp(startRot, endRot, eased));
                sprite.localScale = Vector3.Lerp(baseScale * 1.1f, baseScale, eased);
                yield return null;
            }

            sprite.localPosition = Vector3.zero;
            sprite.localRotation = Quaternion.identity;
            sprite.localScale = baseScale;
        }
    }
}
