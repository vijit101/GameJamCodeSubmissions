using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WhackAMole.Moles;
using WhackAMole.Spawning;

namespace WhackAMole.Weapons
{
    /// <summary>
    /// Rare explosive weapon. Flood-fills from the clicked mole's hole through
    /// adjacent holes (8-way) and wipes out every active mole in the connected
    /// cluster. Deals massive damage so everything dies in one blast.
    /// </summary>
    [CreateAssetMenu(fileName = "BombWeapon", menuName = "Whack-a-Mole/Weapons/Bomb")]
    public class BombWeapon : Weapon
    {
        [Header("Bomb Config")]
        [Tooltip("Damage the blast deals. High enough to one-shot every mole including armored.")]
        public int blastDamage = 99;

        [Header("VFX")]
        [Tooltip("Sprite spawned as a smoke cloud on detonation (one per victim plus a big central puff).")]
        public Sprite smokeSprite;

        public override void Attack(Vector2 worldPos, WeaponContext ctx)
        {
            // 1. Find the hole at the click position (primary target).
            Hole seedHole = FindHoleAtPoint(worldPos, ctx);
            if (seedHole == null) return;

            // 2. Collect the flood-fill set: primary hole + all adjacent holes with
            //    active moles, then expand from each found mole's hole.
            var factory = MoleFactory.Instance;
            if (factory == null) return;
            var allMoles = factory.GetActiveMoles();
            if (allMoles == null || allMoles.Count == 0) return;

            // Index active moles by their hole index for O(1) lookup during flood-fill.
            var moleByHole = new Dictionary<int, Mole>();
            foreach (var m in allMoles)
            {
                if (m == null || !m.IsAlive) continue;
                if (m.CurrentHole == null) continue;
                moleByHole[m.CurrentHole.HoleIndex] = m;
            }

            var visitedHoles = new HashSet<int>();
            var victims = new List<Mole>();
            var queue = new Queue<Hole>();
            queue.Enqueue(seedHole);
            visitedHoles.Add(seedHole.HoleIndex);

            while (queue.Count > 0)
            {
                var hole = queue.Dequeue();
                if (moleByHole.TryGetValue(hole.HoleIndex, out var victim) && victim.IsAlive)
                    victims.Add(victim);

                // Expand to 8-way neighbours. Only continue flooding from holes that
                // are adjacent to the primary OR contain an active mole (so the
                // blast radiates through the cluster of moles, not every hole).
                foreach (int ni in hole.GetAdjacentIndices())
                {
                    if (visitedHoles.Contains(ni)) continue;
                    visitedHoles.Add(ni);

                    bool isImmediate = (hole == seedHole);
                    bool hasMole = moleByHole.ContainsKey(ni);
                    if (!isImmediate && !hasMole) continue;

                    var neighbour = FindHoleByIndex(ni);
                    if (neighbour != null) queue.Enqueue(neighbour);
                }
            }

            // 3. Detonate — one-shot every mole in the blast.
            //    NOTE: a splitter killed here runs its OnDefeated hook *during*
            //    this loop and immediately spawns NormalMole children in its
            //    adjacent free holes. Those children land inside `visitedHoles`
            //    (since every victim's adjacents were added during the flood),
            //    so we do a second sweep below to smoke them in the same blast.
            int restoreDamage = BaseDamage;
            BaseDamage = blastDamage;
            foreach (var victim in victims)
            {
                if (victim == null || !victim.IsAlive) continue;
                victim.OnHit(this, victim.transform.position);
                SpawnHitEffect(victim.transform.position);
            }

            // 4. Aftermath sweep — any mole now alive inside the blast zone is a
            //    freshly-spawned splitter child (or another late arrival). Kill
            //    them in the same detonation so splitters can't escape the bomb.
            var fresh = factory.GetActiveMoles();
            for (int i = 0; i < fresh.Count; i++)
            {
                var m = fresh[i];
                if (m == null || !m.IsAlive || m.CurrentHole == null) continue;
                if (!visitedHoles.Contains(m.CurrentHole.HoleIndex)) continue;
                m.OnHit(this, m.transform.position);
                SpawnHitEffect(m.transform.position);
            }
            BaseDamage = restoreDamage;
        }

        private static Hole FindHoleAtPoint(Vector2 worldPos, WeaponContext ctx)
        {
            // Prefer the mole at the click — they know their hole.
            var primary = Physics2D.OverlapCircle(worldPos, 0.8f, ctx.HittableLayer);
            if (primary != null)
            {
                var mole = primary.GetComponent<Mole>();
                if (mole != null && mole.CurrentHole != null) return mole.CurrentHole;
            }
            // Fallback: nearest hole by world distance.
            Hole best = null;
            float bestSq = float.MaxValue;
            foreach (var h in Object.FindObjectsByType<Hole>(FindObjectsInactive.Exclude))
            {
                float d = ((Vector2)h.transform.position - worldPos).sqrMagnitude;
                if (d < bestSq) { bestSq = d; best = h; }
            }
            return best;
        }

        private static Hole FindHoleByIndex(int index)
        {
            foreach (var h in Object.FindObjectsByType<Hole>(FindObjectsInactive.Exclude))
                if (h.HoleIndex == index) return h;
            return null;
        }

        // Override the base hit effect: every mole caught in the blast spits a
        // smoke puff at its own position.
        public override GameObject SpawnHitEffect(Vector2 pos)
        {
            SpawnSmoke(pos, 0.9f);
            return base.SpawnHitEffect(pos);
        }

        private void SpawnSmoke(Vector2 pos, float endScale)
        {
            if (smokeSprite == null) return;
            var go = new GameObject("SmokePuff");
            go.transform.position = pos;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = smokeSprite;
            sr.sortingOrder = 80;
            sr.color = new Color(1f, 1f, 1f, 0.9f);
            go.AddComponent<SmokePuff>().Init(endScale);
        }

        // Detonate-squash-respawn. Bomb bursts into smoke at the click position
        // (plus one puff at each victim), squashes, then respawns at the cursor
        // ready for the next throw.
        public override IEnumerator ExecuteAttack(Vector2 worldPos, WeaponContext ctx, Transform sprite, Vector3 baseScale)
        {
            if (sprite == null || sprite.parent == null) { Attack(worldPos, ctx); yield break; }
            Transform parent = sprite.parent;

            // Phase 1 — detonate. Big central smoke puff + Attack (which triggers
            // per-victim puffs via the overridden SpawnHitEffect above).
            SpawnSmoke(worldPos, 1.6f);
            Attack(worldPos, ctx);

            // Phase 2 — bomb squashes into the ground and disappears while the smoke blooms.
            const float squash = 0.14f;
            float elapsed = 0f;
            Vector3 impactLocal = (Vector3)worldPos - parent.position;
            while (elapsed < squash)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / squash);
                sprite.localPosition = impactLocal;
                sprite.localRotation = Quaternion.identity;
                float s = Mathf.Lerp(1.2f, 0f, t);
                sprite.localScale = baseScale * s;
                yield return null;
            }

            // Phase 3 — respawn at the cursor so the next click has a bomb ready.
            sprite.localPosition = Vector3.zero;
            const float respawn = 0.18f;
            elapsed = 0f;
            while (elapsed < respawn)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / respawn);
                sprite.localScale = baseScale * t;
                yield return null;
            }
            sprite.localScale = baseScale;
        }

        // Idle: gentle breathing pulse so the bomb reads as "armed."
        public override IEnumerator PlayIdleAnim(Transform sprite, Vector3 baseScale)
        {
            while (true)
            {
                float s = 1f + Mathf.Sin(Time.time * 3f) * 0.05f;
                sprite.localScale = baseScale * s;
                sprite.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(Time.time * 2f) * 4f);
                yield return null;
            }
        }

        // Swing: quick drop pop + flash-sized bulge to sell the detonation.
        public override IEnumerator PlaySwingAnim(Transform sprite, Vector3 baseScale)
        {
            const float duration = 0.3f;
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                // Grow to 1.5x at the midpoint, shrink back.
                float k = 1f + Mathf.Sin(t * Mathf.PI) * 0.5f;
                sprite.localScale = baseScale * k;
                // Tilt into the drop
                sprite.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(t * Mathf.PI * 2f) * 10f);
                yield return null;
            }
            sprite.localScale = baseScale;
            sprite.localRotation = Quaternion.identity;
        }
    }
}
