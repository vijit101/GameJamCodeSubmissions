using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using WhackAMole.Core;
using WhackAMole.Moles;

namespace WhackAMole.Weapons
{
    /// <summary>
    /// Drives the on-screen weapon cursor. Loads all weapons from Resources/Weapons
    /// and swaps to a random *different* weapon every time the player hits the
    /// next swap threshold — a fresh random count in [MinKillsForSwap,
    /// MaxKillsForSwap] picked after every swap. Mole types are irrelevant:
    /// it's the total kill count that drives the cadence. Each weapon owns its
    /// idle + swing animation and can request a cursor offset if its pivot
    /// isn't at the impact point.
    /// </summary>
    public class WeaponController : MonoBehaviour
    {
        [SerializeField] private LayerMask hittableLayer = ~0;
        [SerializeField] private Transform cursorTransform;

        // Each swap triggers after a randomised number of kills in this range, so
        // the player can't predict exactly when a swap fires.
        private const int MinKillsForSwap = 3;
        private const int MaxKillsForSwap = 8;

        private List<Weapon> _pool = new();
        private Weapon _activeWeapon;
        private Transform _spriteChild;
        private SpriteRenderer _cursorSR;
        private Vector3 _baseScale = new Vector3(1.8f, 1.8f, 1f);
        private Coroutine _idleRoutine;

        // Total mole-kill counter since the last swap. When it hits
        // _nextSwapThreshold we pick a different weapon. Mole types are not
        // tracked — the swap cadence is driven purely by kill count.
        private int _killsSinceSwap;
        private int _nextSwapThreshold;
        // Set true when a kill triggers a swap mid-swing. The swap then runs once
        // the current weapon's attack coroutine has finished so its animation
        // never collides with the next weapon's idle.
        private bool _pendingSwap;

        private float _cooldownTimer;
        private float _chargeStartTime;
        private bool _isCharging;
        private bool _isSwinging;
        private Camera _mainCamera;

        public Weapon ActiveWeapon => _activeWeapon;
        public float CooldownProgress => _activeWeapon != null ? Mathf.Clamp01(_cooldownTimer / _activeWeapon.Cooldown) : 0f;
        public bool IsOnCooldown => _cooldownTimer > 0f;

        private void Start()
        {
            _mainCamera = Camera.main;

            // Load every weapon in Resources/Weapons. Start with Hammer if present.
            _pool = new List<Weapon>(Resources.LoadAll<Weapon>("Weapons"));
            Weapon starter = _pool.Find(w => w is HammerWeapon) ?? (_pool.Count > 0 ? _pool[0] : null);

            // Parent transform tracks the mouse position.
            if (cursorTransform == null)
            {
                var cursorGO = new GameObject("WeaponCursor");
                cursorGO.transform.SetParent(transform);
                cursorTransform = cursorGO.transform;
            }

            // Sprite child handles per-weapon animation.
            _spriteChild = cursorTransform.Find("Sprite");
            if (_spriteChild == null)
            {
                var spriteGO = new GameObject("Sprite");
                spriteGO.transform.SetParent(cursorTransform, false);
                _cursorSR = spriteGO.AddComponent<SpriteRenderer>();
                _cursorSR.sortingOrder = 100;
                spriteGO.transform.localScale = _baseScale;
                _spriteChild = spriteGO.transform;
            }
            else
            {
                _cursorSR = _spriteChild.GetComponent<SpriteRenderer>();
                _baseScale = _spriteChild.localScale;
            }

            if (starter != null) SetActiveWeapon(starter);
            _nextSwapThreshold = Random.Range(MinKillsForSwap, MaxKillsForSwap + 1);
        }

        private void OnEnable()
        {
            EventBus.OnMoleKilled += HandleMoleKilled;
        }

        private void OnDisable()
        {
            EventBus.OnMoleKilled -= HandleMoleKilled;
        }

        private void OnDestroy()
        {
            Cursor.visible = true;
        }

        private void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.CurrentState != GameState.Playing)
            {
                if (!Cursor.visible) Cursor.visible = true;
                if (cursorTransform != null) cursorTransform.gameObject.SetActive(false);
                return;
            }

            if (Cursor.visible) Cursor.visible = false;
            if (cursorTransform != null && !cursorTransform.gameObject.activeSelf)
                cursorTransform.gameObject.SetActive(true);

            var mouse = Mouse.current;
            if (mouse == null) return;

            UpdateCursorPosition(mouse);
            if (_cooldownTimer > 0f) _cooldownTimer -= Time.deltaTime;
            HandleAttackInput(mouse);
        }

        private void UpdateCursorPosition(Mouse mouse)
        {
            if (cursorTransform == null || _mainCamera == null) return;
            Vector2 screenPos = mouse.position.ReadValue();
            Vector3 worldPos = _mainCamera.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, 0));
            worldPos.z = 0f;
            // Offset so that weapons with non-centred pivots (e.g. hammer pommel)
            // still put their impact point under the mouse.
            if (_activeWeapon != null)
                worldPos -= (Vector3)_activeWeapon.cursorWorldOffset;
            cursorTransform.position = worldPos;
        }

        private void HandleAttackInput(Mouse mouse)
        {
            if (_activeWeapon == null) return;

            if (mouse.leftButton.wasPressedThisFrame)
            {
                _chargeStartTime = Time.time;
                _isCharging = true;
            }

            if (mouse.leftButton.wasReleasedThisFrame && _isCharging)
            {
                if (_cooldownTimer <= 0f && !_isSwinging)
                {
                    PerformAttack(mouse);
                    _cooldownTimer = _activeWeapon.Cooldown;
                }
                _isCharging = false;
            }
        }

        private void PerformAttack(Mouse mouse)
        {
            if (_mainCamera == null) return;
            Vector2 screenPos = mouse.position.ReadValue();
            Vector2 worldPos = _mainCamera.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, 0));

            var ctx = new WeaponContext
            {
                MainCamera = _mainCamera,
                CursorTransform = cursorTransform,
                HittableLayer = hittableLayer,
                ChargeTime = Time.time - _chargeStartTime
            };

            if (_activeWeapon.swingSound != null)
                AudioManager.Instance.PlaySFX(_activeWeapon.swingSound);

            EventBus.FireWeaponSwung(worldPos);

            // Hand the whole attack (animation + damage timing) to the weapon.
            StartCoroutine(RunExecute(worldPos, ctx));
        }

        // Pause idle → run weapon's full attack coroutine → resume idle (or
        // apply a deferred weapon swap if a kill during the swing queued one).
        private IEnumerator RunExecute(Vector2 worldPos, WeaponContext ctx)
        {
            if (_activeWeapon == null || _spriteChild == null) yield break;
            _isSwinging = true;

            if (_idleRoutine != null) { StopCoroutine(_idleRoutine); _idleRoutine = null; }

            yield return StartCoroutine(_activeWeapon.ExecuteAttack(worldPos, ctx, _spriteChild, _baseScale));

            _isSwinging = false;

            if (_pendingSwap)
            {
                // Kill happened mid-swing and wanted a new weapon — do it now,
                // cleanly, so the next attack starts from a fresh sprite state.
                _pendingSwap = false;
                PickRandomOtherWeapon();
            }
            else
            {
                // Make sure the sprite is in a canonical rest pose before the
                // idle takes over — weapons like the katana leave a spun rotation
                // at the end of their throw which would pop on idle start.
                _spriteChild.localPosition = Vector3.zero;
                _spriteChild.localRotation = Quaternion.identity;
                _spriteChild.localScale = _baseScale;
                _idleRoutine = StartCoroutine(_activeWeapon.PlayIdleAnim(_spriteChild, _baseScale));
            }
        }

        // ─── Kill tracking + random swap ───
        //
        // Every positive-score kill increments a single counter. When the
        // counter hits a random threshold in [MinKillsForSwap, MaxKillsForSwap]
        // the controller swaps to a randomly-chosen weapon that is NOT the
        // currently-equipped one, then re-rolls the threshold. That guarantees
        // every swap is a visible change and that swaps keep firing forever.

        private void HandleMoleKilled(MoleType _)
        {
            _killsSinceSwap++;
            if (_killsSinceSwap < _nextSwapThreshold) return;

            _killsSinceSwap = 0;
            _nextSwapThreshold = Random.Range(MinKillsForSwap, MaxKillsForSwap + 1);

            // If a swing is already in flight (we're usually being invoked from
            // *inside* the weapon's Attack call), defer the swap until the
            // coroutine finishes. Otherwise the current weapon's remaining
            // animation frames would run AFTER SetActiveWeapon's sprite reset
            // and corrupt the new weapon's starting pose.
            if (_isSwinging) { _pendingSwap = true; return; }

            PickRandomOtherWeapon();
        }

        // Picks any weapon in the pool other than the currently-equipped one
        // with uniform probability. Guarantees the swap is always a different
        // weapon so the player sees a visible change every threshold.
        private void PickRandomOtherWeapon()
        {
            if (_pool == null || _pool.Count < 2) return;

            var candidates = new List<Weapon>(_pool.Count - 1);
            foreach (var w in _pool)
            {
                if (w == null || w == _activeWeapon) continue;
                candidates.Add(w);
            }
            if (candidates.Count == 0) return;

            SetActiveWeapon(candidates[Random.Range(0, candidates.Count)]);
        }

        private void SetActiveWeapon(Weapon weapon)
        {
            _activeWeapon = weapon;
            _cooldownTimer = 0f;

            if (_cursorSR != null && weapon.cursorSprite != null)
                _cursorSR.sprite = weapon.cursorSprite;

            // Reset the sprite transform cleanly and restart the idle animation.
            if (_spriteChild != null)
            {
                _spriteChild.localPosition = Vector3.zero;
                _spriteChild.localRotation = Quaternion.identity;
                _spriteChild.localScale = _baseScale;
            }

            if (_idleRoutine != null) { StopCoroutine(_idleRoutine); _idleRoutine = null; }
            _idleRoutine = StartCoroutine(weapon.PlayIdleAnim(_spriteChild, _baseScale));
        }
    }
}
