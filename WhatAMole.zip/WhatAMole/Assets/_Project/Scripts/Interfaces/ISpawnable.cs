using WhackAMole.Spawning;

namespace WhackAMole.Interfaces
{
    /// <summary>
    /// Anything the spawner can produce from a hole.
    /// </summary>
    public interface ISpawnable
    {
        void Spawn(Hole hole);
        void Despawn();
    }
}
