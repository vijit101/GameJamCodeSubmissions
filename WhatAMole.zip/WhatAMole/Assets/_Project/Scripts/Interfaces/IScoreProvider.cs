namespace WhackAMole.Interfaces
{
    /// <summary>
    /// Anything that awards or penalizes score when hit.
    /// BombMole returns negative via IsPositiveScore = false.
    /// </summary>
    public interface IScoreProvider
    {
        int GetScoreValue();
        bool IsPositiveScore { get; }
    }
}
