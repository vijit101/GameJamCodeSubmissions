using UnityEngine;
using WhackAMole.Weapons;

namespace WhackAMole.Interfaces
{
    /// <summary>
    /// Anything the player can whack — moles, power-ups, destructibles.
    /// This is the central polymorphic contract that all hittable entities implement
    /// and all weapons target.
    /// </summary>
    public interface IHittable
    {
        void OnHit(Weapon weapon, Vector2 hitPoint);
        bool IsAlive { get; }
    }
}
