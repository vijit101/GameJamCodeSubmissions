using UnityEngine;
using WhackAMole.Core;

namespace WhackAMole.Utils
{
    /// <summary>
    /// Resets all singleton statics when entering play mode.
    /// Required because [RuntimeInitializeOnLoadMethod] cannot be in generic classes.
    /// </summary>
    public static class SingletonResetter
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetAll()
        {
            Singleton<GameManager>.ResetStatic();
            Singleton<ScoreManager>.ResetStatic();
            Singleton<AudioManager>.ResetStatic();
        }
    }
}
