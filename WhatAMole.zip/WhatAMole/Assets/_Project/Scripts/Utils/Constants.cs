namespace WhackAMole.Utils
{
    public static class Constants
    {
        // Tags
        public const string TAG_MOLE = "Mole";
        public const string TAG_HOLE = "Hole";
        public const string TAG_POWERUP = "PowerUp";

        // Layers
        public const string LAYER_MOLE = "Mole";
        public const string LAYER_UI = "UI";

        // Scoring
        public const int MAX_COMBO_MULTIPLIER = 4;
        public const float COMBO_WINDOW_SECONDS = 1.5f;
        public const float COMBO_DECAY_SECONDS = 2.0f;

        // Timing
        public const float DEFAULT_MOLE_VISIBLE_TIME = 1.5f;
        public const float DEFAULT_POP_UP_DURATION = 0.2f;
        public const float DEFAULT_HIDE_DURATION = 0.15f;

        // Weapons
        public const float HAMMER_CHARGE_TIME = 0.5f;
        public const int HAMMER_CHARGE_DAMAGE = 3;

        // Holes
        public const int HOLE_COUNT = 25;
        public const int HOLE_COLUMNS = 5;
        public const int HOLE_ROWS = 5;

        // Carrots
        public const float CARROT_WARNING_DURATION = 0.4f;
        public const float CARROT_REGEN_BASE_INTERVAL = 5f;    // seconds before first regen
        public const float CARROT_REGEN_BACKOFF = 1.2f;       // multiply interval each consecutive regen
        public const float CARROT_REGEN_MAX_INTERVAL = 20f;   // cap so it never stalls completely
        public const float CARROT_GROW_DURATION = 0.5f;       // grow-back animation time

        // Audio
        public const int SFX_POOL_SIZE = 8;
        public const float MUSIC_DUCK_VOLUME = 0.3f;
        public const float MUSIC_NORMAL_VOLUME = 0.7f;

        // Dynamic Difficulty Adjustment
        //
        // Tuned aggressive: the game starts already in "easy-medium" territory,
        // ramps up fast over time, hits push hard, and misses barely relieve
        // pressure. The lerp toward target difficulty runs almost twice as fast
        // so changes are felt immediately.
        public const float DDA_INITIAL_DIFFICULTY = 0.20f;   // was 0.05 — start with some bite
        public const float DDA_HIT_INCREASE = 0.015f;        // was 0.008 — hits ramp faster
        public const float DDA_MISS_DECREASE = 0.010f;       // was 0.015 — less relief on miss
        public const float DDA_BOMB_DECREASE = 0.015f;       // was 0.030 — bomb hits sting less
        public const float DDA_COMBO_BONUS = 0.003f;         // was 0.002 — combos push harder
        public const float DDA_PASSIVE_PER_SECOND = 0.004f;  // was 0.001 — ~4× faster ramp
        public const float DDA_SMOOTH_SPEED = 3.5f;          // was 2.0 — catches up snappier
        public const float DDA_CEILING = 1.5f;

        // Mole AI Targeting — "best steal" scoring and softmax selection
        public const float TARGETING_TEMP_EASY                 = 2.0f;   // softmax τ at DDA 0 (near-uniform over top-K)
        public const float TARGETING_TEMP_HARD                 = 0.3f;   // softmax τ at DDA ceiling (laser-targeted)
        public const float TARGETING_THREAT_WEIGHT             = 1.0f;   // coefficient for line-pressure component
        public const float TARGETING_MULTIPLICITY_WEIGHT       = 0.25f;  // per-line bump for holes on many lines
        public const float TARGETING_RECENCY_PENALTY           = 0.30f;  // subtract if any of h's lines had a recent steal
        public const float TARGETING_RECENCY_WINDOW            = 3.0f;   // seconds — how long a steal counts as recent
        public const int   TARGETING_TOP_K_MIN                 = 3;
        public const int   TARGETING_TOP_K_MAX                 = 8;
        public const float TARGETING_TOP_K_FRACTION            = 0.5f;   // K = clamp(ceil(freeCount * fraction), MIN, MAX)
        public const float TARGETING_CLUSTER_DDA_THRESHOLD     = 1.0f;   // above this, consecutive spawns pile on one line
        public const float TARGETING_CLUSTER_BONUS             = 0.5f;   // score bonus for holes on the most-pressured line
        public const float TARGETING_STEALTH_THREAT_MULTIPLIER = 1.2f;   // stealth moles punish neglected lines harder

        // PlayerPrefs Keys
        public const string PREF_HIGH_SCORE = "HighScore";
        public const string PREF_MUSIC_VOLUME = "MusicVolume";
        public const string PREF_SFX_VOLUME = "SFXVolume";

        // Scenes
        public const string SCENE_MAIN_MENU = "MainMenu";
        public const string SCENE_GAME = "Game";
        public const string SCENE_CREDITS = "Credits";
    }
}
