using System.Collections;
using UnityEngine;
using WhackAMole.Core;

namespace WhackAMole.Utils
{
    /// <summary>
    /// Camera shake effect triggered by EventBus events.
    /// Uses Perlin noise for organic shake feel. Bomb hits get heavy shake.
    /// Will be replaced by Cinemachine Impulse once the package is configured.
    /// </summary>
    public class CameraShake : MonoBehaviour
    {
        [Header("Shake Settings")]
        [SerializeField] private float hitShakeIntensity = 0.1f;
        [SerializeField] private float hitShakeDuration = 0.1f;
        [SerializeField] private float bombShakeIntensity = 0.4f;
        [SerializeField] private float bombShakeDuration = 0.3f;

        private Vector3 _originalPosition;
        private Coroutine _shakeCoroutine;

        private void Start()
        {
            _originalPosition = transform.localPosition;
        }

        private void OnEnable()
        {
            EventBus.OnMoleHit += HandleMoleHit;
            EventBus.OnBombHit += HandleBombHit;
        }

        private void OnDisable()
        {
            EventBus.OnMoleHit -= HandleMoleHit;
            EventBus.OnBombHit -= HandleBombHit;
        }

        private void HandleMoleHit(Vector2 hitPoint, int score)
        {
            if (score > 0)
                Shake(hitShakeIntensity, hitShakeDuration);
        }

        private void HandleBombHit(Vector2 hitPoint)
        {
            Shake(bombShakeIntensity, bombShakeDuration);
        }

        public void Shake(float intensity, float duration)
        {
            if (_shakeCoroutine != null)
                StopCoroutine(_shakeCoroutine);

            _shakeCoroutine = StartCoroutine(ShakeRoutine(intensity, duration));
        }

        private IEnumerator ShakeRoutine(float intensity, float duration)
        {
            float elapsed = 0f;
            float seed = Random.value * 100f;

            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                float t = elapsed / duration;
                float dampedIntensity = intensity * (1f - t); // Fade out

                float x = (Mathf.PerlinNoise(seed, elapsed * 25f) - 0.5f) * 2f * dampedIntensity;
                float y = (Mathf.PerlinNoise(seed + 100f, elapsed * 25f) - 0.5f) * 2f * dampedIntensity;

                transform.localPosition = _originalPosition + new Vector3(x, y, 0f);
                yield return null;
            }

            transform.localPosition = _originalPosition;
            _shakeCoroutine = null;
        }
    }
}
