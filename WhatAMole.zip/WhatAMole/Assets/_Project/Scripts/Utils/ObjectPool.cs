using System.Collections.Generic;
using UnityEngine;

namespace WhackAMole.Utils
{
    /// <summary>
    /// Generic object pool for MonoBehaviour components.
    /// Pre-warms on initialization to avoid runtime GC spikes (critical for WebGL).
    /// </summary>
    public class ObjectPool<T> where T : Component
    {
        private readonly T _prefab;
        private readonly Transform _parent;
        private readonly Queue<T> _available = new Queue<T>();
        private readonly List<T> _allInstances = new List<T>();

        public int CountActive => _allInstances.Count - _available.Count;
        public int CountAll => _allInstances.Count;

        public ObjectPool(T prefab, Transform parent, int preWarmCount = 0)
        {
            _prefab = prefab;
            _parent = parent;

            for (int i = 0; i < preWarmCount; i++)
            {
                var instance = CreateInstance();
                instance.gameObject.SetActive(false);
                _available.Enqueue(instance);
            }
        }

        public T Get()
        {
            T instance;

            if (_available.Count > 0)
            {
                instance = _available.Dequeue();
            }
            else
            {
                instance = CreateInstance();
            }

            instance.gameObject.SetActive(true);
            return instance;
        }

        public void Return(T instance)
        {
            instance.gameObject.SetActive(false);
            _available.Enqueue(instance);
        }

        public void ReturnAll()
        {
            foreach (var instance in _allInstances)
            {
                if (instance != null && instance.gameObject.activeSelf)
                {
                    instance.gameObject.SetActive(false);
                    _available.Enqueue(instance);
                }
            }
        }

        private T CreateInstance()
        {
            var instance = Object.Instantiate(_prefab, _parent);
            _allInstances.Add(instance);
            return instance;
        }
    }
}
