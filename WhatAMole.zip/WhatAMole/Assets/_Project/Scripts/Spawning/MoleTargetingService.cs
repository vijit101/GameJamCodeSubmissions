using System.Collections.Generic;
using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Moles;
using WhackAMole.Utils;

namespace WhackAMole.Spawning
{
    /// <summary>
    /// Chooses which hole each spawning mole should occupy, using a live-updating
    /// "best steal" score. Holes on near-complete rows/cols/diagonals rank higher;
    /// DDA-scaled softmax keeps the choice fair at low difficulty and laser-targeted
    /// at high difficulty.
    ///
    /// Pure selection logic — no changes to <see cref="Mole"/> or <see cref="MoleFactory"/>
    /// are needed. Stateless aside from a per-line recency map updated via
    /// <see cref="EventBus.OnCarrotStolen"/>.
    /// </summary>
    public class MoleTargetingService : MonoBehaviour
    {
        private static MoleTargetingService _instance;
        public static MoleTargetingService Instance => _instance;

        /// <summary>
        /// Auto-create the service on scene load if it isn't already present.
        /// Keeps gameplay working without a manual scene wire-up — the MoleSpawner
        /// also falls back to random selection if this fails, so it's safe.
        /// </summary>
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void EnsureInstance()
        {
            if (_instance != null) return;
            var existing = FindFirstObjectByType<MoleTargetingService>();
            if (existing != null) { _instance = existing; return; }
            var go = new GameObject("[MoleTargetingService]");
            go.AddComponent<MoleTargetingService>();
        }

#if UNITY_EDITOR
        [Header("Debug")]
        [Tooltip("Logs one line per PickTargetHole call with score breakdown.")]
        [SerializeField] private bool logPicks = false;
#endif

        private float[] _lineLastStolenAt;

        private readonly List<Hole> _candidates = new List<Hole>();
        private readonly List<float> _scores = new List<float>();

        private void Awake()
        {
            _instance = this;
            _lineLastStolenAt = new float[GridLines.Lines.Length];
            for (int i = 0; i < _lineLastStolenAt.Length; i++)
                _lineLastStolenAt[i] = float.NegativeInfinity;
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        private void OnEnable() { EventBus.OnCarrotStolen += HandleCarrotStolen; }
        private void OnDisable() { EventBus.OnCarrotStolen -= HandleCarrotStolen; }

        private void HandleCarrotStolen(int holeIndex)
        {
            if (holeIndex < 0 || holeIndex >= GridLines.LinesContaining.Length) return;
            float now = Time.time;
            foreach (int lineIdx in GridLines.LinesContaining[holeIndex])
                _lineLastStolenAt[lineIdx] = now;
        }

        /// <summary>
        /// Returns the chosen hole for a mole of the given type. Falls back to
        /// uniform random free-with-carrot if <see cref="CarrotManager"/> is unavailable
        /// or the mole type doesn't benefit from strategic targeting (e.g. Golden).
        /// Returns null if there are no valid free holes.
        /// </summary>
        public Hole PickTargetHole(MoleType type, Hole[] allHoles)
        {
            if (allHoles == null || allHoles.Length == 0) return null;

            _candidates.Clear();
            foreach (var h in allHoles)
            {
                if (h != null && !h.IsOccupied && h.HasCarrot)
                    _candidates.Add(h);
            }
            if (_candidates.Count == 0) return null;
            if (_candidates.Count == 1) return _candidates[0];

            // Golden is a reward (doesn't steal) — random is more forgiving.
            if (type == MoleType.Golden || CarrotManager.Instance == null)
                return _candidates[Random.Range(0, _candidates.Count)];

            float difficulty = DifficultyManager.Instance != null
                ? DifficultyManager.Instance.Difficulty
                : 0f;

            // Bomb mole pressures the player on the most-threatened line.
            // Argmax (not softmax) — bombs never actually steal, so making them
            // unambiguously threatening gives the player a clear read.
            if (type == MoleType.Bomb)
                return PickArgmax(ScoreBomb);

            float threatMultiplier = type == MoleType.Stealth
                ? Constants.TARGETING_STEALTH_THREAT_MULTIPLIER
                : 1.0f;

            return PickSoftmax(h => ScoreDefault(h, threatMultiplier, difficulty), difficulty);
        }

        // ─── Scoring functions ───────────────────────────────────────────────

        private float ScoreDefault(Hole hole, float threatMultiplier, float difficulty)
        {
            int idx = hole.HoleIndex;
            var lines = GridLines.LinesContaining[idx];

            float threatA = 0f;
            float now = Time.time;
            bool anyRecent = false;

            foreach (int lineIdx in lines)
            {
                int stolen = CarrotManager.Instance.GetStolenCountOnLine(lineIdx);
                int lineLen = GridLines.Lines[lineIdx].Length;
                // Pressure excludes this hole itself: at most (lineLen - 1) other holes stolen.
                float pressure = lineLen > 1 ? (float)stolen / (lineLen - 1) : 0f;
                if (pressure > 1f) pressure = 1f;
                threatA += pressure * pressure;

                if (now - _lineLastStolenAt[lineIdx] < Constants.TARGETING_RECENCY_WINDOW)
                    anyRecent = true;
            }

            float threatB = Constants.TARGETING_MULTIPLICITY_WEIGHT * lines.Length;
            float penaltyC = anyRecent ? Constants.TARGETING_RECENCY_PENALTY : 0f;

            float bonusD = 0f;
            if (difficulty >= Constants.TARGETING_CLUSTER_DDA_THRESHOLD)
            {
                int mostPressured = ArgmaxMostStolenLine();
                if (mostPressured >= 0)
                {
                    foreach (int lineIdx in lines)
                    {
                        if (lineIdx == mostPressured) { bonusD = Constants.TARGETING_CLUSTER_BONUS; break; }
                    }
                }
            }

            return Constants.TARGETING_THREAT_WEIGHT * threatMultiplier * threatA
                 + threatB
                 - penaltyC
                 + bonusD;
        }

        private float ScoreBomb(Hole hole)
        {
            // Bomb uses raw threat only — center/recency don't matter, it's about
            // putting the threat where the player has to choose: hit the bomb or
            // lose the line next cycle.
            int idx = hole.HoleIndex;
            float threat = 0f;
            foreach (int lineIdx in GridLines.LinesContaining[idx])
            {
                int stolen = CarrotManager.Instance.GetStolenCountOnLine(lineIdx);
                int lineLen = GridLines.Lines[lineIdx].Length;
                float pressure = lineLen > 1 ? (float)stolen / (lineLen - 1) : 0f;
                if (pressure > 1f) pressure = 1f;
                threat += pressure * pressure;
            }
            return threat;
        }

        private int ArgmaxMostStolenLine()
        {
            int best = -1;
            int bestStolen = 0;
            var lines = GridLines.Lines;
            for (int li = 0; li < lines.Length; li++)
            {
                int stolen = CarrotManager.Instance.GetStolenCountOnLine(li);
                if (stolen > bestStolen)
                {
                    bestStolen = stolen;
                    best = li;
                }
            }
            return best;
        }

        // ─── Selection strategies ────────────────────────────────────────────

        private Hole PickArgmax(System.Func<Hole, float> scorer)
        {
            Hole best = _candidates[0];
            float bestScore = scorer(best);
            for (int i = 1; i < _candidates.Count; i++)
            {
                float s = scorer(_candidates[i]);
                if (s > bestScore)
                {
                    bestScore = s;
                    best = _candidates[i];
                }
            }
            return best;
        }

        private Hole PickSoftmax(System.Func<Hole, float> scorer, float difficulty)
        {
            _scores.Clear();
            float maxScore = float.NegativeInfinity;
            for (int i = 0; i < _candidates.Count; i++)
            {
                float s = scorer(_candidates[i]);
                _scores.Add(s);
                if (s > maxScore) maxScore = s;
            }

            // Top-K prune
            int k = Mathf.Clamp(
                Mathf.CeilToInt(_candidates.Count * Constants.TARGETING_TOP_K_FRACTION),
                Constants.TARGETING_TOP_K_MIN,
                Constants.TARGETING_TOP_K_MAX);
            if (k > _candidates.Count) k = _candidates.Count;

            // Gather top-K indices without full sort (small N — selection by threshold).
            var topIdx = new List<int>(k);
            var remaining = new List<int>(_candidates.Count);
            for (int i = 0; i < _candidates.Count; i++) remaining.Add(i);
            for (int pick = 0; pick < k && remaining.Count > 0; pick++)
            {
                int bestPos = 0;
                for (int j = 1; j < remaining.Count; j++)
                    if (_scores[remaining[j]] > _scores[remaining[bestPos]]) bestPos = j;
                topIdx.Add(remaining[bestPos]);
                remaining.RemoveAt(bestPos);
            }

            // DDA-scaled temperature: easy → high τ (uniform-ish), hard → low τ (peaked).
            float t = Mathf.Clamp01(difficulty / Constants.DDA_CEILING);
            float tau = Mathf.Lerp(Constants.TARGETING_TEMP_EASY, Constants.TARGETING_TEMP_HARD, t);
            if (tau < 0.05f) tau = 0.05f; // numerical floor

            // Softmax with max-subtraction for numerical stability.
            float topMax = float.NegativeInfinity;
            foreach (int i in topIdx) if (_scores[i] > topMax) topMax = _scores[i];

            float sum = 0f;
            var weights = new float[topIdx.Count];
            for (int j = 0; j < topIdx.Count; j++)
            {
                weights[j] = Mathf.Exp((_scores[topIdx[j]] - topMax) / tau);
                sum += weights[j];
            }

            if (sum <= 0f || float.IsNaN(sum) || float.IsInfinity(sum))
                return _candidates[topIdx[0]]; // defensive fallback to argmax

            float roll = Random.value * sum;
            float cum = 0f;
            int chosenTopPos = topIdx.Count - 1;
            for (int j = 0; j < topIdx.Count; j++)
            {
                cum += weights[j];
                if (roll <= cum) { chosenTopPos = j; break; }
            }

            int chosenIdx = topIdx[chosenTopPos];

#if UNITY_EDITOR
            if (logPicks) LogPick(chosenIdx, tau, topIdx);
#endif

            return _candidates[chosenIdx];
        }

#if UNITY_EDITOR
        private void LogPick(int chosenIdx, float tau, List<int> topIdx)
        {
            var lineStolen = new int[GridLines.Lines.Length];
            for (int li = 0; li < lineStolen.Length; li++)
                lineStolen[li] = CarrotManager.Instance != null
                    ? CarrotManager.Instance.GetStolenCountOnLine(li)
                    : 0;

            Debug.Log(string.Format(
                "[Targeting] dda={0:F2} free={1} pick=hole{2} score={3:F2} τ={4:F2} topK={5} lineStolen=[{6}]",
                DifficultyManager.Instance != null ? DifficultyManager.Instance.Difficulty : 0f,
                _candidates.Count,
                _candidates[chosenIdx].HoleIndex,
                _scores[chosenIdx],
                tau,
                topIdx.Count,
                string.Join(",", lineStolen)));
        }
#endif
    }
}
