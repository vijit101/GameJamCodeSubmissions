using System.Collections.Generic;
using UnityEngine;
using WhackAMole.Moles;
using WhackAMole.Utils;

namespace WhackAMole.Spawning
{
    public class MoleFactory : MonoBehaviour
    {
        [SerializeField] private MolePrefabEntry[] molePrefabs;

        private Dictionary<MoleType, ObjectPool<Mole>> _pools;
        private List<Mole> _activeMoles = new List<Mole>();
        private Transform _poolParent;

        private static MoleFactory _instance;
        public static MoleFactory Instance => _instance;

        [System.Serializable]
        public struct MolePrefabEntry
        {
            public MoleType type;
            public Mole prefab;
            public int preWarmCount;
        }

        private void Awake()
        {
            _instance = this;
            AutoLoadPrefabs();
            InitializePools();
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        private void AutoLoadPrefabs()
        {
            if (molePrefabs != null && molePrefabs.Length > 0) return;

            var loaded = Resources.LoadAll<Mole>("MolePrefabs");
            if (loaded.Length == 0) return;

            molePrefabs = new MolePrefabEntry[loaded.Length];
            for (int i = 0; i < loaded.Length; i++)
            {
                molePrefabs[i] = new MolePrefabEntry
                {
                    type = loaded[i].Type,
                    prefab = loaded[i],
                    preWarmCount = loaded[i].Type == MoleType.Normal ? 5 : 2
                };
            }
        }

        private void InitializePools()
        {
            _pools = new Dictionary<MoleType, ObjectPool<Mole>>();
            var go = new GameObject("[MolePool]");
            _poolParent = go.transform;

            if (molePrefabs == null) return;

            foreach (var entry in molePrefabs)
            {
                if (entry.prefab == null) continue;
                _pools[entry.type] = new ObjectPool<Mole>(entry.prefab, _poolParent, entry.preWarmCount);
            }
        }

        public Mole Spawn(MoleType type, Hole hole)
        {
            if (!_pools.TryGetValue(type, out var pool)) return null;
            var mole = pool.Get();
            mole.Spawn(hole);
            _activeMoles.Add(mole);
            return mole;
        }

        public void Return(Mole mole)
        {
            _activeMoles.Remove(mole);
            if (_pools.TryGetValue(mole.Type, out var pool))
                pool.Return(mole);
        }

        public void ReturnAll()
        {
            for (int i = _activeMoles.Count - 1; i >= 0; i--)
            {
                if (_activeMoles[i] != null) _activeMoles[i].Despawn();
            }
            _activeMoles.Clear();
            foreach (var pool in _pools.Values) pool.ReturnAll();
        }

        public List<Mole> GetActiveMoles()
        {
            _activeMoles.RemoveAll(m => m == null || !m.gameObject.activeSelf);
            return _activeMoles;
        }

        public void FreezeAllMoles(float duration)
        {
            foreach (var mole in _activeMoles)
            {
                if (mole != null && mole.IsAlive) mole.Freeze(duration);
            }
        }
    }
}
