using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Levels;
using WhackAMole.Moles;

namespace WhackAMole.Spawning
{
    public class MoleSpawner : MonoBehaviour
    {
        [SerializeField] private Hole[] holes;

        private Level _currentLevel;
        private Coroutine _spawnCoroutine;
        private float _timeElapsed;
        private bool _isSpawning;

        public Hole[] Holes => holes;
        public float TimeElapsed => _timeElapsed;

        private void Awake()
        {
            if (holes == null || holes.Length == 0)
            {
                holes = FindObjectsByType<Hole>(FindObjectsInactive.Exclude);
                System.Array.Sort(holes, (a, b) => a.HoleIndex.CompareTo(b.HoleIndex));
            }
        }

        private void OnEnable() { EventBus.OnGameStateChanged += HandleGameStateChanged; }
        private void OnDisable() { EventBus.OnGameStateChanged -= HandleGameStateChanged; }

        public void StartSpawning(Level level)
        {
            _currentLevel = level;
            _timeElapsed = 0f;
            _isSpawning = true;
            if (_spawnCoroutine != null) StopCoroutine(_spawnCoroutine);
            _spawnCoroutine = StartCoroutine(SpawnLoop());
        }

        public void StopSpawning()
        {
            _isSpawning = false;
            if (_spawnCoroutine != null) { StopCoroutine(_spawnCoroutine); _spawnCoroutine = null; }
        }

        private IEnumerator SpawnLoop()
        {
            while (_isSpawning)
            {
                int active = MoleFactory.Instance != null ? MoleFactory.Instance.GetActiveMoles().Count : 0;
                int max = DifficultyManager.Instance != null
                    ? DifficultyManager.Instance.GetMaxSimultaneousMoles() : 25;

                if (active >= max)
                {
                    yield return new WaitForSeconds(0.2f);
                    continue;
                }

                // Skip the whole cycle if there's nowhere to spawn — prevents a
                // stateful Level subclass from consuming a spawn event that
                // would have been dropped anyway.
                if (!AnyFreeHoleAvailable())
                {
                    float idle = _currentLevel.GetSpawnInterval(_timeElapsed);
                    yield return new WaitForSeconds(idle);
                    _timeElapsed += idle;
                    continue;
                }

                // Resolve the mole type first so targeting knows what it's placing.
                var request = _currentLevel.GetNextSpawn(_timeElapsed, active);

                Hole hole;
                if (request.IsPowerUp || MoleTargetingService.Instance == null)
                    hole = PickRandomFreeHole();
                else
                    hole = MoleTargetingService.Instance.PickTargetHole(request.MoleType, holes);

                if (hole != null)
                {
                    // Reserve the hole during warning to prevent double-booking
                    hole.SetOccupied(true);

                    // Brief warning: carrot jiggles before mole pops up
                    yield return StartCoroutine(hole.PlayWarningAnimation());

                    // Release occupation — Mole.Spawn() will re-set it
                    hole.SetOccupied(false);

                    if (_isSpawning && !request.IsPowerUp)
                        MoleFactory.Instance.Spawn(request.MoleType, hole);
                }

                float interval = _currentLevel.GetSpawnInterval(_timeElapsed);
                yield return new WaitForSeconds(interval);
                _timeElapsed += interval;
            }
        }

        private Hole PickRandomFreeHole()
        {
            var free = new List<Hole>();
            foreach (var h in holes)
            {
                if (!h.IsOccupied && h.HasCarrot)
                    free.Add(h);
            }
            return free.Count == 0 ? null : free[Random.Range(0, free.Count)];
        }

        private bool AnyFreeHoleAvailable()
        {
            foreach (var h in holes)
                if (!h.IsOccupied && h.HasCarrot) return true;
            return false;
        }

        public Hole GetFreeAdjacentHole(Hole source)
        {
            int[] adj = source.GetAdjacentIndices();
            var free = new List<Hole>();
            foreach (int idx in adj)
            {
                if (idx >= 0 && idx < holes.Length && !holes[idx].IsOccupied && holes[idx].HasCarrot)
                    free.Add(holes[idx]);
            }
            return free.Count == 0 ? null : free[Random.Range(0, free.Count)];
        }

        private void HandleGameStateChanged(GameState state)
        {
            if (state == GameState.GameOver)
                StopSpawning();
        }
    }
}
