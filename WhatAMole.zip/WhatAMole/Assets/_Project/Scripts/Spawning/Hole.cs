using System.Collections;
using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Utils;

namespace WhackAMole.Spawning
{
    /// <summary>
    /// Represents a single hole in the grid. Each hole can hold a carrot
    /// that moles steal when not whacked in time.
    /// </summary>
    public class Hole : MonoBehaviour
    {
        [SerializeField] private Transform spawnPoint;
        [SerializeField] private int holeIndex;
        [SerializeField] private SpriteRenderer carrotRenderer;

        private bool _isOccupied;
        private bool _hasCarrot = true;

        public Transform SpawnPoint => spawnPoint != null ? spawnPoint : transform;
        public bool IsOccupied => _isOccupied;
        public int HoleIndex => holeIndex;
        public bool HasCarrot => _hasCarrot;

        public void SetOccupied(bool occupied)
        {
            _isOccupied = occupied;
        }

        public void ResetCarrot()
        {
            _hasCarrot = true;
            if (carrotRenderer != null)
            {
                carrotRenderer.gameObject.SetActive(true);
                carrotRenderer.color = Color.white;
                carrotRenderer.transform.localScale = Vector3.one;
            }
        }

        /// <summary>
        /// Regenerate a stolen carrot with a grow-back animation.
        /// </summary>
        public void RegenerateCarrot()
        {
            if (_hasCarrot) return;
            _hasCarrot = true;
            if (carrotRenderer != null)
            {
                carrotRenderer.gameObject.SetActive(true);
                carrotRenderer.color = Color.white;
                StartCoroutine(GrowBackAnimation());
            }
            EventBus.FireCarrotRegenerated(holeIndex);
        }

        private IEnumerator GrowBackAnimation()
        {
            float dur = Constants.CARROT_GROW_DURATION;
            float elapsed = 0f;
            carrotRenderer.transform.localScale = Vector3.zero;

            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / dur);
                // Overshoot bounce ease
                float t1 = t - 1f;
                float eased = t1 * t1 * (2.70158f * t1 + 1.70158f) + 1f;
                carrotRenderer.transform.localScale = Vector3.one * eased;
                yield return null;
            }

            carrotRenderer.transform.localScale = Vector3.one;
        }

        public void StealCarrot()
        {
            if (!_hasCarrot) return;
            _hasCarrot = false;
            if (carrotRenderer != null)
                carrotRenderer.gameObject.SetActive(false);
            EventBus.FireCarrotStolen(holeIndex);
        }

        /// <summary>
        /// Short warning animation before a mole pops up — carrot jiggles.
        /// </summary>
        public IEnumerator PlayWarningAnimation()
        {
            if (carrotRenderer == null || !_hasCarrot) yield break;

            float dur = Constants.CARROT_WARNING_DURATION;
            float elapsed = 0f;
            Vector3 basePos = carrotRenderer.transform.localPosition;

            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                // Quick jiggle — small random horizontal offset
                float shake = Mathf.Sin(elapsed * 40f) * 0.03f;
                carrotRenderer.transform.localPosition = basePos + new Vector3(shake, 0, 0);
                yield return null;
            }

            carrotRenderer.transform.localPosition = basePos;
        }

        /// <summary>
        /// Get adjacent hole indices. Works for any NxN grid using Constants.
        /// </summary>
        public int[] GetAdjacentIndices()
        {
            int cols = Constants.HOLE_COLUMNS;
            int rows = Constants.HOLE_ROWS;
            int row = holeIndex / cols;
            int col = holeIndex % cols;
            var adjacent = new System.Collections.Generic.List<int>();

            for (int dr = -1; dr <= 1; dr++)
            {
                for (int dc = -1; dc <= 1; dc++)
                {
                    if (dr == 0 && dc == 0) continue;
                    int nr = row + dr;
                    int nc = col + dc;
                    if (nr >= 0 && nr < rows && nc >= 0 && nc < cols)
                        adjacent.Add(nr * cols + nc);
                }
            }

            return adjacent.ToArray();
        }

        private void OnValidate()
        {
            if (spawnPoint == null)
                spawnPoint = transform;
        }
    }
}
