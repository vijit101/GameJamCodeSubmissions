using System.Collections;
using UnityEngine;
using WhackAMole.Core;
using WhackAMole.Interfaces;
using WhackAMole.Spawning;
using WhackAMole.Weapons;

namespace WhackAMole.PowerUps
{
    /// <summary>
    /// Abstract base for all power-ups. Spawns from holes like moles,
    /// but activates a timed effect when hit instead of giving score.
    /// </summary>
    public abstract class PowerUp : MonoBehaviour, IHittable, ISpawnable
    {
        [Header("Power-Up Config")]
        [SerializeField] protected float duration = 5f;
        [SerializeField] protected Sprite icon;
        [SerializeField] protected AudioClip activateSound;
        [SerializeField] protected float visibleTime = 3f;

        protected Hole currentHole;
        private Coroutine _lifetimeCoroutine;
        private Coroutine _effectCoroutine;
        private bool _isActive;

        public bool IsAlive => !_isActive && gameObject.activeSelf;
        public abstract string PowerUpName { get; }

        public virtual void Spawn(Hole hole)
        {
            currentHole = hole;
            currentHole.SetOccupied(true);
            _isActive = false;

            transform.position = hole.SpawnPoint.position;
            gameObject.SetActive(true);

            _lifetimeCoroutine = StartCoroutine(LifetimeRoutine());
        }

        public virtual void Despawn()
        {
            if (_lifetimeCoroutine != null)
            {
                StopCoroutine(_lifetimeCoroutine);
                _lifetimeCoroutine = null;
            }

            if (currentHole != null)
            {
                currentHole.SetOccupied(false);
                currentHole = null;
            }

            gameObject.SetActive(false);
        }

        public virtual void OnHit(Weapon weapon, Vector2 hitPoint)
        {
            if (_isActive) return;

            _isActive = true;

            if (activateSound != null)
                AudioManager.Instance.PlaySFX(activateSound);

            EventBus.FirePowerUpActivated(PowerUpName);
            _effectCoroutine = StartCoroutine(EffectRoutine());
            Despawn();
        }

        /// <summary>Subclass defines what happens when the power-up activates.</summary>
        public abstract void Activate();

        /// <summary>Subclass defines how to clean up when the effect expires.</summary>
        public abstract void Deactivate();

        private IEnumerator EffectRoutine()
        {
            Activate();
            yield return new WaitForSeconds(duration);
            Deactivate();
            EventBus.FirePowerUpDeactivated(PowerUpName);
            _isActive = false;
        }

        private IEnumerator LifetimeRoutine()
        {
            yield return new WaitForSeconds(visibleTime);
            if (!_isActive)
            {
                Despawn();
            }
        }
    }
}
