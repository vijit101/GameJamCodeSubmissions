using UnityEngine;

namespace WhackAMole.PowerUps
{
    /// <summary>
    /// Slows time to 50% for 5 seconds, making moles easier to hit.
    /// Restores normal time on deactivate.
    /// </summary>
    public class SlowMoPowerUp : PowerUp
    {
        private const float SLOW_TIME_SCALE = 0.5f;

        public override string PowerUpName => "Slow Motion";

        public override void Activate()
        {
            Time.timeScale = SLOW_TIME_SCALE;
            Time.fixedDeltaTime = 0.02f * SLOW_TIME_SCALE;
        }

        public override void Deactivate()
        {
            Time.timeScale = 1f;
            Time.fixedDeltaTime = 0.02f;
        }
    }
}
