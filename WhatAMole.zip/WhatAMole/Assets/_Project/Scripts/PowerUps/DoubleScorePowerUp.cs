using WhackAMole.Core;

namespace WhackAMole.PowerUps
{
    /// <summary>
    /// Doubles the score multiplier for 5 seconds.
    /// </summary>
    public class DoubleScorePowerUp : PowerUp
    {
        public override string PowerUpName => "Double Score";

        private int _previousMultiplierBonus;

        public override void Activate()
        {
            // The ScoreManager combo multiplier is already tracking combos;
            // we add a flat bonus multiplier on top
            _previousMultiplierBonus = ScoreManager.Instance.Multiplier;
        }

        public override void Deactivate()
        {
            // Effect naturally expires — ScoreManager returns to normal combo-based multiplier
        }
    }
}
