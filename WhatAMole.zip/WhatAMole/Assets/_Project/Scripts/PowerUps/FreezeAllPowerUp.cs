using WhackAMole.Spawning;

namespace WhackAMole.PowerUps
{
    /// <summary>
    /// Freezes ALL currently active moles in place for 3 seconds.
    /// Hit them during the freeze window for easy points.
    /// </summary>
    public class FreezeAllPowerUp : PowerUp
    {
        private const float FREEZE_DURATION = 3f;

        public override string PowerUpName => "Freeze All";

        public override void Activate()
        {
            MoleFactory.Instance?.FreezeAllMoles(FREEZE_DURATION);
        }

        public override void Deactivate()
        {
            // Moles unfreeze automatically via their own Freeze coroutine
        }
    }
}
