using WhackAMole.Core;

namespace WhackAMole.PowerUps
{
    /// <summary>
    /// Activates a shield that negates the next BombMole score penalty.
    /// One-time use per activation.
    /// </summary>
    public class ShieldPowerUp : PowerUp
    {
        public override string PowerUpName => "Shield";

        public override void Activate()
        {
            ScoreManager.Instance.ShieldActive = true;
        }

        public override void Deactivate()
        {
            // Shield may have already been consumed by a bomb hit.
            // If it hasn't been used, remove it when the power-up expires.
            ScoreManager.Instance.ShieldActive = false;
        }
    }
}
