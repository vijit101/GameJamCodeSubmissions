using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    TextMeshProUGUI _starsText;
    TextMeshProUGUI _timeText;
    TextMeshProUGUI _delayText;
    TextMeshProUGUI _levelNameText;

    GameObject      _prologuePanel;
    GameObject      _deathPanel;
    GameObject      _levelCompletePanel;
    GameObject      _victoryPanel;
    GameObject      _pausePanel;

    TextMeshProUGUI _deathMsgText;
    TextMeshProUGUI _deathInfoText;
    TextMeshProUGUI _completeInfoText;
    TextMeshProUGUI _victoryInfoText;

    RawImage[]      _deathStars    = new RawImage[3];
    RawImage[]      _completeStars = new RawImage[3];
    RawImage[]      _victoryStars  = new RawImage[3];
    RawImage[]      _hudStars      = new RawImage[3];

    Texture2D       _starOnTex;
    Texture2D       _starOffTex;
    Texture2D       _winTex;

    // Powerup HUD
    GameObject      _powerupPanel;
    UnityEngine.UI.RawImage _powerupIcon;
    TextMeshProUGUI _powerupNameText;
    TextMeshProUGUI _powerupHintText;
    Texture2D       _sprintIconTex;
    Texture2D       _invincIconTex;

    readonly List<PopupText> _popupPool = new List<PopupText>(8);
    Canvas _canvas;

    static readonly string[] DeathLines =
    {
        "Rishtey mein toh hum tumhare baap lagte hain... naam hai AGNI.",
        "Mere paas fire hai, speed hai, power hai. Tumhare paas? Kuch nahi.",
        "Don ko pakadna mushkil hi nahin, namumkin hai. Tum toh bhaagte bhi nahi paye.",
        "Vijay... tumhara time khatam ho gaya.",
        "Aaj khush toh bahut hoge tum... nahi? Theek hai. GAME OVER.",
        "Main aur meri aag — hum dono tumse behtar hain.",
        "Hum jahan khade hote hain, line wahin se shuru hoti hai. Aur tum? Peeche reh gaye."
    };

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    void Start()
    {
        _winTex    = Resources.Load<Texture2D>("win");
        _starOnTex  = MakeStarTex(64, true);
        _starOffTex = MakeStarTex(64, false);
        _sprintIconTex = MakeCircleTex(32, new Color(1f, 0.55f, 0.05f));
        _invincIconTex = MakeCircleTex(32, new Color(0.15f, 0.85f, 1.0f));

        EnsureEventSystem();
        BuildCanvas();
        BuildHUD();
        BuildPrologueScreen();
        BuildDeathScreen();
        BuildLevelCompleteScreen();
        BuildVictoryScreen();
        BuildPauseScreen();

        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnGameOver      += HandleGameOver;
            GameManager.Instance.OnLevelComplete += HandleLevelComplete;
            GameManager.Instance.OnScoreChanged  += UpdateStars;
            GameManager.Instance.OnPauseChanged  += HandlePauseChanged;
        }
    }

    void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnGameOver      -= HandleGameOver;
            GameManager.Instance.OnLevelComplete -= HandleLevelComplete;
            GameManager.Instance.OnScoreChanged  -= UpdateStars;
            GameManager.Instance.OnPauseChanged  -= HandlePauseChanged;
        }
        if (_starOnTex  != null) Destroy(_starOnTex);
        if (_starOffTex != null) Destroy(_starOffTex);
        if (_sprintIconTex != null) Destroy(_sprintIconTex);
        if (_invincIconTex != null) Destroy(_invincIconTex);
    }

    void Update()
    {
        if (GameManager.Instance == null) return;

        var state = GameManager.Instance.CurrentState;

        if ((Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P)) &&
            (state == GameManager.GameState.Playing || state == GameManager.GameState.Paused))
        {
            if (state == GameManager.GameState.Playing)
                GameManager.Instance.PauseGame();
            else
                GameManager.Instance.ResumeGame();
        }

        if (state != GameManager.GameState.Playing) return;

        if (_timeText != null)
            _timeText.text = $"TIME: {(int)GameManager.Instance.TimeElapsed}s";

        if (_delayText != null && DifficultyManager.Instance != null)
            _delayText.text = $"AI DELAY: {DifficultyManager.Instance.GetCurrentDelay():F1}s";

        UpdatePowerupHUD();
    }

    // ── Star texture ──────────────────────────────────────────────────────────

    static Texture2D MakeStarTex(int size, bool filled)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false)
            { filterMode = FilterMode.Bilinear };

        float cx = size * 0.5f, cy = size * 0.5f;
        float outerR = size * 0.46f;
        float innerR = outerR * 0.40f;
        var poly = new Vector2[10];
        for (int i = 0; i < 5; i++)
        {
            float a1 = Mathf.PI / 2f - i * 2f * Mathf.PI / 5f;
            float a2 = a1 - Mathf.PI / 5f;
            poly[i * 2]     = new Vector2(cx + outerR * Mathf.Cos(a1), cy + outerR * Mathf.Sin(a1));
            poly[i * 2 + 1] = new Vector2(cx + innerR * Mathf.Cos(a2), cy + innerR * Mathf.Sin(a2));
        }

        Color fillCol  = filled ? new Color(1f, 0.85f, 0.05f) : new Color(0.30f, 0.30f, 0.32f, 0.70f);
        var pixels = new Color[size * size];
        for (int idx = 0; idx < pixels.Length; idx++)
        {
            float px = idx % size + 0.5f, py = idx / size + 0.5f;
            pixels[idx] = PointInPoly(new Vector2(px, py), poly) ? fillCol : Color.clear;
        }
        tex.SetPixels(pixels);
        tex.Apply();
        return tex;
    }

    static bool PointInPoly(Vector2 p, Vector2[] poly)
    {
        bool inside = false;
        int n = poly.Length;
        for (int i = 0, j = n - 1; i < n; j = i++)
        {
            if (((poly[i].y > p.y) != (poly[j].y > p.y)) &&
                p.x < (poly[j].x - poly[i].x) * (p.y - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x)
                inside = !inside;
        }
        return inside;
    }

    // Places a row of 3 star RawImages centred on (anchor + offset) and returns them.
    RawImage[] BuildStarRow(Transform parent, Vector2 anchor, Vector2 offset,
                            float starSize = 52f, float gap = 10f)
    {
        var imgs = new RawImage[3];
        float totalW = 3 * starSize + 2 * gap;
        for (int i = 0; i < 3; i++)
        {
            var go = new GameObject($"Star{i}");
            go.transform.SetParent(parent, false);
            var r       = go.AddComponent<RectTransform>();
            r.anchorMin = anchor;
            r.anchorMax = anchor;
            r.pivot     = new Vector2(0.5f, 0.5f);
            r.sizeDelta = new Vector2(starSize, starSize);
            r.anchoredPosition = offset + new Vector2(-totalW / 2f + i * (starSize + gap) + starSize / 2f, 0f);
            imgs[i] = go.AddComponent<RawImage>();
            imgs[i].texture = _starOffTex;
        }
        return imgs;
    }

    void SetStars(RawImage[] row, int earned)
    {
        for (int i = 0; i < row.Length; i++)
            if (row[i] != null) row[i].texture = i < earned ? _starOnTex : _starOffTex;
    }

    // ── EventSystem ───────────────────────────────────────────────────────────

    static void EnsureEventSystem()
    {
        if (FindFirstObjectByType<EventSystem>() != null) return;
        var go = new GameObject("EventSystem");
        go.AddComponent<EventSystem>();
        go.AddComponent<StandaloneInputModule>();
    }

    // ── Canvas ────────────────────────────────────────────────────────────────

    void BuildCanvas()
    {
        var go = new GameObject("GameCanvas");
        go.transform.SetParent(transform);
        _canvas = go.AddComponent<Canvas>();
        _canvas.renderMode   = RenderMode.ScreenSpaceOverlay;
        _canvas.sortingOrder = 20;

        var scaler = go.AddComponent<CanvasScaler>();
        scaler.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.screenMatchMode     = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight  = 0.5f;

        go.AddComponent<GraphicRaycaster>();
    }

    // ── HUD ───────────────────────────────────────────────────────────────────

    void BuildHUD()
    {
        var p = _canvas.transform;

        _levelNameText = AddTMP(LevelData.Current.Name, p,
            new Vector2(0.5f, 1f), new Vector2(1200, 60), 30f,
            new Color(1f, 0.75f, 0.15f), TextAlignmentOptions.Center,
            pivot: new Vector2(0.5f, 1f), pos: new Vector2(0f, -12f));

        // Star icons row top-left
        _hudStars = BuildStarRow(p, new Vector2(0f, 1f),
            new Vector2(100f, -38f), starSize: 34f, gap: 6f);

        // Star count text beside icons
        _starsText = AddTMP("0 / 3", p,
            new Vector2(0f, 1f), new Vector2(120, 50), 30f,
            Color.white, TextAlignmentOptions.Left,
            pivot: new Vector2(0f, 1f), pos: new Vector2(196f, -24f));

        _timeText = AddTMP("TIME: 0s", p,
            new Vector2(1f, 1f), new Vector2(400, 60), 38f,
            Color.white, TextAlignmentOptions.TopRight,
            pivot: new Vector2(1f, 1f), pos: new Vector2(-24f, -24f));

        _delayText = AddTMP($"AI DELAY: {LevelData.Current.AIDelay:F1}s", p,
            new Vector2(0.5f, 0f), new Vector2(500, 60), 34f,
            new Color(1f, 0.3f, 0.3f), TextAlignmentOptions.Center,
            pivot: new Vector2(0.5f, 0f), pos: new Vector2(0f, 32f));

        BuildPowerupSlot();
    }

    // ── Prologue screen ───────────────────────────────────────────────────────

    void BuildPrologueScreen()
    {
        _prologuePanel = new GameObject("ProloguePanel");
        _prologuePanel.transform.SetParent(_canvas.transform, false);

        var img  = _prologuePanel.AddComponent<Image>();
        img.color = new Color(0f, 0f, 0f, 0.95f);
        var rect = _prologuePanel.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        var p = _prologuePanel.transform;

        AddTMP(LevelData.Current.Name, p,
            new Vector2(0.5f, 0.84f), new Vector2(1400, 70), 38f,
            new Color(1f, 0.3f, 0.3f), TextAlignmentOptions.Center);

        string body = string.Join("\n", LevelData.Current.IntroLines);
        AddTMP(body, p,
            new Vector2(0.5f, 0.54f), new Vector2(1100, 460), 34f,
            new Color(0.88f, 0.88f, 0.88f), TextAlignmentOptions.Center);

        if (LevelData.CurrentIndex == 0)
            AddTMP("WASD / Arrow Keys se chalo  |  EXIT dhundho  |  Taare uthao", p,
                new Vector2(0.5f, 0.26f), new Vector2(1200, 50), 26f,
                new Color(0.55f, 0.55f, 0.55f), TextAlignmentOptions.Center);

        var prompt = AddTMP("[ PRESS ANY KEY TO BEGIN ]", p,
            new Vector2(0.5f, 0.14f), new Vector2(900, 60), 36f,
            new Color(1f, 0.85f, 0.15f), TextAlignmentOptions.Center);

        StartCoroutine(PulseAlpha(prompt));
        StartCoroutine(WaitForAnyKey());
    }

    IEnumerator PulseAlpha(TextMeshProUGUI tmp)
    {
        while (_prologuePanel != null && _prologuePanel.activeSelf)
        {
            float t = Mathf.PingPong(Time.unscaledTime * 1.4f, 1f);
            if (tmp != null) tmp.alpha = Mathf.Lerp(0.3f, 1f, t);
            yield return null;
        }
    }

    IEnumerator WaitForAnyKey()
    {
        yield return new WaitForSecondsRealtime(0.5f);
        while (true)
        {
            if (Input.anyKeyDown) { DismissPrologue(); yield break; }
            yield return null;
        }
    }

    void DismissPrologue()
    {
        if (_prologuePanel != null) _prologuePanel.SetActive(false);
        GameManager.Instance?.BeginPlay();
    }

    // ── Pause screen ─────────────────────────────────────────────────────────

    void BuildPauseScreen()
    {
        _pausePanel = new GameObject("PausePanel");
        _pausePanel.transform.SetParent(_canvas.transform, false);

        var bg   = _pausePanel.AddComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.85f);
        var rect = _pausePanel.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        var p = _pausePanel.transform;

        var title = AddTMP("RUKO ZARA — SABAR KARO", p,
            new Vector2(0.5f, 0.78f), new Vector2(1200, 90), 64f,
            new Color(1f, 0.85f, 0.15f), TextAlignmentOptions.Center);
        title.fontStyle = FontStyles.Bold;

        AddTMP("[ ESC / P to resume ]", p,
            new Vector2(0.5f, 0.66f), new Vector2(800, 50), 24f,
            new Color(0.45f, 0.45f, 0.45f), TextAlignmentOptions.Center);

        MakeButton("[ RESUME ]",        p, new Vector2(0.5f, 0.50f),
            () => GameManager.Instance?.ResumeGame());
        MakeButton("[ RESTART ]",       p, new Vector2(0.5f, 0.38f),
            () => GameManager.Instance?.RestartGame());
        MakeButton("[ RETURN TO MENU ]",p, new Vector2(0.5f, 0.26f),
            () => GameManager.Instance?.GoToMenu());

        _pausePanel.SetActive(false);
    }

    void HandlePauseChanged(bool paused) => _pausePanel.SetActive(paused);

    // ── Death screen ──────────────────────────────────────────────────────────

    void BuildDeathScreen()
    {
        _deathPanel = new GameObject("DeathPanel");
        _deathPanel.transform.SetParent(_canvas.transform, false);

        var bg   = _deathPanel.AddComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.88f);
        var rect = _deathPanel.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        var p = _deathPanel.transform;

        _deathMsgText = AddTMP("GG EZ", p,
            new Vector2(0.5f, 0.88f), new Vector2(1300, 100), 72f,
            new Color(1f, 0.22f, 0.22f), TextAlignmentOptions.Center);
        _deathMsgText.fontStyle = FontStyles.Bold;

        var imgGO   = new GameObject("GameOverImage");
        imgGO.transform.SetParent(p, false);
        var imgRect = imgGO.AddComponent<RectTransform>();
        imgRect.anchorMin        = new Vector2(0.5f, 0.5f);
        imgRect.anchorMax        = new Vector2(0.5f, 0.5f);
        imgRect.pivot            = new Vector2(0.5f, 0.5f);
        imgRect.anchoredPosition = new Vector2(0f, 40f);
        imgRect.sizeDelta        = new Vector2(480f, 270f);
        var rawImg = imgGO.AddComponent<RawImage>();
        var goTex  = Resources.Load<Texture2D>("gameover");
        if (goTex != null) rawImg.texture = goTex;

        // Star icons
        _deathStars = BuildStarRow(p, new Vector2(0.5f, 0.5f),
            new Vector2(0f, -200f), starSize: 60f, gap: 14f);

        _deathInfoText = AddTMP("", p,
            new Vector2(0.5f, 0.5f), new Vector2(800, 120), 34f,
            new Color(0.75f, 0.75f, 0.75f), TextAlignmentOptions.Center,
            pos: new Vector2(0f, -290f));
        _deathInfoText.lineSpacing = 6f;

        MakeButton("[ RETRY ]", p, new Vector2(0.35f, 0.08f),
            () => GameManager.Instance?.RestartGame());
        MakeButton("[ MENU ]",  p, new Vector2(0.65f, 0.08f),
            () => GameManager.Instance?.GoToMenu());

        _deathPanel.SetActive(false);
    }

    void HandleGameOver()
    {
        _deathPanel.SetActive(true);
        _deathMsgText.text = DeathLines[Random.Range(0, DeathLines.Length)];

        if (GameManager.Instance != null)
        {
            var gm = GameManager.Instance;
            SetStars(_deathStars, gm.StarsCollected);
            _deathInfoText.text =
                $"{LevelData.Current.Name}\n" +
                $"SURVIVED: {(int)gm.TimeElapsed}s";
        }
    }

    // ── Level Complete screen ─────────────────────────────────────────────────

    void BuildLevelCompleteScreen()
    {
        _levelCompletePanel = new GameObject("LevelCompletePanel");
        _levelCompletePanel.transform.SetParent(_canvas.transform, false);

        var bg   = _levelCompletePanel.AddComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.90f);
        var rect = _levelCompletePanel.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        var p = _levelCompletePanel.transform;

        AddTMP("SAHI HAI BOSS!", p,
            new Vector2(0.5f, 0.90f), new Vector2(1300, 100), 72f,
            new Color(0.2f, 1.0f, 0.5f), TextAlignmentOptions.Center).fontStyle = FontStyles.Bold;

        // Win image
        var winImgGO   = new GameObject("WinImage");
        winImgGO.transform.SetParent(p, false);
        var winImgRect = winImgGO.AddComponent<RectTransform>();
        winImgRect.anchorMin        = new Vector2(0.5f, 0.5f);
        winImgRect.anchorMax        = new Vector2(0.5f, 0.5f);
        winImgRect.pivot            = new Vector2(0.5f, 0.5f);
        winImgRect.anchoredPosition = new Vector2(0f, 40f);
        winImgRect.sizeDelta        = new Vector2(640f, 360f);
        var winRaw = winImgGO.AddComponent<RawImage>();
        if (_winTex != null) winRaw.texture = _winTex;

        // Star icons below image
        _completeStars = BuildStarRow(p, new Vector2(0.5f, 0.5f),
            new Vector2(0f, -200f), starSize: 64f, gap: 16f);

        _completeInfoText = AddTMP("", p,
            new Vector2(0.5f, 0.5f), new Vector2(900, 100), 34f,
            new Color(0.75f, 0.75f, 0.75f), TextAlignmentOptions.Center,
            pos: new Vector2(0f, -290f));
        _completeInfoText.lineSpacing = 8f;

        MakeButton("[ RETRY LEVEL ]", p, new Vector2(0.22f, 0.08f),
            () => GameManager.Instance?.RestartGame());

        MakeButton("[ NEXT LEVEL ]", p, new Vector2(0.50f, 0.08f), () => {
            int next = LevelData.CurrentIndex + 1;
            if (next < LevelData.All.Length && LevelData.IsUnlocked(next))
                GameManager.Instance?.GoToNextLevel();
            else
                GameManager.Instance?.GoToMenu();
        });

        MakeButton("[ MENU ]", p, new Vector2(0.78f, 0.08f),
            () => GameManager.Instance?.GoToMenu());

        _levelCompletePanel.SetActive(false);
    }

    // ── Victory screen ────────────────────────────────────────────────────────

    void BuildVictoryScreen()
    {
        _victoryPanel = new GameObject("VictoryPanel");
        _victoryPanel.transform.SetParent(_canvas.transform, false);

        var bg   = _victoryPanel.AddComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.92f);
        var rect = _victoryPanel.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        var p = _victoryPanel.transform;

        var title = AddTMP("7 CRORE!", p,
            new Vector2(0.5f, 0.92f), new Vector2(1600, 120), 96f,
            new Color(1f, 0.85f, 0.15f), TextAlignmentOptions.Center);
        title.fontStyle = FontStyles.Bold;

        var victWinGO   = new GameObject("WinImage");
        victWinGO.transform.SetParent(p, false);
        var victWinRect = victWinGO.AddComponent<RectTransform>();
        victWinRect.anchorMin        = new Vector2(0.5f, 0.5f);
        victWinRect.anchorMax        = new Vector2(0.5f, 0.5f);
        victWinRect.pivot            = new Vector2(0.5f, 0.5f);
        victWinRect.anchoredPosition = new Vector2(0f, 50f);
        victWinRect.sizeDelta        = new Vector2(640f, 360f);
        var victWinRaw = victWinGO.AddComponent<RawImage>();
        if (_winTex != null) victWinRaw.texture = _winTex;

        _victoryStars = BuildStarRow(p, new Vector2(0.5f, 0.5f),
            new Vector2(0f, -195f), starSize: 64f, gap: 16f);

        _victoryInfoText = AddTMP("Paanch levels jeet liye. Aag bhi haar gayi. Baap baap hota hai.", p,
            new Vector2(0.5f, 0.5f), new Vector2(1200, 80), 34f,
            new Color(0.88f, 0.88f, 0.88f), TextAlignmentOptions.Center,
            pos: new Vector2(0f, -285f));

        MakeButton("[ PLAY AGAIN ]", p, new Vector2(0.35f, 0.05f), () => {
            LevelData.CurrentIndex = 0;
            GameManager.Instance?.RestartGame();
        });
        MakeButton("[ MENU ]", p, new Vector2(0.65f, 0.05f),
            () => GameManager.Instance?.GoToMenu());

        _victoryPanel.SetActive(false);
    }

    void HandleLevelComplete()
    {
        if (GameManager.Instance == null) return;
        var gm = GameManager.Instance;

        if (gm.CurrentState == GameManager.GameState.Victory)
        {
            _victoryPanel.SetActive(true);
            SetStars(_victoryStars, gm.StarsCollected);
        }
        else
        {
            _levelCompletePanel.SetActive(true);
            SetStars(_completeStars, gm.StarsCollected);

            int    nextIdx = LevelData.CurrentIndex + 1;
            string info    = $"TIME: {(int)gm.TimeElapsed}s";
            if (nextIdx < LevelData.All.Length)
            {
                info += LevelData.IsUnlocked(nextIdx)
                    ? $"\nUNLOCKED: {LevelData.All[nextIdx].Name}"
                    : $"\nNeed {LevelData.All[nextIdx].TotalStarsRequired} total stars to unlock next";
            }
            _completeInfoText.text = info;
        }
    }

    void UpdateStars(int count)
    {
        if (_starsText != null) _starsText.text = $"{count} / 3";
        SetStars(_hudStars, count);
    }

    // ── Powerup HUD ───────────────────────────────────────────────────────────

    void BuildPowerupSlot()
    {
        var p = _canvas.transform;

        // Background panel — bottom left
        _powerupPanel = new GameObject("PowerupSlot");
        _powerupPanel.transform.SetParent(p, false);
        var pr = _powerupPanel.AddComponent<RectTransform>();
        pr.anchorMin        = new Vector2(0f, 0f);
        pr.anchorMax        = new Vector2(0f, 0f);
        pr.pivot            = new Vector2(0f, 0f);
        pr.anchoredPosition = new Vector2(20f, 20f);
        pr.sizeDelta        = new Vector2(280f, 70f);
        var bg = _powerupPanel.AddComponent<UnityEngine.UI.Image>();
        bg.color = new Color(0f, 0f, 0f, 0.65f);

        // Icon
        var iconGO = new GameObject("Icon");
        iconGO.transform.SetParent(_powerupPanel.transform, false);
        var ir = iconGO.AddComponent<RectTransform>();
        ir.anchorMin        = new Vector2(0f, 0.5f);
        ir.anchorMax        = new Vector2(0f, 0.5f);
        ir.pivot            = new Vector2(0f, 0.5f);
        ir.anchoredPosition = new Vector2(10f, 0f);
        ir.sizeDelta        = new Vector2(48f, 48f);
        _powerupIcon = iconGO.AddComponent<UnityEngine.UI.RawImage>();

        // Name text
        _powerupNameText = AddTMP("", _powerupPanel.transform,
            new Vector2(0f, 0.7f), new Vector2(200f, 32f), 22f,
            Color.white, TextAlignmentOptions.Left,
            pivot: new Vector2(0f, 0.5f), pos: new Vector2(68f, 0f));

        // Hint / countdown text
        _powerupHintText = AddTMP("", _powerupPanel.transform,
            new Vector2(0f, 0.3f), new Vector2(200f, 26f), 17f,
            new Color(0.6f, 0.6f, 0.6f), TextAlignmentOptions.Left,
            pivot: new Vector2(0f, 0.5f), pos: new Vector2(68f, 0f));

        _powerupPanel.SetActive(false);
    }

    static Texture2D MakeCircleTex(int size, Color color)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
        float r = size * 0.5f, cx = r, cy = r;
        var px = new Color[size * size];
        for (int i = 0; i < px.Length; i++)
        {
            float dx = i % size - cx + 0.5f, dy = i / size - cy + 0.5f;
            px[i] = dx * dx + dy * dy <= r * r ? color : Color.clear;
        }
        tex.SetPixels(px); tex.Apply();
        return tex;
    }

    void UpdatePowerupHUD()
    {
        if (_powerupPanel == null || PlayerController.Instance == null) return;

        var pc = PlayerController.Instance;
        bool sprinting   = pc.IsSprinting;
        bool invincible  = pc.IsInvincible;
        bool active      = sprinting || invincible;
        bool held        = pc.HeldPowerup.HasValue;

        if (!active && !held) { _powerupPanel.SetActive(false); return; }

        _powerupPanel.SetActive(true);

        if (active)
        {
            var type = sprinting ? PowerupType.Sprint : PowerupType.Invincibility;
            _powerupIcon.texture    = type == PowerupType.Sprint ? _sprintIconTex : _invincIconTex;
            _powerupNameText.text   = type == PowerupType.Sprint ? "SPRINT" : "SHIELD";
            _powerupNameText.color  = type == PowerupType.Sprint
                ? new Color(1f, 0.6f, 0.1f) : new Color(0.2f, 0.9f, 1f);
            float pulse = 0.6f + 0.4f * Mathf.Abs(Mathf.Sin(Time.time * 4f));
            _powerupHintText.text  = $"{pc.PowerupTimer:F1}s remaining";
            _powerupHintText.color = new Color(0.9f, 0.9f, 0.9f, pulse);
        }
        else if (held)
        {
            var type = pc.HeldPowerup.Value;
            _powerupIcon.texture   = type == PowerupType.Sprint ? _sprintIconTex : _invincIconTex;
            _powerupNameText.text  = type == PowerupType.Sprint ? "SPRINT" : "SHIELD";
            _powerupNameText.color = type == PowerupType.Sprint
                ? new Color(1f, 0.6f, 0.1f) : new Color(0.2f, 0.9f, 1f);
            _powerupHintText.text  = "[SPACE] to activate";
            _powerupHintText.color = new Color(0.55f, 0.55f, 0.55f, 1f);
        }
    }

    // ── World-space popups ────────────────────────────────────────────────────

    public void ShowPopup(string text, Vector3 worldPos)
    {
        PopupText popup = null;
        foreach (var p in _popupPool)
            if (p != null && !p.gameObject.activeSelf) { popup = p; break; }

        if (popup == null)
        {
            var go = new GameObject("Popup");
            popup  = go.AddComponent<PopupText>();
            _popupPool.Add(popup);
        }
        popup.Show(text, worldPos);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    TextMeshProUGUI AddTMP(string text, Transform parent,
        Vector2 anchor, Vector2 size, float fontSize,
        Color color, TextAlignmentOptions align,
        Vector2 pivot = default, Vector2 pos = default)
    {
        if (pivot == default) pivot = new Vector2(0.5f, 0.5f);

        var go = new GameObject(text.Length > 24 ? text.Substring(0, 24) : text);
        go.transform.SetParent(parent, false);

        var r = go.AddComponent<RectTransform>();
        r.anchorMin        = anchor;
        r.anchorMax        = anchor;
        r.pivot            = pivot;
        r.anchoredPosition = pos;
        r.sizeDelta        = size;

        var tmp       = go.AddComponent<TextMeshProUGUI>();
        tmp.text      = text;
        tmp.fontSize  = fontSize;
        tmp.color     = color;
        tmp.alignment = align;
        return tmp;
    }

    void MakeButton(string label, Transform parent, Vector2 anchor,
        UnityEngine.Events.UnityAction onClick)
    {
        var go = new GameObject(label);
        go.transform.SetParent(parent, false);

        var r = go.AddComponent<RectTransform>();
        r.anchorMin        = anchor;
        r.anchorMax        = anchor;
        r.pivot            = new Vector2(0.5f, 0.5f);
        r.anchoredPosition = Vector2.zero;
        r.sizeDelta        = new Vector2(300, 76);

        var img   = go.AddComponent<Image>();
        img.color = new Color(0.14f, 0.14f, 0.26f, 0.96f);

        var btn    = go.AddComponent<Button>();
        var colors = btn.colors;
        colors.normalColor      = new Color(0.14f, 0.14f, 0.26f);
        colors.highlightedColor = new Color(0.30f, 0.30f, 0.55f);
        colors.pressedColor     = new Color(0.55f, 0.12f, 0.12f);
        colors.selectedColor    = new Color(0.30f, 0.30f, 0.55f);
        btn.colors              = colors;
        btn.targetGraphic       = img;
        btn.onClick.AddListener(onClick);

        AddTMP(label, go.transform,
            new Vector2(0.5f, 0.5f), new Vector2(300, 76), 30f,
            Color.white, TextAlignmentOptions.Center);
    }
}
