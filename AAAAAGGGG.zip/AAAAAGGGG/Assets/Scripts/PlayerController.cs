using System;
using System.Collections;
using UnityEngine;

/// <summary>
/// Grid-based player movement. Raises OnMoved so AI can record moves.
/// Checks exit cell after each step to trigger level completion.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class PlayerController : MonoBehaviour
{
    public static PlayerController Instance { get; private set; }

    public Vector2Int GridPos { get; private set; }

    /// <summary>Fires with the direction vector every time the player moves one cell.</summary>
    public event Action<Vector2Int> OnMoved;

    const float MoveInterval      = 0.2f;
    const float SprintMoveInterval = 0.09f;
    const float SprintDuration     = 4f;
    const float InvincDuration     = 5f;

    public PowerupType? HeldPowerup  { get; private set; }
    public bool         IsInvincible { get; private set; }
    public bool         IsSprinting  { get; private set; }
    public float        PowerupTimer { get; private set; }  // time remaining on active effect

    SpriteRenderer _sr;
    float          _moveTimer;
    Coroutine      _lerpRoutine;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        _sr = GetComponent<SpriteRenderer>();
        _sr.sortingOrder = 2;
    }

    void Start()
    {
        GridPos = new Vector2Int(1, 1);
        if (MazeManager.Instance != null)
            transform.position = MazeManager.Instance.GridToWorld(GridPos);
        if (AssetManager.Instance != null)
            _sr.sprite = AssetManager.Instance.PlayerSprite;
    }

    void Update()
    {
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.CurrentState != GameManager.GameState.Playing) return;

        // Powerup activation
        if (Input.GetKeyDown(KeyCode.Space) && HeldPowerup.HasValue)
            ActivatePowerup();

        // Tick active effect
        if (IsSprinting || IsInvincible)
        {
            PowerupTimer -= Time.deltaTime;
            if (PowerupTimer <= 0f)
            {
                IsSprinting  = false;
                IsInvincible = false;
                PowerupTimer = 0f;
                _sr.color = Color.white;
            }
        }

        _moveTimer += Time.deltaTime;
        float interval = IsSprinting ? SprintMoveInterval : MoveInterval;
        if (_moveTimer < interval) return;

        Vector2Int dir = ReadInput();
        if (dir == Vector2Int.zero) return;

        Vector2Int next = GridPos + dir;
        if (MazeManager.Instance != null && MazeManager.Instance.IsWall(next)) return;

        _moveTimer = 0f;
        GridPos    = next;
        OnMoved?.Invoke(dir);

        // Exit reached → complete level
        if (MazeManager.Instance != null && GridPos == MazeManager.Instance.Exit)
            GameManager.Instance?.TriggerLevelComplete();

        Vector3 worldTarget = MazeManager.Instance != null
            ? MazeManager.Instance.GridToWorld(GridPos)
            : new Vector3(GridPos.x + 0.5f, GridPos.y + 0.5f, 0f);

        float moveLen = IsSprinting ? SprintMoveInterval : MoveInterval;
        if (_lerpRoutine != null) StopCoroutine(_lerpRoutine);
        _lerpRoutine = StartCoroutine(LerpTo(worldTarget, moveLen));
    }

    static Vector2Int ReadInput()
    {
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))    return Vector2Int.up;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))  return Vector2Int.down;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))  return Vector2Int.left;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) return Vector2Int.right;
        return Vector2Int.zero;
    }

    IEnumerator LerpTo(Vector3 target, float duration)
    {
        Vector3 start = transform.position;
        float   t     = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            transform.position = Vector3.Lerp(start, target, t / duration);
            yield return null;
        }
        transform.position = target;
        _lerpRoutine = null;
    }

    public void CollectPowerup(PowerupType type)
    {
        if (HeldPowerup.HasValue) return; // can only hold one
        HeldPowerup = type;
        AudioManager.Instance?.PlayCoin();
        UIManager.Instance?.ShowPopup(
            type == PowerupType.Sprint ? "SPRINT!" : "SHIELD!",
            transform.position + Vector3.up * 0.5f);
    }

    void ActivatePowerup()
    {
        if (!HeldPowerup.HasValue) return;
        var type = HeldPowerup.Value;
        HeldPowerup = null;

        if (type == PowerupType.Sprint)
        {
            IsSprinting  = true;
            PowerupTimer = SprintDuration;
            _sr.color    = new Color(1f, 0.6f, 0.1f); // orange tint
        }
        else
        {
            IsInvincible = true;
            PowerupTimer = InvincDuration;
            _sr.color    = new Color(0.3f, 0.9f, 1f);  // cyan tint
        }
    }

    void OnDestroy()
    {
        if (_lerpRoutine != null) StopCoroutine(_lerpRoutine);
    }
}
