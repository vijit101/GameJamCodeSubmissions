using TMPro;
using UnityEngine;

/// <summary>
/// Spawns StarControllers at the maze's dead-end positions and an EXIT label.
/// Attach to: StarManager GameObject in Game scene.
/// </summary>
public class StarManager : MonoBehaviour
{
    void Start()
    {
        if (MazeManager.Instance == null) return;

        // Spawn stars at dead-end positions
        if (MazeManager.Instance.Stars != null)
        {
            foreach (var pos in MazeManager.Instance.Stars)
            {
                var go  = new GameObject($"Star_{pos.x}_{pos.y}");
                go.AddComponent<SpriteRenderer>();
                go.transform.position = MazeManager.Instance.GridToWorld(pos);
                var star = go.AddComponent<StarController>();
                star.Initialize(pos);
            }
        }

        // Place EXIT label above the exit cell
        SpawnExitLabel();
    }

    static void SpawnExitLabel()
    {
        if (MazeManager.Instance == null) return;

        var exit      = MazeManager.Instance.Exit;
        var worldPos  = MazeManager.Instance.GridToWorld(exit);

        var labelGO = new GameObject("ExitLabel");
        labelGO.transform.position = worldPos + new Vector3(0f, 0.6f, 0f);

        var tmp          = labelGO.AddComponent<TextMeshPro>();
        tmp.text         = "EXIT";
        tmp.fontSize     = 1.4f;
        tmp.color        = new Color(0.2f, 1.0f, 0.7f);
        tmp.alignment    = TextAlignmentOptions.Center;
        tmp.sortingOrder = 4;
        tmp.fontStyle    = FontStyles.Bold;
    }
}
