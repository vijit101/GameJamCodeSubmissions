/// <summary>
/// Static config for all 5 levels.
/// All levels share the same 41×35 maze footprint — difficulty comes from
/// different seeds (layouts), increasing braiding (more path choices), and
/// shrinking AI delay.
/// Width/Height must be ODD: DFS rooms sit at odd coords, walls between at even.
/// </summary>
public static class LevelData
{
    public struct Config
    {
        public string   Name;
        public int      Width, Height;
        public int      Seed;
        public float    AIDelay;
        public float    BraidFraction;      // fraction of removable walls deleted after DFS (adds loops)
        public int      TotalStarsRequired; // cumulative stars across ALL levels to unlock this one
        public string[] IntroLines;
    }

    public static readonly Config[] All =
    {
        new Config {
            Name   = "LEVEL 1  —  THE SHARABI WAKES UP",
            Width  = 41, Height = 35, Seed = 1001,
            AIDelay = 3.0f, BraidFraction = 0.10f, TotalStarsRequired = 0,
            IntroLines = new[] {
                "Rishtey mein toh hum tumhare baap lagte hain.",
                "Naam hai... AGNI.",
                "Yeh aag abhi sirf jaag rahi hai — 3 second peeche.",
                "",
                "EXIT dhundho (top-right). Taare uthao.",
                "Minimap dekhna — wahan sab dikha deta hai.",
                "Pakadne mat do."
            }
        },
        new Config {
            Name   = "LEVEL 2  —  DON KA INTEZAAR",
            Width  = 41, Height = 35, Seed = 2002,
            AIDelay = 2.5f, BraidFraction = 0.13f, TotalStarsRequired = 1,
            IntroLines = new[] {
                "Don ko pakadna mushkil hi nahin, namumkin hai.",
                "Par aag? Woh 2.5 second mein tumhare peeche hai.",
                "",
                "Teen taare chhuppe hain andheron mein.",
                "Lena zaroori nahi.",
                "Par loge zaroor."
            }
        },
        new Config {
            Name   = "LEVEL 3  —  DEEWAR KE PEECHE",
            Width  = 41, Height = 35, Seed = 3003,
            AIDelay = 2.0f, BraidFraction = 0.16f, TotalStarsRequired = 3,
            IntroLines = new[] {
                "2 second.",
                "Mere paas aag hai. Tumhare paas kya hai?",
                "",
                "Zyada raaste. Zyada dhoka. Zyada confusion.",
                "Yeh deewar tumhe nahi bachayegi.",
                "Aag bhi nahi maafi deti."
            }
        },
        new Config {
            Name   = "LEVEL 4  —  AGNEEPATH",
            Width  = 41, Height = 35, Seed = 4004,
            AIDelay = 1.5f, BraidFraction = 0.19f, TotalStarsRequired = 6,
            IntroLines = new[] {
                "1.5 second.",
                "Har galat mod pe sab kuch kho jaoge.",
                "",
                "Aag tumhare kaanon mein saaans le rahi hai.",
                "Sochho. Badho. Jiyo."
            }
        },
        new Config {
            Name   = "LEVEL 5  —  KAALIA KA KAHAR",
            Width  = 41, Height = 35, Seed = 5005,
            AIDelay = 1.0f, BraidFraction = 0.22f, TotalStarsRequired = 9,
            IntroLines = new[] {
                "1 second.",
                "Aag ab TUM ho.",
                "",
                "Yeh aakhri maze hai.",
                "Ek hi niklega yahan se.",
                "",
                "Hum. Jahan. Khade. Hote. Hain."
            }
        },
    };

    public static int CurrentIndex
    {
        get => UnityEngine.PlayerPrefs.GetInt("CurrentLevel", 0);
        set => UnityEngine.PlayerPrefs.SetInt("CurrentLevel", value);
    }

    public static Config Current =>
        All[UnityEngine.Mathf.Clamp(CurrentIndex, 0, All.Length - 1)];

    public static bool IsLastLevel => CurrentIndex >= All.Length - 1;

    public static int GetBestStars(int levelIndex) =>
        UnityEngine.PlayerPrefs.GetInt($"Level{levelIndex}Stars", 0);

    public static void SaveBestStars(int levelIndex, int stars)
    {
        if (stars > GetBestStars(levelIndex))
            UnityEngine.PlayerPrefs.SetInt($"Level{levelIndex}Stars", stars);
    }

    public static int TotalStarsEarned()
    {
        int total = 0;
        for (int i = 0; i < All.Length; i++) total += GetBestStars(i);
        return total;
    }

    public static bool IsUnlocked(int levelIndex)
    {
        if (levelIndex <= 0) return true;
        return TotalStarsEarned() >= All[levelIndex].TotalStarsRequired;
    }
}
