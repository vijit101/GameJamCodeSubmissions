using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuManager : MonoBehaviour
{
    Texture2D _starOnTex;
    Texture2D _starOffTex;

    void Awake()
    {
        Application.targetFrameRate = 60;
        var cam = Camera.main;
        if (cam != null)
        {
            cam.clearFlags      = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.04f, 0.04f, 0.06f);
        }
    }

    void Start()
    {
        _starOnTex  = MakeStarTex(48, true);
        _starOffTex = MakeStarTex(48, false);

        EnsureEventSystem();
        BuildMenu();
        PlayBGMusic();
    }

    void PlayBGMusic()
    {
        var bgClip = Resources.Load<AudioClip>("bg");
        if (bgClip == null) return;
        var src = gameObject.AddComponent<AudioSource>();
        src.clip = bgClip;
        src.loop = true;
        src.volume = 0.35f;
        src.playOnAwake = false;
        src.Play();
    }

    void OnDestroy()
    {
        if (_starOnTex  != null) Destroy(_starOnTex);
        if (_starOffTex != null) Destroy(_starOffTex);
    }

    static void EnsureEventSystem()
    {
        if (FindFirstObjectByType<EventSystem>() == null)
        {
            var go = new GameObject("EventSystem");
            go.AddComponent<EventSystem>();
            go.AddComponent<StandaloneInputModule>();
        }
    }

    void BuildMenu()
    {
        var canvasGO = new GameObject("MenuCanvas");
        var canvas   = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        var scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.screenMatchMode     = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight  = 0.5f;
        canvasGO.AddComponent<GraphicRaycaster>();

        var p = canvas.transform;

        var title = MakeTMP("AAAAAGGGG", p,
            new Vector2(0.5f, 0.93f), new Vector2(1600, 110), 96f,
            new Color(1f, 0.22f, 0.22f));
        title.fontStyle = FontStyles.Bold;

        MakeTMP("Aag ne teri films dekhi hain. Impress nahi hua. Ab woh tujhe pakadne aaya hai.", p,
            new Vector2(0.5f, 0.84f), new Vector2(1400, 55), 26f,
            new Color(0.60f, 0.60f, 0.60f));

        // Total stars — label on the left, star images to the right
        int totalEarned = LevelData.TotalStarsEarned();
        int totalMax    = LevelData.All.Length * 3;
        MakeTMP($"TOTAL STARS:  {totalEarned} / {totalMax}", p,
            new Vector2(0.5f, 0.76f), new Vector2(500, 50), 28f,
            new Color(1f, 0.80f, 0.15f));

        MakeTMP("SELECT LEVEL", p,
            new Vector2(0.5f, 0.69f), new Vector2(700, 44), 24f,
            new Color(0.45f, 0.45f, 0.45f));

        float[] anchors = { 0.625f, 0.525f, 0.425f, 0.325f, 0.225f };
        for (int i = 0; i < LevelData.All.Length; i++)
            BuildLevelRow(p, i, anchors[i]);

        MakeTMP("WASD / Arrow Keys  |  EXIT dhundho  |  Taare uthao  |  Aag se bachte raho", p,
            new Vector2(0.5f, 0.07f), new Vector2(1500, 42), 20f,
            new Color(0.38f, 0.38f, 0.38f));
    }

    void BuildLevelRow(Transform parent, int idx, float anchorY)
    {
        var  cfg      = LevelData.All[idx];
        bool unlocked = LevelData.IsUnlocked(idx);
        int  best     = LevelData.GetBestStars(idx);

        var panelGO   = new GameObject($"LevelRow_{idx}");
        panelGO.transform.SetParent(parent, false);
        var pr        = panelGO.AddComponent<RectTransform>();
        pr.anchorMin        = new Vector2(0.5f, anchorY);
        pr.anchorMax        = new Vector2(0.5f, anchorY);
        pr.pivot            = new Vector2(0.5f, 0.5f);
        pr.anchoredPosition = Vector2.zero;
        pr.sizeDelta        = new Vector2(1200, 85);

        var bg   = panelGO.AddComponent<Image>();
        bg.color = unlocked
            ? new Color(0.10f, 0.12f, 0.22f, 0.95f)
            : new Color(0.07f, 0.07f, 0.10f, 0.95f);

        var pt = panelGO.transform;

        // Level number badge
        string badge = unlocked ? $"{idx + 1}" : "X";
        MakeChild(badge, pt, new Vector2(0.05f, 0.5f), new Vector2(55, 70), 32f,
            unlocked ? new Color(1f, 0.80f, 0.15f) : new Color(0.35f, 0.35f, 0.35f));

        // Level name
        MakeChild(cfg.Name, pt, new Vector2(0.36f, 0.5f), new Vector2(600, 70), 24f,
            unlocked ? Color.white : new Color(0.38f, 0.38f, 0.38f));

        // Star icons (3 stars max per level)
        PlaceStarRow(pt, new Vector2(0.68f, 0.5f), Vector2.zero, best, 3, 26f, 5f);

        // Right tag
        string tag; Color tagColor;
        if (!unlocked)
        {
            tag      = $"Need {cfg.TotalStarsRequired} stars";
            tagColor = new Color(0.70f, 0.35f, 0.35f);
        }
        else
        {
            tag      = $"AI {cfg.AIDelay:F1}s";
            tagColor = new Color(1f, 0.40f, 0.40f);
        }
        MakeChild(tag, pt, new Vector2(0.90f, 0.5f), new Vector2(220, 70), 20f, tagColor);

        if (unlocked)
        {
            int cap    = idx;
            var btn    = panelGO.AddComponent<Button>();
            var colors = btn.colors;
            colors.normalColor      = Color.white;
            colors.highlightedColor = new Color(1.35f, 1.35f, 1.35f);
            colors.pressedColor     = new Color(0.75f, 0.75f, 0.75f);
            btn.colors              = colors;
            btn.targetGraphic       = bg;
            btn.onClick.AddListener(() => {
                LevelData.CurrentIndex = cap;
                SceneManager.LoadScene("Game");
            });
        }
    }

    // Places N star images centred on the anchor
    void PlaceStarRow(Transform parent, Vector2 anchor, Vector2 offset,
                      int earned, int total, float size, float gap)
    {
        float totalW = total * size + (total - 1) * gap;
        for (int i = 0; i < total; i++)
        {
            var go = new GameObject($"Star{i}");
            go.transform.SetParent(parent, false);
            var r       = go.AddComponent<RectTransform>();
            r.anchorMin = anchor;
            r.anchorMax = anchor;
            r.pivot     = new Vector2(0.5f, 0.5f);
            r.sizeDelta = new Vector2(size, size);
            r.anchoredPosition = offset +
                new Vector2(-totalW / 2f + i * (size + gap) + size / 2f, 0f);
            go.AddComponent<RawImage>().texture = i < earned ? _starOnTex : _starOffTex;
        }
    }

    // ── Star texture ──────────────────────────────────────────────────────────

    static Texture2D MakeStarTex(int size, bool filled)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false)
            { filterMode = FilterMode.Bilinear };

        float cx = size * 0.5f, cy = size * 0.5f;
        float outerR = size * 0.46f;
        float innerR = outerR * 0.40f;
        var poly = new Vector2[10];
        for (int i = 0; i < 5; i++)
        {
            float a1 = Mathf.PI / 2f - i * 2f * Mathf.PI / 5f;
            float a2 = a1 - Mathf.PI / 5f;
            poly[i * 2]     = new Vector2(cx + outerR * Mathf.Cos(a1), cy + outerR * Mathf.Sin(a1));
            poly[i * 2 + 1] = new Vector2(cx + innerR * Mathf.Cos(a2), cy + innerR * Mathf.Sin(a2));
        }

        Color fillCol = filled ? new Color(1f, 0.85f, 0.05f) : new Color(0.28f, 0.28f, 0.30f, 0.70f);
        var pixels = new Color[size * size];
        for (int idx = 0; idx < pixels.Length; idx++)
        {
            float px = idx % size + 0.5f, py = idx / size + 0.5f;
            pixels[idx] = PointInPoly(new Vector2(px, py), poly) ? fillCol : Color.clear;
        }
        tex.SetPixels(pixels);
        tex.Apply();
        return tex;
    }

    static bool PointInPoly(Vector2 p, Vector2[] poly)
    {
        bool inside = false;
        int n = poly.Length;
        for (int i = 0, j = n - 1; i < n; j = i++)
        {
            if (((poly[i].y > p.y) != (poly[j].y > p.y)) &&
                p.x < (poly[j].x - poly[i].x) * (p.y - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x)
                inside = !inside;
        }
        return inside;
    }

    // ── TMP helpers ───────────────────────────────────────────────────────────

    static TextMeshProUGUI MakeTMP(string text, Transform parent, Vector2 anchor,
        Vector2 size, float fontSize, Color color)
    {
        var go = new GameObject(text.Length > 30 ? text.Substring(0, 30) : text);
        go.transform.SetParent(parent, false);

        var r = go.AddComponent<RectTransform>();
        r.anchorMin        = anchor;
        r.anchorMax        = anchor;
        r.pivot            = new Vector2(0.5f, 0.5f);
        r.anchoredPosition = Vector2.zero;
        r.sizeDelta        = size;

        var tmp = go.AddComponent<TextMeshProUGUI>();
        tmp.text      = text;
        tmp.fontSize  = fontSize;
        tmp.color     = color;
        tmp.alignment = TextAlignmentOptions.Center;
        return tmp;
    }

    static TextMeshProUGUI MakeChild(string text, Transform parent, Vector2 anchor,
        Vector2 size, float fontSize, Color color)
        => MakeTMP(text, parent, anchor, size, fontSize, color);
}
