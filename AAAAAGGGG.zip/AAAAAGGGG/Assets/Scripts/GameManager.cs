using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public enum GameState { Intro, Playing, Paused, LevelComplete, Dead, Victory }
    public GameState CurrentState { get; private set; }

    public event Action<bool> OnPauseChanged;

    public float TimeElapsed    { get; private set; }
    public int   StarsCollected { get; private set; }
    public int   HighScore      { get; private set; }

    public event Action      OnGameOver;
    public event Action      OnLevelComplete;
    public event Action<int> OnScoreChanged;
    public event Action      OnPlayBegin;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        Application.targetFrameRate = 60;
        HighScore = PlayerPrefs.GetInt("HighScore", 0);
    }

    void Start()
    {
        CurrentState = GameState.Intro;
    }

    void Update()
    {
        if (CurrentState != GameState.Playing) return;
        TimeElapsed += Time.deltaTime;
    }

    public void PauseGame()
    {
        if (CurrentState != GameState.Playing) return;
        CurrentState = GameState.Paused;
        Time.timeScale = 0f;
        OnPauseChanged?.Invoke(true);
    }

    public void ResumeGame()
    {
        if (CurrentState != GameState.Paused) return;
        CurrentState = GameState.Playing;
        Time.timeScale = 1f;
        OnPauseChanged?.Invoke(false);
    }

    public void BeginPlay()
    {
        if (CurrentState != GameState.Intro) return;
        CurrentState = GameState.Playing;
        AudioManager.Instance?.PlayStart();
        OnPlayBegin?.Invoke();
    }

    public void AddStar()
    {
        StarsCollected++;
        OnScoreChanged?.Invoke(StarsCollected);
    }

    public void TriggerLevelComplete()
    {
        if (CurrentState != GameState.Playing) return;

        // Persist best star count for this level (used for unlock gating)
        LevelData.SaveBestStars(LevelData.CurrentIndex, StarsCollected);

        int score = (LevelData.CurrentIndex + 1) * 100
                    + StarsCollected * 50
                    + (int)(500f / Mathf.Max(TimeElapsed, 1f));
        if (score > HighScore)
        {
            HighScore = score;
            PlayerPrefs.SetInt("HighScore", HighScore);
        }
        PlayerPrefs.Save();

        CurrentState = LevelData.IsLastLevel ? GameState.Victory : GameState.LevelComplete;
        AudioManager.Instance?.StopBG();
        AudioManager.Instance?.PlayWin();
        OnLevelComplete?.Invoke();
    }

    public void TriggerGameOver()
    {
        if (CurrentState == GameState.Dead) return;
        CurrentState = GameState.Dead;
        AudioManager.Instance?.StopBG();
        AudioManager.Instance?.PlayKill();
        OnGameOver?.Invoke();
    }

    public void GoToNextLevel()
    {
        LevelData.CurrentIndex++;
        SceneManager.LoadScene("Game");
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Game");
    }

    public void GoToMenu()
    {
        Time.timeScale = 1f;
        LevelData.CurrentIndex = 0;
        SceneManager.LoadScene("MainMenu");
    }
}
