using System.Collections;
using UnityEngine;

/// <summary>
/// Pixelated cellular-automaton fire inside an asymmetric flame silhouette mask.
/// Fits exactly within one grid cell (1 × 1 world unit).
/// The flame leans slightly right and has a secondary tongue on the upper-left.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class FireEffect : MonoBehaviour
{
    const int W = 10;   // texture width  (pixels)
    const int H = 16;   // texture height (pixels) — also used as pixelsPerUnit → 1 unit tall

    SpriteRenderer _sr;
    Texture2D      _tex;
    float[,]       _heat = new float[W, H];
    bool[,]        _mask;
    Coroutine      _anim;

    void Awake()
    {
        _sr = GetComponent<SpriteRenderer>();
        _sr.sortingOrder = 3;

        _mask = BuildMask();

        _tex            = new Texture2D(W, H, TextureFormat.RGBA32, false);
        _tex.filterMode = FilterMode.Point;
        _tex.wrapMode   = TextureWrapMode.Clamp;

        // pixelsPerUnit = H  →  sprite is exactly 1 unit tall, W/H units wide
        // Center pivot (0.5, 0.5)  →  fits neatly in one cell, no position offset needed
        _sr.sprite = Sprite.Create(
            _tex,
            new Rect(0, 0, W, H),
            new Vector2(0.5f, 0.5f),
            H
        );
    }

    void OnEnable()
    {
        if (_anim != null) StopCoroutine(_anim);
        _anim = StartCoroutine(Animate());
    }

    void OnDisable()
    {
        if (_anim != null) { StopCoroutine(_anim); _anim = null; }
    }

    void OnDestroy()
    {
        if (_anim != null) StopCoroutine(_anim);
        if (_tex  != null) Destroy(_tex);
    }

    // ── Flame silhouette ──────────────────────────────────────────────────────
    //
    //  Shape goal (X = inside mask, row 0 = bottom):
    //
    //  y=15  . . . . . X . . . .   ← single tip (leans right)
    //  y=13  . . . . X X X . . .
    //  y=11  . . . X X X X X . .   ← main body leans right
    //  y= 9  . X X X X X X X . .   ← secondary tongue on left
    //  y= 7  X X X X X X X X X .
    //  y= 5  X X X X X X X X X X   ← broad mid-section
    //  y= 2  . . X X X X X X . .
    //  y= 0  . . . X X X X . . .   ← narrower base (flame sitting on ground)

    static bool[,] BuildMask()
    {
        var mask = new bool[W, H];
        float cx = (W - 1) / 2f;   // = 4.5

        for (int y = 0; y < H; y++)
        {
            float t = (float)y / (H - 1);   // 0 = bottom, 1 = top

            // ── Main body ──────────────────────────────────────────────────
            // Center leans right as the flame rises
            float leanCx = cx + 1.6f * t * t;

            // Half-width: broad in the lower-middle, tapers to nothing at top
            // Raised at the base too (flames are narrower at the very root)
            float bodyT   = Mathf.Clamp01(t < 0.12f ? t / 0.12f : 1f); // 0→1 over bottom 12%
            float taperT  = 1f - t;
            float halfW   = (cx + 1f) * Mathf.Pow(taperT, 0.42f) * Mathf.Sqrt(bodyT);

            // Asymmetric: left half shrinks faster than right
            float leftHalf  = halfW * (1f - 0.40f * t);
            float rightHalf = halfW * (1f + 0.18f * t);

            // ── Secondary tongue ─────────────────────────────────────────
            // A smaller protrusion on the upper-left (t = 0.45 → 0.80)
            float tongueHalf = 0f;
            float tongueCx   = cx - 2.2f;
            if (t > 0.45f && t < 0.80f)
            {
                float st = (t - 0.45f) / 0.35f;           // 0 → 1 within tongue zone
                tongueHalf = 1.6f * Mathf.Sin(st * Mathf.PI); // peaks at mid-zone
            }

            for (int x = 0; x < W; x++)
            {
                bool inMain   = (x >= leanCx - leftHalf)  && (x <= leanCx + rightHalf);
                bool inTongue = (tongueHalf > 0) && (Mathf.Abs(x - tongueCx) < tongueHalf);
                mask[x, y]    = inMain || inTongue;
            }
        }

        // Force a clean 1-pixel tip that leans right of centre
        for (int x = 0; x < W; x++) mask[x, H - 1] = false;
        mask[Mathf.Clamp(W / 2 + 1, 0, W - 1), H - 1] = true;

        return mask;
    }

    // ── Fire simulation ───────────────────────────────────────────────────────

    IEnumerator Animate()
    {
        var wait = new WaitForSeconds(0.05f);   // 20 fps
        while (true) { Step(); yield return wait; }
    }

    void Step()
    {
        // Seed bottom two rows inside mask with near-maximum heat
        for (int x = 0; x < W; x++)
        {
            if (_mask[x, 0]) _heat[x, 0] = Random.Range(0.85f, 1.00f);
            if (_mask[x, 1]) _heat[x, 1] = Random.Range(0.78f, 0.96f);
        }

        // Propagate heat upward inside mask only
        for (int y = 2; y < H; y++)
        for (int x = 0; x < W; x++)
        {
            if (!_mask[x, y]) { _heat[x, y] = 0f; continue; }

            int xl = Mathf.Max(x - 1, 0);
            int xr = Mathf.Min(x + 1, W - 1);

            float avg = (_heat[xl, y-1] + _heat[x, y-1] + _heat[xr, y-1] + _heat[x, y-2]) * 0.25f;

            // Cells on the mask boundary cool faster — keeps the silhouette crisp
            bool edgeCell = !_mask[xl, y] || !_mask[xr, y];
            float cool    = edgeCell ? 0.05f : 0f;

            _heat[x, y] = Mathf.Clamp01(avg * 0.93f - Random.Range(0f, 0.04f) - cool);
        }

        // Write pixels
        for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            _tex.SetPixel(x, y, _mask[x, y] ? HeatToColor(_heat[x, y]) : Color.clear);

        _tex.Apply();
    }

    // ── Colour palette: dark-red core → orange → yellow-white hot tip ─────────

    static Color HeatToColor(float t)
    {
        if (t < 0.05f) return Color.clear;
        if (t < 0.30f) return Color.Lerp(new Color(0.35f, 0.00f, 0.00f, 1f),
                                          new Color(0.82f, 0.04f, 0.00f, 1f), (t - 0.05f) / 0.25f);
        if (t < 0.55f) return Color.Lerp(new Color(0.82f, 0.04f, 0.00f, 1f),
                                          new Color(1.00f, 0.40f, 0.00f, 1f), (t - 0.30f) / 0.25f);
        if (t < 0.78f) return Color.Lerp(new Color(1.00f, 0.40f, 0.00f, 1f),
                                          new Color(1.00f, 0.82f, 0.05f, 1f), (t - 0.55f) / 0.23f);
        return             Color.Lerp(new Color(1.00f, 0.82f, 0.05f, 1f),
                                      new Color(1.00f, 1.00f, 0.80f, 1f), (t - 0.78f) / 0.22f);
    }
}
