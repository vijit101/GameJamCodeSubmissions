using UnityEngine;

/// <summary>
/// Smoothly follows the player and clamps the view within maze bounds,
/// preventing the camera from showing the void outside the border walls.
/// Attach to: Main Camera in the Game scene.
/// </summary>
[RequireComponent(typeof(Camera))]
public class CameraFollow : MonoBehaviour
{
    const float FollowSpeed = 9f;

    Camera _cam;

    void Awake() => _cam = GetComponent<Camera>();

    void LateUpdate()
    {
        if (PlayerController.Instance == null) return;

        // Don't chase during intro — camera already placed at start cell by MazeManager
        if (GameManager.Instance != null &&
            GameManager.Instance.CurrentState == GameManager.GameState.Intro)
            return;

        Vector3 target = PlayerController.Instance.transform.position;
        target.z = transform.position.z;

        transform.position = Vector3.Lerp(transform.position, target, Time.deltaTime * FollowSpeed);

        ClampToBounds();
    }

    void ClampToBounds()
    {
        if (MazeManager.Instance == null || _cam == null) return;

        float halfH = _cam.orthographicSize;
        float halfW = halfH * _cam.aspect;

        // Clamp so the camera never shows past the outer border walls.
        // Maze world extents: x in [0, Width], y in [0, Height].
        float minX = halfW;
        float maxX = MazeManager.Width  - halfW;
        float minY = halfH;
        float maxY = MazeManager.Height - halfH;

        float x = Mathf.Clamp(transform.position.x, Mathf.Min(minX, maxX), Mathf.Max(minX, maxX));
        float y = Mathf.Clamp(transform.position.y, Mathf.Min(minY, maxY), Mathf.Max(minY, maxY));

        transform.position = new Vector3(x, y, transform.position.z);
    }
}
