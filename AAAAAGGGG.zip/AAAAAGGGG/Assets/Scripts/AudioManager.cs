using UnityEngine;

/// <summary>
/// Generates all SFX via sine waves at runtime — no audio files needed.
/// Attach to: the same GameSetup GameObject as other managers.
/// Inspector: nothing to wire.
/// </summary>
public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    AudioSource _src;
    AudioSource _bgSrc;
    AudioClip   _coinClip, _killClip, _startClip, _wallClip, _warningClip, _deathClip, _winClip, _bgClip;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        _src = gameObject.AddComponent<AudioSource>();
        _src.playOnAwake = false;
        _src.volume = 0.5f;

        _bgSrc = gameObject.AddComponent<AudioSource>();
        _bgSrc.playOnAwake = false;
        _bgSrc.loop = true;
        _bgSrc.volume = 0.35f;

        // Frequencies chosen for distinct feel
        _coinClip  = MakeSine(880f, 0.12f, 0.4f, false);         // bright ping
        _killClip  = MakeDescend(180f, 80f, 0.55f, 0.45f);       // doom drop
        _startClip = MakeSine(528f, 0.20f, 0.35f, false);        // clean tone
        _wallClip  = MakeSine(220f, 0.18f, 0.25f, false);        // low thud

        _warningClip = Resources.Load<AudioClip>("aag");
        if (_warningClip == null)
            Debug.LogWarning("[AudioManager] Assets/Resources/aag.mp3 not found — proximity warning silent.");

        _deathClip = Resources.Load<AudioClip>("death");
        if (_deathClip == null)
            Debug.LogWarning("[AudioManager] Assets/Resources/death.mp3 not found — will use fallback SFX.");

        _winClip = Resources.Load<AudioClip>("win");
        if (_winClip == null)
            Debug.LogWarning("[AudioManager] Assets/Resources/win.mp3 not found — level complete will be silent.");

        _bgClip = Resources.Load<AudioClip>("bg");
        if (_bgClip == null)
            Debug.LogWarning("[AudioManager] Assets/Resources/bg.mp3 not found — background music silent.");

        if (_bgClip != null)
        {
            _bgSrc.clip = _bgClip;
            _bgSrc.Play();
        }
    }

    public void PlayCoin()    => PlayClip(_coinClip);
    public void PlayKill()    => PlayClip(_deathClip != null ? _deathClip : _killClip);
    public void PlayStart()   => PlayClip(_startClip);
    public void PlayWall()    => PlayClip(_wallClip);
    public void PlayWarning() => PlayClip(_warningClip);
    public void PlayWin()     => PlayClip(_winClip);

    public void StopBG()
    {
        if (_bgSrc != null && _bgSrc.isPlaying) _bgSrc.Stop();
    }

    public void PlayBG()
    {
        if (_bgSrc != null && _bgClip != null && !_bgSrc.isPlaying)
        {
            _bgSrc.clip = _bgClip;
            _bgSrc.Play();
        }
    }

    void PlayClip(AudioClip clip)
    {
        if (clip == null || _src == null) return;
        _src.PlayOneShot(clip);
    }

    AudioClip MakeSine(float freq, float duration, float vol, bool fadeIn)
    {
        int rate  = 44100;
        int count = Mathf.CeilToInt(rate * duration);
        var data  = new float[count];
        for (int i = 0; i < count; i++)
        {
            float t     = i / (float)rate;
            float fade  = fadeIn ? t / duration : 1f - t / duration;
            data[i]     = vol * Mathf.Sin(2f * Mathf.PI * freq * t) * Mathf.Sqrt(fade);
        }
        var clip = AudioClip.Create("sfx", count, 1, rate, false);
        clip.SetData(data, 0);
        return clip;
    }

    AudioClip MakeDescend(float freqStart, float freqEnd, float duration, float vol)
    {
        int rate  = 44100;
        int count = Mathf.CeilToInt(rate * duration);
        var data  = new float[count];
        for (int i = 0; i < count; i++)
        {
            float t    = i / (float)rate;
            float pct  = t / duration;
            float freq = Mathf.Lerp(freqStart, freqEnd, pct);
            float fade = 1f - pct;
            data[i]    = vol * Mathf.Sin(2f * Mathf.PI * freq * t) * fade;
        }
        var clip = AudioClip.Create("sfxDescend", count, 1, rate, false);
        clip.SetData(data, 0);
        return clip;
    }
}
