using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

/// <summary>
/// Copies the player's exact moves with a time delay that shrinks over time.
/// Stays hidden and inactive until 1 second after the player's very first move,
/// then materialises at the player's starting cell and begins the copy loop.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class AIController : MonoBehaviour
{
    public static AIController Instance { get; private set; }

    public Vector2Int GridPos { get; private set; }

    struct MoveRecord
    {
        public Vector2Int Direction;
        public float      RecordedAt;
    }

    readonly Queue<MoveRecord> _queue = new Queue<MoveRecord>();
    SpriteRenderer             _sr;
    Coroutine                  _processCoroutine;
    Coroutine                  _stepCoroutine;

    bool  _spawned;          // false until the 1-second grace period ends
    bool  _spawnTriggered;   // so we only start the spawn countdown once
    float _lastWarningTime;  // prevents aag.mp3 from spamming every frame

    public bool IsSpawned => _spawned;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        _sr = GetComponent<SpriteRenderer>();
        _sr.sortingOrder = 2;
    }

    void Start()
    {
        GridPos = new Vector2Int(1, 1); // player's starting cell

        if (MazeManager.Instance != null)
            transform.position = MazeManager.Instance.GridToWorld(GridPos);

        // Replace static sprite with animated fire — FireEffect owns the SpriteRenderer content
        gameObject.AddComponent<FireEffect>();
        _sr.enabled = false;   // FireEffect manages its own sprite; hide until spawned

        BuildLabel();

        if (PlayerController.Instance != null)
            PlayerController.Instance.OnMoved += EnqueueMove;

        _processCoroutine = StartCoroutine(ProcessQueue());
    }

    void OnDestroy()
    {
        if (PlayerController.Instance != null)
            PlayerController.Instance.OnMoved -= EnqueueMove;
        if (_stepCoroutine    != null) StopCoroutine(_stepCoroutine);
        if (_processCoroutine != null) StopCoroutine(_processCoroutine);
    }

    void BuildLabel()
    {
        var labelGO = new GameObject("AILabel");
        labelGO.transform.SetParent(transform);
        labelGO.transform.localPosition = new Vector3(0f, 0.65f, 0f);

        var tmp          = labelGO.AddComponent<TextMeshPro>();
        tmp.text         = "FIRE";
        tmp.fontSize     = 1.4f;
        tmp.color        = Color.white;
        tmp.alignment    = TextAlignmentOptions.Center;
        tmp.sortingOrder = 5;
        tmp.fontStyle    = FontStyles.Bold;
        // Also hide the label until spawned
        tmp.enabled      = false;
    }

    void EnqueueMove(Vector2Int direction)
    {
        _queue.Enqueue(new MoveRecord { Direction = direction, RecordedAt = Time.time });

        // First move ever → start the 1-second spawn countdown
        if (!_spawnTriggered)
        {
            _spawnTriggered = true;
            StartCoroutine(SpawnAfterDelay(1f));
        }
    }

    IEnumerator SpawnAfterDelay(float seconds)
    {
        yield return new WaitForSeconds(seconds);

        _spawned    = true;
        _sr.enabled = true;   // FireEffect sprite becomes visible

        var label = GetComponentInChildren<TextMeshPro>();
        if (label != null) label.enabled = true;
    }

    IEnumerator ProcessQueue()
    {
        while (true)
        {
            if (GameManager.Instance == null ||
                GameManager.Instance.CurrentState != GameManager.GameState.Playing)
            {
                yield return null;
                continue;
            }

            // Don't execute any moves until the AI has visually spawned
            if (!_spawned || _queue.Count == 0)
            {
                yield return null;
                continue;
            }

            float delay = DifficultyManager.Instance != null
                ? DifficultyManager.Instance.GetCurrentDelay()
                : 1.0f;

            var record = _queue.Peek();
            if (Time.time - record.RecordedAt < delay)
            {
                yield return null;
                continue;
            }

            _queue.Dequeue();
            Vector2Int target = GridPos + record.Direction;

            // AI phases through interior walls — only the outer border stops it.
            // IsWall returns true for out-of-bounds, so this naturally clamps to the map.
            bool outOfBounds = target.x <= 0 || target.x >= MazeManager.Width  - 1 ||
                               target.y <= 0 || target.y >= MazeManager.Height - 1;
            if (outOfBounds) continue;

            _stepCoroutine = StartCoroutine(ExecuteStep(target));
            yield return _stepCoroutine;
            _stepCoroutine = null;
        }
    }

    IEnumerator ExecuteStep(Vector2Int targetCell)
    {
        GridPos = targetCell;
        Vector3 worldTarget = MazeManager.Instance != null
            ? MazeManager.Instance.GridToWorld(GridPos)
            : new Vector3(GridPos.x + 0.5f, GridPos.y + 0.5f, 0f);

        Vector3 start    = transform.position;
        float   duration = 0.18f;
        float   t        = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            transform.position = Vector3.Lerp(start, worldTarget, t / duration);
            yield return null;
        }
        transform.position = worldTarget;

        CheckCollision();
    }

    void CheckCollision()
    {
        if (!_spawned) return;
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.CurrentState != GameManager.GameState.Playing) return;
        if (PlayerController.Instance == null) return;

        if (GridPos == PlayerController.Instance.GridPos)
        {
            if (PlayerController.Instance.IsInvincible) return;
            GameManager.Instance.TriggerGameOver();
        }
    }

    void Update()
    {
        if (!_spawned) return;
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.CurrentState != GameManager.GameState.Playing) return;
        if (PlayerController.Instance == null) return;

        var pPos = PlayerController.Instance.GridPos;

        // Kill check
        if (GridPos == pPos)
        {
            if (!PlayerController.Instance.IsInvincible)
                GameManager.Instance.TriggerGameOver();
            return;
        }

        // Proximity warning — play aag.mp3 when fire is exactly 1 block away
        int dist = Mathf.Abs(GridPos.x - pPos.x) + Mathf.Abs(GridPos.y - pPos.y);
        if (dist == 1 && Time.time - _lastWarningTime > 1.2f)
        {
            _lastWarningTime = Time.time;
            AudioManager.Instance?.PlayWarning();
        }
    }
}
