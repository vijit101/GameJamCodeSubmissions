using UnityEngine;

/// <summary>
/// Creates all game sprites programmatically at runtime.
/// Attach to: GameSetup GameObject in Game scene.
/// </summary>
public class AssetManager : MonoBehaviour
{
    public static AssetManager Instance { get; private set; }

    public Sprite PlayerSprite        { get; private set; }
    public Sprite AISprite            { get; private set; }
    public Sprite StarSprite          { get; private set; }
    public Sprite ExitSprite          { get; private set; }
    public Sprite WallSprite          { get; private set; }
    public Sprite FloorSprite         { get; private set; }
    public Sprite SprintSprite        { get; private set; }
    public Sprite InvincibilitySprite { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        BuildSprites();
    }

    void BuildSprites()
    {
        PlayerSprite        = LoadPlayerSprite();
        AISprite            = MakeSquare(new Color(0.90f, 0.12f, 0.12f), 32);
        StarSprite          = MakeDiamond(new Color(1.00f, 0.85f, 0.05f), 32);
        ExitSprite          = MakeExitTile(32);
        WallSprite          = MakeSquare(new Color(0.18f, 0.22f, 0.38f), 32);
        FloorSprite         = MakeSquare(new Color(0.07f, 0.07f, 0.10f), 32);
        SprintSprite        = MakeLightning(new Color(1.0f, 0.55f, 0.05f), 32);
        InvincibilitySprite = MakeShield(new Color(0.15f, 0.85f, 1.0f), 32);
    }

    static Sprite LoadPlayerSprite()
    {
        var tex = Resources.Load<Texture2D>("player");
        if (tex == null)
        {
            Debug.LogWarning("[AssetManager] Resources/player.png not found — using fallback.");
            var fb = new Texture2D(32, 32) { filterMode = FilterMode.Point };
            var px = new Color[32 * 32];
            for (int i = 0; i < px.Length; i++) px[i] = new Color(1f, 0.92f, 0.02f);
            fb.SetPixels(px); fb.Apply();
            return Sprite.Create(fb, new Rect(0, 0, 32, 32), Vector2.one * 0.5f, 32);
        }
        float ppu = Mathf.Max(tex.width, tex.height);
        return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.one * 0.5f, ppu);
    }

    Sprite MakeSquare(Color c, int size)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
        var px  = new Color[size * size];
        for (int i = 0; i < px.Length; i++) px[i] = c;
        tex.SetPixels(px); tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), Vector2.one * 0.5f, size);
    }

    // Gold diamond shape using Manhattan distance
    Sprite MakeDiamond(Color c, int size)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
        var px  = new Color[size * size];
        float r = size * 0.5f;
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float dx = Mathf.Abs(x - r + 0.5f), dy = Mathf.Abs(y - r + 0.5f);
            px[y * size + x] = (dx + dy) <= r - 0.5f ? c : Color.clear;
        }
        tex.SetPixels(px); tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), Vector2.one * 0.5f, size);
    }

    // Orange lightning bolt shape for Sprint
    Sprite MakeLightning(Color c, int size)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
        var px  = new Color[size * size];
        // Lightning bolt: top-right slant downward, then bottom-left slant
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float nx = x / (float)(size - 1);   // 0..1
            float ny = y / (float)(size - 1);   // 0..1
            // Upper half: diagonal strip from top-right to mid-left
            // Lower half: diagonal strip from mid-right to bottom-left
            bool topHalf    = ny >= 0.5f;
            float midX      = topHalf ? (1f - ny) * 1.4f - 0.1f : (1f - ny) * 0.8f + 0.15f;
            bool inBolt     = Mathf.Abs(nx - midX) < 0.20f;
            px[y * size + x] = inBolt ? c : Color.clear;
        }
        tex.SetPixels(px); tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), Vector2.one * 0.5f, size);
    }

    // Cyan shield / circle with inner ring for Invincibility
    Sprite MakeShield(Color c, int size)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
        var px  = new Color[size * size];
        float r  = size * 0.46f;
        float r2 = size * 0.28f;
        float cx = size * 0.5f, cy = size * 0.5f;
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float dx   = x - cx + 0.5f, dy = y - cy + 0.5f;
            float dist2 = dx * dx + dy * dy;
            bool outer = dist2 <= r  * r;
            bool inner = dist2 <= r2 * r2;
            Color col  = inner ? c : (outer ? new Color(c.r, c.g, c.b, 0.55f) : Color.clear);
            px[y * size + x] = col;
        }
        tex.SetPixels(px); tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), Vector2.one * 0.5f, size);
    }

    // Bright teal/green exit tile — clearly distinct from the dark floor
    Sprite MakeExitTile(int size)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
        var px  = new Color[size * size];
        var bg  = new Color(0.0f, 0.55f, 0.40f);  // teal fill
        var border = new Color(0.2f, 1.0f, 0.7f); // bright outline
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            bool edge = x == 0 || y == 0 || x == size - 1 || y == size - 1
                     || x == 1 || y == 1 || x == size - 2 || y == size - 2;
            px[y * size + x] = edge ? border : bg;
        }
        tex.SetPixels(px); tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), Vector2.one * 0.5f, size);
    }
}
