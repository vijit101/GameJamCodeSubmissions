using System.Collections;
using TMPro;
using UnityEngine;

/// <summary>
/// World-space animated text popup: scales 0→1.2→1, floats up, then fades.
/// Pooled and reused by UIManager.ShowPopup().
/// Do NOT attach manually — UIManager creates these at runtime.
/// </summary>
public class PopupText : MonoBehaviour
{
    TextMeshPro _tmp;
    Coroutine   _anim;

    void Awake()
    {
        _tmp                 = gameObject.AddComponent<TextMeshPro>();
        _tmp.fontSize        = 2.8f;
        _tmp.alignment       = TextAlignmentOptions.Center;
        _tmp.fontStyle       = FontStyles.Bold;
        _tmp.sortingOrder    = 10;
        gameObject.SetActive(false);
    }

    public void Show(string text, Vector3 worldPos)
    {
        transform.position = worldPos;
        _tmp.text          = text;
        _tmp.color         = new Color(1f, 0.88f, 0.15f, 1f);
        gameObject.SetActive(true);

        if (_anim != null) StopCoroutine(_anim);
        _anim = StartCoroutine(Animate());
    }

    IEnumerator Animate()
    {
        // Phase 1: scale 0 → 1.2
        yield return LerpScale(0f, 1.2f, 0.12f);

        // Phase 2: settle 1.2 → 1.0
        yield return LerpScale(1.2f, 1.0f, 0.08f);

        // Phase 3: hold
        yield return new WaitForSeconds(0.4f);

        // Phase 4: float up + fade out
        float   elapsed   = 0f;
        float   fadeTime  = 0.6f;
        Vector3 startPos  = transform.position;
        Color   startCol  = _tmp.color;

        while (elapsed < fadeTime)
        {
            elapsed += Time.deltaTime;
            float pct = elapsed / fadeTime;
            transform.position = startPos + Vector3.up * (pct * 0.8f);
            _tmp.color         = new Color(startCol.r, startCol.g, startCol.b, 1f - pct);
            yield return null;
        }

        _anim = null;
        gameObject.SetActive(false);
    }

    IEnumerator LerpScale(float from, float to, float duration)
    {
        float t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            transform.localScale = Vector3.one * Mathf.Lerp(from, to, t / duration);
            yield return null;
        }
        transform.localScale = Vector3.one * to;
    }

    void OnDestroy()
    {
        if (_anim != null) StopCoroutine(_anim);
    }
}
