using System.Collections;
using UnityEngine;

/// <summary>
/// A collectible star placed at a dead-end cell.
/// Pulses in place; collected when the player steps on it.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class StarController : MonoBehaviour
{
    public Vector2Int GridPos { get; private set; }

    SpriteRenderer _sr;
    Coroutine      _pulse;

    void Awake()
    {
        _sr = GetComponent<SpriteRenderer>();
        _sr.sortingOrder = 1;
    }

    public void Initialize(Vector2Int gridPos)
    {
        GridPos    = gridPos;
        if (AssetManager.Instance != null)
            _sr.sprite = AssetManager.Instance.StarSprite;
        gameObject.SetActive(true);
        if (_pulse != null) StopCoroutine(_pulse);
        _pulse = StartCoroutine(Pulse());
    }

    void OnDestroy()
    {
        if (_pulse != null) StopCoroutine(_pulse);
    }

    IEnumerator Pulse()
    {
        while (true)
        {
            float t = Mathf.PingPong(Time.time * 2.2f, 1f);
            transform.localScale = Vector3.one * Mathf.Lerp(0.65f, 1.0f, t);
            yield return null;
        }
    }

    void Update()
    {
        if (!gameObject.activeSelf) return;
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.CurrentState != GameManager.GameState.Playing) return;
        if (PlayerController.Instance == null) return;

        if (PlayerController.Instance.GridPos == GridPos)
            Collect();
    }

    void Collect()
    {
        GameManager.Instance.AddStar();
        AudioManager.Instance?.PlayCoin();
        if (UIManager.Instance != null && MazeManager.Instance != null)
            UIManager.Instance.ShowPopup("STAR!", MazeManager.Instance.GridToWorld(GridPos));
        gameObject.SetActive(false);
    }
}
