using UnityEngine;

/// <summary>
/// Returns the fixed AI copy-delay for the current level.
/// Delay is set in LevelData and does not change mid-level.
/// </summary>
public class DifficultyManager : MonoBehaviour
{
    public static DifficultyManager Instance { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public float GetCurrentDelay() => LevelData.Current.AIDelay;
}
