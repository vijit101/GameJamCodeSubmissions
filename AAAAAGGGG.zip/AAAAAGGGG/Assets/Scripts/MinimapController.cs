using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Simple dot-based positional minimap — no fog of war, no maze walls.
/// Shows approximate positions of player, fire, exit, start, and stars.
/// </summary>
public class MinimapController : MonoBehaviour
{
    const float MAP_W = 160f;
    const float MAP_H = 120f;

    RectTransform _mapRect;

    RectTransform _playerDot;
    RectTransform _fireDot;
    RectTransform _exitDot;
    RectTransform _startDot;
    readonly List<(RectTransform dot, StarController star)> _starDots = new();

    void Start() => StartCoroutine(LateInit());

    IEnumerator LateInit()
    {
        yield return null;

        if (MazeManager.Instance == null) yield break;

        BuildUI();

        foreach (var s in FindObjectsByType<StarController>(FindObjectsSortMode.None))
            _starDots.Add((MakeDot(_mapRect, new Color(1f, 0.80f, 0.05f), 7f), s));
    }

    void BuildUI()
    {
        var cvGO = new GameObject("MinimapCanvas");
        cvGO.transform.SetParent(transform, false);
        var cv = cvGO.AddComponent<Canvas>();
        cv.renderMode   = RenderMode.ScreenSpaceOverlay;
        cv.sortingOrder = 15;

        var sc = cvGO.AddComponent<CanvasScaler>();
        sc.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        sc.referenceResolution = new Vector2(1920, 1080);
        sc.screenMatchMode     = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        sc.matchWidthOrHeight  = 0.5f;
        cvGO.AddComponent<GraphicRaycaster>();

        // Outer frame — bottom-right corner
        var frameGO = new GameObject("MinimapFrame");
        frameGO.transform.SetParent(cvGO.transform, false);
        var fr = frameGO.AddComponent<RectTransform>();
        fr.anchorMin        = new Vector2(1f, 0f);
        fr.anchorMax        = new Vector2(1f, 0f);
        fr.pivot            = new Vector2(1f, 0f);
        fr.anchoredPosition = new Vector2(-14f, 14f);
        fr.sizeDelta        = new Vector2(MAP_W + 10f, MAP_H + 26f);
        frameGO.AddComponent<Image>().color = new Color(0f, 0f, 0f, 0.75f);

        // "MAP" label at top of frame
        var labelGO = new GameObject("MapLabel");
        labelGO.transform.SetParent(frameGO.transform, false);
        var lr = labelGO.AddComponent<RectTransform>();
        lr.anchorMin        = new Vector2(0f, 1f);
        lr.anchorMax        = new Vector2(1f, 1f);
        lr.pivot            = new Vector2(0.5f, 1f);
        lr.anchoredPosition = Vector2.zero;
        lr.sizeDelta        = new Vector2(0f, 22f);
        var lt       = labelGO.AddComponent<TextMeshProUGUI>();
        lt.text      = "MAP";
        lt.fontSize  = 12f;
        lt.color     = new Color(0.5f, 0.5f, 0.55f);
        lt.alignment = TextAlignmentOptions.Center;

        // Map area
        var imgGO = new GameObject("MinimapArea");
        imgGO.transform.SetParent(frameGO.transform, false);
        _mapRect = imgGO.AddComponent<RectTransform>();
        _mapRect.anchorMin        = Vector2.zero;
        _mapRect.anchorMax        = Vector2.zero;
        _mapRect.pivot            = Vector2.zero;
        _mapRect.anchoredPosition = new Vector2(5f, 4f);
        _mapRect.sizeDelta        = new Vector2(MAP_W, MAP_H);

        var bg = imgGO.AddComponent<Image>();
        bg.color = new Color(0.08f, 0.10f, 0.18f, 1f);

        // Dots (rendered on top of bg, parented to _mapRect)
        _startDot  = MakeDot(_mapRect, new Color(0.45f, 0.45f, 0.50f), 6f);
        _exitDot   = MakeDot(_mapRect, new Color(0.15f, 1.00f, 0.70f), 8f);
        _fireDot   = MakeDot(_mapRect, new Color(1.00f, 0.22f, 0.10f), 8f);
        _playerDot = MakeDot(_mapRect, new Color(1.00f, 0.92f, 0.10f), 10f);

        _fireDot.gameObject.SetActive(false);

        // Place static dots immediately
        PlaceDot(_startDot, MazeManager.Instance.GridToWorld(MazeManager.Instance.StartCell));
        PlaceDot(_exitDot,  MazeManager.Instance.GridToWorld(MazeManager.Instance.Exit));
    }

    static RectTransform MakeDot(RectTransform parent, Color color, float size)
    {
        const int S = 16;
        var tex = new Texture2D(S, S, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
        var px  = new Color[S * S];
        float r = S / 2f;
        for (int i = 0; i < S * S; i++)
        {
            float dx = (i % S) - r + 0.5f;
            float dy = (i / S) - r + 0.5f;
            px[i] = dx * dx + dy * dy <= r * r ? color : Color.clear;
        }
        tex.SetPixels(px);
        tex.Apply();

        var go = new GameObject("Dot");
        go.transform.SetParent(parent, false);
        var rt       = go.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.zero;
        rt.pivot     = new Vector2(0.5f, 0.5f);
        rt.sizeDelta = new Vector2(size, size);
        go.AddComponent<RawImage>().texture = tex;
        return rt;
    }

    void PlaceDot(RectTransform dot, Vector3 worldPos)
    {
        float nx = worldPos.x / MazeManager.Width;
        float ny = worldPos.y / MazeManager.Height;
        dot.anchoredPosition = new Vector2(nx * MAP_W, ny * MAP_H);
    }

    void Update()
    {
        if (_mapRect == null || MazeManager.Instance == null) return;

        if (PlayerController.Instance != null)
            PlaceDot(_playerDot, PlayerController.Instance.transform.position);

        if (AIController.Instance != null)
        {
            bool spawned = AIController.Instance.IsSpawned;
            _fireDot.gameObject.SetActive(spawned);
            if (spawned) PlaceDot(_fireDot, AIController.Instance.transform.position);
        }

        foreach (var (dot, star) in _starDots)
        {
            if (star == null || !star.gameObject.activeSelf)
            {
                dot.gameObject.SetActive(false);
                continue;
            }
            dot.gameObject.SetActive(true);
            PlaceDot(dot, MazeManager.Instance.GridToWorld(star.GridPos));
        }
    }
}
