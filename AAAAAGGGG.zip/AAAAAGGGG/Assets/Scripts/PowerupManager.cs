using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Spawns one Sprint and one Invincibility powerup at mid-maze crossroads.
/// Sprint placed near 35% BFS depth, Invincibility near 65% BFS depth.
/// </summary>
public class PowerupManager : MonoBehaviour
{
    void Start() => StartCoroutine(LateInit());

    IEnumerator LateInit()
    {
        yield return null; // wait for MazeManager.Start()

        if (MazeManager.Instance == null) yield break;

        var spots = MazeManager.Instance.PowerupSpots;
        if (spots == null || spots.Length < 2) yield break;

        Spawn(PowerupType.Sprint,        spots[0]);
        Spawn(PowerupType.Invincibility, spots[1]);
    }

    static void Spawn(PowerupType type, Vector2Int cell)
    {
        var go = new GameObject($"Powerup_{type}");
        go.AddComponent<SpriteRenderer>();
        var pc = go.AddComponent<PowerupController>();
        pc.Init(type, cell);
    }
}
