using UnityEngine;

public enum PowerupType { Sprint, Invincibility }

[RequireComponent(typeof(SpriteRenderer))]
public class PowerupController : MonoBehaviour
{
    public PowerupType Type    { get; private set; }
    public Vector2Int  GridPos { get; private set; }

    SpriteRenderer _sr;
    float          _t;

    public void Init(PowerupType type, Vector2Int cell)
    {
        Type    = type;
        GridPos = cell;

        _sr              = GetComponent<SpriteRenderer>();
        _sr.sortingOrder = 1;

        if (MazeManager.Instance != null)
            transform.position = MazeManager.Instance.GridToWorld(cell);

        if (AssetManager.Instance != null)
        {
            _sr.sprite = type == PowerupType.Sprint
                ? AssetManager.Instance.SprintSprite
                : AssetManager.Instance.InvincibilitySprite;
        }

        _sr.color = type == PowerupType.Sprint
            ? new Color(1.0f, 0.55f, 0.05f)   // orange
            : new Color(0.15f, 0.85f, 1.0f);   // cyan
    }

    void Update()
    {
        if (GameManager.Instance?.CurrentState != GameManager.GameState.Playing) return;

        // Pulse scale
        _t += Time.deltaTime * 2.5f;
        float s = 0.82f + 0.18f * Mathf.Abs(Mathf.Sin(_t));
        transform.localScale = new Vector3(s, s, 1f);

        // Collection
        if (PlayerController.Instance != null &&
            PlayerController.Instance.GridPos == GridPos &&
            PlayerController.Instance.HeldPowerup == null)
        {
            PlayerController.Instance.CollectPowerup(Type);
            gameObject.SetActive(false);
        }
    }
}
