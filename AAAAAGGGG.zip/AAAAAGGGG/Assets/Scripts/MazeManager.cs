using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

/// <summary>
/// Generates a seeded maze per level via iterative DFS, then "braids" it by
/// removing a fraction of removable walls to add loops and path choices.
/// The player only sees a portion of the maze via CameraFollow.
/// </summary>
public class MazeManager : MonoBehaviour
{
    public static MazeManager Instance { get; private set; }

    public static int Width  { get; private set; }
    public static int Height { get; private set; }

    public Vector2Int   StartCell { get; private set; }
    public Vector2Int   Exit      { get; private set; }
    public Vector2Int[] Stars        { get; private set; }
    public Vector2Int[] PowerupSpots { get; private set; }

    Tilemap _wallTilemap;
    Tilemap _floorTilemap;
    bool[,] _walls;
    Tile    _wallTile;
    Tile    _floorTile;
    Tile    _exitTile;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        var cfg = LevelData.Current;
        Width   = cfg.Width;
        Height  = cfg.Height;
        _walls  = new bool[Width, Height];
    }

    void Start()
    {
        var cfg = LevelData.Current;

        FindTilemaps();
        BuildRuntimeTiles();
        GenerateMaze(cfg.Seed);
        BraidMaze(cfg.BraidFraction, cfg.Seed);
        FindStars();
        FindPowerupSpots();
        RedrawAll();
        SetupCamera();
    }

    // ── Tilemap setup ─────────────────────────────────────────────────────────

    void FindTilemaps()
    {
        var all = FindObjectsByType<Tilemap>(FindObjectsSortMode.None);
        foreach (var tm in all)
        {
            if (tm.name == "WallTilemap")  _wallTilemap  = tm;
            if (tm.name == "FloorTilemap") _floorTilemap = tm;
        }
        var fr = _floorTilemap?.GetComponent<TilemapRenderer>();
        if (fr != null) fr.sortingOrder = -10;
        var wr = _wallTilemap?.GetComponent<TilemapRenderer>();
        if (wr != null) wr.sortingOrder = -5;
    }

    void BuildRuntimeTiles()
    {
        if (AssetManager.Instance == null) return;

        _wallTile         = ScriptableObject.CreateInstance<Tile>();
        _wallTile.sprite  = AssetManager.Instance.WallSprite;

        _floorTile        = ScriptableObject.CreateInstance<Tile>();
        _floorTile.sprite = AssetManager.Instance.FloorSprite;

        _exitTile         = ScriptableObject.CreateInstance<Tile>();
        _exitTile.sprite  = AssetManager.Instance.ExitSprite;
    }

    // ── Maze generation (iterative DFS) ──────────────────────────────────────

    void GenerateMaze(int seed)
    {
        // Start all as walls
        for (int x = 0; x < Width;  x++)
        for (int y = 0; y < Height; y++)
            _walls[x, y] = true;

        var rng   = new System.Random(seed);
        var stack = new Stack<Vector2Int>();
        var s     = new Vector2Int(1, 1);
        _walls[s.x, s.y] = false;
        stack.Push(s);

        var dirs = new[] {
            new Vector2Int( 0,  2),
            new Vector2Int( 0, -2),
            new Vector2Int(-2,  0),
            new Vector2Int( 2,  0),
        };

        while (stack.Count > 0)
        {
            var curr = stack.Peek();

            for (int i = dirs.Length - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (dirs[i], dirs[j]) = (dirs[j], dirs[i]);
            }

            bool carved = false;
            foreach (var d in dirs)
            {
                var next = curr + d;
                if (next.x <= 0 || next.x >= Width  - 1) continue;
                if (next.y <= 0 || next.y >= Height - 1) continue;
                if (!_walls[next.x, next.y]) continue;

                var mid = curr + new Vector2Int(d.x / 2, d.y / 2);
                _walls[mid.x,  mid.y]  = false;
                _walls[next.x, next.y] = false;
                stack.Push(next);
                carved = true;
                break;
            }
            if (!carved) stack.Pop();
        }

        StartCell = new Vector2Int(1, 1);

        // Exit = gap punched in the RIGHT border wall at the topmost room row.
        // The player walks through the outer wall to complete the level.
        int exitRow = Height - 2;
        _walls[Width - 1, exitRow] = false;   // border gap (the actual exit cell)
        _walls[Width - 2, exitRow] = false;   // guarantee the approach room is open
        Exit = new Vector2Int(Width - 1, exitRow);
    }

    // ── Braiding — adds loops and path choices ────────────────────────────────
    //
    // Finds wall cells that sit between two open cells on the same axis,
    // then removes a random fraction of them. This breaks the "one path only"
    // property of the pure DFS maze, creating intersections and dead-end
    // branches that the player can choose to explore.

    void BraidMaze(float fraction, int seed)
    {
        if (fraction <= 0f) return;

        var candidates = new List<Vector2Int>(Width * Height / 4);

        for (int x = 1; x < Width  - 1; x++)
        for (int y = 1; y < Height - 1; y++)
        {
            if (!_walls[x, y]) continue;

            // Horizontal pair: open left AND open right
            bool horizLoop = x > 0 && x < Width  - 1 && !_walls[x - 1, y] && !_walls[x + 1, y];
            // Vertical pair:   open below AND open above
            bool vertLoop  = y > 0 && y < Height - 1 && !_walls[x, y - 1] && !_walls[x, y + 1];

            if (horizLoop || vertLoop)
                candidates.Add(new Vector2Int(x, y));
        }

        // Deterministic shuffle using a different seed so pattern differs from DFS
        var rng = new System.Random(seed ^ 0xBEEF);
        for (int i = candidates.Count - 1; i > 0; i--)
        {
            int j = rng.Next(i + 1);
            (candidates[i], candidates[j]) = (candidates[j], candidates[i]);
        }

        int removeCount = Mathf.RoundToInt(candidates.Count * fraction);
        for (int i = 0; i < removeCount && i < candidates.Count; i++)
        {
            var p = candidates[i];
            _walls[p.x, p.y] = false;
        }
    }

    // ── Star placement ────────────────────────────────────────────────────────
    //
    // BFS from StartCell; find cells with exactly 1 open cardinal neighbor
    // (dead ends), sorted by distance descending. Takes 3 farthest.
    // Runs AFTER braiding so only surviving dead ends are considered.

    void FindStars()
    {
        var cardDirs = new[] {
            Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right
        };

        var dist    = new int[Width, Height];
        var visited = new bool[Width, Height];
        var queue   = new Queue<Vector2Int>();

        for (int x = 0; x < Width;  x++)
        for (int y = 0; y < Height; y++)
            dist[x, y] = -1;

        dist[StartCell.x, StartCell.y]    = 0;
        visited[StartCell.x, StartCell.y] = true;
        queue.Enqueue(StartCell);

        while (queue.Count > 0)
        {
            var c = queue.Dequeue();
            foreach (var d in cardDirs)
            {
                var n = c + d;
                if (n.x < 0 || n.x >= Width || n.y < 0 || n.y >= Height) continue;
                if (visited[n.x, n.y] || _walls[n.x, n.y]) continue;
                visited[n.x, n.y] = true;
                dist[n.x, n.y]    = dist[c.x, c.y] + 1;
                queue.Enqueue(n);
            }
        }

        var exitApproach = new Vector2Int(Width - 2, Height - 2);
        var deadEnds     = new List<(Vector2Int pos, int d)>();

        for (int x = 1; x < Width  - 1; x++)
        for (int y = 1; y < Height - 1; y++)
        {
            if (_walls[x, y]) continue;
            var p = new Vector2Int(x, y);
            if (p == StartCell || p == Exit || p == exitApproach) continue;
            if (dist[x, y] < 0) continue;

            int open = 0;
            foreach (var d in cardDirs)
            {
                var n = p + d;
                if (n.x >= 0 && n.x < Width && n.y >= 0 && n.y < Height && !_walls[n.x, n.y])
                    open++;
            }
            if (open == 1)
                deadEnds.Add((p, dist[x, y]));
        }

        deadEnds.Sort((a, b) => b.d.CompareTo(a.d));
        int count = Mathf.Min(3, deadEnds.Count);
        Stars = new Vector2Int[count];
        for (int i = 0; i < count; i++)
            Stars[i] = deadEnds[i].pos;
    }

    void FindPowerupSpots()
    {
        var cardDirs = new[] {
            Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right
        };

        // BFS from StartCell to get distances
        var dist    = new int[Width, Height];
        var visited = new bool[Width, Height];
        var queue   = new Queue<Vector2Int>();

        for (int x = 0; x < Width;  x++)
        for (int y = 0; y < Height; y++)
            dist[x, y] = -1;

        dist[StartCell.x, StartCell.y]    = 0;
        visited[StartCell.x, StartCell.y] = true;
        queue.Enqueue(StartCell);
        int maxDist = 0;

        while (queue.Count > 0)
        {
            var c = queue.Dequeue();
            foreach (var d in cardDirs)
            {
                var n = c + d;
                if (n.x < 0 || n.x >= Width || n.y < 0 || n.y >= Height) continue;
                if (visited[n.x, n.y] || _walls[n.x, n.y]) continue;
                visited[n.x, n.y] = true;
                dist[n.x, n.y]    = dist[c.x, c.y] + 1;
                if (dist[n.x, n.y] > maxDist) maxDist = dist[n.x, n.y];
                queue.Enqueue(n);
            }
        }

        var exitApproach = new Vector2Int(Width - 2, Height - 2);
        var starSet = new HashSet<Vector2Int>(Stars ?? new Vector2Int[0]);

        // Collect open non-dead-end non-reserved cells with their BFS distance
        var candidates = new List<(Vector2Int pos, int d)>();
        for (int x = 1; x < Width  - 1; x++)
        for (int y = 1; y < Height - 1; y++)
        {
            if (_walls[x, y]) continue;
            var p = new Vector2Int(x, y);
            if (p == StartCell || p == Exit || p == exitApproach) continue;
            if (starSet.Contains(p)) continue;
            if (dist[x, y] < 0) continue;

            // Prefer junctions (2+ open neighbors) — avoid dead ends (1 open neighbor)
            int open = 0;
            foreach (var d in cardDirs)
            {
                var n = p + d;
                if (n.x >= 0 && n.x < Width && n.y >= 0 && n.y < Height && !_walls[n.x, n.y])
                    open++;
            }
            if (open >= 2)
                candidates.Add((p, dist[x, y]));
        }

        if (candidates.Count < 2) { PowerupSpots = new Vector2Int[0]; return; }

        float target0 = maxDist * 0.35f;  // Sprint — early-mid maze
        float target1 = maxDist * 0.65f;  // Invincibility — mid-late maze

        candidates.Sort((a, b) => a.d.CompareTo(b.d));

        var spot0 = ClosestTo(candidates, target0);
        var spot1 = ClosestTo(candidates, target1);

        // Ensure they're not the same cell
        if (spot0 == spot1)
        {
            // pick second-closest for spot1
            Vector2Int fallback = spot0;
            float bestDiff = float.MaxValue;
            foreach (var (pos, d) in candidates)
            {
                if (pos == spot0) continue;
                float diff = Mathf.Abs(d - target1);
                if (diff < bestDiff) { bestDiff = diff; fallback = pos; }
            }
            spot1 = fallback;
        }

        PowerupSpots = new[] { spot0, spot1 };
    }

    static Vector2Int ClosestTo(List<(Vector2Int pos, int d)> list, float target)
    {
        var best = list[0].pos;
        float bestDiff = float.MaxValue;
        foreach (var (pos, d) in list)
        {
            float diff = Mathf.Abs(d - target);
            if (diff < bestDiff) { bestDiff = diff; best = pos; }
        }
        return best;
    }

    // ── Rendering ─────────────────────────────────────────────────────────────

    void RedrawAll()
    {
        if (_wallTilemap == null || _floorTilemap == null) return;
        _wallTilemap.ClearAllTiles();
        _floorTilemap.ClearAllTiles();

        for (int x = 0; x < Width;  x++)
        for (int y = 0; y < Height; y++)
        {
            var pos = new Vector3Int(x, y, 0);
            _floorTilemap.SetTile(pos, _floorTile);
            if (_walls[x, y])
                _wallTilemap.SetTile(pos, _wallTile);
        }

        if (_exitTile != null)
            _floorTilemap.SetTile(new Vector3Int(Exit.x, Exit.y, 0), _exitTile);
    }

    // ── Camera ────────────────────────────────────────────────────────────────
    //
    // Fixed ortho size — CameraFollow.cs handles tracking the player.
    // Camera starts at the player spawn so the first frame isn't a jarring jump.

    void SetupCamera()
    {
        var cam = Camera.main;
        if (cam == null) return;
        cam.orthographic     = true;
        cam.orthographicSize = 8f;

        var startWorld = GridToWorld(StartCell);
        cam.transform.position = new Vector3(startWorld.x, startWorld.y, -10f);
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public bool IsWall(int x, int y)
    {
        if (x < 0 || x >= Width || y < 0 || y >= Height) return true;
        return _walls[x, y];
    }

    public bool IsWall(Vector2Int p) => IsWall(p.x, p.y);

    public Vector3 GridToWorld(Vector2Int cell)
    {
        if (_wallTilemap != null)
            return _wallTilemap.GetCellCenterWorld(new Vector3Int(cell.x, cell.y, 0));
        return new Vector3(cell.x + 0.5f, cell.y + 0.5f, 0f);
    }
}
