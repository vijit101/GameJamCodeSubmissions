using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using System.IO;

public class WebGLBuilder
{
    public static void Build()
    {
        string outputPath = Path.Combine(Directory.GetParent(Application.dataPath).FullName, "WebGL-Build");

        BuildPlayerOptions options = new BuildPlayerOptions
        {
            scenes = new[] { "Assets/Scenes/MainMenu.unity", "Assets/Scenes/Game.unity" },
            locationPathName = outputPath,
            target = BuildTarget.WebGL,
            options = BuildOptions.None
        };

        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Gzip;
        PlayerSettings.WebGL.template = "APPLICATION:Default";

        BuildReport report = BuildPipeline.BuildPlayer(options);

        if (report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
            Debug.Log("WebGL build succeeded: " + outputPath);
        else
            Debug.LogError("WebGL build FAILED: " + report.summary.result);
    }
}
