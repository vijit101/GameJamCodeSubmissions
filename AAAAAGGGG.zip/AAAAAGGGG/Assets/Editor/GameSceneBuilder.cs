using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering.Universal;
using UnityEngine.Tilemaps;

/// <summary>
/// Auto-runs when Unity opens or recompiles.
///
/// Pass 1 — imports TMP Essential Resources (if missing), then returns.
///           Unity refreshes; InitializeOnLoad fires again automatically.
/// Pass 2 — builds MainMenu.unity + Game.unity with every GameObject wired,
///           adds Global Light 2D (required for URP 2D renderer),
///           configures Build Settings.
///
/// The user never has to touch any Unity UI.
/// </summary>
[InitializeOnLoad]
public static class GameSceneBuilder
{
    static GameSceneBuilder()
    {
        EditorApplication.delayCall += RunSetup;
    }

    static void RunSetup()
    {
        EditorApplication.delayCall -= RunSetup;

        if (EditorApplication.isPlayingOrWillChangePlaymode) return;

        // ── Step 1: TMP Essential Resources ──────────────────────────────────
        if (!Directory.Exists("Assets/TextMesh Pro"))
        {
            string pkg = FindInPackageCache("TMP Essential Resources.unitypackage");
            if (pkg != null)
            {
                Debug.Log("[CTRL+C CTRL+KILL] Importing TMP Essential Resources…");
                AssetDatabase.ImportPackage(pkg, false);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                return;
            }
            Debug.LogWarning("[CTRL+C CTRL+KILL] TMP package not found in cache. " +
                             "If text is invisible: Window → TextMeshPro → Import TMP Essential Resources.");
        }

        // ── Step 2: Build scenes (idempotent — skips if files exist) ─────────
        bool needMenu = !File.Exists("Assets/Scenes/MainMenu.unity");
        bool needGame = !File.Exists("Assets/Scenes/Game.unity");

        if (!needMenu && !needGame)
        {
            SetBuildScenes();
            return;
        }

        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        if (needMenu) BuildMainMenuScene();
        if (needGame) BuildGameScene();

        SetBuildScenes();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorSceneManager.OpenScene("Assets/Scenes/Game.unity");

        Debug.Log("<color=cyan>[CTRL+C CTRL+KILL]</color> Setup complete! " +
                  "Press ▶ Play to test.");
    }

    static string FindInPackageCache(string filename)
    {
        string cache = Path.GetFullPath(
            Path.Combine(Application.dataPath, "../Library/PackageCache"));
        if (!Directory.Exists(cache)) return null;
        string[] hits = Directory.GetFiles(cache, filename, SearchOption.AllDirectories);
        return hits.Length > 0 ? hits[0] : null;
    }

    static void AddEventSystem()
    {
        var go = new GameObject("EventSystem");
        go.AddComponent<EventSystem>();
        go.AddComponent<StandaloneInputModule>();
    }

    static void AddGlobalLight(float intensity = 1.2f)
    {
        var go    = new GameObject("GlobalLight2D");
        var light = go.AddComponent<Light2D>();
        light.lightType = Light2D.LightType.Global;
        light.intensity = intensity;
        light.color     = Color.white;
    }

    static Camera MakeCamera(Vector3 pos, bool addFollow = false)
    {
        var camGO = new GameObject("Main Camera");
        camGO.tag = "MainCamera";
        var cam              = camGO.AddComponent<Camera>();
        cam.clearFlags       = CameraClearFlags.SolidColor;
        cam.backgroundColor  = new Color(0.04f, 0.04f, 0.06f);
        cam.orthographic     = true;
        cam.orthographicSize = 8f;
        camGO.transform.position = pos;
        camGO.AddComponent<AudioListener>();
        if (addFollow) camGO.AddComponent<CameraFollow>();
        return cam;
    }

    // ── MainMenu scene ────────────────────────────────────────────────────────

    static void BuildMainMenuScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        MakeCamera(new Vector3(0f, 0f, -10f));
        AddGlobalLight();
        AddEventSystem();
        new GameObject("MainMenuManager").AddComponent<MainMenuManager>();

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/MainMenu.unity");
        Debug.Log("[CTRL+C CTRL+KILL] MainMenu.unity saved.");
    }

    // ── Game scene ────────────────────────────────────────────────────────────

    static void BuildGameScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Camera — MazeManager.SetupCamera() sets ortho size and initial pos at runtime.
        // CameraFollow then tracks the player each frame.
        MakeCamera(new Vector3(2f, 2f, -10f), addFollow: true);

        AddGlobalLight();
        AddEventSystem();

        // ── All managers on one GameObject ─────────────────────────────────
        var setup = new GameObject("GameSetup");
        setup.AddComponent<GameManager>();
        setup.AddComponent<AssetManager>();
        setup.AddComponent<AudioManager>();
        setup.AddComponent<DifficultyManager>();
        setup.AddComponent<UIManager>();

        // ── Grid + Tilemaps ─────────────────────────────────────────────────
        var gridGO = new GameObject("Grid");
        var grid   = gridGO.AddComponent<Grid>();
        grid.cellSize = Vector3.one;

        var floorGO = new GameObject("FloorTilemap");
        floorGO.transform.SetParent(gridGO.transform, false);
        floorGO.AddComponent<Tilemap>();
        floorGO.AddComponent<TilemapRenderer>().sortingOrder = -10;

        var wallGO = new GameObject("WallTilemap");
        wallGO.transform.SetParent(gridGO.transform, false);
        wallGO.AddComponent<Tilemap>();
        wallGO.AddComponent<TilemapRenderer>().sortingOrder = -5;

        // ── Game objects ────────────────────────────────────────────────────
        new GameObject("MazeManager").AddComponent<MazeManager>();

        var playerGO = new GameObject("Player");
        playerGO.AddComponent<SpriteRenderer>();
        playerGO.AddComponent<PlayerController>();

        var aiGO = new GameObject("AI");
        aiGO.AddComponent<SpriteRenderer>();
        aiGO.AddComponent<AIController>();

        new GameObject("StarManager").AddComponent<StarManager>();
        new GameObject("PowerupManager").AddComponent<PowerupManager>();
        new GameObject("Minimap").AddComponent<MinimapController>();

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/Game.unity");
        Debug.Log("[CTRL+C CTRL+KILL] Game.unity saved.");
    }

    static readonly string[] ScenePaths =
    {
        "Assets/Scenes/MainMenu.unity",
        "Assets/Scenes/Game.unity",
    };

    static void SetBuildScenes()
    {
        var entries = new EditorBuildSettingsScene[ScenePaths.Length];
        for (int i = 0; i < ScenePaths.Length; i++)
            entries[i] = new EditorBuildSettingsScene(ScenePaths[i], true);

        EditorBuildSettings.scenes = entries;
        TryAddToActiveBuildProfile(entries);
        Debug.Log("[CTRL+C CTRL+KILL] Build scenes set: 0=MainMenu, 1=Game");
    }

    // Manual fallback — run via Tools > Fix Build Scenes if auto-setup fails
    [MenuItem("Tools/Fix Build Scenes (CTRL+C CTRL+KILL)")]
    static void FixBuildScenesMenu()
    {
        SetBuildScenes();
        Debug.Log("[CTRL+C CTRL+KILL] Manual scene fix applied.");
    }

    static void TryAddToActiveBuildProfile(EditorBuildSettingsScene[] entries)
    {
        try
        {
            // Unity 6 BuildProfile lives in different assemblies depending on version
            System.Type type = null;
            foreach (var asm in new[] {
                "UnityEditor.Build.Profile.BuildProfile, UnityEditor.BuildProfileModule",
                "UnityEditor.Build.Profile.BuildProfile, UnityEditor" })
            {
                type = System.Type.GetType(asm);
                if (type != null) break;
            }
            if (type == null) return;

            // Get active profile — try static method, then static property
            UnityEngine.Object profile = null;
            var flags = System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static;

            var getMethod = type.GetMethod("GetActiveBuildProfile", flags);
            if (getMethod != null)
                profile = getMethod.Invoke(null, null) as UnityEngine.Object;

            if (profile == null)
            {
                var getProp = type.GetProperty("activeProfile", flags);
                if (getProp != null)
                    profile = getProp.GetValue(null) as UnityEngine.Object;
            }
            if (profile == null)
            {
                Debug.LogWarning("[CTRL+C CTRL+KILL] No active Build Profile found. " +
                    "Run Tools > Fix Build Scenes or use File > Build Profiles to add scenes manually.");
                return;
            }

            var so = new SerializedObject(profile);
            so.Update();

            // Try both property name conventions used across Unity 6 versions
            SerializedProperty scenes = so.FindProperty("m_Scenes") ?? so.FindProperty("scenes");
            if (scenes == null || !scenes.isArray)
            {
                Debug.LogWarning("[CTRL+C CTRL+KILL] Could not find scenes array in BuildProfile. " +
                    "Run Tools > Fix Build Scenes.");
                return;
            }

            scenes.ClearArray();
            for (int i = 0; i < entries.Length; i++)
            {
                scenes.InsertArrayElementAtIndex(i);
                var elem = scenes.GetArrayElementAtIndex(i);

                // Try both naming conventions for sub-properties
                var enabledProp = elem.FindPropertyRelative("enabled")
                               ?? elem.FindPropertyRelative("m_Enabled");
                var pathProp    = elem.FindPropertyRelative("path")
                               ?? elem.FindPropertyRelative("m_Path");
                var guidProp    = elem.FindPropertyRelative("guid")
                               ?? elem.FindPropertyRelative("m_GUID");

                if (enabledProp != null) enabledProp.boolValue = true;
                if (pathProp    != null) pathProp.stringValue   = entries[i].path;
                if (guidProp    != null)
                {
                    // Store GUID as hex string (Unity internal format)
                    string guid = AssetDatabase.AssetPathToGUID(entries[i].path);
                    if (!string.IsNullOrEmpty(guid))
                    {
                        // GUID may be a SerializedProperty of type string or a struct
                        if (guidProp.propertyType == SerializedPropertyType.String)
                            guidProp.stringValue = guid;
                        else
                        {
                            var serializedGuid = guidProp.FindPropertyRelative("serializedGuid")
                                              ?? guidProp.FindPropertyRelative("m_SerializedGuid");
                            if (serializedGuid != null) serializedGuid.stringValue = guid;
                        }
                    }
                }
            }
            so.ApplyModifiedPropertiesWithoutUndo();
            AssetDatabase.SaveAssets();
            Debug.Log("[CTRL+C CTRL+KILL] Scenes added to active Unity 6 build profile.");
        }
        catch (System.Exception ex)
        {
            Debug.LogWarning($"[CTRL+C CTRL+KILL] Build profile update failed: {ex.Message}\n" +
                "Run Tools > Fix Build Scenes or File > Build Profiles to add scenes manually.");
        }
    }
}
