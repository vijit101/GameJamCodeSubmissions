using UnityEngine;
public class ConstructorGame : MonoBehaviour
{
    private const float GoalHeight = 8f;
    private const float GoalHoldDuration = 3f;
    private const float ResultInputDelay = 0.35f;
    private static readonly Color SkyTop = new Color(0.40f, 0.69f, 0.95f);
    private static readonly Color SkyBottom = new Color(0.95f, 0.86f, 0.67f);
    private static readonly Color Steel = new Color(0.22f, 0.26f, 0.33f);
    private static readonly Color CraneYellow = new Color(0.97f, 0.78f, 0.16f);
    private static readonly Color CraneShadow = new Color(0.72f, 0.53f, 0.08f);
    private static readonly Color GoalGreen = new Color(0.26f, 0.94f, 0.57f);

    private enum GameState
    {
        Title,
        Playing,
        Won,
        Lost
    }

    private static ConstructorGame instance;

    private GameState state = GameState.Title;
    private SpawnerMovement spawner;
    private GoalZone goalZone;
    private string statusMessage = "Press Space to Start";
    private float contactTimer;
    private int playStartFrame = -1;
    private float resultStateEnteredAt = -999f;

    public bool IsPlaying => state == GameState.Playing;
    public bool CanDropBlock => IsPlaying && Time.frameCount > playStartFrame;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Bootstrap()
    {
        if (instance != null)
        {
            return;
        }

        GameObject managerObject = new GameObject("ConstructorGame");
        instance = managerObject.AddComponent<ConstructorGame>();
    }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        BuildLevel();
        SetState(GameState.Title, "Press Space to Start");
    }

    private void Update()
    {
        switch (state)
        {
            case GameState.Title:
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    StartGame();
                }
                break;
            case GameState.Won:
            case GameState.Lost:
                if (Time.unscaledTime >= resultStateEnteredAt + ResultInputDelay && Input.GetKeyDown(KeyCode.Space))
                {
                    RestartGame();
                }
                break;
        }
    }

    public void NotifyGoalContactStarted()
    {
        if (!IsPlaying)
        {
            return;
        }

        if (goalZone != null && goalZone.HasTrackedBlock)
        {
            contactTimer = GoalHoldDuration;
        }
    }

    public void NotifyGoalContactEnded()
    {
        contactTimer = 0f;
    }

    public void NotifyBlockEnteredKillZone()
    {
        if (IsPlaying)
        {
            SetState(GameState.Lost, "A block fell off. Space to Restart");
        }
    }

    private void FixedUpdate()
    {
        if (!IsPlaying || goalZone == null || !goalZone.HasTrackedBlock)
        {
            return;
        }

        contactTimer -= Time.fixedDeltaTime;
        statusMessage = $"Hold the goal for {Mathf.Max(contactTimer, 0f):0.0}s";

        if (contactTimer <= 0f)
        {
            SetState(GameState.Won, "Tower Complete! Space to Restart");
        }
    }

    private void BuildLevel()
    {
        ConfigureCamera();
        BuildBackdrop();
        BuildScaffolding();

        GameObject platform = CreateBox("Platform", new Vector2(0f, -4.5f), new Vector2(14f, 1f), new Color(0.38f, 0.28f, 0.20f), false, true, -1);
        platform.tag = "Untagged";
        CreatePlatformTrim();

        CreateBox("KillZone", new Vector2(0f, -7f), new Vector2(30f, 1f), new Color(0.79f, 0.20f, 0.18f, 0.18f), true, true, -5)
            .AddComponent<KillZone>()
            .Initialize(this);

        GameObject goal = CreateBox("GoalLine", new Vector2(0f, GoalHeight), new Vector2(14f, 0.35f), new Color(GoalGreen.r, GoalGreen.g, GoalGreen.b, 0.72f), true, true, 3);
        goalZone = goal.AddComponent<GoalZone>();
        goalZone.Initialize(this);
        BuildGoalFrame();

        GameObject spawnerObject = CreateBox("Spawner", new Vector2(0f, 6.5f), new Vector2(1.7f, 0.52f), new Color(0.95f, 0.88f, 0.34f), false, false, 6);
        spawner = spawnerObject.AddComponent<SpawnerMovement>();
        spawner.Initialize(this, LoadBlockPrefab());
        BuildCraneVisuals(spawnerObject.transform);
    }

    private void ConfigureCamera()
    {
        Camera mainCamera = Camera.main;
        if (mainCamera == null)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            mainCamera = cameraObject.AddComponent<Camera>();
            mainCamera.orthographic = true;
            cameraObject.AddComponent<AudioListener>();
        }

        mainCamera.transform.position = new Vector3(0f, 1.5f, -10f);
        mainCamera.orthographic = true;
        mainCamera.orthographicSize = 8.5f;
        mainCamera.backgroundColor = SkyTop;
        mainCamera.clearFlags = CameraClearFlags.SolidColor;
    }

    private GameObject LoadBlockPrefab()
    {
        GameObject prefab = Resources.Load<GameObject>("Block");
        if (prefab != null)
        {
            return prefab;
        }

        return null;
    }

    private void BuildBackdrop()
    {
        CreateBox("SkyBottom", new Vector2(0f, -0.6f), new Vector2(24f, 15f), SkyBottom, false, false, -20);
        CreateBox("SkyTop", new Vector2(0f, 5.6f), new Vector2(24f, 12f), SkyTop, false, false, -21);
        CreateBox("Sun", new Vector2(-6.3f, 6.2f), new Vector2(2.3f, 2.3f), new Color(1f, 0.83f, 0.39f, 0.85f), false, false, -19);

        CreateCloud(new Vector2(-5.6f, 4.6f), 0.9f);
        CreateCloud(new Vector2(4.8f, 5.4f), 1.1f);
        CreateCloud(new Vector2(1.2f, 3.7f), 0.7f);

        BuildCityLayer(-12, new Color(0.66f, 0.68f, 0.74f, 0.55f), -2.7f, 2.0f, 0.75f);
        BuildCityLayer(-10, new Color(0.49f, 0.53f, 0.60f, 0.78f), -3.2f, 2.8f, 1.0f);
    }

    private void BuildScaffolding()
    {
        CreateBox("LeftScaffold", new Vector2(-6.9f, -0.5f), new Vector2(0.22f, 8.6f), Steel, false, false, 0);
        CreateBox("RightScaffold", new Vector2(6.9f, -0.5f), new Vector2(0.22f, 8.6f), Steel, false, false, 0);
        CreateBox("TopBeam", new Vector2(0f, 7.1f), new Vector2(13.8f, 0.22f), Steel, false, false, 0);

        for (float y = -2.5f; y <= 5.8f; y += 1.65f)
        {
            CreateBox($"BraceLeft{y:0}", new Vector2(-6.1f, y), new Vector2(1.9f, 0.14f), new Color(0.30f, 0.35f, 0.42f, 0.75f), false, false, 0)
                .transform.rotation = Quaternion.Euler(0f, 0f, 26f);
            CreateBox($"BraceRight{y:0}", new Vector2(6.1f, y), new Vector2(1.9f, 0.14f), new Color(0.30f, 0.35f, 0.42f, 0.75f), false, false, 0)
                .transform.rotation = Quaternion.Euler(0f, 0f, -26f);
        }
    }

    private void BuildGoalFrame()
    {
        CreateBox("GoalGlow", new Vector2(0f, GoalHeight), new Vector2(14.6f, 0.65f), new Color(0.62f, 1f, 0.72f, 0.20f), false, false, 2);
        CreateBox("GoalPostLeft", new Vector2(-6.8f, GoalHeight - 0.7f), new Vector2(0.25f, 1.8f), GoalGreen, false, false, 2);
        CreateBox("GoalPostRight", new Vector2(6.8f, GoalHeight - 0.7f), new Vector2(0.25f, 1.8f), GoalGreen, false, false, 2);
        CreateBox("GoalFlagLeft", new Vector2(-6.4f, GoalHeight + 0.45f), new Vector2(0.55f, 0.32f), new Color(0.17f, 0.80f, 0.49f), false, false, 2);
        CreateBox("GoalFlagRight", new Vector2(6.4f, GoalHeight + 0.45f), new Vector2(0.55f, 0.32f), new Color(0.17f, 0.80f, 0.49f), false, false, 2);
    }

    private void CreatePlatformTrim()
    {
        CreateBox("PlatformTopLip", new Vector2(0f, -4.02f), new Vector2(14f, 0.12f), new Color(0.82f, 0.62f, 0.33f), false, false, 0);

        float startX = -6.1f;
        for (int i = 0; i < 9; i++)
        {
            float x = startX + (i * 1.52f);
            Color stripeColor = i % 2 == 0 ? CraneYellow : Steel;
            CreateBox($"PlatformStripe{i}", new Vector2(x, -4.9f), new Vector2(1.15f, 0.26f), stripeColor, false, false, 1)
                .transform.rotation = Quaternion.Euler(0f, 0f, -12f);
        }
    }

    private void BuildCraneVisuals(Transform spawnerTransform)
    {
        Transform mast = CreateChildBox(spawnerTransform, "Mast", new Vector2(0f, 0f), new Vector2(0.22f, 1.2f), CraneYellow, 5);
        mast.localPosition = new Vector3(0f, 0.35f, 0f);

        CreateChildBox(spawnerTransform, "Boom", new Vector2(0f, 0f), new Vector2(2.2f, 0.18f), CraneYellow, 5).localPosition = new Vector3(0f, 0.74f, 0f);
        CreateChildBox(spawnerTransform, "Cab", new Vector2(0f, 0f), new Vector2(0.75f, 0.48f), CraneShadow, 6).localPosition = new Vector3(0f, 0f, 0f);
        CreateChildBox(spawnerTransform, "Window", new Vector2(0f, 0f), new Vector2(0.42f, 0.22f), new Color(0.73f, 0.92f, 1f), 7).localPosition = new Vector3(0f, 0.06f, 0f);
        CreateChildBox(spawnerTransform, "HookCable", new Vector2(0f, 0f), new Vector2(0.05f, 0.9f), Steel, 4).localPosition = new Vector3(0f, -0.72f, 0f);
        CreateChildBox(spawnerTransform, "Hook", new Vector2(0f, 0f), new Vector2(0.18f, 0.18f), Steel, 6).localPosition = new Vector3(0f, -1.18f, 0f);
    }

    private void BuildCityLayer(int sortingOrder, Color color, float yBase, float maxHeight, float widthScale)
    {
        float x = -8.2f;
        int index = 0;
        float[] widths = { 1.0f, 1.35f, 0.9f, 1.6f, 0.8f, 1.2f, 1.45f, 0.95f };
        float[] heights = { 1.5f, 2.7f, 1.9f, 3.1f, 2.2f, 2.9f, 1.8f, 2.4f };

        while (x < 8.5f)
        {
            float width = widths[index % widths.Length] * widthScale;
            float height = Mathf.Min(heights[index % heights.Length], maxHeight);
            CreateBox($"Building{sortingOrder}_{index}", new Vector2(x, yBase + height * 0.5f), new Vector2(width, height), color, false, false, sortingOrder);
            x += width * 0.78f;
            index++;
        }
    }

    private void CreateCloud(Vector2 center, float scale)
    {
        Color cloud = new Color(1f, 1f, 1f, 0.63f);
        CreateBox($"Cloud{center.x:0}_{center.y:0}_A", center, new Vector2(2.1f, 0.7f) * scale, cloud, false, false, -18);
        CreateBox($"Cloud{center.x:0}_{center.y:0}_B", center + new Vector2(-0.7f, 0.24f) * scale, new Vector2(1.0f, 0.72f) * scale, cloud, false, false, -18);
        CreateBox($"Cloud{center.x:0}_{center.y:0}_C", center + new Vector2(0.72f, 0.18f) * scale, new Vector2(1.15f, 0.8f) * scale, cloud, false, false, -18);
    }

    private Transform CreateChildBox(Transform parent, string objectName, Vector2 localPosition, Vector2 size, Color color, int sortingOrder)
    {
        GameObject go = CreateBox(objectName, Vector2.zero, size, color, false, false, sortingOrder);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPosition;
        return go.transform;
    }

    private GameObject CreateBox(string objectName, Vector2 position, Vector2 size, Color color, bool isTrigger, bool addCollider = true, int sortingOrder = 0)
    {
        GameObject go = new GameObject(objectName);
        go.transform.position = new Vector3(position.x, position.y, 0f);
        go.transform.localScale = new Vector3(size.x, size.y, 1f);

        SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
        renderer.sprite = RuntimeSpriteFactory.Sprite;
        renderer.color = color;
        renderer.sortingOrder = sortingOrder;

        if (addCollider)
        {
            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = isTrigger;
        }

        return go;
    }

    private void StartGame()
    {
        ClearBlocks();
        contactTimer = 0f;
        playStartFrame = Time.frameCount;
        SetState(GameState.Playing, "Build to the green goal line");
    }

    private void RestartGame()
    {
        ClearBlocks();
        contactTimer = 0f;
        goalZone?.ResetZone();

        if (spawner != null)
        {
            spawner.transform.position = new Vector3(0f, 6.5f, 0f);
        }

        SetState(GameState.Title, "Press Space to Start");
    }

    private void SetState(GameState newState, string message)
    {
        state = newState;
        statusMessage = message;
        contactTimer = 0f;
        if (newState == GameState.Won || newState == GameState.Lost)
        {
            resultStateEnteredAt = Time.unscaledTime;
        }
        if (newState != GameState.Playing)
        {
            playStartFrame = -1;
        }
        Time.timeScale = 1f;
    }

    private void ClearBlocks()
    {
        foreach (BlockMarker block in FindObjectsOfType<BlockMarker>())
        {
            Destroy(block.gameObject);
        }
    }

    private void OnGUI()
    {
        GUIStyle titleStyle = new GUIStyle(GUI.skin.label)
        {
            alignment = TextAnchor.MiddleCenter,
            fontSize = 28,
            fontStyle = FontStyle.Bold
        };
        titleStyle.normal.textColor = Color.white;

        GUIStyle infoStyle = new GUIStyle(GUI.skin.label)
        {
            alignment = TextAnchor.MiddleCenter,
            fontSize = 18
        };
        infoStyle.normal.textColor = Color.white;

        GUIStyle panelTitleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 22,
            fontStyle = FontStyle.Bold
        };
        panelTitleStyle.normal.textColor = Color.white;

        Color previousColor = GUI.color;

        GUI.color = new Color(0.10f, 0.13f, 0.17f, 0.82f);
        GUI.Box(new Rect(14f, 14f, 332f, 92f), GUIContent.none);
        GUI.color = new Color(0.94f, 0.76f, 0.18f, 1f);
        GUI.Box(new Rect(18f, 18f, 324f, 6f), GUIContent.none);
        GUI.color = previousColor;

        GUI.Label(new Rect(24f, 20f, 296f, 28f), "Building Tension", panelTitleStyle);
        GUI.Label(new Rect(24f, 48f, 296f, 20f), "Build a stable tower before it slips.", GUI.skin.label);
        GUI.Label(new Rect(24f, 68f, 296f, 20f), "Space: start, drop blocks, restart", GUI.skin.label);

        if (state == GameState.Title)
        {
            GUI.color = new Color(0.08f, 0.11f, 0.15f, 0.72f);
            GUI.Box(new Rect(Screen.width * 0.5f - 230f, Screen.height * 0.22f - 10f, 460f, 210f), GUIContent.none);
            GUI.color = new Color(0.94f, 0.76f, 0.18f, 1f);
            GUI.Box(new Rect(Screen.width * 0.5f - 214f, Screen.height * 0.22f + 8f, 428f, 6f), GUIContent.none);
            GUI.color = previousColor;

            GUI.Label(new Rect(0f, Screen.height * 0.25f, Screen.width, 40f), "BUILDING TENSION", titleStyle);
            GUI.Label(new Rect(0f, Screen.height * 0.25f + 42f, Screen.width, 90f), "Pilot the crane, stack clean drops,\nand hold the green line for 3 seconds.", infoStyle);
            GUI.Label(new Rect(0f, Screen.height * 0.25f + 132f, Screen.width, 30f), "Press Space to Start", infoStyle);
            return;
        }

        GUI.Label(new Rect(0f, 12f, Screen.width, 36f), statusMessage, infoStyle);

        if (state == GameState.Won || state == GameState.Lost)
        {
            GUI.color = new Color(0.08f, 0.11f, 0.15f, 0.80f);
            GUI.Box(new Rect(Screen.width * 0.5f - 180f, Screen.height * 0.3f, 360f, 124f), GUIContent.none);
            GUI.color = state == GameState.Won ? GoalGreen : new Color(0.88f, 0.31f, 0.26f);
            GUI.Box(new Rect(Screen.width * 0.5f - 166f, Screen.height * 0.3f + 12f, 332f, 6f), GUIContent.none);
            GUI.color = previousColor;
            GUI.Label(new Rect(0f, Screen.height * 0.3f + 18f, Screen.width, 34f), state == GameState.Won ? "YOU WIN" : "GAME OVER", titleStyle);
            GUI.Label(new Rect(0f, Screen.height * 0.3f + 58f, Screen.width, 26f), statusMessage, infoStyle);
        }
    }
}

public static class RuntimeSpriteFactory
{
    private static Sprite sprite;

    public static Sprite Sprite
    {
        get
        {
            if (sprite != null)
            {
                return sprite;
            }

            Texture2D texture = new Texture2D(1, 1);
            texture.SetPixel(0, 0, Color.white);
            texture.Apply();
            sprite = Sprite.Create(texture, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 1f);
            return sprite;
        }
    }
}
