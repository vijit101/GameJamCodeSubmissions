using UnityEngine;

public class KillZone : MonoBehaviour
{
    private ConstructorGame game;

    public void Initialize(ConstructorGame gameManager)
    {
        game = gameManager;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.TryGetComponent(out BlockMarker _))
        {
            return;
        }

        game.NotifyBlockEnteredKillZone();
    }
}
