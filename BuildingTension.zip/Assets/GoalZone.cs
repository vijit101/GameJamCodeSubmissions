using UnityEngine;

public class GoalZone : MonoBehaviour
{
    private ConstructorGame game;
    private int trackedBlocks;

    public bool HasTrackedBlock => trackedBlocks > 0;

    public void Initialize(ConstructorGame gameManager)
    {
        game = gameManager;
    }

    public void ResetZone()
    {
        trackedBlocks = 0;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.TryGetComponent(out BlockMarker _))
        {
            return;
        }

        trackedBlocks++;
        if (trackedBlocks == 1)
        {
            game.NotifyGoalContactStarted();
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (!other.TryGetComponent(out BlockMarker _))
        {
            return;
        }

        trackedBlocks = Mathf.Max(0, trackedBlocks - 1);
        if (trackedBlocks == 0)
        {
            game.NotifyGoalContactEnded();
        }
    }
}
