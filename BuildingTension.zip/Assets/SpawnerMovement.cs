using UnityEngine;

public class SpawnerMovement : MonoBehaviour
{
    [SerializeField] private float speed = 3f;
    [SerializeField] private float boundary = 5f;
    [SerializeField] private float spawnHeight = 6.5f;
    [SerializeField] private GameObject blockPrefab;

    private ConstructorGame game;
    private Sprite runtimeSprite;

    public void Initialize(ConstructorGame gameManager, GameObject prefabOverride)
    {
        game = gameManager;
        blockPrefab = prefabOverride;
    }

    private void Update()
    {
        if (game == null || !game.IsPlaying)
        {
            return;
        }

        float x = Mathf.PingPong(Time.time * speed, boundary * 2f) - boundary;
        transform.position = new Vector3(x, spawnHeight, 0f);

        if (game.CanDropBlock && Input.GetKeyDown(KeyCode.Space))
        {
            DropBlock();
        }
    }

    private void DropBlock()
    {
        GameObject block = blockPrefab != null
            ? Instantiate(blockPrefab, transform.position, Quaternion.identity)
            : CreateFallbackBlock();

        block.name = "Block";
        if (block.GetComponent<BlockMarker>() == null)
        {
            block.AddComponent<BlockMarker>();
        }
    }

    private GameObject CreateFallbackBlock()
    {
        GameObject block = new GameObject("RuntimeBlock");
        block.transform.position = transform.position;
        block.transform.localScale = Vector3.one;

        SpriteRenderer renderer = block.AddComponent<SpriteRenderer>();
        renderer.sprite = GetRuntimeSprite();
        renderer.color = new Color(0.95f, 0.75f, 0.28f);

        block.AddComponent<BoxCollider2D>();

        Rigidbody2D body = block.AddComponent<Rigidbody2D>();
        body.mass = 1f;
        body.gravityScale = 1f;
        body.angularDrag = 0.05f;

        return block;
    }

    private Sprite GetRuntimeSprite()
    {
        if (runtimeSprite != null)
        {
            return runtimeSprite;
        }

        Texture2D texture = new Texture2D(1, 1);
        texture.SetPixel(0, 0, Color.white);
        texture.Apply();

        runtimeSprite = Sprite.Create(texture, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 1f);
        return runtimeSprite;
    }
}
