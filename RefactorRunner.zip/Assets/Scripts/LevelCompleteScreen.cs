using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class LevelCompleteScreen : MonoBehaviour
{
    public GameObject levelCompletePanel;
    public Text messageText;

    public float delayBeforeNextLevel = 3f;

    void Start()
    {
        if (levelCompletePanel != null)
        {
            levelCompletePanel.SetActive(false);
        }
    }

    public void Show()
    {
        int currentIndex = SceneManager.GetActiveScene().buildIndex;
        int nextIndex = currentIndex + 1;
        bool isLastLevel = nextIndex >= SceneManager.sceneCountInBuildSettings;

        if (levelCompletePanel != null)
        {
            levelCompletePanel.SetActive(true);
        }

        if (messageText != null)
        {
            messageText.text = isLastLevel ? "YOU WIN!" : "LEVEL COMPLETE!";
        }

        if (isLastLevel)
        {
            // Final level — stay on screen, let player press R to replay
            StartCoroutine(WaitForReplay());
        }
        else
        {
            StartCoroutine(LoadNextLevelAfterDelay(nextIndex));
        }
    }

    IEnumerator LoadNextLevelAfterDelay(int nextIndex)
    {
        yield return new WaitForSeconds(delayBeforeNextLevel);
        SceneManager.LoadScene(nextIndex);
    }

    IEnumerator WaitForReplay()
    {
        // Wait for R key to replay from Level 1
        while (true)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                SceneManager.LoadScene(0);
                yield break;
            }
            yield return null;
        }
    }
}
