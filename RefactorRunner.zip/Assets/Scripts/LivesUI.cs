using UnityEngine;
using UnityEngine.UI;

public class LivesUI : MonoBehaviour
{
    public Image[] hearts;        // drag Heart1,2,3 here
    public PlayerController player;

    void Start()
    {
        // Auto-find player if not assigned in Inspector
        if (player == null)
        {
            player = FindAnyObjectByType<PlayerController>();
        }

        if (player == null)
        {
            Debug.LogWarning("LivesUI: PlayerController not found!");
        }
    }

    void Update()
    {
        if (player == null || hearts == null) return;

        for (int i = 0; i < hearts.Length; i++)
        {
            if (hearts[i] == null) continue;

            if (i < player.lives)
            {
                hearts[i].enabled = true;   // show heart
            }
            else
            {
                hearts[i].enabled = false;  // hide heart
            }
        }
    }
}