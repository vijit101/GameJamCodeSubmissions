using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    private GameHUD hud;

    void Start()
    {
        hud = FindAnyObjectByType<GameHUD>();
    }

    public void GameOver()
    {
        Debug.Log("Game Over");

        if (hud != null)
        {
            hud.ShowGameOver();
        }
        else
        {
            // Fallback: reload scene if no HUD
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void NextLevel()
    {
        Debug.Log("LEVEL COMPLETE!");

        if (hud != null)
        {
            hud.ShowLevelComplete();
        }
        else
        {
            // Fallback: direct scene load with boundary check
            int currentIndex = SceneManager.GetActiveScene().buildIndex;
            int nextIndex = currentIndex + 1;

            if (nextIndex < SceneManager.sceneCountInBuildSettings)
            {
                SceneManager.LoadScene(nextIndex);
            }
            else
            {
                Debug.Log("YOU WIN! No more levels.");
                SceneManager.LoadScene(0);
            }
        }
    }
}