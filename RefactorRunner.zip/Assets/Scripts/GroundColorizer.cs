using UnityEngine;
using System;

/// <summary>
/// Colorize any tagged objects in the scene.
/// Add entries in the Inspector: pick a Tag + Color for each group.
/// Attach to any GameObject (e.g. GameHUD).
/// </summary>
public class GroundColorizer : MonoBehaviour
{
    [Serializable]
    public class TagColorEntry
    {
        public string tag = "Ground";
        public Color color = new Color(0.55f, 0.27f, 0.07f, 1f); // brown
    }

    [Header("Add tag + color pairs below")]
    public TagColorEntry[] entries = new TagColorEntry[]
    {
        new TagColorEntry { tag = "Ground", color = new Color(0.55f, 0.27f, 0.07f, 1f) }
    };

    void Start()
    {
        foreach (TagColorEntry entry in entries)
        {
            ColorizeTag(entry.tag, entry.color);
        }
    }

    void ColorizeTag(string tag, Color color)
    {
        GameObject[] objects;
        try
        {
            objects = GameObject.FindGameObjectsWithTag(tag);
        }
        catch
        {
            Debug.LogWarning("GroundColorizer: Tag '" + tag + "' does not exist! Add it in Edit > Project Settings > Tags and Layers.");
            return;
        }

        int colored = 0;

        foreach (GameObject obj in objects)
        {
            // Color all renderers on this object and its children
            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            foreach (Renderer rend in renderers)
            {
                // Try SpriteRenderer
                SpriteRenderer sr = rend as SpriteRenderer;
                if (sr != null)
                {
                    sr.color = color;
                    colored++;
                    continue;
                }

                // For MeshRenderer / other renderers — handle URP and Standard shaders
                Material mat = rend.material;
                if (mat != null)
                {
                    // URP Lit / URP Unlit use _BaseColor
                    if (mat.HasProperty("_BaseColor"))
                    {
                        mat.SetColor("_BaseColor", color);
                        colored++;
                    }
                    // Standard shader uses _Color
                    else if (mat.HasProperty("_Color"))
                    {
                        mat.SetColor("_Color", color);
                        colored++;
                    }
                    else
                    {
                        // Fallback: try .color
                        mat.color = color;
                        colored++;
                    }
                }
            }
        }

        Debug.Log("GroundColorizer: Tag '" + tag + "' → Found " + objects.Length + " objects, colored " + colored + " renderers");
    }
}
