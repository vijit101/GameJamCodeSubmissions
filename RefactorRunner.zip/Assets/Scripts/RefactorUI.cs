using UnityEngine;
using UnityEngine.UI;

public class RefactorUI : MonoBehaviour
{
    [Header("References")]
    public RefactorManager refactorManager;
    public GameObject refactorPanel;

    [Header("UI Elements")]
    public Text timerText;
    public Text controlMappingText;
    public Text warningText;

    // 🔥 NEW: Camera color effect
    private Camera cam;
    private Color originalColor;
    private Color refactorColor = new Color(0.61f, 0.36f, 0.90f); // #9B5DE5

    void Start()
    {
        cam = Camera.main;
        originalColor = cam.backgroundColor;

        if (refactorPanel != null)
        {
            refactorPanel.SetActive(false);
        }

        if (refactorManager != null)
        {
            refactorManager.OnRefactorStart += ShowPanel;
            refactorManager.OnRefactorEnd += HidePanel;
        }
    }

    void OnDestroy()
    {
        if (refactorManager != null)
        {
            refactorManager.OnRefactorStart -= ShowPanel;
            refactorManager.OnRefactorEnd -= HidePanel;
        }
    }

    void Update()
    {
        if (refactorManager == null) return;
        if (!refactorManager.IsRefactored) return;

        // Update countdown timer
        if (timerText != null)
        {
            float t = refactorManager.TimeRemaining;
            timerText.text = "REFACTOR: " + Mathf.CeilToInt(t) + "s";
        }
    }

    void ShowPanel()
    {
        if (refactorPanel != null)
        {
            refactorPanel.SetActive(true);
        }

        if (controlMappingText != null)
        {
            controlMappingText.text =
                "W → Down\n" +
                "S → Jump\n" +
                "A → Right\n" +
                "D → Left";
        }

        if (warningText != null)
        {
            warningText.text = "⚠ CONTROLS SWAPPED!";
        }

        // 🔥 CHANGE BACKGROUND TO PURPLE
        if (cam != null)
        {
            StopAllCoroutines();
            StartCoroutine(SmoothColorChange(refactorColor));
        }
    }

    void HidePanel()
    {
        if (refactorPanel != null)
        {
            refactorPanel.SetActive(false);
        }

        // 🔥 RESET BACKGROUND COLOR
        if (cam != null)
        {
            StopAllCoroutines();
            StartCoroutine(SmoothColorChange(originalColor));
        }
    }

    // 🔥 SMOOTH TRANSITION EFFECT
    System.Collections.IEnumerator SmoothColorChange(Color targetColor)
    {
        float duration = 0.5f;
        float time = 0;

        Color startColor = cam.backgroundColor;

        while (time < duration)
        {
            cam.backgroundColor = Color.Lerp(startColor, targetColor, time / duration);
            time += Time.deltaTime;
            yield return null;
        }

        cam.backgroundColor = targetColor;
    }
}