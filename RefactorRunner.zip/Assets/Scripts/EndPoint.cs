using UnityEngine;

/// <summary>
/// Attach this to the end-point/flag/portal GameObject.
/// Make sure the Player has the "Player" tag.
/// Works with both Trigger and non-Trigger colliders.
/// </summary>
public class EndPoint : MonoBehaviour
{
    // Detect via COLLISION (isTrigger OFF)
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("ENDPOINT REACHED (collision)");
            CompleteLevel();
        }
    }

    // Detect via TRIGGER (isTrigger ON)
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Debug.Log("ENDPOINT REACHED (trigger)");
            CompleteLevel();
        }
    }

    void CompleteLevel()
    {
        GameHUD hud = FindAnyObjectByType<GameHUD>();
        if (hud != null)
        {
            hud.ShowLevelComplete();
        }
        else
        {
            // Fallback: use GameManager
            GameManager gm = FindAnyObjectByType<GameManager>();
            if (gm != null)
            {
                gm.NextLevel();
            }
        }
    }
}
