using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 8f;
    public float jumpForce = 10f;
    public float acceleration = 5f;       // how fast player reaches full speed (lower = slidier)
    public float deceleration = 3f;       // how fast player stops (lower = more slide)

    [Header("Jump")]
    public int maxJumps = 2;              // 2 = double jump
    private int jumpsRemaining = 0;

    [Header("Lives")]
    public int lives = 3;

    private Rigidbody2D rb;
    private bool isGrounded;
    private int groundContactCount = 0; // track multiple ground colliders

    private float targetVelocityX;

    private bool isInvincible = false;

    private RefactorManager refactorManager;
    private GameManager gameManager;

    // Checkpoint / respawn position
    private Vector3 lastSafePosition;
    private float checkpointTimer = 0f;

    private SpriteRenderer spriteRenderer;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        refactorManager = FindAnyObjectByType<RefactorManager>();
        gameManager = FindAnyObjectByType<GameManager>();

        // Prevent the player from spinning on collision
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;

        // Load lives from previous level (persists across scenes)
        if (PlayerPrefs.HasKey("PlayerLives"))
        {
            lives = PlayerPrefs.GetInt("PlayerLives");
        }

        // Save starting position as first checkpoint
        lastSafePosition = transform.position;

        if (refactorManager == null)
        {
            Debug.LogWarning("PlayerController: RefactorManager not found in scene!");
        }
        if (gameManager == null)
        {
            Debug.LogWarning("PlayerController: GameManager not found in scene!");
        }
    }

    /// <summary>
    /// Call this to reset lives back to 3 (used on Game Over restart).
    /// </summary>
    public static void ResetLives()
    {
        PlayerPrefs.SetInt("PlayerLives", 3);
        PlayerPrefs.Save();
    }

    void Update()
    {
        // Smooth sliding movement — different speeds for accelerating vs stopping
        float currentVelocityX = rb.linearVelocity.x;
        float lerpSpeed;
        if (Mathf.Abs(targetVelocityX) > 0.1f)
        {
            lerpSpeed = acceleration; // speeding up
        }
        else
        {
            lerpSpeed = deceleration; // slowing down (slide)
        }
        float newVelocityX = Mathf.Lerp(currentVelocityX, targetVelocityX, Time.deltaTime * lerpSpeed);
        rb.linearVelocity = new Vector2(newVelocityX, rb.linearVelocity.y);

        // Flip sprite based on movement direction
        if (spriteRenderer != null)
        {
            if (targetVelocityX < -0.1f)
            {
                spriteRenderer.flipX = true;
            }
            else if (targetVelocityX > 0.1f)
            {
                spriteRenderer.flipX = false;
            }
        }

        // Save checkpoint every 0.3 seconds (works even in air)
        // Only skips if player is falling below the world
        if (transform.position.y > -5f)
        {
            checkpointTimer += Time.deltaTime;
            if (checkpointTimer >= 0.3f)
            {
                lastSafePosition = transform.position;
                checkpointTimer = 0f;
            }
        }

        // FALL CHECK — respawn at last safe position
        if (transform.position.y < -10f)
        {
            DieAndRespawn();
        }
    }

    public void MoveLeft()
    {
        targetVelocityX = -moveSpeed;
    }

    public void MoveRight()
    {
        targetVelocityX = moveSpeed;
    }

    public void StopMoving()
    {
        targetVelocityX = 0f;
    }

    public void Jump()
    {
        if (jumpsRemaining > 0)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            jumpsRemaining--;

            // If we were grounded, mark as not grounded
            if (isGrounded)
            {
                isGrounded = false;
                groundContactCount = 0;
            }
        }
    }

    public void MoveDown()
    {
        // Only apply downward force when in the air (refactored controls)
        if (!isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, -moveSpeed);
        }
    }

    // --- Ground Detection ---

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            groundContactCount++;
            isGrounded = true;
            jumpsRemaining = maxJumps;
            // Save checkpoint immediately on landing
            lastSafePosition = transform.position;
        }

        // Handle damage from enemies and obstacles via collision too
        // (works whether isTrigger is on or off in the Inspector)
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Debug.Log("COLLISION WITH ENEMY");
            DieAndRespawn();
        }

        if (collision.gameObject.CompareTag("Obstacle"))
        {
            Debug.Log("COLLISION WITH OBSTACLE");
            DieAndRespawn();
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            groundContactCount--;
            if (groundContactCount <= 0)
            {
                groundContactCount = 0;
                isGrounded = false;
            }
        }
    }

    // --- Trigger Detection ---

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("TRIGGER DETECTED: " + collision.gameObject.name + " [Tag: " + collision.tag + "]");

        if (collision.CompareTag("Enemy"))
        {
            DieAndRespawn();
        }

        if (collision.CompareTag("Obstacle"))
        {
            Debug.Log("HIT OBSTACLE");
            DieAndRespawn();
        }

        if (collision.CompareTag("End"))
        {
            Debug.Log("LEVEL COMPLETE!");
            if (gameManager != null)
            {
                gameManager.NextLevel();
            }
        }
    }

    // --- Damage & Respawn ---

    void TriggerRefactor()
    {
        if (refactorManager != null)
        {
            refactorManager.TriggerRefactor();
        }
    }

    public void TakeDamage()
    {
        DieAndRespawn();
    }

    void DieAndRespawn()
    {
        if (isInvincible) return;

        lives--;
        PlayerPrefs.SetInt("PlayerLives", lives);
        PlayerPrefs.Save();
        Debug.Log("DAMAGE TAKEN — Lives: " + lives);

        // Always refactor on damage
        TriggerRefactor();

        if (lives <= 0)
        {
            if (gameManager != null)
            {
                gameManager.GameOver();
            }
            return;
        }

        // Respawn at last safe position
        transform.position = lastSafePosition;
        rb.linearVelocity = Vector2.zero;
        targetVelocityX = 0f;

        StartCoroutine(InvincibilityCooldown());
    }

    IEnumerator InvincibilityCooldown()
    {
        isInvincible = true;

        // Flash the sprite to give visual feedback
        if (spriteRenderer != null)
        {
            for (int i = 0; i < 6; i++)
            {
                spriteRenderer.enabled = false;
                yield return new WaitForSeconds(0.15f);
                spriteRenderer.enabled = true;
                yield return new WaitForSeconds(0.15f);
            }
        }
        else
        {
            yield return new WaitForSeconds(1.5f);
        }

        isInvincible = false;
    }
}