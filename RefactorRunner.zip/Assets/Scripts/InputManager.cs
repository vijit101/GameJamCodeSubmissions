using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    public PlayerController player;

    public Dictionary<KeyCode, string> keyMap = new Dictionary<KeyCode, string>();

    void Start()
    {
        // Default controls
        keyMap[KeyCode.W] = "JUMP";
        keyMap[KeyCode.A] = "LEFT";
        keyMap[KeyCode.D] = "RIGHT";
        keyMap[KeyCode.S] = "NONE";
    }

    void Update()
    {
        if (player == null) return;

        bool movingLeft = false;
        bool movingRight = false;

        // --- Handle each key ---

        // W key
        if (Input.GetKey(KeyCode.W))
        {
            string action = keyMap.ContainsKey(KeyCode.W) ? keyMap[KeyCode.W] : "NONE";
            if (action == "LEFT") movingLeft = true;
            else if (action == "RIGHT") movingRight = true;
            else if (action == "DOWN") player.MoveDown();
            // JUMP is handled below with GetKeyDown
        }

        // S key
        if (Input.GetKey(KeyCode.S))
        {
            string action = keyMap.ContainsKey(KeyCode.S) ? keyMap[KeyCode.S] : "NONE";
            if (action == "LEFT") movingLeft = true;
            else if (action == "RIGHT") movingRight = true;
            else if (action == "DOWN") player.MoveDown();
            // JUMP is handled below with GetKeyDown
        }

        // A key
        if (Input.GetKey(KeyCode.A))
        {
            string action = keyMap.ContainsKey(KeyCode.A) ? keyMap[KeyCode.A] : "NONE";
            if (action == "LEFT") movingLeft = true;
            else if (action == "RIGHT") movingRight = true;
            else if (action == "DOWN") player.MoveDown();
            // JUMP is handled below with GetKeyDown
        }

        // D key
        if (Input.GetKey(KeyCode.D))
        {
            string action = keyMap.ContainsKey(KeyCode.D) ? keyMap[KeyCode.D] : "NONE";
            if (action == "LEFT") movingLeft = true;
            else if (action == "RIGHT") movingRight = true;
            else if (action == "DOWN") player.MoveDown();
            // JUMP is handled below with GetKeyDown
        }

        // --- Jump: always use GetKeyDown regardless of which key maps to it ---
        // This prevents jump from firing every frame
        foreach (var kvp in keyMap)
        {
            if (kvp.Value == "JUMP" && Input.GetKeyDown(kvp.Key))
            {
                player.Jump();
            }
        }

        // --- Apply horizontal movement ---
        if (movingLeft && !movingRight)
        {
            player.MoveLeft();
        }
        else if (movingRight && !movingLeft)
        {
            player.MoveRight();
        }
        else if (!movingLeft && !movingRight)
        {
            // No horizontal input — stop the player (prevents infinite sliding)
            player.StopMoving();
        }
    }
}