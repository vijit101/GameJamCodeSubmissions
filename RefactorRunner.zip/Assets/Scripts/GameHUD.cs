using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Self-contained game HUD. Attach to any GameObject.
/// Handles: Hearts display, Game Over screen, Level Complete screen, Refactor UI.
/// No manual Canvas/UI setup needed — everything is drawn via OnGUI.
/// </summary>
public class GameHUD : MonoBehaviour
{
    [Header("References (auto-found if empty)")]
    public PlayerController player;
    public RefactorManager refactorManager;

    [Header("Heart Texture (optional — uses colored box if not set)")]
    public Texture2D heartTexture;

    // State
    private bool isGameOver = false;
    private bool isLevelComplete = false;
    private string levelCompleteMessage = "";

    // Flash message state
    private string flashMessage = "";
    private float flashTimer = 0f;
    private float flashDuration = 2.5f;
    private Color flashColor = Color.white;

    // Track refactor state for detecting changes
    private bool wasRefactored = false;

    private GUIStyle heartStyle;
    private GUIStyle bigTextStyle;
    private GUIStyle mediumTextStyle;
    private GUIStyle buttonStyle;
    private GUIStyle refactorStyle;
    private GUIStyle timerStyle;
    private GUIStyle controlsStyle;
    private GUIStyle flashStyle;
    private bool stylesInitialized = false;

    void Start()
    {
        if (player == null)
            player = FindAnyObjectByType<PlayerController>();
        if (refactorManager == null)
            refactorManager = FindAnyObjectByType<RefactorManager>();

        if (player == null)
            Debug.LogWarning("GameHUD: PlayerController not found!");
        if (refactorManager == null)
            Debug.LogWarning("GameHUD: RefactorManager not found!");

        // Subscribe to refactor events
        if (refactorManager != null)
        {
            refactorManager.OnRefactorStart += OnRefactorStart;
            refactorManager.OnRefactorEnd += OnRefactorEnd;
        }
    }

    void OnDestroy()
    {
        if (refactorManager != null)
        {
            refactorManager.OnRefactorStart -= OnRefactorStart;
            refactorManager.OnRefactorEnd -= OnRefactorEnd;
        }
    }

    void OnRefactorStart()
    {
        ShowFlash("⚡ CONTROLS REFACTORED!", new Color(0.85f, 0.2f, 0.95f, 1f), "Adapt to survive!");
    }

    void OnRefactorEnd()
    {
        ShowFlash("✔ CONTROLS RESTORED!", new Color(0.15f, 0.95f, 0.5f, 1f), "Back to normal");
    }

    private string flashSubtitle = "";

    void ShowFlash(string message, Color color, string subtitle = "")
    {
        flashMessage = message;
        flashColor = color;
        flashSubtitle = subtitle;
        flashTimer = flashDuration;
    }

    void InitStyles()
    {
        if (stylesInitialized) return;
        stylesInitialized = true;

        heartStyle = new GUIStyle();
        heartStyle.fontSize = 40;
        heartStyle.normal.textColor = Color.red;

        bigTextStyle = new GUIStyle();
        bigTextStyle.fontSize = 64;
        bigTextStyle.alignment = TextAnchor.MiddleCenter;
        bigTextStyle.normal.textColor = Color.white;
        bigTextStyle.fontStyle = FontStyle.Bold;

        mediumTextStyle = new GUIStyle();
        mediumTextStyle.fontSize = 28;
        mediumTextStyle.alignment = TextAnchor.MiddleCenter;
        mediumTextStyle.normal.textColor = Color.white;

        buttonStyle = new GUIStyle("button");
        buttonStyle.fontSize = 28;
        buttonStyle.fixedHeight = 60;
        buttonStyle.fixedWidth = 250;
        buttonStyle.normal.textColor = Color.white;

        refactorStyle = new GUIStyle();
        refactorStyle.fontSize = 24;
        refactorStyle.alignment = TextAnchor.MiddleCenter;
        refactorStyle.normal.textColor = new Color(1f, 0.3f, 0.3f, 1f);
        refactorStyle.fontStyle = FontStyle.Bold;

        timerStyle = new GUIStyle();
        timerStyle.fontSize = 20;
        timerStyle.alignment = TextAnchor.MiddleCenter;
        timerStyle.normal.textColor = Color.yellow;
        timerStyle.fontStyle = FontStyle.Bold;

        controlsStyle = new GUIStyle();
        controlsStyle.fontSize = 18;
        controlsStyle.alignment = TextAnchor.MiddleLeft;
        controlsStyle.normal.textColor = Color.white;

        flashStyle = new GUIStyle();
        flashStyle.fontSize = 36;
        flashStyle.alignment = TextAnchor.MiddleCenter;
        flashStyle.fontStyle = FontStyle.Bold;
    }

    void Update()
    {
        // Countdown flash message
        if (flashTimer > 0f)
        {
            flashTimer -= Time.unscaledDeltaTime; // Use unscaledDeltaTime so it works even when paused
        }

        if (isGameOver)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                RestartLevel();
            }
        }

        if (isLevelComplete)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                RestartLevel();
            }
        }
    }

    public void ShowGameOver()
    {
        isGameOver = true;
        Time.timeScale = 0f;
    }

    public void ShowLevelComplete()
    {
        int currentIndex = SceneManager.GetActiveScene().buildIndex;
        int nextIndex = currentIndex + 1;
        bool isLastLevel = nextIndex >= SceneManager.sceneCountInBuildSettings;

        isLevelComplete = true;
        levelCompleteMessage = isLastLevel ? "YOU WIN!" : "LEVEL COMPLETE!";
        Time.timeScale = 0f; // Pause so player can choose
    }

    void LoadNextLevel()
    {
        Time.timeScale = 1f;
        int nextIndex = SceneManager.GetActiveScene().buildIndex + 1;
        if (nextIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextIndex);
        }
    }

    void RestartLevel()
    {
        Time.timeScale = 1f;
        if (isGameOver)
        {
            // Game Over = lost all lives → reset lives and go back to Level 1
            PlayerController.ResetLives();
            SceneManager.LoadScene(0);
        }
        else
        {
            // Replay (from Level Complete screen) → restart current level
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    void OnGUI()
    {
        InitStyles();

        DrawHearts();
        DrawRefactorUI();
        DrawFlashMessage();

        if (isGameOver)
        {
            DrawGameOver();
        }

        if (isLevelComplete)
        {
            DrawLevelComplete();
        }
    }

    void DrawHearts()
    {
        if (player == null) return;

        float x = 20f;
        float y = 20f;
        float heartHeight = 50f;
        float heartWidth = heartHeight;
        float spacing = 10f;

        // Calculate proper width from texture aspect ratio
        if (heartTexture != null && heartTexture.height > 0)
        {
            float aspect = (float)heartTexture.width / (float)heartTexture.height;
            heartWidth = heartHeight * aspect;
        }

        // Only draw hearts for remaining lives — no empty placeholders
        for (int i = 0; i < player.lives; i++)
        {
            if (heartTexture != null)
            {
                GUI.DrawTexture(new Rect(x, y, heartWidth, heartHeight), heartTexture, ScaleMode.ScaleToFit);
            }
            else
            {
                GUI.Label(new Rect(x, y, heartWidth, heartHeight), "\u2764", heartStyle);
            }
            x += heartWidth + spacing;
        }
    }

    void DrawRefactorUI()
    {
        if (refactorManager == null) return;
        if (!refactorManager.IsRefactored) return;

        float screenW = Screen.width;
        float t = refactorManager.TimeRemaining;
        float duration = refactorManager.refactorDuration;
        float time = Time.unscaledTime;
        float pulse = (Mathf.Sin(time * 4f) + 1f) / 2f;
        float fastPulse = (Mathf.Sin(time * 8f) + 1f) / 2f;
        float progress = Mathf.Clamp01(t / duration);
        bool isUrgent = t < 3f;

        // === FULL-WIDTH TOP BANNER ===
        float bannerY = 60f;
        float bannerH = 80f;

        // Multi-layer gradient background
        // Layer 1: Deep base
        GUI.color = new Color(0.12f, 0.04f, 0.2f, 0.92f);
        GUI.DrawTexture(new Rect(0, bannerY, screenW, bannerH), Texture2D.whiteTexture);

        // Layer 2: Pulsing color accent
        Color accentA = new Color(0.55f, 0.1f, 0.85f, 0.35f * pulse);
        Color accentB = new Color(0.85f, 0.15f, 0.4f, 0.25f * (1f - pulse));
        GUI.color = accentA;
        GUI.DrawTexture(new Rect(0, bannerY, screenW * 0.5f, bannerH), Texture2D.whiteTexture);
        GUI.color = accentB;
        GUI.DrawTexture(new Rect(screenW * 0.5f, bannerY, screenW * 0.5f, bannerH), Texture2D.whiteTexture);

        // Layer 3: Scanline effect (thin horizontal lines)
        for (int i = 0; i < 6; i++)
        {
            float lineY = bannerY + (i * 14f) + ((time * 30f) % 14f);
            if (lineY < bannerY + bannerH)
            {
                GUI.color = new Color(1f, 1f, 1f, 0.04f);
                GUI.DrawTexture(new Rect(0, lineY, screenW, 1), Texture2D.whiteTexture);
            }
        }

        // Top edge glow line
        Color edgeColor = Color.Lerp(
            new Color(0.7f, 0.3f, 1f, 0.9f),
            new Color(1f, 0.3f, 0.5f, 0.9f),
            fastPulse
        );
        GUI.color = edgeColor;
        GUI.DrawTexture(new Rect(0, bannerY, screenW, 3), Texture2D.whiteTexture);
        // Bottom edge
        GUI.color = new Color(edgeColor.r, edgeColor.g, edgeColor.b, 0.4f);
        GUI.DrawTexture(new Rect(0, bannerY + bannerH - 1, screenW, 1), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // === GLITCH-STYLE WARNING TEXT ===
        // Pick a warning message that alternates
        string[] warnings = {
            "\u26a0  CONTROLS REFACTORED  \u26a0",
            "\u26a0  INPUTS SCRAMBLED  \u26a0",
            "\u26a0  CONTROLS SWAPPED  \u26a0"
        };
        int msgIndex = Mathf.FloorToInt(time * 0.8f) % warnings.Length;
        string warningMsg = warnings[msgIndex];

        // Glitch offset (occasional horizontal jitter)
        float glitchX = 0f;
        if (Mathf.Sin(time * 17f) > 0.92f) glitchX = UnityEngine.Random.Range(-4f, 4f);

        GUIStyle bannerText = new GUIStyle();
        bannerText.fontSize = isUrgent ? 30 : 28;
        bannerText.fontStyle = FontStyle.Bold;
        bannerText.alignment = TextAnchor.MiddleCenter;

        // Triple shadow for depth
        bannerText.normal.textColor = new Color(0, 0, 0, 0.6f);
        GUI.Label(new Rect(3 + glitchX, bannerY + 10, screenW, 30), warningMsg, bannerText);
        bannerText.normal.textColor = new Color(0.5f, 0f, 0.8f, 0.4f);
        GUI.Label(new Rect(-2 + glitchX, bannerY + 7, screenW, 30), warningMsg, bannerText);
        // Main text: white → hot pink pulse
        bannerText.normal.textColor = Color.Lerp(
            new Color(1f, 1f, 1f, 1f),
            isUrgent ? new Color(1f, 0.2f, 0.3f, 1f) : new Color(1f, 0.6f, 0.9f, 1f),
            pulse
        );
        GUI.Label(new Rect(glitchX, bannerY + 8, screenW, 30), warningMsg, bannerText);

        // === PROGRESS BAR (inside banner) ===
        float barWidth = Mathf.Min(420f, screenW * 0.5f);
        float barHeight = 10f;
        float barX = (screenW - barWidth) / 2f;
        float barY = bannerY + 48f;
        float barRadius = barHeight / 2f;

        // Bar track (dark inset)
        GUI.color = new Color(0, 0, 0, 0.5f);
        GUI.DrawTexture(new Rect(barX - 1, barY - 1, barWidth + 2, barHeight + 2), Texture2D.whiteTexture);

        // Bar fill with color that shifts based on progress
        Color barFillA, barFillB;
        if (progress > 0.5f)
        {
            barFillA = new Color(0.2f, 0.9f, 0.5f, 1f);  // green
            barFillB = new Color(0.1f, 0.7f, 1f, 1f);     // cyan
        }
        else if (progress > 0.25f)
        {
            barFillA = new Color(1f, 0.8f, 0.1f, 1f);     // yellow
            barFillB = new Color(1f, 0.5f, 0.1f, 1f);     // orange
        }
        else
        {
            barFillA = new Color(1f, 0.2f, 0.2f, 1f);     // red
            barFillB = new Color(1f, 0.05f, 0.3f, 1f);    // hot red
        }
        float fillWidth = barWidth * progress;
        GUI.color = Color.Lerp(barFillA, barFillB, fastPulse);
        GUI.DrawTexture(new Rect(barX, barY, fillWidth, barHeight), Texture2D.whiteTexture);

        // Shimmer highlight on fill bar
        float shimmerPos = ((time * 120f) % (fillWidth + 40f)) - 20f;
        if (shimmerPos > 0 && shimmerPos < fillWidth)
        {
            GUI.color = new Color(1f, 1f, 1f, 0.25f);
            GUI.DrawTexture(new Rect(barX + shimmerPos, barY, 20f, barHeight), Texture2D.whiteTexture);
        }

        // Glow at fill edge
        if (fillWidth > 2f)
        {
            GUI.color = new Color(barFillA.r, barFillA.g, barFillA.b, 0.5f * pulse);
            GUI.DrawTexture(new Rect(barX + fillWidth - 6, barY - 2, 12, barHeight + 4), Texture2D.whiteTexture);
        }
        GUI.color = Color.white;

        // Timer text below bar
        GUIStyle timerLabel = new GUIStyle();
        timerLabel.fontSize = 14;
        timerLabel.alignment = TextAnchor.MiddleCenter;
        timerLabel.fontStyle = FontStyle.Bold;
        int seconds = Mathf.CeilToInt(t);
        if (isUrgent)
        {
            timerLabel.normal.textColor = Color.Lerp(new Color(1f, 0.3f, 0.3f), Color.white, fastPulse);
            GUI.Label(new Rect(0, barY + 12, screenW, 18), seconds + "s  \u2022  HURRY!", timerLabel);
        }
        else
        {
            timerLabel.normal.textColor = new Color(0.8f, 0.75f, 0.9f, 0.9f);
            GUI.Label(new Rect(0, barY + 12, screenW, 18), seconds + "s remaining", timerLabel);
        }

        // === CONTROL MAPPING PANEL (top-right) ===
        float panelW = 190f;
        float panelH = 155f;
        float panelX = screenW - panelW - 15;
        float panelTopY = 15;

        // Panel shadow
        GUI.color = new Color(0, 0, 0, 0.3f);
        GUI.DrawTexture(new Rect(panelX + 4, panelTopY + 4, panelW, panelH), Texture2D.whiteTexture);

        // Panel background (dark glassmorphism feel)
        GUI.color = new Color(0.08f, 0.05f, 0.15f, 0.93f);
        GUI.DrawTexture(new Rect(panelX, panelTopY, panelW, panelH), Texture2D.whiteTexture);

        // Animated top border (purple ↔ pink)
        Color borderCol = Color.Lerp(
            new Color(0.6f, 0.2f, 1f, 1f),
            new Color(1f, 0.3f, 0.6f, 1f),
            pulse
        );
        GUI.color = borderCol;
        GUI.DrawTexture(new Rect(panelX, panelTopY, panelW, 3), Texture2D.whiteTexture);
        // Side borders (subtle)
        GUI.color = new Color(borderCol.r, borderCol.g, borderCol.b, 0.3f);
        GUI.DrawTexture(new Rect(panelX, panelTopY, 1, panelH), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panelX + panelW - 1, panelTopY, 1, panelH), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panelX, panelTopY + panelH - 1, panelW, 1), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // Panel title with icon
        GUIStyle panelTitle = new GUIStyle();
        panelTitle.fontSize = 13;
        panelTitle.fontStyle = FontStyle.Bold;
        panelTitle.alignment = TextAnchor.MiddleCenter;
        panelTitle.normal.textColor = new Color(0.85f, 0.65f, 1f, 1f);
        GUI.Label(new Rect(panelX, panelTopY + 10, panelW, 18), "\u2328  NEW CONTROLS", panelTitle);

        // Separator line
        GUI.color = new Color(0.5f, 0.3f, 0.8f, 0.3f);
        GUI.DrawTexture(new Rect(panelX + 12, panelTopY + 32, panelW - 24, 1), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // Control entries with key badges
        string[] keys = { "W", "S", "A", "D" };
        string[] actions = { "Nothing", "Jump", "Right", "Left" };
        string[] icons = { "\u2716", "\u2191", "\u2192", "\u2190" };
        Color[] actionColors = {
            new Color(0.5f, 0.5f, 0.5f, 0.8f),     // grey for nothing
            new Color(0.3f, 1f, 0.55f, 1f),          // green for jump
            new Color(1f, 0.75f, 0.25f, 1f),          // golden for right
            new Color(1f, 0.75f, 0.25f, 1f)           // golden for left
        };

        float entryY = panelTopY + 40;
        float entrySpacing = 26f;

        for (int i = 0; i < keys.Length; i++)
        {
            float rowY = entryY + i * entrySpacing;

            // Key badge background
            GUI.color = new Color(0.25f, 0.15f, 0.4f, 0.8f);
            GUI.DrawTexture(new Rect(panelX + 14, rowY, 28, 22), Texture2D.whiteTexture);
            // Key badge border
            GUI.color = new Color(0.5f, 0.3f, 0.8f, 0.5f);
            GUI.DrawTexture(new Rect(panelX + 14, rowY, 28, 1), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(panelX + 14, rowY + 21, 28, 1), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(panelX + 14, rowY, 1, 22), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(panelX + 41, rowY, 1, 22), Texture2D.whiteTexture);
            GUI.color = Color.white;

            // Key letter (centered in badge)
            GUIStyle keyBadge = new GUIStyle();
            keyBadge.fontSize = 14;
            keyBadge.fontStyle = FontStyle.Bold;
            keyBadge.alignment = TextAnchor.MiddleCenter;
            keyBadge.normal.textColor = new Color(0.9f, 0.85f, 1f, 1f);
            GUI.Label(new Rect(panelX + 14, rowY, 28, 22), keys[i], keyBadge);

            // Arrow
            GUIStyle arrowStyle = new GUIStyle();
            arrowStyle.fontSize = 14;
            arrowStyle.alignment = TextAnchor.MiddleCenter;
            arrowStyle.normal.textColor = new Color(0.6f, 0.5f, 0.8f, 0.7f);
            GUI.Label(new Rect(panelX + 46, rowY, 20, 22), "\u2192", arrowStyle);

            // Action with icon
            GUIStyle actionStyle = new GUIStyle();
            actionStyle.fontSize = 14;
            actionStyle.alignment = TextAnchor.MiddleLeft;
            actionStyle.normal.textColor = actionColors[i];
            actionStyle.fontStyle = FontStyle.Bold;
            GUI.Label(new Rect(panelX + 70, rowY, panelW - 80, 22), icons[i] + " " + actions[i], actionStyle);
        }
    }

    void DrawFlashMessage()
    {
        if (flashTimer <= 0f) return;

        float screenW = Screen.width;
        float screenH = Screen.height;
        float time = Time.unscaledTime;

        // Timing calculations
        float elapsed = flashDuration - flashTimer;
        float fadeOutAlpha = Mathf.Clamp01(flashTimer / 0.6f);    // fade out in last 0.6s
        float fadeInAlpha = Mathf.Clamp01(elapsed / 0.15f);        // fade in over 0.15s
        float alpha = fadeOutAlpha * fadeInAlpha;

        // Slide-in: starts 40px above, settles to position
        float slideOffset = Mathf.Lerp(-40f, 0f, Mathf.Clamp01(elapsed / 0.25f));
        // Scale pop: starts slightly larger, settles
        float scaleFactor = Mathf.Lerp(1.08f, 1f, Mathf.Clamp01(elapsed / 0.3f));

        float pulse = (Mathf.Sin(time * 5f) + 1f) / 2f;

        // === PANEL DIMENSIONS ===
        float panelW = 560f;
        float panelH = string.IsNullOrEmpty(flashSubtitle) ? 80f : 100f;
        float panelX = (screenW - panelW) / 2f;
        float panelY = screenH * 0.16f + slideOffset;

        // === OUTER GLOW (multiple layers) ===
        for (int g = 3; g >= 1; g--)
        {
            float glowSize = g * 8f;
            Color glowColor = flashColor;
            glowColor.a = alpha * 0.08f * (4 - g);
            GUI.color = glowColor;
            GUI.DrawTexture(new Rect(
                panelX - glowSize, panelY - glowSize,
                panelW + glowSize * 2, panelH + glowSize * 2
            ), Texture2D.whiteTexture);
        }

        // === MAIN PANEL BACKGROUND ===
        // Shadow
        GUI.color = new Color(0, 0, 0, alpha * 0.4f);
        GUI.DrawTexture(new Rect(panelX + 5, panelY + 5, panelW, panelH), Texture2D.whiteTexture);

        // Background (dark with slight tint)
        GUI.color = new Color(0.06f, 0.03f, 0.12f, alpha * 0.92f);
        GUI.DrawTexture(new Rect(panelX, panelY, panelW, panelH), Texture2D.whiteTexture);

        // Inner color wash
        Color washColor = flashColor;
        washColor.a = alpha * 0.1f;
        GUI.color = washColor;
        GUI.DrawTexture(new Rect(panelX, panelY, panelW, panelH), Texture2D.whiteTexture);

        // === ANIMATED BORDER ===
        Color borderColor = flashColor;
        borderColor.a = alpha * (0.7f + 0.3f * pulse);

        // Top border (thick, main accent)
        GUI.color = borderColor;
        GUI.DrawTexture(new Rect(panelX, panelY, panelW, 3), Texture2D.whiteTexture);
        // Bottom border
        Color bottomBorder = borderColor;
        bottomBorder.a *= 0.5f;
        GUI.color = bottomBorder;
        GUI.DrawTexture(new Rect(panelX, panelY + panelH - 1, panelW, 1), Texture2D.whiteTexture);
        // Side borders (subtle)
        Color sideBorder = borderColor;
        sideBorder.a *= 0.25f;
        GUI.color = sideBorder;
        GUI.DrawTexture(new Rect(panelX, panelY, 1, panelH), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panelX + panelW - 1, panelY, 1, panelH), Texture2D.whiteTexture);

        // === DECORATIVE SPARKLE DOTS on borders ===
        float sparkleSpeed = time * 80f;
        for (int s = 0; s < 3; s++)
        {
            float dotX = panelX + ((sparkleSpeed + s * 180f) % panelW);
            GUI.color = new Color(1f, 1f, 1f, alpha * (0.4f + 0.3f * Mathf.Sin(time * 6f + s)));
            GUI.DrawTexture(new Rect(dotX, panelY, 4, 3), Texture2D.whiteTexture);
        }
        GUI.color = Color.white;

        // === MAIN TEXT with chromatic aberration effect ===
        float textY = string.IsNullOrEmpty(flashSubtitle) ? panelY : panelY - 6f;

        GUIStyle flashTextStyle = new GUIStyle();
        flashTextStyle.fontSize = Mathf.RoundToInt(34 * scaleFactor);
        flashTextStyle.fontStyle = FontStyle.Bold;
        flashTextStyle.alignment = TextAnchor.MiddleCenter;

        // Chromatic aberration layers (colored shadow offsets)
        if (elapsed < 0.5f)
        {
            float aberration = Mathf.Lerp(3f, 0f, elapsed / 0.5f);
            // Red channel offset
            flashTextStyle.normal.textColor = new Color(1f, 0.1f, 0.1f, alpha * 0.35f);
            GUI.Label(new Rect(panelX - aberration, textY, panelW, panelH), flashMessage, flashTextStyle);
            // Blue channel offset
            flashTextStyle.normal.textColor = new Color(0.1f, 0.3f, 1f, alpha * 0.35f);
            GUI.Label(new Rect(panelX + aberration, textY, panelW, panelH), flashMessage, flashTextStyle);
        }

        // Drop shadow
        flashTextStyle.normal.textColor = new Color(0, 0, 0, alpha * 0.5f);
        GUI.Label(new Rect(panelX + 2, textY + 2, panelW, panelH), flashMessage, flashTextStyle);

        // Main text (pulsing brightness)
        Color mainTextColor = flashColor;
        mainTextColor = Color.Lerp(mainTextColor, Color.white, 0.3f + 0.1f * pulse);
        mainTextColor.a = alpha;
        flashTextStyle.normal.textColor = mainTextColor;
        GUI.Label(new Rect(panelX, textY, panelW, panelH), flashMessage, flashTextStyle);

        // === SUBTITLE ===
        if (!string.IsNullOrEmpty(flashSubtitle))
        {
            GUIStyle subStyle = new GUIStyle();
            subStyle.fontSize = 16;
            subStyle.alignment = TextAnchor.MiddleCenter;
            subStyle.fontStyle = FontStyle.Italic;
            Color subColor = flashColor;
            subColor = Color.Lerp(subColor, Color.white, 0.5f);
            subColor.a = alpha * 0.7f;
            subStyle.normal.textColor = subColor;
            GUI.Label(new Rect(panelX, panelY + panelH - 30, panelW, 24), flashSubtitle, subStyle);
        }
    }

    void DrawGameOver()
    {
        float screenW = Screen.width;
        float screenH = Screen.height;

        // Dark overlay
        GUI.color = new Color(0, 0, 0, 0.75f);
        GUI.DrawTexture(new Rect(0, 0, screenW, screenH), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // "GAME OVER" text
        GUI.Label(new Rect(0, screenH * 0.3f, screenW, 80), "GAME OVER", bigTextStyle);

        // Reload button
        float btnX = (screenW - 250) / 2f;
        float btnY = screenH * 0.5f;
        if (GUI.Button(new Rect(btnX, btnY, 250, 60), "RESTART", buttonStyle))
        {
            RestartLevel();
        }

        // Also show hint
        GUI.Label(new Rect(0, btnY + 80, screenW, 40), "or press R", mediumTextStyle);
    }

    void DrawLevelComplete()
    {
        float screenW = Screen.width;
        float screenH = Screen.height;

        // Dark overlay
        GUI.color = new Color(0, 0, 0, 0.6f);
        GUI.DrawTexture(new Rect(0, 0, screenW, screenH), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // Message
        GUI.Label(new Rect(0, screenH * 0.25f, screenW, 80), levelCompleteMessage, bigTextStyle);

        float btnWidth = 250f;
        float btnHeight = 60f;
        float gap = 30f;

        // Check if there's a next level
        int nextIndex = SceneManager.GetActiveScene().buildIndex + 1;
        bool isLastLevel = nextIndex >= SceneManager.sceneCountInBuildSettings;

        if (isLastLevel)
        {
            // Only REPLAY button
            float btnX = (screenW - btnWidth) / 2f;
            float btnY = screenH * 0.45f;
            if (GUI.Button(new Rect(btnX, btnY, btnWidth, btnHeight), "REPLAY", buttonStyle))
            {
                RestartLevel();
            }
            GUI.Label(new Rect(0, btnY + 80, screenW, 40), "or press R", mediumTextStyle);
        }
        else
        {
            // Two buttons: REPLAY and NEXT LEVEL
            float totalWidth = btnWidth * 2 + gap;
            float startX = (screenW - totalWidth) / 2f;
            float btnY = screenH * 0.45f;

            // REPLAY button
            if (GUI.Button(new Rect(startX, btnY, btnWidth, btnHeight), "REPLAY", buttonStyle))
            {
                RestartLevel();
            }

            // NEXT LEVEL button
            if (GUI.Button(new Rect(startX + btnWidth + gap, btnY, btnWidth, btnHeight), "NEXT LEVEL", buttonStyle))
            {
                LoadNextLevel();
            }
        }
    }
}
