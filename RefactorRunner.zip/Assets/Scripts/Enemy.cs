using UnityEngine;

public class Enemy : MonoBehaviour
{
     public float speed = 2f;
    public float moveDistance = 3f;

    private Vector3 startPos;
    private float offset;

    void Start()
    {
        startPos = transform.position;

        // 🔥 random offset so enemies don't sync
        offset = Random.Range(0f, 100f);
    }

    void Update()
    {
        float movement = Mathf.PingPong((Time.time + offset) * speed, moveDistance * 2) - moveDistance;

        transform.position = new Vector3(
            startPos.x + movement, // 👈 horizontal movement
            startPos.y,
            startPos.z
        );
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerController player = collision.gameObject.GetComponent<PlayerController>();
            if (player != null) player.TakeDamage();
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            PlayerController player = collision.GetComponent<PlayerController>();
            if (player != null) player.TakeDamage();
        }
    }
}