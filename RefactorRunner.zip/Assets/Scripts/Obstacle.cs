using UnityEngine;

public class Obstacle : MonoBehaviour
{
    // Detect player via COLLISION (isTrigger OFF on this object)
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("OBSTACLE HIT PLAYER (collision)");
            PlayerController player = collision.gameObject.GetComponent<PlayerController>();
            if (player != null)
            {
                player.TakeDamage();
            }
        }
    }

    // Detect player via TRIGGER (isTrigger ON on this object)
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Debug.Log("OBSTACLE HIT PLAYER (trigger)");
            PlayerController player = collision.GetComponent<PlayerController>();
            if (player != null)
            {
                player.TakeDamage();
            }
        }
    }
}