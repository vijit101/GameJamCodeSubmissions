using System.Collections;
using UnityEngine;
using System;

public class RefactorManager : MonoBehaviour
{
    public InputManager inputManager;

    private bool isRefactored = false;
    private float refactorTimeRemaining = 0f;

    // Events for UI
    public event Action OnRefactorStart;
    public event Action OnRefactorEnd;

    public bool IsRefactored => isRefactored;
    public float TimeRemaining => refactorTimeRemaining;

    public float refactorDuration = 10f;

    public void TriggerRefactor()
    {
        if (!isRefactored)
        {
            StartCoroutine(RefactorRoutine());
        }
        else
        {
            // Reset the timer if already refactored (extend duration)
            refactorTimeRemaining = refactorDuration;
        }
    }

    IEnumerator RefactorRoutine()
    {
        isRefactored = true;
        refactorTimeRemaining = refactorDuration;

        Debug.Log("REFACTOR START");

        // Refactored: W→Nothing, S→Jump, A→Right, D→Left
        inputManager.keyMap[KeyCode.W] = "NONE";
        inputManager.keyMap[KeyCode.S] = "JUMP";
        inputManager.keyMap[KeyCode.A] = "RIGHT";
        inputManager.keyMap[KeyCode.D] = "LEFT";

        OnRefactorStart?.Invoke();

        while (refactorTimeRemaining > 0f)
        {
            refactorTimeRemaining -= Time.deltaTime;
            yield return null;
        }

        refactorTimeRemaining = 0f;

        // Restore normal controls
        inputManager.keyMap[KeyCode.W] = "JUMP";
        inputManager.keyMap[KeyCode.S] = "NONE";
        inputManager.keyMap[KeyCode.A] = "LEFT";
        inputManager.keyMap[KeyCode.D] = "RIGHT";

        Debug.Log("REFACTOR END");

        isRefactored = false;
        OnRefactorEnd?.Invoke();
    }
}