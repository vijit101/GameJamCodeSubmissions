using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float jumpForce = 13f;
    public float fallMultiplier = 3f;
    public Color whiteColor = Color.white;
    public Color blackColor = Color.black;

    private Rigidbody2D rb;
    private SpriteRenderer spriteRenderer;
    private bool isWhite = true;
    private bool isFrozen = false;
    private float freezeTimer = 0f;
    private bool isDying = false;
    private float deathTimer = 0f;
    private float flashTimer = 0f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.color = whiteColor;

        rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
        rb.gravityScale = 0f;
    }

    void Update()
    {
        // Death animation
        if (isDying)
        {
            deathTimer -= Time.deltaTime;
            flashTimer += Time.deltaTime;

            // Flash between red and current color
            if (Mathf.FloorToInt(flashTimer * 10f) % 2 == 0)
                spriteRenderer.color = Color.red;
            else
                spriteRenderer.color = isWhite ? whiteColor : blackColor;

            // Shake camera
            if (Camera.main != null)
            {
                float shake = 0.1f * (deathTimer / 1f);
                Camera.main.transform.position = new Vector3(
                    Random.Range(-shake, shake),
                    Random.Range(-shake, shake),
                    -10f
                );
            }

            if (deathTimer <= 0f)
            {
                // Reset camera
                if (Camera.main != null)
                    Camera.main.transform.position = new Vector3(0, 0, -10f);

                if (GameManager.Instance != null)
                    GameManager.Instance.GameOver();
            }
            return;
        }

        if (GameManager.Instance == null || !GameManager.Instance.isPlaying)
            return;

        // Enable gravity on first frame of playing
        if (rb.gravityScale == 0f)
            rb.gravityScale = 1f;

        // Jump
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        }

        // Better jump feel - fall faster than rise
        if (rb.linearVelocity.y < 0)
        {
            rb.linearVelocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }

        // Swap color
        if (Input.GetKeyDown(KeyCode.Space) && !isFrozen)
        {
            isWhite = !isWhite;
            spriteRenderer.color = isWhite ? whiteColor : blackColor;
        }

        // Freeze timer
        if (isFrozen)
        {
            freezeTimer -= Time.deltaTime;
            if (freezeTimer <= 0f)
            {
                isFrozen = false;
            }
        }

        // Fall off screen = die
        if (transform.position.y < -6f)
        {
            Die();
        }
    }

    void OnCollisionStay2D(Collision2D collision)
    {
        if (isDying) return;

        // When frozen, player can stand on ANY platform safely
        if (isFrozen) return;

        Platform platform = collision.gameObject.GetComponent<Platform>();
        if (platform != null)
        {
            if (platform.isWhite != isWhite)
            {
                Die();
            }
        }
    }

    public void Die()
    {
        if (isDying) return;
        isDying = true;
        deathTimer = 1f;
        flashTimer = 0f;

        // Tell GameManager we're dying so everything freezes
        if (GameManager.Instance != null)
            GameManager.Instance.isDying = true;

        // Stop player movement
        rb.linearVelocity = Vector2.zero;
        rb.gravityScale = 0f;
    }

    public void Freeze(float duration)
    {
        isFrozen = true;
        freezeTimer = duration;
    }

    public bool IsWhite()
    {
        return isWhite;
    }

    public bool IsFrozen()
    {
        return isFrozen;
    }

    public bool IsDying()
    {
        return isDying;
    }

    public float GetFreezeTimeLeft()
    {
        return freezeTimer;
    }
}
