using UnityEngine;

public static class SpriteHelper
{
    private static Sprite circleSprite;

    public static Sprite GetCircleSprite()
    {
        if (circleSprite != null) return circleSprite;

        int size = 64;
        Texture2D texture = new Texture2D(size, size);
        texture.filterMode = FilterMode.Bilinear;

        float center = size / 2f;
        float radius = size / 2f;

        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                float dist = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                if (dist < radius - 1f)
                    texture.SetPixel(x, y, Color.white);
                else if (dist < radius)
                    texture.SetPixel(x, y, new Color(1, 1, 1, 0.5f)); // soft edge
                else
                    texture.SetPixel(x, y, Color.clear);
            }
        }

        texture.Apply();
        circleSprite = Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        return circleSprite;
    }
}
