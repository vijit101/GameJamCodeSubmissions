using UnityEngine;

public class CoinVisual : MonoBehaviour
{
    void Start()
    {
        SpriteRenderer mainRenderer = GetComponent<SpriteRenderer>();
        Sprite circle = SpriteHelper.GetCircleSprite();

        // Outer ring - dark gold circle
        mainRenderer.sprite = circle;
        mainRenderer.color = new Color(0.85f, 0.65f, 0f);
        mainRenderer.sortingOrder = 5;

        // Inner circle - bright gold
        GameObject inner = new GameObject("Inner");
        inner.transform.SetParent(transform, false);
        inner.transform.localPosition = Vector3.zero;
        inner.transform.localScale = new Vector3(0.7f, 0.7f, 1f);
        SpriteRenderer innerSr = inner.AddComponent<SpriteRenderer>();
        innerSr.sprite = circle;
        innerSr.color = new Color(1f, 0.9f, 0.2f);
        innerSr.sortingOrder = 6;

        // Small dot in center
        GameObject dot = new GameObject("Dot");
        dot.transform.SetParent(transform, false);
        dot.transform.localPosition = Vector3.zero;
        dot.transform.localScale = new Vector3(0.2f, 0.2f, 1f);
        SpriteRenderer dotSr = dot.AddComponent<SpriteRenderer>();
        dotSr.sprite = circle;
        dotSr.color = new Color(0.85f, 0.65f, 0f);
        dotSr.sortingOrder = 7;
    }
}
