using UnityEngine;
using System.Collections.Generic;

public class PlatformSpawner : MonoBehaviour
{
    public GameObject platformPrefab;
    public GameObject freezeObstaclePrefab;

    public float platformSpeed = 5f;
    public float maxSpeed = 15f;
    public float speedIncreaseRate = 0.1f;
    public float spawnX = 14f;
    public float platformY = -2f;
    public float minChunkWidth = 3f;
    public float maxChunkWidth = 10f;

    private float nextSpawnX;
    private bool nextIsWhite = true;
    private int chunkCount = 0;
    private float currentSpeed;

    // Track positions to avoid overlaps
    private List<Vector2> usedPositions = new List<Vector2>();
    private float minDistance = 1.2f;

    void Start()
    {
        currentSpeed = platformSpeed;
        nextSpawnX = spawnX;
    }

    void Update()
    {
        if (GameManager.Instance == null || !GameManager.Instance.isPlaying || GameManager.Instance.isGameOver)
            return;

        currentSpeed += speedIncreaseRate * Time.deltaTime;
        if (currentSpeed > maxSpeed)
            currentSpeed = maxSpeed;

        nextSpawnX -= currentSpeed * Time.deltaTime;

        if (nextSpawnX < spawnX)
        {
            SpawnChunk();
        }
    }

    void SpawnChunk()
    {
        chunkCount++;
        usedPositions.Clear();

        float chunkWidth = Random.Range(minChunkWidth, maxChunkWidth);

        // Create ground chunk
        if (platformPrefab != null)
        {
            GameObject chunk = Instantiate(platformPrefab,
                new Vector3(nextSpawnX + chunkWidth / 2f, platformY, 0), Quaternion.identity);

            chunk.transform.localScale = new Vector3(chunkWidth, 0.5f, 1f);

            Platform platScript = chunk.GetComponent<Platform>();
            platScript.SetColor(nextIsWhite);
            platScript.moveSpeed = currentSpeed;
        }

        // Decide what goes on this chunk — freeze takes priority
        bool hasFreeze = false;
        float freezeX = 0f;

        if (chunkCount > 5 && chunkCount % 8 == 0)
        {
            freezeX = nextSpawnX + chunkWidth / 2f;
            float freezeY = platformY + 1.2f;
            SpawnFreeze(freezeX);
            usedPositions.Add(new Vector2(freezeX, freezeY));
            hasFreeze = true;
        }

        // Spawn obstacle (35% chance, not on first 4, not on freeze chunks)
        if (!hasFreeze && chunkCount > 4 && Random.value < 0.35f)
        {
            float obsX = nextSpawnX + Random.Range(1f, chunkWidth - 1f);
            float obsY = platformY + 0.7f;

            if (IsPositionFree(obsX, obsY))
            {
                SpawnObstacle(obsX);
                usedPositions.Add(new Vector2(obsX, obsY));
            }
        }

        // Spawn coins — evenly spaced, skip positions near obstacles/freeze
        if (chunkCount > 1)
        {
            int coinCount = Random.Range(3, 6);
            float spacing = (chunkWidth - 1f) / coinCount;

            for (int i = 0; i < coinCount; i++)
            {
                float coinX = nextSpawnX + 0.5f + (i * spacing) + Random.Range(0f, spacing * 0.3f);
                float coinY = platformY + Random.Range(0.8f, 2f);

                if (IsPositionFree(coinX, coinY))
                {
                    SpawnCoin(coinX, coinY);
                    usedPositions.Add(new Vector2(coinX, coinY));
                }
            }
        }

        nextSpawnX += chunkWidth;
        nextIsWhite = !nextIsWhite;
    }

    bool IsPositionFree(float x, float y)
    {
        Vector2 pos = new Vector2(x, y);
        for (int i = 0; i < usedPositions.Count; i++)
        {
            if (Vector2.Distance(pos, usedPositions[i]) < minDistance)
                return false;
        }
        return true;
    }

    void SpawnObstacle(float x)
    {
        GameObject obs = new GameObject("Obstacle");
        obs.transform.position = new Vector3(x, platformY + 0.7f, 0);
        obs.transform.localScale = new Vector3(0.5f, 0.9f, 1f);

        SpriteRenderer sr = obs.AddComponent<SpriteRenderer>();
        sr.sprite = GetSquareSprite();
        sr.sortingOrder = 1;

        BoxCollider2D col = obs.AddComponent<BoxCollider2D>();
        col.isTrigger = true;

        Obstacle obsScript = obs.AddComponent<Obstacle>();
        obsScript.moveSpeed = currentSpeed;
        obs.AddComponent<ObstacleVisual>();
    }

    void SpawnFreeze(float x)
    {
        if (freezeObstaclePrefab != null)
        {
            GameObject freeze = Instantiate(freezeObstaclePrefab,
                new Vector3(x, platformY + 1.2f, 0), Quaternion.identity);
            FreezeObstacle freezeScript = freeze.GetComponent<FreezeObstacle>();
            freezeScript.moveSpeed = currentSpeed;
        }
    }

    void SpawnCoin(float x, float y)
    {
        GameObject coin = new GameObject("Coin");
        coin.transform.position = new Vector3(x, y, 0);
        coin.transform.localScale = new Vector3(0.5f, 0.5f, 1f);

        SpriteRenderer sr = coin.AddComponent<SpriteRenderer>();
        sr.sprite = GetSquareSprite();
        sr.sortingOrder = 2;

        BoxCollider2D col = coin.AddComponent<BoxCollider2D>();
        col.isTrigger = true;

        Coin coinScript = coin.AddComponent<Coin>();
        coinScript.moveSpeed = currentSpeed;
        coin.AddComponent<CoinVisual>();
    }

    Sprite GetSquareSprite()
    {
        if (platformPrefab != null)
        {
            SpriteRenderer sr = platformPrefab.GetComponent<SpriteRenderer>();
            if (sr != null) return sr.sprite;
        }
        return null;
    }
}
