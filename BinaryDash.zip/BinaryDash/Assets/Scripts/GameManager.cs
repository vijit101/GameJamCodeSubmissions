using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public bool isGameOver = false;
    public bool isPlaying = false;
    public bool isDying = false;

    private GameObject startPanel;
    private GameObject gameOverPanel;
    private Text gameOverScoreText;
    private Text freezeWarningText;
    private Text scoreText;
    private GameObject newRecordFlyer;
    private Text newRecordText;
    private float flyerTimer = 0f;
    private bool flyerActive = false;
    private Canvas mainCanvas;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        CreateUI();
    }

    void Update()
    {
        if (!isPlaying && !isGameOver && Input.GetKeyDown(KeyCode.Space))
        {
            StartGame();
        }

        if (isGameOver && Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
        }

        // Show freeze warning
        if (isPlaying)
        {
            PlayerController player = FindAnyObjectByType<PlayerController>();
            if (player != null && freezeWarningText != null)
            {
                if (player.IsFrozen())
                {
                    float timeLeft = player.GetFreezeTimeLeft();
                    freezeWarningText.gameObject.SetActive(true);

                    if (timeLeft <= 2f)
                    {
                        // Warning! Blink red text
                        bool show = Mathf.FloorToInt(Time.time * 10f) % 2 == 0;
                        freezeWarningText.color = show ? new Color(1f, 0.2f, 0.2f) : new Color(1f, 0.6f, 0.2f);
                        freezeWarningText.text = "SWAP NOW! " + timeLeft.ToString("F1") + "s";
                        freezeWarningText.fontSize = 50;
                    }
                    else
                    {
                        freezeWarningText.color = new Color(0.5f, 0.8f, 1f);
                        freezeWarningText.text = "FROZEN! " + timeLeft.ToString("F1") + "s";
                        freezeWarningText.fontSize = 40;
                    }
                }
                else
                {
                    freezeWarningText.gameObject.SetActive(false);
                }
            }
        }

        // Animate the new record flyer
        if (flyerActive && newRecordFlyer != null)
        {
            flyerTimer += Time.deltaTime;

            // Scale pulse animation
            float scale = 1f + 0.15f * Mathf.Sin(flyerTimer * 4f);
            newRecordFlyer.transform.localScale = new Vector3(scale, scale, 1f);

            // Color shimmer between gold and white
            float t = (Mathf.Sin(flyerTimer * 3f) + 1f) / 2f;
            Color gold = new Color(1f, 0.85f, 0f);
            newRecordText.color = Color.Lerp(gold, Color.white, t);
        }
    }

    void StartGame()
    {
        isPlaying = true;

        if (startPanel != null)
            startPanel.SetActive(false);
    }

    public void GameOver()
    {
        if (isGameOver) return;
        isGameOver = true;
        isPlaying = false;

        // Check for new records
        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.CheckAndSaveRecords();
        }

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(true);
        }

        if (gameOverScoreText != null && ScoreManager.Instance != null)
        {
            string text = "GAME OVER\n\n";
            text += "Score: " + ScoreManager.Instance.GetScore();
            text += "    Best: " + ScoreManager.Instance.GetBestScore();
            text += "\nCoins: " + ScoreManager.Instance.GetCoins();
            text += "    Best: " + ScoreManager.Instance.GetBestCoins();
            text += "\n\nPress R to Restart";

            gameOverScoreText.text = text;
        }

        // Show celebration if new record
        if (ScoreManager.Instance != null &&
            (ScoreManager.Instance.IsNewScoreRecord() || ScoreManager.Instance.IsNewCoinRecord()))
        {
            ShowNewRecordFlyer();
        }
    }

    void ShowNewRecordFlyer()
    {
        if (mainCanvas == null) return;

        newRecordFlyer = new GameObject("NewRecordFlyer");
        newRecordFlyer.transform.SetParent(mainCanvas.transform, false);
        RectTransform flyerRect = newRecordFlyer.AddComponent<RectTransform>();
        flyerRect.anchorMin = new Vector2(0.1f, 0.82f);
        flyerRect.anchorMax = new Vector2(0.9f, 0.95f);
        flyerRect.sizeDelta = Vector2.zero;

        // Background glow
        Image flyerBg = newRecordFlyer.AddComponent<Image>();
        flyerBg.color = new Color(1f, 0.85f, 0f, 0.25f);

        // Record text
        GameObject textObj = new GameObject("RecordText");
        textObj.transform.SetParent(newRecordFlyer.transform, false);
        newRecordText = textObj.AddComponent<Text>();
        newRecordText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        newRecordText.fontSize = 45;
        newRecordText.fontStyle = FontStyle.Bold;
        newRecordText.alignment = TextAnchor.MiddleCenter;
        newRecordText.color = new Color(1f, 0.85f, 0f);

        RectTransform textRect = newRecordText.GetComponent<RectTransform>();
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.sizeDelta = Vector2.zero;

        // Build celebration message
        string msg = "";
        if (ScoreManager.Instance.IsNewScoreRecord() && ScoreManager.Instance.IsNewCoinRecord())
            msg = "NEW BEST SCORE & COINS!";
        else if (ScoreManager.Instance.IsNewScoreRecord())
            msg = "NEW BEST SCORE!";
        else
            msg = "NEW COIN RECORD!";

        newRecordText.text = msg;
        flyerActive = true;
        flyerTimer = 0f;

        // Spawn celebration particles
        SpawnCelebrationParticles();
    }

    void SpawnCelebrationParticles()
    {
        // Spawn small squares that fly outward like confetti
        for (int i = 0; i < 20; i++)
        {
            GameObject particle = new GameObject("Confetti");
            particle.transform.position = new Vector3(
                Random.Range(-6f, 6f),
                Random.Range(-2f, 3f),
                0
            );

            SpriteRenderer sr = particle.AddComponent<SpriteRenderer>();
            // Random bright colors
            Color[] colors = {
                new Color(1f, 0.85f, 0f),   // Gold
                new Color(1f, 0.3f, 0.3f),  // Red
                new Color(0.3f, 1f, 0.3f),  // Green
                new Color(0.3f, 0.5f, 1f),  // Blue
                Color.white
            };
            sr.color = colors[Random.Range(0, colors.Length)];
            sr.sprite = GetSquareSprite();
            sr.sortingOrder = 10;

            particle.transform.localScale = new Vector3(0.15f, 0.15f, 1f);

            CelebrationParticle cp = particle.AddComponent<CelebrationParticle>();
            cp.velocity = new Vector2(Random.Range(-3f, 3f), Random.Range(2f, 6f));
        }
    }

    Sprite GetSquareSprite()
    {
        // Find any sprite renderer in the scene to borrow its sprite
        PlayerController player = FindAnyObjectByType<PlayerController>();
        if (player != null)
        {
            SpriteRenderer sr = player.GetComponent<SpriteRenderer>();
            if (sr != null) return sr.sprite;
        }
        return null;
    }

    void RestartGame()
    {
        isGameOver = false;
        isPlaying = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void SetScoreText(Text text)
    {
        scoreText = text;
    }

    void CreateUI()
    {
        // Create Canvas
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();
        mainCanvas = canvas;

        // ========== START SCREEN ==========
        startPanel = new GameObject("StartPanel");
        startPanel.transform.SetParent(canvasObj.transform, false);
        Image startBg = startPanel.AddComponent<Image>();
        startBg.color = new Color(0.1f, 0.1f, 0.1f, 0.95f);
        RectTransform startRect = startPanel.GetComponent<RectTransform>();
        startRect.anchorMin = Vector2.zero;
        startRect.anchorMax = Vector2.one;
        startRect.sizeDelta = Vector2.zero;

        // Title
        GameObject titleObj = new GameObject("Title");
        titleObj.transform.SetParent(startPanel.transform, false);
        Text titleText = titleObj.AddComponent<Text>();
        titleText.text = "BINARY DASH";
        titleText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        titleText.fontSize = 60;
        titleText.fontStyle = FontStyle.Bold;
        titleText.color = Color.white;
        titleText.alignment = TextAnchor.MiddleCenter;
        RectTransform titleRect = titleText.GetComponent<RectTransform>();
        titleRect.anchorMin = new Vector2(0, 0.55f);
        titleRect.anchorMax = new Vector2(1, 0.85f);
        titleRect.sizeDelta = Vector2.zero;

        // Best scores on start screen
        string bestInfo = "";
        int bestScore = PlayerPrefs.GetInt("BestScore", 0);
        int bestCoins = PlayerPrefs.GetInt("BestCoins", 0);
        if (bestScore > 0 || bestCoins > 0)
        {
            bestInfo = "\n\nBest Score: " + bestScore + "  |  Best Coins: " + bestCoins;
        }

        // Subtitle
        GameObject subObj = new GameObject("Subtitle");
        subObj.transform.SetParent(startPanel.transform, false);
        Text subText = subObj.AddComponent<Text>();
        subText.text = "Match your color to the platform!\n\n" +
                        "UP ARROW  =  Jump\n" +
                        "SPACE  =  Swap Color" +
                        bestInfo +
                        "\n\n< Press SPACE to Start >";
        subText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        subText.fontSize = 25;
        subText.color = new Color(0.8f, 0.8f, 0.8f);
        subText.alignment = TextAnchor.MiddleCenter;
        RectTransform subRect = subText.GetComponent<RectTransform>();
        subRect.anchorMin = new Vector2(0, 0.1f);
        subRect.anchorMax = new Vector2(1, 0.55f);
        subRect.sizeDelta = Vector2.zero;

        // ========== HUD ==========

        // Score Text (top left)
        GameObject scoreObj = new GameObject("ScoreText");
        scoreObj.transform.SetParent(canvasObj.transform, false);
        Text sText = scoreObj.AddComponent<Text>();
        sText.text = "Score: 0";
        sText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        sText.fontSize = 30;
        sText.color = Color.white;
        RectTransform sRect = sText.GetComponent<RectTransform>();
        sRect.anchorMin = new Vector2(0, 1);
        sRect.anchorMax = new Vector2(0, 1);
        sRect.pivot = new Vector2(0, 1);
        sRect.anchoredPosition = new Vector2(20, -20);
        sRect.sizeDelta = new Vector2(400, 50);

        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.SetScoreText(sText);
        }

        // Coin Text (top right)
        GameObject coinObj = new GameObject("CoinText");
        coinObj.transform.SetParent(canvasObj.transform, false);
        Text cText = coinObj.AddComponent<Text>();
        cText.text = "Coins: 0";
        cText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        cText.fontSize = 30;
        cText.color = new Color(1f, 0.85f, 0f);
        cText.alignment = TextAnchor.UpperRight;
        RectTransform cRect = cText.GetComponent<RectTransform>();
        cRect.anchorMin = new Vector2(1, 1);
        cRect.anchorMax = new Vector2(1, 1);
        cRect.pivot = new Vector2(1, 1);
        cRect.anchoredPosition = new Vector2(-20, -20);
        cRect.sizeDelta = new Vector2(400, 50);

        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.SetCoinText(cText);
        }

        // Freeze Warning Text (top center)
        GameObject freezeObj = new GameObject("FreezeWarning");
        freezeObj.transform.SetParent(canvasObj.transform, false);
        freezeWarningText = freezeObj.AddComponent<Text>();
        freezeWarningText.text = "FROZEN!";
        freezeWarningText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        freezeWarningText.fontSize = 40;
        freezeWarningText.color = new Color(0.5f, 0.8f, 1f);
        freezeWarningText.alignment = TextAnchor.MiddleCenter;
        RectTransform freezeRect = freezeWarningText.GetComponent<RectTransform>();
        freezeRect.anchorMin = new Vector2(0.5f, 1);
        freezeRect.anchorMax = new Vector2(0.5f, 1);
        freezeRect.pivot = new Vector2(0.5f, 1);
        freezeRect.anchoredPosition = new Vector2(0, -20);
        freezeRect.sizeDelta = new Vector2(400, 60);
        freezeObj.SetActive(false);

        // ========== GAME OVER SCREEN ==========
        gameOverPanel = new GameObject("GameOverPanel");
        gameOverPanel.transform.SetParent(canvasObj.transform, false);
        Image panelImage = gameOverPanel.AddComponent<Image>();
        panelImage.color = new Color(0, 0, 0, 0.85f);
        RectTransform panelRect = gameOverPanel.GetComponent<RectTransform>();
        panelRect.anchorMin = Vector2.zero;
        panelRect.anchorMax = Vector2.one;
        panelRect.sizeDelta = Vector2.zero;

        // Game Over Text
        GameObject gameOverTextObj = new GameObject("GameOverText");
        gameOverTextObj.transform.SetParent(gameOverPanel.transform, false);
        gameOverScoreText = gameOverTextObj.AddComponent<Text>();
        gameOverScoreText.text = "GAME OVER";
        gameOverScoreText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        gameOverScoreText.fontSize = 45;
        gameOverScoreText.color = Color.white;
        gameOverScoreText.alignment = TextAnchor.MiddleCenter;
        RectTransform goRect = gameOverScoreText.GetComponent<RectTransform>();
        goRect.anchorMin = new Vector2(0, 0.1f);
        goRect.anchorMax = new Vector2(1, 0.75f);
        goRect.sizeDelta = Vector2.zero;

        gameOverPanel.SetActive(false);
    }
}
