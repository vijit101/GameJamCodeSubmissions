using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance;

    private float score = 0f;
    private int coins = 0;
    private Text scoreText;
    private Text coinText;

    // Best records (persist across sessions using PlayerPrefs)
    private int bestScore;
    private int bestCoins;
    private bool newScoreRecord = false;
    private bool newCoinRecord = false;

    void Awake()
    {
        Instance = this;
        bestScore = PlayerPrefs.GetInt("BestScore", 0);
        bestCoins = PlayerPrefs.GetInt("BestCoins", 0);
    }

    void Update()
    {
        if (GameManager.Instance == null || !GameManager.Instance.isPlaying || GameManager.Instance.isGameOver)
            return;

        score += Time.deltaTime * 10f;

        if (scoreText != null)
        {
            scoreText.text = "Score: " + Mathf.FloorToInt(score) + "  (Best: " + bestScore + ")";
        }
    }

    public void AddCoin()
    {
        coins++;
        UpdateCoinText();
    }

    void UpdateCoinText()
    {
        if (coinText != null)
        {
            coinText.text = "Coins: " + coins + "  (Best: " + bestCoins + ")";
        }
    }

    public void CheckAndSaveRecords()
    {
        int currentScore = Mathf.FloorToInt(score);

        if (currentScore > bestScore)
        {
            bestScore = currentScore;
            PlayerPrefs.SetInt("BestScore", bestScore);
            newScoreRecord = true;
        }

        if (coins > bestCoins)
        {
            bestCoins = coins;
            PlayerPrefs.SetInt("BestCoins", bestCoins);
            newCoinRecord = true;
        }

        PlayerPrefs.Save();
    }

    public void SetScoreText(Text text)
    {
        scoreText = text;
    }

    public void SetCoinText(Text text)
    {
        coinText = text;
        UpdateCoinText();
    }

    public int GetScore()
    {
        return Mathf.FloorToInt(score);
    }

    public int GetCoins()
    {
        return coins;
    }

    public int GetBestScore()
    {
        return bestScore;
    }

    public int GetBestCoins()
    {
        return bestCoins;
    }

    public bool IsNewScoreRecord()
    {
        return newScoreRecord;
    }

    public bool IsNewCoinRecord()
    {
        return newCoinRecord;
    }
}
