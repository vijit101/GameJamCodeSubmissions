using UnityEngine;

public class BackgroundManager : MonoBehaviour
{
    private GameObject[] stars;
    private GameObject[] binaryTexts;
    private float[] starSpeeds;
    private float[] binarySpeeds;

    void Start()
    {
        // Set a cool dark gradient-like background
        Camera.main.backgroundColor = new Color(0.05f, 0.05f, 0.12f);

        CreateStars();
        CreateBinaryRain();
        CreateGroundGlow();
    }

    void Update()
    {
        // Move stars (slow parallax)
        for (int i = 0; i < stars.Length; i++)
        {
            if (stars[i] == null) continue;
            stars[i].transform.Translate(Vector2.left * starSpeeds[i] * Time.deltaTime);

            if (stars[i].transform.position.x < -12f)
            {
                stars[i].transform.position = new Vector3(
                    12f,
                    stars[i].transform.position.y,
                    stars[i].transform.position.z
                );
            }
        }

        // Move binary text (medium speed parallax)
        for (int i = 0; i < binaryTexts.Length; i++)
        {
            if (binaryTexts[i] == null) continue;
            binaryTexts[i].transform.Translate(Vector2.left * binarySpeeds[i] * Time.deltaTime);

            if (binaryTexts[i].transform.position.x < -12f)
            {
                binaryTexts[i].transform.position = new Vector3(
                    12f + Random.Range(0f, 4f),
                    binaryTexts[i].transform.position.y,
                    binaryTexts[i].transform.position.z
                );
            }
        }
    }

    void CreateStars()
    {
        // Small twinkling dots in the background
        int count = 30;
        stars = new GameObject[count];
        starSpeeds = new float[count];
        Sprite circle = SpriteHelper.GetCircleSprite();

        for (int i = 0; i < count; i++)
        {
            stars[i] = new GameObject("Star");
            stars[i].transform.position = new Vector3(
                Random.Range(-11f, 11f),
                Random.Range(-4f, 5f),
                5f // behind everything
            );

            float size = Random.Range(0.03f, 0.08f);
            stars[i].transform.localScale = new Vector3(size, size, 1f);

            SpriteRenderer sr = stars[i].AddComponent<SpriteRenderer>();
            sr.sprite = circle;
            float brightness = Random.Range(0.2f, 0.6f);
            sr.color = new Color(brightness, brightness, brightness + 0.1f, Random.Range(0.3f, 0.8f));
            sr.sortingOrder = -10;

            starSpeeds[i] = Random.Range(0.2f, 0.8f);
        }
    }

    void CreateBinaryRain()
    {
        // Floating "0" and "1" in the background
        int count = 15;
        binaryTexts = new GameObject[count];
        binarySpeeds = new float[count];

        Sprite square = null;
        PlayerController player = FindAnyObjectByType<PlayerController>();
        if (player != null)
            square = player.GetComponent<SpriteRenderer>().sprite;

        if (square == null) return;

        for (int i = 0; i < count; i++)
        {
            binaryTexts[i] = new GameObject("Binary");
            binaryTexts[i].transform.position = new Vector3(
                Random.Range(-11f, 11f),
                Random.Range(-3f, 4f),
                5f
            );

            // Create "0" or "1" using squares
            bool isOne = Random.value > 0.5f;

            if (isOne)
            {
                // Vertical bar for "1"
                SpriteRenderer sr = binaryTexts[i].AddComponent<SpriteRenderer>();
                sr.sprite = square;
                float alpha = Random.Range(0.03f, 0.08f);
                sr.color = new Color(0.3f, 0.5f, 1f, alpha);
                sr.sortingOrder = -9;
                binaryTexts[i].transform.localScale = new Vector3(0.15f, 0.5f, 1f);
            }
            else
            {
                // Square with hole for "0"
                SpriteRenderer sr = binaryTexts[i].AddComponent<SpriteRenderer>();
                sr.sprite = SpriteHelper.GetCircleSprite();
                float alpha = Random.Range(0.03f, 0.08f);
                sr.color = new Color(0.3f, 0.5f, 1f, alpha);
                sr.sortingOrder = -9;
                binaryTexts[i].transform.localScale = new Vector3(0.35f, 0.45f, 1f);
            }

            binarySpeeds[i] = Random.Range(0.5f, 1.5f);
        }
    }

    void CreateGroundGlow()
    {
        // A subtle glow line at the bottom where platforms are
        Sprite square = null;
        PlayerController player = FindAnyObjectByType<PlayerController>();
        if (player != null)
            square = player.GetComponent<SpriteRenderer>().sprite;

        if (square == null) return;

        GameObject glow = new GameObject("GroundGlow");
        glow.transform.position = new Vector3(0, -2.5f, 5f);
        glow.transform.localScale = new Vector3(25f, 0.3f, 1f);
        SpriteRenderer sr = glow.AddComponent<SpriteRenderer>();
        sr.sprite = square;
        sr.color = new Color(0.2f, 0.3f, 0.6f, 0.15f);
        sr.sortingOrder = -8;
    }
}
