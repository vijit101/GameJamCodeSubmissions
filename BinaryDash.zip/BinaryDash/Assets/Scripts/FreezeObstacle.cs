using UnityEngine;

public class FreezeObstacle : MonoBehaviour
{
    public float freezeDuration = 5f;
    public float moveSpeed = 5f;

    private SpriteRenderer spriteRenderer;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.color = new Color(0.4f, 0.75f, 1f);
        transform.localScale = new Vector3(0.7f, 0.7f, 1f);

        // Add visual
        gameObject.AddComponent<FreezeVisual>();
    }

    void Update()
    {
        if (GameManager.Instance != null && (GameManager.Instance.isGameOver || GameManager.Instance.isDying))
            return;

        transform.Translate(Vector2.left * moveSpeed * Time.deltaTime);

        if (transform.position.x < -15f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        PlayerController player = other.GetComponent<PlayerController>();
        if (player != null && !player.IsDying())
        {
            player.Freeze(freezeDuration);
            Destroy(gameObject);
        }
    }
}
