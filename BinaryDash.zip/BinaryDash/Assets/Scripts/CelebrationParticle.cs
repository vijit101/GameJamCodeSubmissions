using UnityEngine;

public class CelebrationParticle : MonoBehaviour
{
    public Vector2 velocity;
    private float lifetime = 3f;
    private float rotateSpeed;

    void Start()
    {
        rotateSpeed = Random.Range(-360f, 360f);
    }

    void Update()
    {
        // Move with velocity
        transform.Translate(velocity * Time.deltaTime, Space.World);

        // Gravity pulls it down
        velocity.y -= 5f * Time.deltaTime;

        // Spin
        transform.Rotate(0, 0, rotateSpeed * Time.deltaTime);

        // Fade out
        lifetime -= Time.deltaTime;
        if (lifetime <= 0f)
        {
            Destroy(gameObject);
            return;
        }

        // Fade alpha in last second
        if (lifetime < 1f)
        {
            SpriteRenderer sr = GetComponent<SpriteRenderer>();
            if (sr != null)
            {
                Color c = sr.color;
                c.a = lifetime;
                sr.color = c;
            }
        }
    }
}
