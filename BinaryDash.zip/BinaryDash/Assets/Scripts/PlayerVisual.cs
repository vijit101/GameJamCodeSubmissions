using UnityEngine;

public class PlayerVisual : MonoBehaviour
{
    private SpriteRenderer mainRenderer;
    private SpriteRenderer outlineRenderer;
    private SpriteRenderer headRenderer;
    private SpriteRenderer headOutlineRenderer;
    private SpriteRenderer bodyRenderer;
    private SpriteRenderer bodyOutlineRenderer;
    private SpriteRenderer leftLegRenderer;
    private SpriteRenderer rightLegRenderer;
    private SpriteRenderer leftArmRenderer;
    private SpriteRenderer rightArmRenderer;
    private SpriteRenderer leftEyeRenderer;
    private SpriteRenderer rightEyeRenderer;

    void Start()
    {
        mainRenderer = GetComponent<SpriteRenderer>();
        mainRenderer.enabled = false;

        CreateOutline();
        CreateHead();
        CreateBody();
        CreateLegs();
        CreateArms();
        CreateEyes();

        UpdateColor();
    }

    void Update()
    {
        UpdateColor();
    }

    void UpdateColor()
    {
        PlayerController player = GetComponent<PlayerController>();
        if (player == null) return;

        Color bodyColor = player.IsWhite() ? Color.white : Color.black;
        Color eyeColor = player.IsWhite() ? Color.black : Color.white;
        // Outline is always a contrasting color
        Color outlineColor = player.IsWhite() ? new Color(0.5f, 0.5f, 0.5f) : new Color(0.4f, 0.5f, 0.8f);

        if (outlineRenderer != null) outlineRenderer.color = outlineColor;
        if (headOutlineRenderer != null) headOutlineRenderer.color = outlineColor;
        if (bodyOutlineRenderer != null) bodyOutlineRenderer.color = outlineColor;
        if (headRenderer != null) headRenderer.color = bodyColor;
        if (bodyRenderer != null) bodyRenderer.color = bodyColor;
        if (leftLegRenderer != null) leftLegRenderer.color = bodyColor;
        if (rightLegRenderer != null) rightLegRenderer.color = bodyColor;
        if (leftArmRenderer != null) leftArmRenderer.color = bodyColor;
        if (rightArmRenderer != null) rightArmRenderer.color = bodyColor;
        if (leftEyeRenderer != null) leftEyeRenderer.color = eyeColor;
        if (rightEyeRenderer != null) rightEyeRenderer.color = eyeColor;
    }

    void CreateOutline()
    {
        // Full body outline behind everything
        GameObject outline = new GameObject("BodyOutline");
        outline.transform.SetParent(transform, false);
        outline.transform.localPosition = new Vector3(0, 0.05f, 0);
        outline.transform.localScale = new Vector3(0.42f, 0.57f, 1f);
        outlineRenderer = outline.AddComponent<SpriteRenderer>();
        outlineRenderer.sprite = GetSquareSprite();
        outlineRenderer.sortingOrder = 1;
    }

    void CreateHead()
    {
        // Head outline
        GameObject headOut = new GameObject("HeadOutline");
        headOut.transform.SetParent(transform, false);
        headOut.transform.localPosition = new Vector3(0, 0.45f, 0);
        headOut.transform.localScale = new Vector3(0.47f, 0.47f, 1f);
        headOutlineRenderer = headOut.AddComponent<SpriteRenderer>();
        headOutlineRenderer.sprite = GetSquareSprite();
        headOutlineRenderer.sortingOrder = 1;

        // Head
        GameObject head = new GameObject("Head");
        head.transform.SetParent(transform, false);
        head.transform.localPosition = new Vector3(0, 0.45f, 0);
        head.transform.localScale = new Vector3(0.4f, 0.4f, 1f);
        headRenderer = head.AddComponent<SpriteRenderer>();
        headRenderer.sprite = GetSquareSprite();
        headRenderer.sortingOrder = 2;
    }

    void CreateBody()
    {
        // Body outline
        GameObject bodyOut = new GameObject("BodyOutline2");
        bodyOut.transform.SetParent(transform, false);
        bodyOut.transform.localPosition = new Vector3(0, 0.05f, 0);
        bodyOut.transform.localScale = new Vector3(0.42f, 0.57f, 1f);
        bodyOutlineRenderer = bodyOut.AddComponent<SpriteRenderer>();
        bodyOutlineRenderer.sprite = GetSquareSprite();
        bodyOutlineRenderer.sortingOrder = 1;

        // Body
        GameObject body = new GameObject("Body");
        body.transform.SetParent(transform, false);
        body.transform.localPosition = new Vector3(0, 0.05f, 0);
        body.transform.localScale = new Vector3(0.35f, 0.5f, 1f);
        bodyRenderer = body.AddComponent<SpriteRenderer>();
        bodyRenderer.sprite = GetSquareSprite();
        bodyRenderer.sortingOrder = 2;
    }

    void CreateLegs()
    {
        GameObject leftLeg = new GameObject("LeftLeg");
        leftLeg.transform.SetParent(transform, false);
        leftLeg.transform.localPosition = new Vector3(-0.1f, -0.35f, 0);
        leftLeg.transform.localScale = new Vector3(0.12f, 0.35f, 1f);
        leftLegRenderer = leftLeg.AddComponent<SpriteRenderer>();
        leftLegRenderer.sprite = GetSquareSprite();
        leftLegRenderer.sortingOrder = 2;

        GameObject rightLeg = new GameObject("RightLeg");
        rightLeg.transform.SetParent(transform, false);
        rightLeg.transform.localPosition = new Vector3(0.1f, -0.35f, 0);
        rightLeg.transform.localScale = new Vector3(0.12f, 0.35f, 1f);
        rightLegRenderer = rightLeg.AddComponent<SpriteRenderer>();
        rightLegRenderer.sprite = GetSquareSprite();
        rightLegRenderer.sortingOrder = 2;
    }

    void CreateArms()
    {
        GameObject leftArm = new GameObject("LeftArm");
        leftArm.transform.SetParent(transform, false);
        leftArm.transform.localPosition = new Vector3(-0.25f, 0.1f, 0);
        leftArm.transform.localScale = new Vector3(0.1f, 0.35f, 1f);
        leftArm.transform.localRotation = Quaternion.Euler(0, 0, 15f);
        leftArmRenderer = leftArm.AddComponent<SpriteRenderer>();
        leftArmRenderer.sprite = GetSquareSprite();
        leftArmRenderer.sortingOrder = 2;

        GameObject rightArm = new GameObject("RightArm");
        rightArm.transform.SetParent(transform, false);
        rightArm.transform.localPosition = new Vector3(0.25f, 0.1f, 0);
        rightArm.transform.localScale = new Vector3(0.1f, 0.35f, 1f);
        rightArm.transform.localRotation = Quaternion.Euler(0, 0, -15f);
        rightArmRenderer = rightArm.AddComponent<SpriteRenderer>();
        rightArmRenderer.sprite = GetSquareSprite();
        rightArmRenderer.sortingOrder = 2;
    }

    void CreateEyes()
    {
        GameObject leftEye = new GameObject("LeftEye");
        leftEye.transform.SetParent(transform, false);
        leftEye.transform.localPosition = new Vector3(-0.08f, 0.5f, 0);
        leftEye.transform.localScale = new Vector3(0.08f, 0.08f, 1f);
        leftEyeRenderer = leftEye.AddComponent<SpriteRenderer>();
        leftEyeRenderer.sprite = GetSquareSprite();
        leftEyeRenderer.sortingOrder = 3;

        GameObject rightEye = new GameObject("RightEye");
        rightEye.transform.SetParent(transform, false);
        rightEye.transform.localPosition = new Vector3(0.08f, 0.5f, 0);
        rightEye.transform.localScale = new Vector3(0.08f, 0.08f, 1f);
        rightEyeRenderer = rightEye.AddComponent<SpriteRenderer>();
        rightEyeRenderer.sprite = GetSquareSprite();
        rightEyeRenderer.sortingOrder = 3;
    }

    Sprite GetSquareSprite()
    {
        return GetComponent<SpriteRenderer>().sprite;
    }
}
