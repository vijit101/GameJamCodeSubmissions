using UnityEngine;

public class StartPlatform : MonoBehaviour
{
    public float slideSpeed = 3f;

    private bool sliding = false;
    private bool gameStarted = false;

    void Update()
    {
        if (!gameStarted && GameManager.Instance != null && GameManager.Instance.isPlaying)
        {
            gameStarted = true;
            // Start sliding after a short delay so first platform chunk arrives
            Invoke("StartSliding", 1.5f);
        }

        if (sliding)
        {
            transform.Translate(Vector2.left * slideSpeed * Time.deltaTime);

            if (transform.position.x < -15f)
            {
                Destroy(gameObject);
            }
        }
    }

    void StartSliding()
    {
        sliding = true;
    }
}
