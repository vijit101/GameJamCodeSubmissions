using UnityEngine;

public class Platform : MonoBehaviour
{
    public float moveSpeed = 5f;
    public bool isWhite = true;

    private SpriteRenderer spriteRenderer;
    private SpriteRenderer borderRenderer;
    private SpriteRenderer freezeOverlayRenderer;
    private PlayerController cachedPlayer;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        cachedPlayer = FindAnyObjectByType<PlayerController>();
        CreateBorder();
        CreateFreezeOverlay();
        SetColor(isWhite);
    }

    void Update()
    {
        if (GameManager.Instance != null && (GameManager.Instance.isGameOver || GameManager.Instance.isDying))
            return;

        transform.Translate(Vector2.left * moveSpeed * Time.deltaTime);

        if (transform.position.x < -20f)
        {
            Destroy(gameObject);
        }

        // Show/hide blue freeze overlay with warning blink
        if (freezeOverlayRenderer != null && cachedPlayer != null)
        {
            if (cachedPlayer.IsFrozen())
            {
                float timeLeft = cachedPlayer.GetFreezeTimeLeft();

                if (timeLeft <= 2f)
                {
                    // Last 2 seconds — blink faster as time runs out
                    float blinkSpeed = Mathf.Lerp(12f, 20f, 1f - (timeLeft / 2f));
                    bool show = Mathf.FloorToInt(Time.time * blinkSpeed) % 2 == 0;
                    freezeOverlayRenderer.enabled = show;

                    // Change overlay to red-ish warning color
                    freezeOverlayRenderer.color = new Color(1f, 0.3f, 0.3f, 0.45f);
                }
                else
                {
                    freezeOverlayRenderer.enabled = true;
                    freezeOverlayRenderer.color = new Color(0.3f, 0.55f, 1f, 0.4f);
                }
            }
            else
            {
                freezeOverlayRenderer.enabled = false;
                freezeOverlayRenderer.color = new Color(0.3f, 0.55f, 1f, 0.4f);
            }
        }
    }

    void CreateBorder()
    {
        GameObject border = new GameObject("Border");
        border.transform.SetParent(transform, false);
        border.transform.localPosition = Vector3.zero;
        border.transform.localScale = new Vector3(1.01f, 1.15f, 1f);
        borderRenderer = border.AddComponent<SpriteRenderer>();
        borderRenderer.sprite = spriteRenderer.sprite;
        borderRenderer.sortingOrder = spriteRenderer.sortingOrder - 1;
    }

    void CreateFreezeOverlay()
    {
        GameObject overlay = new GameObject("FreezeOverlay");
        overlay.transform.SetParent(transform, false);
        overlay.transform.localPosition = new Vector3(0, 0, 0);
        overlay.transform.localScale = new Vector3(0.98f, 0.8f, 1f);
        freezeOverlayRenderer = overlay.AddComponent<SpriteRenderer>();
        freezeOverlayRenderer.sprite = spriteRenderer.sprite;
        freezeOverlayRenderer.color = new Color(0.3f, 0.55f, 1f, 0.4f);
        freezeOverlayRenderer.sortingOrder = spriteRenderer.sortingOrder + 1;
        freezeOverlayRenderer.enabled = false;
    }

    public void SetColor(bool white)
    {
        isWhite = white;
        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();

        if (white)
        {
            spriteRenderer.color = Color.white;
            if (borderRenderer != null)
                borderRenderer.color = new Color(0.6f, 0.6f, 0.7f);
        }
        else
        {
            spriteRenderer.color = new Color(0.08f, 0.08f, 0.15f);
            if (borderRenderer != null)
                borderRenderer.color = new Color(0.3f, 0.4f, 0.8f);
        }
    }

    public void SetSpeed(float speed)
    {
        moveSpeed = speed;
    }
}
