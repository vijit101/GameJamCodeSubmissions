using UnityEngine;

public class ObstacleVisual : MonoBehaviour
{
    private SpriteRenderer mainRenderer;

    void Start()
    {
        mainRenderer = GetComponent<SpriteRenderer>();
        Sprite square = mainRenderer.sprite;

        // Main body - dark red
        mainRenderer.color = new Color(0.7f, 0.1f, 0.1f);
        mainRenderer.sortingOrder = 4;

        // Spike top-left
        GameObject spike1 = new GameObject("Spike1");
        spike1.transform.SetParent(transform, false);
        spike1.transform.localPosition = new Vector3(-0.3f, 0.6f, 0);
        spike1.transform.localScale = new Vector3(0.25f, 0.35f, 1f);
        spike1.transform.localRotation = Quaternion.Euler(0, 0, 15f);
        SpriteRenderer sr1 = spike1.AddComponent<SpriteRenderer>();
        sr1.sprite = square;
        sr1.color = new Color(0.9f, 0.15f, 0.15f);
        sr1.sortingOrder = 4;

        // Spike top-center
        GameObject spike2 = new GameObject("Spike2");
        spike2.transform.SetParent(transform, false);
        spike2.transform.localPosition = new Vector3(0, 0.7f, 0);
        spike2.transform.localScale = new Vector3(0.2f, 0.4f, 1f);
        SpriteRenderer sr2 = spike2.AddComponent<SpriteRenderer>();
        sr2.sprite = square;
        sr2.color = new Color(1f, 0.2f, 0.2f);
        sr2.sortingOrder = 4;

        // Spike top-right
        GameObject spike3 = new GameObject("Spike3");
        spike3.transform.SetParent(transform, false);
        spike3.transform.localPosition = new Vector3(0.3f, 0.6f, 0);
        spike3.transform.localScale = new Vector3(0.25f, 0.35f, 1f);
        spike3.transform.localRotation = Quaternion.Euler(0, 0, -15f);
        SpriteRenderer sr3 = spike3.AddComponent<SpriteRenderer>();
        sr3.sprite = square;
        sr3.color = new Color(0.9f, 0.15f, 0.15f);
        sr3.sortingOrder = 4;

        // Warning stripe
        GameObject stripe = new GameObject("Stripe");
        stripe.transform.SetParent(transform, false);
        stripe.transform.localPosition = new Vector3(0, 0, 0);
        stripe.transform.localScale = new Vector3(0.6f, 0.15f, 1f);
        SpriteRenderer sr4 = stripe.AddComponent<SpriteRenderer>();
        sr4.sprite = square;
        sr4.color = new Color(1f, 0.85f, 0f);
        sr4.sortingOrder = 5;
    }
}
