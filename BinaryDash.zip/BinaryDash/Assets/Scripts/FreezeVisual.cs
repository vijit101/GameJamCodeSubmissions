using UnityEngine;

public class FreezeVisual : MonoBehaviour
{
    private SpriteRenderer mainRenderer;
    private SpriteRenderer[] crystalRenderers = new SpriteRenderer[4];

    void Start()
    {
        mainRenderer = GetComponent<SpriteRenderer>();
        Sprite square = mainRenderer.sprite;

        // Main body - ice blue
        mainRenderer.color = new Color(0.4f, 0.75f, 1f);
        mainRenderer.sortingOrder = 4;

        // Ice crystal spikes around the body
        float[] angles = { 45f, -45f, 135f, -135f };
        for (int i = 0; i < 4; i++)
        {
            GameObject crystal = new GameObject("Crystal" + i);
            crystal.transform.SetParent(transform, false);

            float rad = angles[i] * Mathf.Deg2Rad;
            crystal.transform.localPosition = new Vector3(
                Mathf.Cos(rad) * 0.5f,
                Mathf.Sin(rad) * 0.5f,
                0
            );
            crystal.transform.localScale = new Vector3(0.3f, 0.15f, 1f);
            crystal.transform.localRotation = Quaternion.Euler(0, 0, angles[i]);

            crystalRenderers[i] = crystal.AddComponent<SpriteRenderer>();
            crystalRenderers[i].sprite = square;
            crystalRenderers[i].color = new Color(0.7f, 0.9f, 1f, 0.9f);
            crystalRenderers[i].sortingOrder = 4;
        }

        // Inner snowflake
        GameObject inner = new GameObject("Inner");
        inner.transform.SetParent(transform, false);
        inner.transform.localPosition = Vector3.zero;
        inner.transform.localScale = new Vector3(0.4f, 0.4f, 1f);
        inner.transform.localRotation = Quaternion.Euler(0, 0, 45f);
        SpriteRenderer innerSr = inner.AddComponent<SpriteRenderer>();
        innerSr.sprite = square;
        innerSr.color = new Color(0.85f, 0.95f, 1f);
        innerSr.sortingOrder = 5;

        // Cross inside
        GameObject cross1 = new GameObject("Cross1");
        cross1.transform.SetParent(transform, false);
        cross1.transform.localPosition = Vector3.zero;
        cross1.transform.localScale = new Vector3(0.08f, 0.6f, 1f);
        SpriteRenderer cr1 = cross1.AddComponent<SpriteRenderer>();
        cr1.sprite = square;
        cr1.color = Color.white;
        cr1.sortingOrder = 6;

        GameObject cross2 = new GameObject("Cross2");
        cross2.transform.SetParent(transform, false);
        cross2.transform.localPosition = Vector3.zero;
        cross2.transform.localScale = new Vector3(0.6f, 0.08f, 1f);
        SpriteRenderer cr2 = cross2.AddComponent<SpriteRenderer>();
        cr2.sprite = square;
        cr2.color = Color.white;
        cr2.sortingOrder = 6;
    }
}
