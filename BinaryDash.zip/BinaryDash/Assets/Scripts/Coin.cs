using UnityEngine;

public class Coin : MonoBehaviour
{
    public float moveSpeed = 5f;

    private SpriteRenderer spriteRenderer;
    private float bobTimer = 0f;
    private float startY;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.color = new Color(1f, 0.85f, 0f);
        spriteRenderer.sortingOrder = 5;
        startY = transform.position.y;
    }

    void Update()
    {
        if (GameManager.Instance != null && (GameManager.Instance.isGameOver || GameManager.Instance.isDying))
            return;

        // Move left
        transform.Translate(Vector2.left * moveSpeed * Time.deltaTime);

        // Bob up and down to make coins visible
        bobTimer += Time.deltaTime * 3f;
        float newY = startY + Mathf.Sin(bobTimer) * 0.15f;
        transform.position = new Vector3(transform.position.x, newY, transform.position.z);

        if (transform.position.x < -20f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController>() != null)
        {
            if (ScoreManager.Instance != null)
                ScoreManager.Instance.AddCoin();
            Destroy(gameObject);
        }
    }
}
