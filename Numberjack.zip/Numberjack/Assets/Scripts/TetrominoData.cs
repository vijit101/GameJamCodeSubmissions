using UnityEngine;

/// <summary>
/// Defines all 7 Tetromino shapes with their 4 explicit rotation states.
/// Each rotation is a set of Vector2Int offsets from the parent's position.
/// No Unity rotation needed — blocks are repositioned directly.
/// </summary>
public static class TetrominoData
{
    // ShapeRotations[shapeIndex][rotationState] = Vector2Int[] of 4 block positions
    public static readonly Vector2Int[][][] ShapeRotations = new Vector2Int[][][]
    {
        // 0: I-piece  ████
        new Vector2Int[][]
        {
            new[] { new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(2,1), new Vector2Int(3,1) },
            new[] { new Vector2Int(2,0), new Vector2Int(2,1), new Vector2Int(2,2), new Vector2Int(2,3) },
            new[] { new Vector2Int(0,2), new Vector2Int(1,2), new Vector2Int(2,2), new Vector2Int(3,2) },
            new[] { new Vector2Int(1,0), new Vector2Int(1,1), new Vector2Int(1,2), new Vector2Int(1,3) },
        },

        // 1: O-piece  ██
        //             ██
        new Vector2Int[][]
        {
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1) },
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1) },
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1) },
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1) },
        },

        // 2: T-piece  ███
        //              █
        new Vector2Int[][]
        {
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(2,0), new Vector2Int(1,1) },
            new[] { new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(1,2) },
            new[] { new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(2,1) },
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(0,2) },
        },

        // 3: S-piece   ██
        //             ██
        new Vector2Int[][]
        {
            new[] { new Vector2Int(1,0), new Vector2Int(2,0), new Vector2Int(0,1), new Vector2Int(1,1) },
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(1,2) },
            new[] { new Vector2Int(1,1), new Vector2Int(2,1), new Vector2Int(0,2), new Vector2Int(1,2) },
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(1,2) },
        },

        // 4: Z-piece  ██
        //              ██
        new Vector2Int[][]
        {
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(1,1), new Vector2Int(2,1) },
            new[] { new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(0,2) },
            new[] { new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(1,2), new Vector2Int(2,2) },
            new[] { new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(0,2) },
        },

        // 5: J-piece  █
        //             ███
        new Vector2Int[][]
        {
            new[] { new Vector2Int(0,1), new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(2,0) },
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(1,1), new Vector2Int(1,2) },
            new[] { new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(2,1), new Vector2Int(2,0) },
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(0,2), new Vector2Int(1,2) },
        },

        // 6: L-piece    █
        //             ███
        new Vector2Int[][]
        {
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(2,0), new Vector2Int(2,1) },
            new[] { new Vector2Int(1,0), new Vector2Int(1,1), new Vector2Int(1,2), new Vector2Int(0,2) },
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,1), new Vector2Int(2,1) },
            new[] { new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(0,1), new Vector2Int(0,2) },
        },
    };

    public static int ShapeCount => ShapeRotations.Length;

    /// <summary>
    /// Returns a random shape index (0–6).
    /// </summary>
    public static int GetRandomShapeIndex()
    {
        return Random.Range(0, ShapeRotations.Length);
    }

    /// <summary>
    /// Get the block offsets for a specific shape and rotation state.
    /// </summary>
    public static Vector2Int[] GetOffsets(int shapeIndex, int rotation)
    {
        return ShapeRotations[shapeIndex][rotation % 4];
    }
}
