using UnityEngine;
using TMPro;

/// <summary>
/// A floating "+123 pts" text that pops up at merge locations, then drifts upward and fades.
/// Created by MergeEffects.
/// </summary>
public class FloatingScore : MonoBehaviour
{
    private TextMeshPro textMesh;
    private float lifetime = 1.0f;
    private float elapsed = 0f;
    private Vector3 velocity;
    private Color startColor;

    public void Init(int score, Color color)
    {
        // Create TMP text
        textMesh = gameObject.AddComponent<TextMeshPro>();
        textMesh.text = $"+{score}";
        textMesh.fontSize = 3.5f;
        textMesh.fontStyle = FontStyles.Bold;
        textMesh.alignment = TextAlignmentOptions.Center;
        textMesh.sortingOrder = 50;

        startColor = color;
        textMesh.color = startColor;

        RectTransform rt = GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(3f, 1f);

        // Random upward drift
        velocity = new Vector3(Random.Range(-0.3f, 0.3f), Random.Range(1.5f, 2.5f), 0);
    }

    void Update()
    {
        elapsed += Time.deltaTime;
        float t = elapsed / lifetime;

        // Move upward
        transform.position += velocity * Time.deltaTime;
        velocity *= 0.97f; // Drag

        // Scale: pop in then shrink
        float scale = t < 0.2f
            ? Mathf.Lerp(0f, 1.2f, t / 0.2f)
            : Mathf.Lerp(1.2f, 0.5f, (t - 0.2f) / 0.8f);
        transform.localScale = new Vector3(scale, scale, 1f);

        // Fade out
        float alpha = 1f - Mathf.Pow(t, 2);
        if (textMesh != null)
            textMesh.color = new Color(startColor.r, startColor.g, startColor.b, alpha);

        if (elapsed >= lifetime)
            Destroy(gameObject);
    }
}
