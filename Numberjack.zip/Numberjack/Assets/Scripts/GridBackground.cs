using UnityEngine;

/// <summary>
/// Renders a visible dark board background with subtle grid lines.
/// Auto-created by GameManager at runtime.
/// </summary>
public class GridBackground : MonoBehaviour
{
    void Start()
    {
        int w = GridManager.Instance.width;
        int h = GridManager.Instance.height;

        // --- Board background ---
        GameObject board = new GameObject("BoardBackground");
        board.transform.position = new Vector3((w - 1) / 2f, (h - 1) / 2f, 1f); // Behind blocks (z=1)

        SpriteRenderer boardSR = board.AddComponent<SpriteRenderer>();
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        boardSR.sprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);
        boardSR.color = new Color(0.08f, 0.08f, 0.12f, 1f); // Very dark blue-grey
        boardSR.sortingOrder = -10;
        board.transform.localScale = new Vector3(w + 0.1f, h + 0.1f, 1f);

        // --- Grid lines ---
        Color lineColor = new Color(0.15f, 0.15f, 0.22f, 0.5f);

        // Vertical lines
        for (int x = 0; x <= w; x++)
        {
            CreateLine($"VLine_{x}", new Vector3(x - 0.5f, -0.5f, 0.5f),
                new Vector3(0.02f, h, 1f), lineColor);
        }

        // Horizontal lines
        for (int y = 0; y <= h; y++)
        {
            CreateLine($"HLine_{y}", new Vector3((w - 1) / 2f, y - 0.5f, 0.5f),
                new Vector3(w, 0.02f, 1f), lineColor);
        }

        // --- Board border (thicker, brighter) ---
        Color borderColor = new Color(0.3f, 0.3f, 0.45f, 0.8f);
        float borderThickness = 0.06f;

        // Left
        CreateLine("BorderLeft", new Vector3(-0.5f, (h - 1) / 2f, 0.4f),
            new Vector3(borderThickness, h + 0.1f, 1f), borderColor, -5);
        // Right
        CreateLine("BorderRight", new Vector3(w - 0.5f, (h - 1) / 2f, 0.4f),
            new Vector3(borderThickness, h + 0.1f, 1f), borderColor, -5);
        // Bottom
        CreateLine("BorderBottom", new Vector3((w - 1) / 2f, -0.5f, 0.4f),
            new Vector3(w + 0.1f, borderThickness, 1f), borderColor, -5);
        // Top
        CreateLine("BorderTop", new Vector3((w - 1) / 2f, h - 0.5f, 0.4f),
            new Vector3(w + 0.1f, borderThickness, 1f), borderColor, -5);
    }

    void CreateLine(string name, Vector3 position, Vector3 scale, Color color, int sortingOrder = -8)
    {
        GameObject line = new GameObject(name);
        line.transform.SetParent(transform);
        line.transform.position = position;
        line.transform.localScale = scale;

        SpriteRenderer sr = line.AddComponent<SpriteRenderer>();
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        sr.sprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);
        sr.color = color;
        sr.sortingOrder = sortingOrder;
    }
}
