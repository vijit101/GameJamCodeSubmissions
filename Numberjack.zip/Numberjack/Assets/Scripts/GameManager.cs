using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

public enum GameState { Playing, GameOver }

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Block Settings (optional — leave empty to auto-generate)")]
    public GameObject blockPrefab;

    [Header("Difficulty")]
    public int maxStartingValue = 8; // Pool starts with [2, 4, 8]
    private int piecesSpawned = 0;

    // Game state
    public GameState currentState = GameState.Playing;
    public int highScore = 0;

    // Next piece preview
    private int nextShapeIndex;
    private Vector2Int[] nextShapeOffsets;
    private int[] nextShapeValues;

    private bool waitingForFragments = false;

    // Cached sprite for code-generated blocks
    private Sprite blockSprite;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        blockSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);

        // Auto-attach ScreenShake to Main Camera
        Camera cam = Camera.main;
        if (cam != null && cam.GetComponent<ScreenShake>() == null)
        {
            cam.gameObject.AddComponent<ScreenShake>();
        }

        // Auto-create MergeEffects
        if (MergeEffects.Instance == null)
        {
            GameObject effectsObj = new GameObject("MergeEffects");
            effectsObj.AddComponent<MergeEffects>();
        }

        // Auto-attach GameHUD if not already present
        if (GetComponent<GameHUD>() == null)
        {
            gameObject.AddComponent<GameHUD>();
        }

        // Auto-create AudioManager
        if (AudioManager.Instance == null)
        {
            GameObject audioObj = new GameObject("AudioManager");
            audioObj.AddComponent<AudioManager>();
        }

        // Auto-create GridBackground
        if (FindAnyObjectByType<GridBackground>() == null)
        {
            GameObject bgObj = new GameObject("GridBackground");
            bgObj.AddComponent<GridBackground>();
        }

        // Set camera background to dark
        Camera cam2 = Camera.main;
        if (cam2 != null)
        {
            cam2.backgroundColor = new Color(0.04f, 0.04f, 0.06f);
        }

        // Load high score
        highScore = PlayerPrefs.GetInt("HighScore", 0);
    }

    private void Start()
    {
        // Create world-space next piece preview
        if (NextPiecePreview.Instance == null)
        {
            GameObject previewObj = new GameObject("NextPiecePreview");
            previewObj.AddComponent<NextPiecePreview>();
        }

        // Show tutorial overlay if not already present
        if (FindAnyObjectByType<TutorialOverlay>() == null)
        {
            GameObject tutorialObj = new GameObject("TutorialOverlay");
            tutorialObj.AddComponent<TutorialOverlay>();
        }

        PrepareNextPiece();
        SpawnPiece();
    }

    private void Update()
    {
        // Press R to restart at any time
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
        {
            RestartGame();
        }
    }

    // ==================== NEXT PIECE SYSTEM ====================

    private void PrepareNextPiece()
    {
        nextShapeIndex = TetrominoData.GetRandomShapeIndex();
        nextShapeOffsets = TetrominoData.GetOffsets(nextShapeIndex, 0); // Rotation 0 for preview
        nextShapeValues = new int[nextShapeOffsets.Length];

        // Build pool of possible values: [2, 4] initially, grows with difficulty
        // maxStartingValue starts at 4 so we always have [2, 4]
        int[] valuePool;
        if (maxStartingValue <= 4)
            valuePool = new int[] { 2, 4 };
        else if (maxStartingValue <= 8)
            valuePool = new int[] { 2, 4, 8 };
        else if (maxStartingValue <= 16)
            valuePool = new int[] { 2, 4, 8, 16 };
        else if (maxStartingValue <= 32)
            valuePool = new int[] { 4, 8, 16, 32 };
        else
            valuePool = new int[] { 8, 16, 32, 64 };

        // All blocks in one Tetromino share the same value (makes merging viable)
        int sharedValue = valuePool[Random.Range(0, valuePool.Length)];

        for (int i = 0; i < nextShapeValues.Length; i++)
        {
            nextShapeValues[i] = sharedValue;
        }
    }

    public Vector2Int[] GetNextShapeOffsets() => nextShapeOffsets;
    public int[] GetNextShapeValues() => nextShapeValues;

    // ==================== SPAWNING ====================

    public void SpawnPiece()
    {
        if (currentState == GameState.GameOver) return;

        piecesSpawned++;

        // Dynamic difficulty: increase possible values every 10 pieces
        if (piecesSpawned % 10 == 0 && maxStartingValue < 64)
        {
            maxStartingValue *= 2;
            Debug.Log($"HEAT UP! Blocks can now spawn with values up to {maxStartingValue}");
        }

        // Use the pre-generated next piece
        int spawnShapeIndex = nextShapeIndex;
        Vector2Int[] shapeOffsets = nextShapeOffsets;
        int[] shapeValues = nextShapeValues;

        // Prepare the NEXT next piece for the preview
        PrepareNextPiece();

        Vector3 spawnPos = new Vector3(4, 18, 0);

        // --- GAME OVER CHECK ---
        // Before spawning, check if the spawn position is blocked
        foreach (Vector2Int offset in shapeOffsets)
        {
            int x = Mathf.RoundToInt(spawnPos.x) + offset.x;
            int y = Mathf.RoundToInt(spawnPos.y) + offset.y;

            if (GridManager.Instance.IsWithinBounds(x, y) && !GridManager.Instance.IsCellEmpty(x, y))
            {
                GameOver();
                return;
            }
        }

        // Create Tetromino
        GameObject tetrominoObj = new GameObject("Tetromino");
        tetrominoObj.transform.position = spawnPos;
        Tetromino tetromino = tetrominoObj.AddComponent<Tetromino>();
        tetromino.shapeIndex = spawnShapeIndex; // Tell it which shape for rotation lookup

        for (int i = 0; i < shapeOffsets.Length; i++)
        {
            GameObject blockObj;

            if (blockPrefab != null)
            {
                blockObj = Instantiate(blockPrefab, tetrominoObj.transform);
            }
            else
            {
                blockObj = new GameObject("Block");
                blockObj.transform.SetParent(tetrominoObj.transform);

                SpriteRenderer sr = blockObj.AddComponent<SpriteRenderer>();
                sr.sprite = blockSprite;
                sr.sortingOrder = 1;

                blockObj.transform.localScale = new Vector3(0.92f, 0.92f, 1f);
            }

            blockObj.transform.localPosition = new Vector3(shapeOffsets[i].x, shapeOffsets[i].y, 0);

            Block block = blockObj.GetComponent<Block>();
            if (block == null) block = blockObj.AddComponent<Block>();

            block.SetValue(shapeValues[i]);
        }

        // Binary Bomb: ~12% chance to turn one random block into a bomb
        if (Random.value < 0.12f)
        {
            int bombIndex = Random.Range(0, shapeOffsets.Length);
            Block bombBlock = tetrominoObj.transform.GetChild(bombIndex).GetComponent<Block>();
            if (bombBlock != null)
            {
                bombBlock.SetAsBinaryBomb();
                Debug.Log("💣 Binary Bomb spawned!");
            }
        }

        // Ghost piece preview
        tetrominoObj.AddComponent<GhostPiece>();

        // Update next piece preview display
        if (NextPiecePreview.Instance != null)
            NextPiecePreview.Instance.UpdatePreview(nextShapeOffsets, nextShapeValues);

        waitingForFragments = false;
    }

    // ==================== GAME FLOW ====================

    public void OnTetrominoLanded(bool hasFragments)
    {
        if (hasFragments)
        {
            waitingForFragments = true;
        }
        else
        {
            SpawnPiece();
        }
    }

    public void OnAllFragmentsSettled()
    {
        if (waitingForFragments)
        {
            waitingForFragments = false;
            SpawnPiece();
        }
    }

    // ==================== GAME OVER ====================

    private void GameOver()
    {
        currentState = GameState.GameOver;

        // Save high score
        if (GridManager.Instance.totalScore > highScore)
        {
            highScore = GridManager.Instance.totalScore;
            PlayerPrefs.SetInt("HighScore", highScore);
            PlayerPrefs.Save();
        }

        if (AudioManager.Instance != null) AudioManager.Instance.PlayGameOver();

        Debug.Log($"GAME OVER! Final Score: {GridManager.Instance.totalScore} | High Score: {highScore}");
    }

    public void RestartGame()
    {
        // Clear the grid visually
        for (int x = 0; x < GridManager.Instance.width; x++)
        {
            for (int y = 0; y < GridManager.Instance.height; y++)
            {
                if (GridManager.Instance.grid[x, y] != null)
                {
                    Destroy(GridManager.Instance.grid[x, y].gameObject);
                    GridManager.Instance.grid[x, y] = null;
                }
            }
        }

        // Destroy any active tetrominos and fragments
        foreach (Tetromino t in FindObjectsByType<Tetromino>(FindObjectsSortMode.None))
            Destroy(t.gameObject);
        foreach (Fragment f in FindObjectsByType<Fragment>(FindObjectsSortMode.None))
            Destroy(f.gameObject);
        foreach (GhostPiece g in FindObjectsByType<GhostPiece>(FindObjectsSortMode.None))
        {
            if (g.gameObject != null) Destroy(g.gameObject);
        }

        // Reset state
        GridManager.Instance.totalScore = 0;
        GridManager.Instance.currentCombo = 0;
        GridManager.Instance.grid = new Transform[GridManager.Instance.width, GridManager.Instance.height];

        currentState = GameState.Playing;
        piecesSpawned = 0;
        maxStartingValue = 2;
        waitingForFragments = false;

        PrepareNextPiece();
        SpawnPiece();
    }
}
