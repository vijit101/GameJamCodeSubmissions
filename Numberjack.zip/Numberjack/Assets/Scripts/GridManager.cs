using UnityEngine;
using System.Collections.Generic;

public class GridManager : MonoBehaviour
{
    public static GridManager Instance { get; private set; }

    public int width = 10;
    public int height = 20;

    public Transform[,] grid;

    private List<Fragment> activeFragments = new List<Fragment>();

    [HideInInspector] public int currentCombo = 0;
    [HideInInspector] public int totalScore = 0;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        grid = new Transform[width, height];
    }

    // ==================== GRID QUERIES ====================

    public bool IsWithinBounds(int x, int y)
    {
        return x >= 0 && x < width && y >= 0 && y < height;
    }

    public bool IsCellEmpty(int x, int y)
    {
        if (!IsWithinBounds(x, y)) return false;
        return grid[x, y] == null;
    }

    public void AddBlockToGrid(int x, int y, Transform blockTransform)
    {
        if (IsWithinBounds(x, y))
        {
            grid[x, y] = blockTransform;
        }
    }

    // ==================== BINARY BOMB ====================

    /// <summary>
    /// Triggers a Binary Bomb at (x, y): doubles all 4 orthogonally adjacent blocks.
    /// The bomb block itself is destroyed after detonation.
    /// </summary>
    public void TriggerBinaryBomb(int x, int y)
    {
        Debug.Log($"💣 BINARY BOMB at ({x}, {y})! Doubling blocks within distance 2!");

        // All blocks within Euler distance <= 2
        for (int dx = -2; dx <= 2; dx++)
        {
            for (int dy = -2; dy <= 2; dy++)
            {
                // Skip the bomb itself
                if (dx == 0 && dy == 0) continue;

                // Check distance using Manhattan or simple square bounds?
                // The prompt asked for "euler distance <= 2" which usually means Euclidean (or Chebyshev).
                // If it's literally Euclidean distance <= 2, then dx*dx + dy*dy <= 4.
                if (dx * dx + dy * dy > 4) continue;

                int nx = x + dx;
                int ny = y + dy;

            if (IsWithinBounds(nx, ny) && !IsCellEmpty(nx, ny))
            {
                Block neighborBlock = grid[nx, ny].GetComponent<Block>();
                if (neighborBlock != null && !neighborBlock.isBinaryBomb)
                {
                    int oldVal = neighborBlock.value;
                    neighborBlock.SetValue(oldVal * 2);
                    Debug.Log($"  Doubled ({nx},{ny}): {oldVal} → {neighborBlock.value}");

                    // Play effect on each doubled block
                    if (MergeEffects.Instance != null)
                        MergeEffects.Instance.PlayMergeEffect(
                            grid[nx, ny].position, neighborBlock.value, 2);
                }
            }
            }
        }

        // Destroy the bomb block itself
        if (IsWithinBounds(x, y) && !IsCellEmpty(x, y))
        {
            Destroy(grid[x, y].gameObject);
            grid[x, y] = null;
        }

        // Play big explosion effect at bomb position
        if (MergeEffects.Instance != null)
            MergeEffects.Instance.PlayMergeEffect(new Vector3(x, y, 0), 2048, 5);

        if (ScreenShake.Instance != null)
            ScreenShake.Instance.Shake(0.35f, 0.3f);

        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayBomb();

        // Stabilize affected columns
        for (int dx = -2; dx <= 2; dx++)
        {
            int col = x + dx;
            if (col >= 0 && col < width)
                StabilizeColumn(col);
        }
    }

    // ==================== CASCADE SYSTEM ====================

    /// <summary>
    /// Iteratively applies gravity and vertical merges until the column is fully stable.
    /// </summary>
    public void StabilizeColumn(int x)
    {
        bool changed = true;
        while (changed)
        {
            changed = false;

            // Step 1: Full gravity
            bool gravityActive = true;
            while (gravityActive)
            {
                gravityActive = false;
                for (int y = 0; y < height - 1; y++)
                {
                    if (grid[x, y] == null && grid[x, y + 1] != null)
                    {
                        grid[x, y] = grid[x, y + 1];
                        grid[x, y + 1] = null;
                        grid[x, y].position = new Vector3(x, y, 0);
                        gravityActive = true;
                    }
                }
            }

            // Step 2: Check for vertical merges bottom-to-top
            for (int y = 0; y < height - 1; y++)
            {
                if (grid[x, y] == null || grid[x, y + 1] == null) continue;

                Block lower = grid[x, y].GetComponent<Block>();
                Block upper = grid[x, y + 1].GetComponent<Block>();

                if (lower != null && upper != null && lower.value == upper.value)
                {
                    currentCombo++;
                    int mergedValue = lower.value * 2;
                    int score = mergedValue * (currentCombo * currentCombo);
                    totalScore += score;

                    Debug.Log($"CASCADE x{currentCombo}! {lower.value}+{upper.value}={mergedValue} | +{score} pts (Total: {totalScore})");

                    // Play cascade effects!
                    if (MergeEffects.Instance != null)
                        MergeEffects.Instance.PlayMergeEffect(
                            grid[x, y + 1].position, mergedValue, currentCombo);

                    lower.SetValue(mergedValue);
                    Destroy(grid[x, y + 1].gameObject);
                    grid[x, y + 1] = null;

                    changed = true;
                    break;
                }
            }
        }
    }

    public void StabilizeColumns(HashSet<int> columns)
    {
        foreach (int x in columns)
        {
            StabilizeColumn(x);
        }
    }

    // ==================== ROW CLEARING ====================

    public void CheckAndClearRows()
    {
        for (int y = height - 1; y >= 0; y--)
        {
            if (IsRowFullAndUniform(y))
            {
                int rowValue = grid[0, y].GetComponent<Block>().value;
                int rowScore = rowValue * width * 10;
                totalScore += rowScore;

                Debug.Log($"ROW CLEAR at y={y}! All {rowValue}s! +{rowScore} pts");

                // Play row clear effect!
                if (MergeEffects.Instance != null)
                    MergeEffects.Instance.PlayRowClearEffect(y, width);

                ClearRow(y);
                ShiftRowsDown(y);
                y++;
            }
        }
    }

    private bool IsRowFullAndUniform(int y)
    {
        if (!IsWithinBounds(0, y)) return false;

        int firstValue = -1;
        for (int x = 0; x < width; x++)
        {
            if (grid[x, y] == null) return false;

            Block block = grid[x, y].GetComponent<Block>();
            if (block == null) return false;

            if (firstValue == -1)
                firstValue = block.value;
            else if (block.value != firstValue)
                return false;
        }
        return true;
    }

    private void ClearRow(int y)
    {
        for (int x = 0; x < width; x++)
        {
            if (grid[x, y] != null)
            {
                Destroy(grid[x, y].gameObject);
                grid[x, y] = null;
            }
        }
    }

    private void ShiftRowsDown(int clearedY)
    {
        for (int y = clearedY; y < height - 1; y++)
        {
            for (int x = 0; x < width; x++)
            {
                grid[x, y] = grid[x, y + 1];
                grid[x, y + 1] = null;

                if (grid[x, y] != null)
                {
                    grid[x, y].position = new Vector3(x, y, 0);
                }
            }
        }
    }

    // ==================== FRAGMENT TRACKING ====================

    public void RegisterFragment(Fragment f)
    {
        if (!activeFragments.Contains(f))
            activeFragments.Add(f);
    }

    public void UnregisterFragment(Fragment f)
    {
        activeFragments.Remove(f);

        if (activeFragments.Count == 0)
        {
            CheckAndClearRows();
            GameManager.Instance.OnAllFragmentsSettled();
        }
    }

    public bool HasActiveFragments()
    {
        activeFragments.RemoveAll(f => f == null);
        return activeFragments.Count > 0;
    }

    public void ResetCombo()
    {
        currentCombo = 0;
    }

    // ==================== EDITOR GIZMOS ====================

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.white;
        for (int x = 0; x <= width; x++)
        {
            Gizmos.DrawLine(new Vector3(x - 0.5f, -0.5f, 0), new Vector3(x - 0.5f, height - 0.5f, 0));
        }
        for (int y = 0; y <= height; y++)
        {
            Gizmos.DrawLine(new Vector3(-0.5f, y - 0.5f, 0), new Vector3(width - 0.5f, y - 0.5f, 0));
        }
    }
}
