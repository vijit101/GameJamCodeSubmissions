using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

public class Tetromino : MonoBehaviour
{
    public float fallTime = 0.8f;
    private float previousTime;

    // Rotation state (not Unity rotation — explicit position swaps)
    [HideInInspector] public int shapeIndex = 0;
    private int currentRotation = 0;
    private List<Transform> blockChildren = new List<Transform>();

    void Start()
    {
        // Cache only Block children (ignore text objects etc.)
        foreach (Transform child in transform)
        {
            if (child.GetComponent<Block>() != null)
                blockChildren.Add(child);
        }
    }

    void Update()
    {
        if (GameManager.Instance.currentState == GameState.GameOver) return;
        if (Time.timeScale == 0f) return; // Paused by tutorial
        if (Keyboard.current == null) return;

        // --- LATERAL MOVEMENT ---
        if (Keyboard.current.leftArrowKey.wasPressedThisFrame)
        {
            Move(Vector3.left);
        }
        else if (Keyboard.current.rightArrowKey.wasPressedThisFrame)
        {
            Move(Vector3.right);
        }
        else if (Keyboard.current.upArrowKey.wasPressedThisFrame)
        {
            // ROTATION — swap to next rotation state
            TryRotate();
        }
        else if (Keyboard.current.spaceKey.wasPressedThisFrame)
        {
            HardDrop();
            return;
        }

        // --- GRAVITY ---
        bool isFastDropping = Keyboard.current.downArrowKey.isPressed;

        if (Time.time - previousTime > (isFastDropping ? fallTime / 10f : fallTime))
        {
            Move(Vector3.down);
            previousTime = Time.time;
        }
    }

    // ==================== MOVEMENT ====================

    void Move(Vector3 direction)
    {
        transform.position += direction;
        bool valid = IsValidGridPos();
        if (valid && (direction == Vector3.left || direction == Vector3.right))
        {
            if (AudioManager.Instance != null) AudioManager.Instance.PlayMove();
        }
        if (!valid)
        {
            transform.position -= direction;

            // If we failed to move DOWN, the piece has landed
            if (direction == Vector3.down)
            {
                ProcessMergeAndLock();
                this.enabled = false;
            }
        }
    }

    // ==================== ROTATION ====================

    void TryRotate()
    {
        int nextRotation = (currentRotation + 1) % 4;
        Vector2Int[] newOffsets = TetrominoData.GetOffsets(shapeIndex, nextRotation);

        // Save current positions in case we need to revert
        Vector3[] oldPositions = new Vector3[blockChildren.Count];
        for (int i = 0; i < blockChildren.Count; i++)
        {
            if (blockChildren[i] != null)
                oldPositions[i] = blockChildren[i].localPosition;
        }

        // Apply new rotation
        ApplyRotation(newOffsets);

        // Check if the new rotation is valid
        if (IsValidGridPos())
        {
            currentRotation = nextRotation;
            if (AudioManager.Instance != null) AudioManager.Instance.PlayMove();
        }
        else
        {
            // Try wall kicks: shift left, right, up
            Vector3[] kicks = new Vector3[]
            {
                new Vector3(1, 0, 0),
                new Vector3(-1, 0, 0),
                new Vector3(0, 1, 0),
                new Vector3(2, 0, 0),
                new Vector3(-2, 0, 0),
            };

            bool kicked = false;
            foreach (Vector3 kick in kicks)
            {
                transform.position += kick;
                if (IsValidGridPos())
                {
                    currentRotation = nextRotation;
                    kicked = true;
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayMove();
                    break;
                }
                transform.position -= kick;
            }

            // If no kick worked, revert to old positions
            if (!kicked)
            {
                for (int i = 0; i < blockChildren.Count; i++)
                {
                    if (blockChildren[i] != null)
                        blockChildren[i].localPosition = oldPositions[i];
                }
            }
        }
    }

    void ApplyRotation(Vector2Int[] offsets)
    {
        for (int i = 0; i < blockChildren.Count && i < offsets.Length; i++)
        {
            if (blockChildren[i] != null)
                blockChildren[i].localPosition = new Vector3(offsets[i].x, offsets[i].y, 0);
        }
    }

    // ==================== HARD DROP ====================

    void HardDrop()
    {
        if (AudioManager.Instance != null) AudioManager.Instance.PlayDrop();
        while (true)
        {
            transform.position += new Vector3(0, -1, 0);
            if (!IsValidGridPos())
            {
                transform.position -= new Vector3(0, -1, 0);
                break;
            }
        }

        ProcessMergeAndLock();
        this.enabled = false;
    }

    // ==================== VALIDATION ====================

    bool IsValidGridPos()
    {
        foreach (Transform child in blockChildren)
        {
            if (child == null) continue;

            int x = Mathf.RoundToInt(child.position.x);
            int y = Mathf.RoundToInt(child.position.y);

            if (!GridManager.Instance.IsWithinBounds(x, y)) return false;
            if (!GridManager.Instance.IsCellEmpty(x, y)) return false;
        }
        return true;
    }

    // ==================== MERGE & LOCK ====================

    void ProcessMergeAndLock()
    {
        GridManager.Instance.ResetCombo();

        List<Transform> children = new List<Transform>(blockChildren);
        children.Sort((a, b) => Mathf.RoundToInt(a.position.y).CompareTo(Mathf.RoundToInt(b.position.y)));

        HashSet<Transform> mergedBlocks = new HashSet<Transform>();
        HashSet<Transform> lockedBlocks = new HashSet<Transform>();
        HashSet<int> affectedColumns = new HashSet<int>();

        // --- PASS 1: Merges and supported locks ---
        foreach (Transform child in children)
        {
            if (child == null) continue;

            int x = Mathf.RoundToInt(child.position.x);
            int y = Mathf.RoundToInt(child.position.y);
            int belowY = y - 1;

            Block myBlock = child.GetComponent<Block>();

            // Try to merge with grid block below
            if (GridManager.Instance.IsWithinBounds(x, belowY) && !GridManager.Instance.IsCellEmpty(x, belowY))
            {
                Transform gridBlockTransform = GridManager.Instance.grid[x, belowY];
                if (gridBlockTransform != null && !children.Contains(gridBlockTransform))
                {
                    Block gridBlock = gridBlockTransform.GetComponent<Block>();
                    if (gridBlock != null && myBlock != null
                        && !myBlock.isBinaryBomb && !gridBlock.isBinaryBomb
                        && gridBlock.value == myBlock.value && myBlock.value > 0)
                    {
                        GridManager.Instance.currentCombo++;
                        int mergedValue = gridBlock.value * 2;
                        int score = mergedValue * (GridManager.Instance.currentCombo * GridManager.Instance.currentCombo);
                        GridManager.Instance.totalScore += score;

                        Debug.Log($"MERGE! {myBlock.value}+{gridBlock.value}={mergedValue} | +{score} pts");

                        gridBlock.SetValue(mergedValue);
                        mergedBlocks.Add(child);

                        if (MergeEffects.Instance != null)
                            MergeEffects.Instance.PlayMergeEffect(child.position, mergedValue, GridManager.Instance.currentCombo);

                        Destroy(child.gameObject);
                        affectedColumns.Add(x);
                        continue;
                    }
                }
            }

            // Check support
            bool isSupported = (y == 0)
                || (GridManager.Instance.IsWithinBounds(x, belowY) && !GridManager.Instance.IsCellEmpty(x, belowY));

            if (!isSupported)
            {
                foreach (Transform locked in lockedBlocks)
                {
                    if (locked == null) continue;
                    int lx = Mathf.RoundToInt(locked.position.x);
                    int ly = Mathf.RoundToInt(locked.position.y);
                    if (lx == x && ly == belowY)
                    {
                        isSupported = true;
                        break;
                    }
                }
            }

            if (isSupported)
            {
                child.parent = null;
                GridManager.Instance.AddBlockToGrid(x, y, child);
                lockedBlocks.Add(child);
                affectedColumns.Add(x);
            }
        }

        // --- PASS 2: Unsupported → Fragments ---
        bool hasFragments = false;
        foreach (Transform child in children)
        {
            if (child == null) continue;
            if (mergedBlocks.Contains(child)) continue;
            if (lockedBlocks.Contains(child)) continue;

            child.parent = null;
            child.gameObject.AddComponent<Fragment>();
            hasFragments = true;
        }

        // --- PASS 3: Trigger Binary Bombs ---
        List<Vector2Int> bombPositions = new List<Vector2Int>();
        foreach (Transform locked in lockedBlocks)
        {
            if (locked == null) continue;
            Block b = locked.GetComponent<Block>();
            if (b != null && b.isBinaryBomb)
            {
                int bx = Mathf.RoundToInt(locked.position.x);
                int by = Mathf.RoundToInt(locked.position.y);
                bombPositions.Add(new Vector2Int(bx, by));
            }
        }
        foreach (Vector2Int pos in bombPositions)
        {
            GridManager.Instance.TriggerBinaryBomb(pos.x, pos.y);
            affectedColumns.Add(pos.x);
        }

        // --- PASS 4: Cascade affected columns ---
        GridManager.Instance.StabilizeColumns(affectedColumns);

        if (!hasFragments)
        {
            GridManager.Instance.CheckAndClearRows();
        }

        GameManager.Instance.OnTetrominoLanded(hasFragments);
    }
}
