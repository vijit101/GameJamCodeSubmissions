using UnityEngine;

/// <summary>
/// Applies a shake effect to the camera on cascade merges.
/// Automatically attached to the Main Camera by GameManager.
/// </summary>
public class ScreenShake : MonoBehaviour
{
    public static ScreenShake Instance { get; private set; }

    private Vector3 originalPosition;
    private float shakeDuration = 0f;
    private float shakeIntensity = 0f;

    void Awake()
    {
        Instance = this;
        originalPosition = transform.localPosition;
    }

    void Update()
    {
        if (shakeDuration > 0)
        {
            transform.localPosition = originalPosition + (Vector3)Random.insideUnitCircle * shakeIntensity;
            shakeDuration -= Time.deltaTime;

            // Fade out intensity
            shakeIntensity *= 0.9f;
        }
        else
        {
            transform.localPosition = originalPosition;
        }
    }

    /// <summary>
    /// Trigger a camera shake.
    /// </summary>
    /// <param name="intensity">How far the camera moves (0.1 = subtle, 0.5 = heavy)</param>
    /// <param name="duration">How long the shake lasts in seconds</param>
    public void Shake(float intensity, float duration)
    {
        shakeIntensity = intensity;
        shakeDuration = duration;
    }
}
