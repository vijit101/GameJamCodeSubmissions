using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Full game HUD: Score, Combo flash, Next Piece preview, animated Game Over popup.
/// Uses OnGUI — no Canvas setup needed.
/// </summary>
public class GameHUD : MonoBehaviour
{
    // Styles
    private GUIStyle scoreStyle;
    private GUIStyle scoreLabelStyle;
    private GUIStyle comboStyle;
    private GUIStyle highScoreStyle;
    private GUIStyle controlsStyle;

    private float comboFadeTimer = 0f;
    private int lastCombo = 0;
    private int lastDisplayedCombo = 0;

    // Game Over animation
    private float gameOverTimer = 0f;
    private bool wasGameOver = false;

    // Cached texture
    private Texture2D blockTexture;

    void Start()
    {
        blockTexture = new Texture2D(1, 1);
        blockTexture.SetPixel(0, 0, Color.white);
        blockTexture.Apply();

        scoreStyle = new GUIStyle();
        scoreStyle.fontSize = 54;
        scoreStyle.fontStyle = FontStyle.Bold;
        scoreStyle.normal.textColor = Color.white;

        scoreLabelStyle = new GUIStyle();
        scoreLabelStyle.fontSize = 24;
        scoreLabelStyle.normal.textColor = new Color(0.6f, 0.6f, 0.6f);

        comboStyle = new GUIStyle();
        comboStyle.fontSize = 52;
        comboStyle.fontStyle = FontStyle.Bold;
        comboStyle.alignment = TextAnchor.MiddleCenter;

        highScoreStyle = new GUIStyle();
        highScoreStyle.fontSize = 24;
        highScoreStyle.normal.textColor = new Color(0.93f, 0.75f, 0.18f);

        controlsStyle = new GUIStyle();
        controlsStyle.fontSize = 18;
        controlsStyle.normal.textColor = new Color(0.5f, 0.5f, 0.5f);
        controlsStyle.alignment = TextAnchor.UpperLeft;
    }

    void Update()
    {
        // Combo tracking
        if (GridManager.Instance.currentCombo > lastCombo && GridManager.Instance.currentCombo > 0)
        {
            comboFadeTimer = 2.0f;
            lastDisplayedCombo = GridManager.Instance.currentCombo;
        }
        lastCombo = GridManager.Instance.currentCombo;

        if (comboFadeTimer > 0)
            comboFadeTimer -= Time.deltaTime;

        // Game Over animation timer
        if (GameManager.Instance.currentState == GameState.GameOver)
        {
            if (!wasGameOver)
            {
                gameOverTimer = 0f; // Reset animation on first frame of game over
                wasGameOver = true;
            }
            gameOverTimer += Time.deltaTime;
        }
        else
        {
            wasGameOver = false;
            gameOverTimer = 0f;
        }
    }

    void OnGUI()
    {
        DrawScore();
        DrawCombo();
        DrawControls();

        if (GameManager.Instance.currentState == GameState.GameOver)
        {
            DrawGameOverPopup();
        }
    }

    // ==================== SCORE ====================

    void DrawScore()
    {
        GUI.Label(new Rect(30, 20, 200, 30), "SCORE", scoreLabelStyle);
        GUI.Label(new Rect(30, 50, 400, 70), GridManager.Instance.totalScore.ToString("N0"), scoreStyle);
        GUI.Label(new Rect(30, 120, 400, 40), $"BEST: {GameManager.Instance.highScore:N0}", highScoreStyle);
    }

    // ==================== COMBO FLASH ====================

    void DrawCombo()
    {
        if (comboFadeTimer > 0 && lastDisplayedCombo > 0)
        {
            float alpha = Mathf.Clamp01(comboFadeTimer / 0.5f);
            comboStyle.normal.textColor = new Color(1f, Mathf.Max(0.2f, 0.9f - lastDisplayedCombo * 0.1f), 0.2f, alpha);
            comboStyle.fontSize = 52 + lastDisplayedCombo * 6;

            float cx = Screen.width / 2f - 200;
            float cy = Screen.height / 2f - 60;
            GUI.Label(new Rect(cx, cy, 400, 80), $"x{lastDisplayedCombo} COMBO!", comboStyle);
        }
    }

    // ==================== NEXT PIECE PREVIEW ====================

    void DrawNextPiecePreview()
    {
        Vector2Int[] nextShape = GameManager.Instance.GetNextShapeOffsets();
        int[] nextValues = GameManager.Instance.GetNextShapeValues();

        if (nextShape == null || nextValues == null) return;

        float previewX = Screen.width - 150;
        float previewY = 15;

        GUI.Label(new Rect(previewX, previewY, 120, 20), "NEXT", scoreLabelStyle);
        previewY += 25;

        float blockSize = 28;

        for (int i = 0; i < nextShape.Length; i++)
        {
            float bx = previewX + nextShape[i].x * blockSize;
            float by = previewY + (2 - nextShape[i].y) * blockSize;

            Color blockColor = GetColorForValue(nextValues[i]);

            GUI.color = blockColor;
            GUI.DrawTexture(new Rect(bx, by, blockSize - 2, blockSize - 2), blockTexture);
            GUI.color = Color.white;

            GUIStyle valStyle = new GUIStyle();
            valStyle.fontSize = 11;
            valStyle.fontStyle = FontStyle.Bold;
            valStyle.normal.textColor = nextValues[i] >= 64 ? Color.white : Color.black;
            valStyle.alignment = TextAnchor.MiddleCenter;
            GUI.Label(new Rect(bx, by, blockSize - 2, blockSize - 2), nextValues[i].ToString(), valStyle);
        }
    }

    // ==================== CONTROLS HELP ====================

    void DrawControls()
    {
        float y = 170; // Positioned right under the score/high score block
        string controls = "← → Move\n↑ Rotate\n↓ Soft Drop\nSpace Hard Drop\nR Restart";
        GUI.Label(new Rect(30, y, 300, 200), controls, controlsStyle);
    }

    // ==================== ANIMATED GAME OVER POPUP ====================

    void DrawGameOverPopup()
    {
        // --- Animate scale: grows from 0 to 1 with overshoot (elastic ease) ---
        float t = Mathf.Clamp01(gameOverTimer / 0.6f); // 0.6 second animation
        // Elastic ease out
        float scale;
        if (t < 1f)
        {
            float p = 0.4f;
            scale = Mathf.Pow(2, -10 * t) * Mathf.Sin((t - p / 4f) * (2f * Mathf.PI) / p) + 1f;
        }
        else
        {
            scale = 1f;
        }

        // --- Dark overlay fades in ---
        float overlayAlpha = Mathf.Clamp01(gameOverTimer / 0.4f) * 0.75f;
        GUI.color = new Color(0, 0, 0, overlayAlpha);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), blockTexture);
        GUI.color = Color.white;

        // --- Popup panel ---
        float panelWidth = 420 * scale;
        float panelHeight = 300 * scale;
        float panelX = (Screen.width - panelWidth) / 2f;
        float panelY = (Screen.height - panelHeight) / 2f;

        // Panel background
        GUI.color = new Color(0.12f, 0.11f, 0.13f, 0.95f);
        GUI.DrawTexture(new Rect(panelX, panelY, panelWidth, panelHeight), blockTexture);

        // Red accent bar at top
        GUI.color = new Color(0.96f, 0.37f, 0.23f, 1f);
        GUI.DrawTexture(new Rect(panelX, panelY, panelWidth, 6 * scale), blockTexture);
        GUI.color = Color.white;

        if (scale < 0.3f) return; // Don't draw text until panel is visible enough

        // --- GAME OVER title ---
        GUIStyle titleStyle = new GUIStyle();
        titleStyle.fontSize = (int)(48 * scale);
        titleStyle.fontStyle = FontStyle.Bold;
        titleStyle.normal.textColor = new Color(0.96f, 0.37f, 0.23f);
        titleStyle.alignment = TextAnchor.MiddleCenter;
        GUI.Label(new Rect(panelX, panelY + 20 * scale, panelWidth, 60 * scale), "GAME OVER", titleStyle);

        // --- Final Score ---
        GUIStyle scoreInfoStyle = new GUIStyle();
        scoreInfoStyle.fontSize = (int)(28 * scale);
        scoreInfoStyle.fontStyle = FontStyle.Bold;
        scoreInfoStyle.normal.textColor = Color.white;
        scoreInfoStyle.alignment = TextAnchor.MiddleCenter;
        GUI.Label(new Rect(panelX, panelY + 90 * scale, panelWidth, 40 * scale),
            $"{GridManager.Instance.totalScore:N0}", scoreInfoStyle);

        // --- Score label ---
        GUIStyle scoreLbl = new GUIStyle();
        scoreLbl.fontSize = (int)(14 * scale);
        scoreLbl.normal.textColor = new Color(0.6f, 0.6f, 0.6f);
        scoreLbl.alignment = TextAnchor.MiddleCenter;
        GUI.Label(new Rect(panelX, panelY + 125 * scale, panelWidth, 20 * scale), "FINAL SCORE", scoreLbl);

        // --- NEW HIGH SCORE banner ---
        if (GridManager.Instance.totalScore >= GameManager.Instance.highScore && GameManager.Instance.highScore > 0)
        {
            float starPulse = Mathf.Sin(Time.time * 4f) * 0.15f + 0.85f;
            GUIStyle highStyle = new GUIStyle();
            highStyle.fontSize = (int)(18 * scale);
            highStyle.fontStyle = FontStyle.Bold;
            highStyle.normal.textColor = new Color(0.93f, 0.75f, 0.18f, starPulse);
            highStyle.alignment = TextAnchor.MiddleCenter;
            GUI.Label(new Rect(panelX, panelY + 155 * scale, panelWidth, 25 * scale), "★ NEW HIGH SCORE! ★", highStyle);
        }

        // --- Restart prompt (pulsing) ---
        float pulse = Mathf.Sin(Time.time * 3f) * 0.3f + 0.7f;
        GUIStyle restartStyle = new GUIStyle();
        restartStyle.fontSize = (int)(20 * scale);
        restartStyle.normal.textColor = new Color(1f, 1f, 1f, pulse);
        restartStyle.alignment = TextAnchor.MiddleCenter;
        GUI.Label(new Rect(panelX, panelY + 220 * scale, panelWidth, 30 * scale), "Press R to Restart", restartStyle);

        // --- Decorative bottom bar ---
        GUI.color = new Color(0.96f, 0.37f, 0.23f, 0.5f);
        GUI.DrawTexture(new Rect(panelX, panelY + panelHeight - 4 * scale, panelWidth, 4 * scale), blockTexture);
        GUI.color = Color.white;
    }

    // ==================== HELPERS ====================

    private Color GetColorForValue(int value)
    {
        switch (value)
        {
            case 2:    return new Color(0.93f, 0.89f, 0.85f);
            case 4:    return new Color(0.93f, 0.88f, 0.78f);
            case 8:    return new Color(0.95f, 0.69f, 0.47f);
            case 16:   return new Color(0.96f, 0.58f, 0.39f);
            case 32:   return new Color(0.96f, 0.49f, 0.37f);
            case 64:   return new Color(0.96f, 0.37f, 0.23f);
            case 128:  return new Color(0.93f, 0.81f, 0.45f);
            case 256:  return new Color(0.93f, 0.80f, 0.38f);
            case 512:  return new Color(0.93f, 0.78f, 0.31f);
            case 1024: return new Color(0.93f, 0.77f, 0.25f);
            case 2048: return new Color(0.93f, 0.75f, 0.18f);
            default:   return new Color(0.24f, 0.23f, 0.20f);
        }
    }
}
