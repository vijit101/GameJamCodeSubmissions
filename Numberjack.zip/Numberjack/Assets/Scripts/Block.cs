using UnityEngine;
using TMPro;

public class Block : MonoBehaviour
{
    public int value = 2;
    public bool isBinaryBomb = false; // Power-up!

    private TMP_Text textMesh;
    private SpriteRenderer spriteRenderer;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        textMesh = GetComponentInChildren<TMP_Text>();

        if (textMesh == null)
        {
            GameObject textObj = new GameObject("ValueText");
            textObj.transform.SetParent(transform, false);
            textObj.transform.localPosition = new Vector3(0, 0, -1f);

            TextMeshPro tmp = textObj.AddComponent<TextMeshPro>();
            tmp.text = value.ToString();
            tmp.fontSize = 4f;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.sortingOrder = 10;
            tmp.color = Color.black;

            RectTransform rt = textObj.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(1f, 1f);

            textMesh = tmp;
        }

        UpdateVisuals();
    }

    public void SetValue(int newValue)
    {
        value = newValue;
        UpdateVisuals();
    }

    public void SetAsBinaryBomb()
    {
        isBinaryBomb = true;
        value = 0; // Bombs don't have a merge value
        UpdateVisuals();
    }

    public void UpdateVisuals()
    {
        if (isBinaryBomb)
        {
            // Binary Bomb: dark purple with red "X"
            if (spriteRenderer != null)
                spriteRenderer.color = new Color(0.3f, 0.1f, 0.35f); // Dark purple

            if (textMesh != null)
            {
                textMesh.text = "X";
                textMesh.fontSize = 6f;
                textMesh.color = new Color(1f, 0.2f, 0.2f); // Bright red X
            }
            return;
        }

        if (textMesh != null)
        {
            textMesh.text = value.ToString();
            textMesh.fontSize = 4f;

            if (value >= 64)
                textMesh.color = Color.white;
            else
                textMesh.color = new Color(0.12f, 0.11f, 0.10f);
        }

        if (spriteRenderer != null)
        {
            Color blockColor;
            switch (value)
            {
                case 2:    blockColor = new Color(0.93f, 0.89f, 0.85f); break;
                case 4:    blockColor = new Color(0.93f, 0.88f, 0.78f); break;
                case 8:    blockColor = new Color(0.95f, 0.69f, 0.47f); break;
                case 16:   blockColor = new Color(0.96f, 0.58f, 0.39f); break;
                case 32:   blockColor = new Color(0.96f, 0.49f, 0.37f); break;
                case 64:   blockColor = new Color(0.96f, 0.37f, 0.23f); break;
                case 128:  blockColor = new Color(0.93f, 0.81f, 0.45f); break;
                case 256:  blockColor = new Color(0.93f, 0.80f, 0.38f); break;
                case 512:  blockColor = new Color(0.93f, 0.78f, 0.31f); break;
                case 1024: blockColor = new Color(0.93f, 0.77f, 0.25f); break;
                case 2048: blockColor = new Color(0.93f, 0.75f, 0.18f); break;
                default:   blockColor = new Color(0.24f, 0.23f, 0.20f); break;
            }
            spriteRenderer.color = blockColor;
        }
    }
}
