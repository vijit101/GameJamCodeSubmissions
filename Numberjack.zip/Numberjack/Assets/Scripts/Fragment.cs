using UnityEngine;

/// <summary>
/// A Fragment is a single block that has detached from its Tetromino after a partial merge.
/// It falls independently until it hits a surface or merges with a matching block below.
/// </summary>
public class Fragment : MonoBehaviour
{
    public float fallTickTime = 0.15f;
    private float timer;

    void Start()
    {
        timer = fallTickTime;
        GridManager.Instance.RegisterFragment(this);
    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (timer > 0) return;
        timer = fallTickTime;

        int x = Mathf.RoundToInt(transform.position.x);
        int y = Mathf.RoundToInt(transform.position.y);
        int belowY = y - 1;

        bool canFall = (belowY >= 0)
                       && GridManager.Instance.IsWithinBounds(x, belowY)
                       && GridManager.Instance.IsCellEmpty(x, belowY);

        if (canFall)
        {
            transform.position += new Vector3(0, -1, 0);
        }
        else
        {
            Settle();
        }
    }

    void Settle()
    {
        int x = Mathf.RoundToInt(transform.position.x);
        int y = Mathf.RoundToInt(transform.position.y);
        int belowY = y - 1;

        Block myBlock = GetComponent<Block>();

        if (GridManager.Instance.IsWithinBounds(x, belowY) && !GridManager.Instance.IsCellEmpty(x, belowY))
        {
            Transform gridBlockTransform = GridManager.Instance.grid[x, belowY];
            if (gridBlockTransform != null)
            {
                Block gridBlock = gridBlockTransform.GetComponent<Block>();

                if (gridBlock != null && myBlock != null && gridBlock.value == myBlock.value)
                {
                    GridManager.Instance.currentCombo++;
                    int mergedValue = gridBlock.value * 2;
                    int score = mergedValue * (GridManager.Instance.currentCombo * GridManager.Instance.currentCombo);
                    GridManager.Instance.totalScore += score;

                    Debug.Log($"FRAGMENT MERGE! {myBlock.value}+{gridBlock.value}={mergedValue} | +{score} pts");

                    gridBlock.SetValue(mergedValue);

                    // Play merge effect!
                    if (MergeEffects.Instance != null)
                        MergeEffects.Instance.PlayMergeEffect(transform.position, mergedValue, GridManager.Instance.currentCombo);

                    GridManager.Instance.StabilizeColumn(x);
                    GridManager.Instance.UnregisterFragment(this);
                    Destroy(gameObject);
                    return;
                }
            }
        }

        // No merge — lock into grid
        GridManager.Instance.AddBlockToGrid(x, y, transform);

        if (myBlock != null && myBlock.isBinaryBomb)
        {
            GridManager.Instance.TriggerBinaryBomb(x, y);
        }

        GridManager.Instance.StabilizeColumn(x);
        GridManager.Instance.UnregisterFragment(this);
        Destroy(this);
    }
}
