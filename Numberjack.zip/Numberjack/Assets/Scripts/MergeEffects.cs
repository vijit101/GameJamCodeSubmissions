using UnityEngine;

/// <summary>
/// Spawns visual particle bursts at merge positions.
/// Auto-created by GameManager at runtime.
/// </summary>
public class MergeEffects : MonoBehaviour
{
    public static MergeEffects Instance { get; private set; }

    private Sprite particleSprite;

    void Awake()
    {
        Instance = this;

        // Create a tiny white square sprite for particles
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        particleSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);
    }

    /// <summary>
    /// Play a burst of colored particles at a world position.
    /// </summary>
    public void PlayMergeEffect(Vector3 position, int value, int comboCount)
    {
        Color baseColor = GetColorForValue(value);
        int particleCount = 6 + comboCount * 4;

        for (int i = 0; i < particleCount; i++)
        {
            GameObject particle = new GameObject("Particle");
            particle.transform.position = position;
            particle.transform.localScale = new Vector3(0.12f, 0.12f, 1f);

            SpriteRenderer sr = particle.AddComponent<SpriteRenderer>();
            sr.sprite = particleSprite;
            sr.color = baseColor;
            sr.sortingOrder = 100;

            Particle p = particle.AddComponent<Particle>();
            Vector2 dir = Random.insideUnitCircle.normalized;
            float speed = Random.Range(2f, 5f + comboCount);
            p.Init(dir * speed, baseColor, Random.Range(0.3f, 0.6f));
        }

        // Floating score popup
        int score = value * (comboCount * comboCount);
        if (score > 0)
        {
            GameObject scoreObj = new GameObject("FloatingScore");
            scoreObj.transform.position = position + new Vector3(0, 0.5f, 0);
            FloatingScore fs = scoreObj.AddComponent<FloatingScore>();
            fs.Init(score, baseColor);
        }

        // Audio
        if (AudioManager.Instance != null)
        {
            if (comboCount > 1)
                AudioManager.Instance.PlayCombo();
            else
                AudioManager.Instance.PlayMerge();
        }

        // Screen shake scales with combo
        if (ScreenShake.Instance != null && comboCount >= 1)
        {
            float intensity = Mathf.Min(0.05f + comboCount * 0.08f, 0.5f);
            float duration = Mathf.Min(0.1f + comboCount * 0.05f, 0.4f);
            ScreenShake.Instance.Shake(intensity, duration);
        }
    }

    /// <summary>
    /// Play a big explosion effect for row clears.
    /// </summary>
    public void PlayRowClearEffect(int y, int width)
    {
        for (int x = 0; x < width; x++)
        {
            PlayMergeEffect(new Vector3(x, y, 0), 2048, 3);
        }

        if (ScreenShake.Instance != null)
            ScreenShake.Instance.Shake(0.4f, 0.3f);

        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayRowClear();
    }

    private Color GetColorForValue(int value)
    {
        switch (value)
        {
            case 2:    return new Color(0.93f, 0.89f, 0.85f);
            case 4:    return new Color(0.93f, 0.88f, 0.78f);
            case 8:    return new Color(0.95f, 0.69f, 0.47f);
            case 16:   return new Color(0.96f, 0.58f, 0.39f);
            case 32:   return new Color(0.96f, 0.49f, 0.37f);
            case 64:   return new Color(0.96f, 0.37f, 0.23f);
            case 128:  return new Color(0.93f, 0.81f, 0.45f);
            case 256:  return new Color(0.93f, 0.80f, 0.38f);
            case 512:  return new Color(0.93f, 0.78f, 0.31f);
            case 1024: return new Color(0.93f, 0.77f, 0.25f);
            case 2048: return new Color(0.93f, 0.75f, 0.18f);
            default:   return new Color(1f, 0.85f, 0.3f);
        }
    }
}

/// <summary>
/// Simple flying sprite particle that fades and destroys itself.
/// </summary>
public class Particle : MonoBehaviour
{
    private Vector2 velocity;
    private float lifetime;
    private float elapsed;
    private SpriteRenderer sr;
    private Color startColor;

    public void Init(Vector2 vel, Color color, float life)
    {
        velocity = vel;
        lifetime = life;
        startColor = color;
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        elapsed += Time.deltaTime;
        transform.position += (Vector3)velocity * Time.deltaTime;
        velocity *= 0.92f; // Drag

        // Scale down and fade out
        float t = elapsed / lifetime;
        float alpha = 1f - t;
        float scale = Mathf.Lerp(0.12f, 0.02f, t);
        transform.localScale = new Vector3(scale, scale, 1f);

        if (sr != null)
            sr.color = new Color(startColor.r, startColor.g, startColor.b, alpha);

        if (elapsed >= lifetime)
            Destroy(gameObject);
    }
}
