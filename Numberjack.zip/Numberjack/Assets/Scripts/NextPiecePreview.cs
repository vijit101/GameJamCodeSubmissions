using UnityEngine;
using TMPro;
using System.Collections.Generic;

/// <summary>
/// Displays the next piece preview as actual sprites in the game world,
/// positioned to the right of the board.
/// Auto-created by GameManager.
/// </summary>
public class NextPiecePreview : MonoBehaviour
{
    public static NextPiecePreview Instance { get; private set; }

    private List<GameObject> previewBlocks = new List<GameObject>();
    private TextMeshPro labelText;
    private Sprite blockSprite;

    // Position: to the right of the 10-wide board (board goes 0–9)
    private Vector3 previewOrigin = new Vector3(12f, 17f, 0f);

    void Awake()
    {
        Instance = this;

        // Create sprite
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        blockSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);

        // Create "NEXT" label
        GameObject labelObj = new GameObject("NextLabel");
        labelObj.transform.SetParent(transform);
        labelObj.transform.position = previewOrigin + new Vector3(1f, 2.5f, 0); // Moved up and centered a bit more

        labelText = labelObj.AddComponent<TextMeshPro>();
        labelText.text = "NEXT";
        labelText.fontSize = 7f; // Bigger text
        labelText.alignment = TextAlignmentOptions.Center;
        labelText.color = new Color(0.6f, 0.6f, 0.6f);
        labelText.sortingOrder = 5;

        RectTransform rt = labelObj.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(3f, 1f);
    }

    public void UpdatePreview(Vector2Int[] shapeOffsets, int[] values)
    {
        // Clear old blocks
        foreach (GameObject block in previewBlocks)
        {
            if (block != null) Destroy(block);
        }
        previewBlocks.Clear();

        if (shapeOffsets == null || values == null) return;

        // Create new preview blocks
        for (int i = 0; i < shapeOffsets.Length; i++)
        {
            GameObject blockObj = new GameObject("PreviewBlock");
            blockObj.transform.SetParent(transform);
            blockObj.transform.position = previewOrigin + new Vector3(shapeOffsets[i].x * 1f, shapeOffsets[i].y * 1f, 0);
            blockObj.transform.localScale = new Vector3(0.9f, 0.9f, 1f); // 50% bigger

            SpriteRenderer sr = blockObj.AddComponent<SpriteRenderer>();
            sr.sprite = blockSprite;
            sr.sortingOrder = 5;
            sr.color = GetColorForValue(values[i]);

            // Add value text
            GameObject textObj = new GameObject("Text");
            textObj.transform.SetParent(blockObj.transform, false);
            textObj.transform.localPosition = new Vector3(0, 0, -1f);

            TextMeshPro tmp = textObj.AddComponent<TextMeshPro>();
            tmp.text = values[i].ToString();
            tmp.fontSize = 5f;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.sortingOrder = 6;
            tmp.color = values[i] >= 64 ? Color.white : Color.black;

            RectTransform trt = textObj.GetComponent<RectTransform>();
            trt.sizeDelta = new Vector2(1f, 1f);

            previewBlocks.Add(blockObj);
        }
    }

    private Color GetColorForValue(int value)
    {
        switch (value)
        {
            case 2:    return new Color(0.93f, 0.89f, 0.85f);
            case 4:    return new Color(0.93f, 0.88f, 0.78f);
            case 8:    return new Color(0.95f, 0.69f, 0.47f);
            case 16:   return new Color(0.96f, 0.58f, 0.39f);
            case 32:   return new Color(0.96f, 0.49f, 0.37f);
            case 64:   return new Color(0.96f, 0.37f, 0.23f);
            case 128:  return new Color(0.93f, 0.81f, 0.45f);
            default:   return new Color(0.24f, 0.23f, 0.20f);
        }
    }
}
