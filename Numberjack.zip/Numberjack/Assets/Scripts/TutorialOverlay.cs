using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Displays a tutorial screen before the game starts.
/// Halts game logic until dismissed.
/// </summary>
public class TutorialOverlay : MonoBehaviour
{
    private bool isVisible = true;
    private Texture2D bgTexture;
    
    // Styles
    private GUIStyle titleStyle;
    private GUIStyle bodyStyle;
    private GUIStyle keyStyle;
    private GUIStyle buttonStyle;

    void Awake()
    {
        bgTexture = new Texture2D(1, 1);
        bgTexture.SetPixel(0, 0, new Color(0.1f, 0.1f, 0.15f, 0.95f));
        bgTexture.Apply();
    }

    void Start()
    {
        // Pause game (prevent falling)
        Time.timeScale = 0f;
    }

    void OnGUI()
    {
        if (!isVisible) return;

        // Ensure styles are initialized
        if (titleStyle == null) InitStyles();

        // Draw overlay
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), bgTexture);

        float panelWidth = 760;
        float panelHeight = 580;
        float cx = Screen.width / 2f;
        float cy = Screen.height / 2f;

        Rect panelRect = new Rect(cx - panelWidth / 2f, cy - panelHeight / 2f, panelWidth, panelHeight);
        
        // Draw decorative border
        GUI.color = new Color(0.96f, 0.37f, 0.23f, 1f); // Accent red
        GUI.DrawTexture(new Rect(panelRect.x - 4, panelRect.y - 4, panelRect.width + 8, panelRect.height + 8), Texture2D.whiteTexture);
        GUI.color = Color.white;
        GUI.DrawTexture(panelRect, bgTexture);

        // Content
        float startY = panelRect.y + 30;
        
        GUI.Label(new Rect(cx - 200, startY, 400, 50), "HOW TO PLAY", titleStyle);
        startY += 70;

        string controlsText = 
            "<b><color=#f9633e>← →</color></b>  Move Left/Right\n\n" +
            "<b><color=#f9633e>  ↑  </color></b>  Rotate Piece\n\n" +
            "<b><color=#f9633e>  ↓  </color></b>  Soft Drop\n\n" +
            "<b><color=#f9633e>SPACE</color></b>  Hard Drop\n\n" +
            "<b><color=#f9633e>  R  </color></b>  Restart Game";

        string rulesText = 
            "<b>1.</b> Stack blocks. Identical numbers merge and double!\n\n" +
            "<b>2.</b> Unmatched blocks will break off and fall (Fragmentation).\n\n" +
            "<b>3.</b> Merging triggers Cascades for massive combo points.\n\n" +
            "<b>4.</b> Form a full row of identical numbers to clear it.\n\n" +
            "<b>5.</b> Watch out for <color=#bb22ff>Binary Bombs</color> to blow up blocks!";

        // Split panel into two columns
        GUI.Label(new Rect(panelRect.x + 40, startY, 300, 360), controlsText, keyStyle);
        GUI.Label(new Rect(panelRect.x + 360, startY, 360, 360), rulesText, bodyStyle);

        startY += 260;

        // Skip / Play button
        if (GUI.Button(new Rect(cx - 120, panelRect.y + panelHeight - 100, 240, 60), "PLAY NOW", buttonStyle))
        {
            Dismiss();
        }

        // Also dismiss on Escape or Space or Enter
        if (Keyboard.current != null && 
           (Keyboard.current.spaceKey.wasPressedThisFrame || Keyboard.current.enterKey.wasPressedThisFrame || Keyboard.current.escapeKey.wasPressedThisFrame))
        {
            Dismiss();
        }
    }

    void Dismiss()
    {
        isVisible = false;
        Time.timeScale = 1f; // Resume game
        Destroy(gameObject);
    }

    void InitStyles()
    {
        titleStyle = new GUIStyle();
        titleStyle.fontSize = 54;
        titleStyle.fontStyle = FontStyle.Bold;
        titleStyle.normal.textColor = Color.white;
        titleStyle.alignment = TextAnchor.MiddleCenter;

        keyStyle = new GUIStyle();
        keyStyle.fontSize = 26;
        keyStyle.richText = true;
        keyStyle.normal.textColor = new Color(0.9f, 0.9f, 0.9f);

        bodyStyle = new GUIStyle();
        bodyStyle.fontSize = 22;
        bodyStyle.richText = true;
        bodyStyle.normal.textColor = new Color(0.85f, 0.85f, 0.85f);
        bodyStyle.wordWrap = true;

        buttonStyle = new GUIStyle(GUI.skin.button);
        buttonStyle.fontSize = 32;
        buttonStyle.fontStyle = FontStyle.Bold;
        buttonStyle.normal.textColor = Color.white;
        // Basic styling for the button to make it look decent in OnGUI
    }

    void OnDestroy()
    {
        Time.timeScale = 1f; // Ensure timescale is restored if destroyed early
    }
}
