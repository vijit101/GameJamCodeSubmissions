using UnityEngine;

/// <summary>
/// Procedurally generates all game sound effects using AudioClip.Create().
/// No audio files needed — pure waveform synthesis.
/// Auto-created by GameManager at runtime.
/// </summary>
public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    private AudioSource audioSource;

    // Pre-generated clips
    private AudioClip mergeClip;
    private AudioClip comboClip;
    private AudioClip dropClip;
    private AudioClip gameOverClip;
    private AudioClip rowClearClip;
    private AudioClip bombClip;
    private AudioClip moveClip;

    private int sampleRate = 44100;

    void Awake()
    {
        Instance = this;
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
        audioSource.volume = 0.35f;

        // Generate all sounds at startup
        mergeClip = GenerateTone(440f, 660f, 0.12f, WaveType.Sine);       // Quick ascending pop
        comboClip = GenerateTone(600f, 1200f, 0.18f, WaveType.Sine);     // Higher ascending sweep
        dropClip = GenerateTone(200f, 120f, 0.08f, WaveType.Square);     // Low thud
        gameOverClip = GenerateGameOverSound();                            // Sad descending
        rowClearClip = GenerateTone(523f, 1047f, 0.3f, WaveType.Sine);   // Triumphant sweep
        bombClip = GenerateExplosionSound();                               // Noise burst
        moveClip = GenerateTone(300f, 320f, 0.04f, WaveType.Square);     // Subtle click
    }

    // ==================== PUBLIC API ====================

    public void PlayMerge()   { PlayOneShot(mergeClip); }
    public void PlayCombo()   { PlayOneShot(comboClip, 0.4f); }
    public void PlayDrop()    { PlayOneShot(dropClip, 0.25f); }
    public void PlayGameOver(){ PlayOneShot(gameOverClip, 0.5f); }
    public void PlayRowClear(){ PlayOneShot(rowClearClip, 0.45f); }
    public void PlayBomb()    { PlayOneShot(bombClip, 0.4f); }
    public void PlayMove()    { PlayOneShot(moveClip, 0.15f); }

    private void PlayOneShot(AudioClip clip, float volume = 0.35f)
    {
        if (clip != null)
            audioSource.PlayOneShot(clip, volume);
    }

    // ==================== SOUND GENERATION ====================

    private enum WaveType { Sine, Square, Noise }

    private AudioClip GenerateTone(float startFreq, float endFreq, float duration, WaveType type)
    {
        int sampleCount = (int)(sampleRate * duration);
        float[] samples = new float[sampleCount];

        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleCount;
            float freq = Mathf.Lerp(startFreq, endFreq, t);
            float phase = 2f * Mathf.PI * freq * i / sampleRate;

            // Envelope: quick attack, smooth decay
            float envelope = (1f - t) * Mathf.Clamp01(t * 20f);

            switch (type)
            {
                case WaveType.Sine:
                    samples[i] = Mathf.Sin(phase) * envelope;
                    break;
                case WaveType.Square:
                    samples[i] = (Mathf.Sin(phase) > 0 ? 0.5f : -0.5f) * envelope;
                    break;
                case WaveType.Noise:
                    samples[i] = Random.Range(-1f, 1f) * envelope;
                    break;
            }
        }

        AudioClip clip = AudioClip.Create("tone", sampleCount, 1, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    private AudioClip GenerateGameOverSound()
    {
        float duration = 0.8f;
        int sampleCount = (int)(sampleRate * duration);
        float[] samples = new float[sampleCount];

        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleCount;

            // Three descending notes overlaid
            float freq1 = Mathf.Lerp(440f, 220f, t);
            float freq2 = Mathf.Lerp(330f, 165f, t);

            float phase1 = 2f * Mathf.PI * freq1 * i / sampleRate;
            float phase2 = 2f * Mathf.PI * freq2 * i / sampleRate;

            float envelope = (1f - t * t); // Slow fade

            samples[i] = (Mathf.Sin(phase1) * 0.5f + Mathf.Sin(phase2) * 0.3f) * envelope;
        }

        AudioClip clip = AudioClip.Create("gameOver", sampleCount, 1, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    private AudioClip GenerateExplosionSound()
    {
        float duration = 0.25f;
        int sampleCount = (int)(sampleRate * duration);
        float[] samples = new float[sampleCount];

        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleCount;
            float envelope = Mathf.Pow(1f - t, 3f); // Sharp decay

            // Noise + low rumble
            float noise = Random.Range(-1f, 1f);
            float rumble = Mathf.Sin(2f * Mathf.PI * 80f * i / sampleRate);

            samples[i] = (noise * 0.6f + rumble * 0.4f) * envelope;
        }

        AudioClip clip = AudioClip.Create("explosion", sampleCount, 1, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }
}
