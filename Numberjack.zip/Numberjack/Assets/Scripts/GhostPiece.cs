using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Shows a ghost preview of where the current Tetromino will land.
/// Automatically attached to the Tetromino by GameManager.
/// </summary>
public class GhostPiece : MonoBehaviour
{
    private GameObject ghostContainer;
    private SpriteRenderer[] ghostRenderers;
    private Tetromino tetromino;
    private List<Transform> blockChildren = new List<Transform>(); // Cache only Block children

    private Sprite ghostSprite;

    void Start()
    {
        tetromino = GetComponent<Tetromino>();

        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        ghostSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);

        // Only grab DIRECT children that have a Block component (ignore text children etc.)
        foreach (Transform child in transform)
        {
            if (child.GetComponent<Block>() != null)
            {
                blockChildren.Add(child);
            }
        }

        if (blockChildren.Count == 0) return;

        // Create ghost container
        ghostContainer = new GameObject("GhostPiece");
        ghostContainer.transform.position = Vector3.zero;

        ghostRenderers = new SpriteRenderer[blockChildren.Count];

        for (int i = 0; i < blockChildren.Count; i++)
        {
            GameObject ghostBlock = new GameObject("GhostBlock");
            ghostBlock.transform.SetParent(ghostContainer.transform);
            ghostBlock.transform.localScale = new Vector3(0.92f, 0.92f, 1f);

            SpriteRenderer sr = ghostBlock.AddComponent<SpriteRenderer>();
            sr.sprite = ghostSprite;
            sr.color = new Color(1f, 1f, 1f, 0.25f); // Semi-transparent white
            sr.sortingOrder = 2; // In front of background, behind real blocks

            ghostRenderers[i] = sr;
        }
    }

    void Update()
    {
        if (tetromino == null || !tetromino.enabled)
        {
            if (ghostContainer != null) Destroy(ghostContainer);
            Destroy(this);
            return;
        }

        UpdateGhostPosition();
    }

    void UpdateGhostPosition()
    {
        if (ghostContainer == null || blockChildren.Count == 0) return;

        // Start from the current position and simulate dropping
        Vector3 dropPos = transform.position;

        while (true)
        {
            dropPos += new Vector3(0, -1, 0);
            if (!IsValidAt(dropPos))
            {
                dropPos -= new Vector3(0, -1, 0);
                break;
            }
        }

        // Position ghost blocks using only Block children
        for (int i = 0; i < blockChildren.Count; i++)
        {
            if (i >= ghostRenderers.Length) break;
            if (blockChildren[i] == null) continue;

            // No rotation math needed — blocks are already repositioned
            Vector3 offset = blockChildren[i].localPosition;
            ghostRenderers[i].transform.position = dropPos + offset;
        }
    }

    bool IsValidAt(Vector3 testPosition)
    {
        foreach (Transform child in blockChildren)
        {
            if (child == null) continue;

            Vector3 offset = child.localPosition;
            Vector3 worldPos = testPosition + offset;

            int x = Mathf.RoundToInt(worldPos.x);
            int y = Mathf.RoundToInt(worldPos.y);

            if (!GridManager.Instance.IsWithinBounds(x, y)) return false;
            if (!GridManager.Instance.IsCellEmpty(x, y)) return false;
        }
        return true;
    }

    void OnDestroy()
    {
        if (ghostContainer != null) Destroy(ghostContainer);
    }
}
